package pl.zenstage.db.store.converter;

import com.fasterxml.jackson.core.type.TypeReference;
import jakarta.persistence.Converter;

import java.util.List;
import java.util.Set;

@Converter(autoApply = true)
public class StringSetConverter extends JacksonConverter<Set<String>> {
    @Override
    protected TypeReference<Set<String>> getType() {
        return new TypeReference<>() {
        };
    }
}
