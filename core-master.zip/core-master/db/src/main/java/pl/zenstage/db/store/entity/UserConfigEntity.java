package pl.zenstage.db.store.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.LastModifiedDate;

import java.time.LocalDateTime;
import java.util.Map;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "user_config")
@Entity
public class UserConfigEntity {
    @Id
    private String userId;
    @Column(columnDefinition = "TEXT")
    private Map<String, Object> config;
    @Column(name = "modified_date")
    @LastModifiedDate
    private LocalDateTime modifiedDate;

    public UserConfigEntity(
            String userId,
            Map<String, Object> config
    ) {
        this(userId, config, LocalDateTime.now());
    }
}
