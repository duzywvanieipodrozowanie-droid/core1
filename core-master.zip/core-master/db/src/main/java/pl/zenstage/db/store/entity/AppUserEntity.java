package pl.zenstage.db.store.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Application user with the roles granted in Settings → Users and access: everyone from {@code person} and everyone
 * who logged in. MANAGER also comes from the unit managers in the organization.
 */
@Data
@Entity
@Table(name = "app_user")
@NoArgsConstructor
@AllArgsConstructor
public class AppUserEntity {
    private static final String FLAG = "boolean not null default false";

    @Id
    private String id;
    private String name;
    private String email;
    private boolean admin;
    private boolean developer;
    // with a default: ddl-auto update adds the columns to a table with users
    @Column(name = "tech_lead", columnDefinition = FLAG)
    private boolean techLead;
    @Column(columnDefinition = FLAG)
    private boolean manager;
    @Column(columnDefinition = FLAG)
    private boolean po;
    @Column(name = "domain_leader", columnDefinition = FLAG)
    private boolean domainLeader;
    private LocalDateTime created;
    @Column(name = "last_login")
    private LocalDateTime lastLogin;

    /** A new user: a developer, an admin when they were one before. */
    public AppUserEntity(String id, String name, String email, boolean admin, LocalDateTime created) {
        this(id, name, email, admin, true, false, false, false, false, created, null);
    }
}
