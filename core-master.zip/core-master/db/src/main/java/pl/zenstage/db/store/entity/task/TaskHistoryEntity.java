package pl.zenstage.db.store.entity.task;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import pl.zenstage.api.task.History;

import java.time.LocalDateTime;


@Data
@Entity
@Table(name = "task_history", indexes = {
        @Index(name = "idx_task_history_author_created", columnList = "author_id, created"),
        @Index(name = "idx_task_history_task_fk", columnList = "task_project_id, task_key"),
        @Index(name = "idx_task_history_author", columnList = "author_id")})
@NoArgsConstructor
@AllArgsConstructor
public class TaskHistoryEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id private Long id;

    @JsonBackReference
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumns({
            @JoinColumn(name = "task_project_id", referencedColumnName = "projectId"),
            @JoinColumn(name = "task_key", referencedColumnName = "key")
    })
    private TaskEntity task;

    private String fieldType;
    @Column(name = "from_value")
    private String from;
    @Column(name = "to_value")
    private String to;
    private LocalDateTime created;
    @Column(name = "author_id")
    private String authorId;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(columnDefinition = "jsonb")
    private History content;
}
