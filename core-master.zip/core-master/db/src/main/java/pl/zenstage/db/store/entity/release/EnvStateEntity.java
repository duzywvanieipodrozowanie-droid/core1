package pl.zenstage.db.store.entity.release;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@IdClass(EnvStateEntity.Pk.class)
@Table(name = "environemt_state")
@NoArgsConstructor
@AllArgsConstructor
public class EnvStateEntity {
    @Id
    private String projectId;
    @Id
    private String environment;
    @Id
    private String module;
    private String image;
    private String version;

    public record Pk(
            @Id String projectId,
            @Id String environment,
            @Id String module
    ) {
    }
}
