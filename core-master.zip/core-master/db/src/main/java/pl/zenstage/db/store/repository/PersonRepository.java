package pl.zenstage.db.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import pl.zenstage.db.store.entity.PersonEntity;

import java.util.List;

public interface PersonRepository extends JpaRepository<PersonEntity, String> {
    @Query("SELECT p.id FROM PersonEntity p WHERE p.admin = true")
    List<String> adminUsers();
}
