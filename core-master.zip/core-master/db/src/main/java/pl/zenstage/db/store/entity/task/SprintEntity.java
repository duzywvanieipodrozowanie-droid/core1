package pl.zenstage.db.store.entity.task;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Index;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import pl.zenstage.api.task.Sprint;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


@Data
@Entity
@IdClass(SprintEntity.Pk.class)
@Table(name = "sprint", indexes = {
        @Index(name = "idx_sprint_id", columnList = "projectId, name"),
        @Index(name = "idx_sprint_projectId_state", columnList = "project_id, state"),
        @Index(name = "idx_sprint_proj_start_desc", columnList = "project_id, startDate DESC"),
        @Index(name = "idx_sprint_proj_state_start_desc", columnList = "project_id, state, startDate DESC")
})
@NoArgsConstructor
@AllArgsConstructor
public class SprintEntity {

    @Column(name = "project_id", nullable = false)
    @Id private String projectId;
    @Column(name = "name", nullable = false)
    @Id private String name;
    private String state;
    @Column(columnDefinition = "TEXT")
    private String goal;
    private LocalDateTime startDate;
    private LocalDateTime endDate;

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @JsonBackReference
    @ManyToMany(mappedBy = "sprints", fetch = FetchType.LAZY)
    private List<TaskEntity> tasks = new ArrayList<>();

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(columnDefinition = "jsonb")
    private Sprint content;

    public record Pk(
            @Id String projectId,
            @Id String name
    ) implements Serializable {
    }
}
