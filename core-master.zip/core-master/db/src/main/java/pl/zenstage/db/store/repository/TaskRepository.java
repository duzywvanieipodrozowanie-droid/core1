package pl.zenstage.db.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import pl.zenstage.api.task.Task;
import pl.zenstage.api.task.TaskStatus;
import pl.zenstage.db.store.entity.task.SprintEntity;
import pl.zenstage.db.store.entity.task.TaskEntity;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

public interface TaskRepository extends JpaRepository<TaskEntity, TaskEntity.Pk> {

    /**
     * Wyszukuje najświeższe zadanie (ostatnio zmodyfikowane lub utworzone) w ramach wskazanego projektu.
     * <p>
     * Wykorzystuje natywne zapytanie SQL bazy PostgreSQL z funkcjami {@code GREATEST} oraz {@code COALESCE},
     * co pozwala na precyzyjne porównanie daty utworzenia i aktualizacji z obsługą wartości {@code NULL}
     * (poprzez zastąpienie ich wartością {@code -infinity}). Zapytanie zwraca maksymalnie jeden rekord.
     *
     * @param projectId identyfikator projektu
     * @return najnowsza encja {@link TaskEntity} lub {@code null}, jeśli projekt nie zawiera zadań
     */
    @Query(value = """
             SELECT * FROM task WHERE project_Id = :projectId ORDER BY GREATEST(
                            COALESCE(created, '-infinity'::timestamptz),
                            COALESCE(updated, '-infinity'::timestamptz)) DESC LIMIT 1
            """, nativeQuery = true)
    TaskEntity findLatest(@Param("projectId") String projectId);

    /**
     * Pobiera wszystkie zadania należące do wskazanego projektu.
     *
     * @param projectId identyfikator projektu
     * @return lista zadań przypisanych do danego projektu
     */
    List<TaskEntity> findByProjectId(String projectId);

    /**
     * Tasks with a Jira Fix Version starting with {@code prefix} (lower case, a LIKE pattern), e.g. the issues and
     * release tasks of one microservice ("orders-service 1.4.2").
     */
    @Query(value = """
            SELECT * FROM task t WHERE EXISTS (
                SELECT 1 FROM jsonb_array_elements_text(CASE WHEN jsonb_typeof(t.content -> 'fixVersions') = 'array'
                        THEN t.content -> 'fixVersions' ELSE '[]'::jsonb END) fv
                WHERE lower(fv) LIKE :prefix ESCAPE '\\')
            """, nativeQuery = true)
    List<TaskEntity> findByFixVersionLike(@Param("prefix") String prefix);

    /**
     * Zadania o danym kluczu Jira we wszystkich projektach (klucz jest zwykle unikalny, ale PK to projekt + klucz).
     */
    List<TaskEntity> findByKey(String key);

    /**
     * Wyszukuje zadania dla wskazanych projektów z określonym statusem i w podanym przedziale czasowym,
     * z opcjonalnym filtrowaniem po fladze BAU (Business As Usual).
     * <p>
     * Klauzula {@code (:bau IS NULL OR t.bau = :bau)} umożliwia warunkowe pominięcie
     * filtrowania flagi BAU, jeśli do metody zostanie przekazana wartość {@code null}.
     *
     * @param projectsId kolekcja identyfikatorów projektów do przeszukania
     * @param bau flaga określająca charakter zadania (true/false) lub {@code null}, aby uwzględnić wszystkie zadania
     * @param status oczekiwany status zadania (np. DONE, IN_PROGRESS)
     * @param startDate początek przedziału daty modyfikacji (updated)
     * @param endDate koniec przedziału daty modyfikacji (updated)
     * @return lista przefiltrowanych zadań
     */
    @Query("""
                SELECT t FROM TaskEntity t 
                WHERE t.projectId IN :projectsId 
                  AND (:bau IS NULL OR t.bau = :bau) 
                  AND t.status = :status 
                  AND t.updated BETWEEN :startDate AND :endDate
            """)
    List<TaskEntity> findTasksWithOptionalBau(
            @Param("projectsId") Collection<String> projectsId,
            @Param("bau") Boolean bau,
            @Param("status") TaskStatus status,
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate
    );

    /**
     * Pobiera zadania z określonej grupy projektów, które posiadają wskazany status.
     *
     * @param projectsId kolekcja identyfikatorów projektów
     * @param status poszukiwany status zadań
     * @return lista zadań pasujących do kryteriów
     */
    List<TaskEntity> findByProjectIdInAndStatus(Collection<String> projectsId, TaskStatus status);

    /**
     * Zadania z podanych projektów zmienione od wskazanej chwili (np. do metryk przepływu: przejścia statusów
     * w okresie mają datę nie wcześniejszą niż ostatnia aktualizacja zadania).
     */
    List<TaskEntity> findByProjectIdInAndUpdatedAfter(Collection<String> projectsId, LocalDateTime updated);

    /**
     * Zadania danego typu (np. "Epic", bez rozróżniania wielkości liter) z podanych projektów.
     */
    List<TaskEntity> findByProjectIdInAndTypeIgnoreCase(Collection<String> projectsId, String type);

    /**
     * Zadania z podanych projektów, których aktualny status jest jednym z podanych (np. praca w toku).
     */
    List<TaskEntity> findByProjectIdInAndStatusIn(Collection<String> projectsId, Collection<TaskStatus> statuses);

    /**
     * Wyszukuje zadania potomne (subtaski) na podstawie kolekcji kluczy zadań nadrzędnych.
     *
     * @param parentKeys kolekcja kluczy zadań nadrzędnych (parentKey)
     * @return lista powiązanych zadań potomnych
     */
    @Query("SELECT t FROM TaskEntity t WHERE t.parentKey IN :parentKeys")
    List<TaskEntity> findByParentKeyIn(@Param("parentKeys") Collection<String> parentKeys);

    /**
     * Pobiera wszystkie zadania, które wymagają uzupełnienia danych powiązanych osób —
     * czyli takie, w których brakuje identyfikatora wykonawcy (assigneeId IS NULL)
     * lub autora (creatorId IS NULL).
     * <p>
     * Używane głównie przez procesy asynchronicznej synchronizacji i uzupełniania danych użytkowników.
     *
     * @return lista zadań z brakującym przypisaniem do użytkownika
     */
    List<TaskEntity> findByAssigneeIdIsNullOrCreatorIdIsNull();

    /**
     * Wyszukuje unikalne zadania przypisane do podanej listy sprintów, które mają już
     * wyznaczonego wykonawcę (assigneeId IS NOT NULL).
     * <p>
     * Klauzula {@code DISTINCT} zapobiega powielaniu encji zadania w wyniku, jeśli
     * byłoby ono powiązane z więcej niż jednym sprintem z przekazanej listy.
     *
     * @param sprints lista encji sprintów {@link SprintEntity}, z których zadania mają zostać pobrane
     * @return lista unikalnych, przypisanych do użytkowników zadań w tych sprintach
     */
    @Query("""
        SELECT DISTINCT t FROM TaskEntity t
        JOIN t.sprints s
        WHERE s IN :sprints AND t.assigneeId IS NOT NULL
    """)
    List<TaskEntity> findTasksInSprints(@Param("sprints") List<SprintEntity> sprints);

    /**
     * Pobiera zawartość obiektów JSON (pole {@code content}) jedynie dla tych zadań,
     * które nie mają jeszcze skojarzonego identyfikatora wykonawcy (assigneeId IS NULL)
     * lub autora (creatorId IS NULL).
     * <p>
     * Selektywne pobieranie samego obiektu biznesowego eliminuje narzut związany
     * z ładowaniem powiązanych encji oraz leniwych relacji (np. historii czy sprintów),
     * co optymalizuje zużycie pamięci i przyspiesza ekstrakcję brakujących identyfikatorów kont.
     *
     * @return lista obiektów {@link Task} z nieprzypisanymi użytkownikami
     */
    @Query("SELECT t.content FROM TaskEntity t WHERE t.assigneeId IS NULL OR t.creatorId IS NULL")
    List<Task> findContentsWithUnassignedUsers();
}
