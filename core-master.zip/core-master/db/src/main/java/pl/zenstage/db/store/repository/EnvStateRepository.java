package pl.zenstage.db.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.zenstage.db.store.entity.release.EnvStateEntity;

import java.util.List;

public interface EnvStateRepository extends JpaRepository<EnvStateEntity, EnvStateEntity.Pk> {
    List<EnvStateEntity> findAllByProjectId(String projectId);
}
