package pl.zenstage.db.store.converter;

import com.fasterxml.jackson.core.type.TypeReference;
import jakarta.persistence.Converter;
import pl.zenstage.api.commit.Commit;

@Converter(autoApply = true)
public class CommitConverter extends JacksonConverter<Commit> {
    @Override
    protected TypeReference<Commit> getType() {
        return new TypeReference<>() {
        };
    }
}
