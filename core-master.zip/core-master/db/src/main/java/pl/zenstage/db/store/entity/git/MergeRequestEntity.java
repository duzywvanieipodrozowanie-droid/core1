package pl.zenstage.db.store.entity.git;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import pl.zenstage.api.mr.MergeRequest;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

@Data
@Entity
@IdClass(MergeRequestEntity.Pk.class)
@Table(name = "merge_request", indexes = {
        @Index(name = "idx_merge_request_project_id_create_date", columnList = "project_id, create_date"),
        @Index(name = "idx_merge_request_author_id_create_date", columnList = "author_id, create_date"),
        @Index(name = "idx_merge_request_project_id_module_name_commit_id", columnList = "project_id, module_name, commit_id"),
})
@NoArgsConstructor
@AllArgsConstructor
public class MergeRequestEntity {
    @Id private String projectId;
    @Id private String moduleName;
    @Id private String mrId;
    private String commitId;
    private String authorId;
    private LocalDateTime createDate;
    private BigDecimal pickupTimeMinutes;
    private BigDecimal reviewTimeMinutes;
    @Column(columnDefinition = "TEXT")
    private MergeRequest source;

    public record Pk(
            @Id String projectId,
            @Id String moduleName,
            @Id String mrId
    ) {
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        MergeRequestEntity that = (MergeRequestEntity) o;
        return Objects.equals(projectId, that.projectId) && Objects.equals(moduleName, that.moduleName) && Objects.equals(mrId, that.mrId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(projectId, moduleName, mrId);
    }
}
