package pl.zenstage.db.store.entity.release;

import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import pl.zenstage.db.store.converter.StringListConverter;

import java.util.List;

@Data
@Entity
@Table(name = "project")
@NoArgsConstructor
@AllArgsConstructor
public class ProjectEntity {
    @Id
    private String name;
    private String label;
    private String taskRegex;
    @Convert(converter = StringListConverter.class)
    private List<String> environments;
    @Convert(converter = StringListConverter.class)
    private List<String> priorityModules;
}
