package pl.zenstage.db.store.repository.model;

import pl.zenstage.api.task.History;

public interface TaskHistoryUpdateProjection {
    Long getId();
    History getContent();
}
