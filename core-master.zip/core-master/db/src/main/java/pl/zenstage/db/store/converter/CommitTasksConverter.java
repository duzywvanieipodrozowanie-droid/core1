package pl.zenstage.db.store.converter;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;
import pl.zenstage.api.commit.CommitTasks;

import java.util.Arrays;
import java.util.Optional;
import java.util.TreeSet;


@Converter(autoApply = true)
public class CommitTasksConverter implements AttributeConverter<CommitTasks, String> {

    public static final String SEPARATOR = ",";

    @Override
    public String convertToDatabaseColumn(CommitTasks attribute) {
        return Optional.ofNullable(attribute).map(CommitTasks::tasks)
                .map(it -> String.join(SEPARATOR, it)).orElse(null);
    }

    @Override
    public CommitTasks convertToEntityAttribute(String dbData) {
        return Optional.ofNullable(dbData).map(String::trim).map(it -> it.split(","))
                .filter(it -> it.length > 0).map(Arrays::asList).map(TreeSet::new)
                .map(CommitTasks::new).orElseGet(CommitTasks::new);
    }
}
