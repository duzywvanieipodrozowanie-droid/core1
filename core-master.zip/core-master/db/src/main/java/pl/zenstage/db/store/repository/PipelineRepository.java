package pl.zenstage.db.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import pl.zenstage.db.store.entity.git.PipelineEntity;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

public interface PipelineRepository extends JpaRepository<PipelineEntity, PipelineEntity.Pk> {
    List<PipelineEntity> findAllByProjectIdAndModuleNameAndCommitId(String projectId, String moduleName, String commitId);
    List<PipelineEntity> findByProjectIdInAndCreateDateBetween(Collection<String> projectsId, LocalDateTime startDate, LocalDateTime endDate);

    @Query("SELECT pp.updateDate FROM PipelineEntity pp WHERE pp.projectId = ?1 AND pp.status='success' ORDER BY pp.updateDate DESC LIMIT 1")
    LocalDateTime findLatestDate(@Param("project") String project);

}
