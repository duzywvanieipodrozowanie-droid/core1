package pl.zenstage.db.store.converter;

import com.fasterxml.jackson.core.type.TypeReference;
import jakarta.persistence.Converter;

import java.util.Map;

@Converter(autoApply = true)
public class MapConverter extends JacksonConverter<Map<String, Object>> {
    @Override
    protected TypeReference<Map<String, Object>> getType() {
        return new TypeReference<>() {
        };
    }
}
