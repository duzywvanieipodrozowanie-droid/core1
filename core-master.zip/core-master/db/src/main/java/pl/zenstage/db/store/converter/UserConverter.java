package pl.zenstage.db.store.converter;

import com.fasterxml.jackson.core.type.TypeReference;
import jakarta.persistence.Converter;
import pl.zenstage.api.task.User;

@Converter(autoApply = true)
public class UserConverter extends JacksonConverter<User> {
    @Override
    protected TypeReference<User> getType() {
        return new TypeReference<>() {
        };
    }

}
