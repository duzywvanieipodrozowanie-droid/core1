package pl.zenstage.db.store.entity.git;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import pl.zenstage.api.mr.MergeRequest;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.Objects;

@Data
@Entity
@IdClass(PipelineEntity.Pk.class)
@Table(name = "pipeline", indexes = {
        @Index(name = "idx_pipeline_project_id_create_date", columnList = "project_id, create_date"),
        @Index(name = "idx_pipeline_project_id_module_name_commit_id", columnList = "project_id, module_name, commit_id"),
})
@NoArgsConstructor
@AllArgsConstructor
public class PipelineEntity {
    @Id private String projectId;
    @Id private String moduleName;
    @Id private String id;
    private String commitId;
    private String ref;
    private String status;
    private String source;
    private LocalDateTime createDate;
    private LocalDateTime updateDate;

    public record Pk(
            @Id String projectId,
            @Id String moduleName,
            @Id String id
    ) {
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        PipelineEntity that = (PipelineEntity) o;
        return Objects.equals(projectId, that.projectId) && Objects.equals(moduleName, that.moduleName) && Objects.equals(commitId, that.commitId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(projectId, moduleName, commitId);
    }
}
