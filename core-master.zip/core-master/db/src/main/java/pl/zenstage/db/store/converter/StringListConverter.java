package pl.zenstage.db.store.converter;

import com.fasterxml.jackson.core.type.TypeReference;
import jakarta.persistence.Converter;

import java.util.List;

@Converter(autoApply = true)
public class StringListConverter extends JacksonConverter<List<String>> {
    @Override
    protected TypeReference<List<String>> getType() {
        return new TypeReference<>() {
        };
    }
}
