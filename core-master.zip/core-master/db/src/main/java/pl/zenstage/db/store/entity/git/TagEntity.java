package pl.zenstage.db.store.entity.git;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@IdClass(TagEntity.Pk.class)
@Table(name = "commit_tag")
@NoArgsConstructor
@AllArgsConstructor
public class TagEntity {
    @Id private String projectId;
    @Id private String moduleName;
    @Id private String tagName;
    private String commitId;

    public record Pk(
            @Id String projectId,
            @Id String moduleName,
            @Id String tagName
    ) {}
}
