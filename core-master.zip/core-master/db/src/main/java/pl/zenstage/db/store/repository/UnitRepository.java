package pl.zenstage.db.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.zenstage.db.store.entity.UnitEntity;

public interface UnitRepository extends JpaRepository<UnitEntity, String> {
}
