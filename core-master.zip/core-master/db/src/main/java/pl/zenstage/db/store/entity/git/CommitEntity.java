package pl.zenstage.db.store.entity.git;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.commit.CommitTasks;

import java.time.LocalDateTime;
import java.util.Objects;

@Data
@Entity
@IdClass(CommitEntity.Pk.class)
@Table(name = "commit", indexes = {
    @Index(name = "idx_commit_project_id_commit_date", columnList = "project_id, commit_date"),
    @Index(name = "idx_commit_project_id_module_name_commit_date", columnList = "project_id, module_name, commit_date"),
    @Index(name = "idx_commit_project_id_commiter_id_commit_date", columnList = "project_id, commiter_id, commit_date"),
    @Index(name = "idx_commit_commiter_id_commit_date", columnList = "commiter_id, commit_date"),
})
@NoArgsConstructor
@AllArgsConstructor
public class CommitEntity {
    @Id private String projectId;
    @Id private String moduleName;
    @Id private String commitId;
    private String commiterId;
    private LocalDateTime commitDate;
    private CommitTasks taskKey;
    @Column(columnDefinition = "TEXT")
    private Commit source;

    public record Pk(
            @Id String projectId,
            @Id String moduleName,
            @Id String commitId
    ) {}

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        CommitEntity that = (CommitEntity) o;
        return Objects.equals(projectId, that.projectId) && Objects.equals(moduleName, that.moduleName) && Objects.equals(commitId, that.commitId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(projectId, moduleName, commitId);
    }
}
