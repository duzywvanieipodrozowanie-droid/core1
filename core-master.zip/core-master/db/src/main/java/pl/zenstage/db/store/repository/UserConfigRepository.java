package pl.zenstage.db.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserConfigRepository extends JpaRepository<pl.zenstage.db.store.entity.UserConfigEntity, String> {

}
