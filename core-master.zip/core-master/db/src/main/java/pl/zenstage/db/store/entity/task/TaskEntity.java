package pl.zenstage.db.store.entity.task;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import pl.zenstage.api.task.Task;
import pl.zenstage.api.task.TaskStatus;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


@Data
@Entity
@IdClass(TaskEntity.Pk.class)
@Table(name = "task", indexes = {
        @Index(name = "idx_task_id", columnList = "projectId, key"),
        @Index(name = "idx_task_id_parentKey", columnList = "projectId, key, parentKey"),
        @Index(name = "idx_task_parentKey", columnList = "parentKey"),
        @Index(name = "idx_task_proj_status_bau_updated", columnList = "project_id, status, bau, updated"),
        @Index(name = "idx_task_proj_assignee", columnList = "project_id, assignee_id"),
        @Index(name = "idx_task_assignee", columnList = "assignee_id"),
        @Index(name = "idx_task_creator", columnList = "creator_id")})
@NoArgsConstructor
@AllArgsConstructor
public class TaskEntity {

    @Column(name = "project_id", nullable = false)
    @Id private String projectId;

    @Column(name = "key", nullable = false)
    @Id private String key;
    private String parentKey;
    private String url;
    private Boolean bau;
    private Boolean technical;
    private String type;
    private String priority;
    @Enumerated(EnumType.STRING)
    private TaskStatus status;
    private List<String> labels;
    @Column(name = "assignee_id")
    private String assigneeId;
    @Column(name = "creator_id")
    private String creatorId;
    private LocalDateTime updated;
    private LocalDateTime created;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(columnDefinition = "jsonb")
    private Task content;

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @JsonManagedReference
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "tasks_sprint",
            joinColumns = {
                    @JoinColumn(name = "task_project_id"),
                    @JoinColumn(name = "task_key")
            },
            inverseJoinColumns = {
                    @JoinColumn(name = "sprint_project_id"),
                    @JoinColumn(name = "sprint_name")
            },
            indexes = {
                    @Index(name = "idx_tasks_sprint_task_fk", columnList = "task_project_id, task_key"),
                    @Index(name = "idx_tasks_sprint_sprint_fk", columnList = "sprint_project_id, sprint_name")
            }
    )
    private List<SprintEntity> sprints = new ArrayList<>();

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @JsonManagedReference
    @OneToMany(mappedBy = "task", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<TaskHistoryEntity> histories = new ArrayList<>();

    public void addHistory(TaskHistoryEntity taskHistoryEntity) {
        histories.add(taskHistoryEntity);
        taskHistoryEntity.setTask(this);
    }

    public record Pk(
            @Id String projectId,
            @Id String key
    ) implements Serializable {
    }

}
