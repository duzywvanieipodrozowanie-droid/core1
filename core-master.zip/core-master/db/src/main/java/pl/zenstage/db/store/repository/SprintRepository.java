package pl.zenstage.db.store.repository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pl.zenstage.db.store.entity.task.SprintEntity;
import pl.zenstage.db.store.repository.model.SprintCapacityAggregatedRow;

import java.util.List;

@Repository
public interface SprintRepository extends JpaRepository<SprintEntity, SprintEntity.Pk> {

    @Query("""
        SELECT s FROM SprintEntity s
        WHERE s.projectId = :projectId
        ORDER BY COALESCE(s.startDate, s.endDate) DESC
    """)
    List<SprintEntity> findLatestSprintsByProject(@Param("projectId") String projectId, Pageable pageable);

    @Query("""
        SELECT s FROM SprintEntity s
        WHERE s.projectId = :projectId AND LOWER(s.state) = 'active'
        ORDER BY s.startDate DESC
    """)
    List<SprintEntity> findActiveSprintsByProject(@Param("projectId") String projectId, Pageable pageable);

    @Query(value = """
        WITH recent_sprints AS (
            SELECT project_id, name, state, start_date, COALESCE(end_date, NOW()) AS effective_end_date
            FROM sprint
            WHERE project_id IN (:projectIds)
            ORDER BY start_date DESC NULLS LAST
            LIMIT 10
        ),
        sprint_task_user_matrix AS (
            -- Użytkownik jest aktualnym assignee
            SELECT 
                s.name AS sprint_name,
                s.state AS sprint_state,
                s.start_date AS sprint_start_date,
                s.effective_end_date AS sprint_end_date,
                t.project_id,
                t.key,
                t.created AS task_created,
                t.status AS task_status,
                t.assignee_id AS user_id,
                COALESCE(NULLIF(TRIM(t.content ->> 'estimate'), '')::NUMERIC, 0) AS estimate,
                TRUE AS is_current_assignee
            FROM recent_sprints s
            JOIN tasks_sprint ts 
                ON ts.sprint_project_id = s.project_id 
                AND ts.sprint_name = s.name
            JOIN task t 
                ON t.project_id = ts.task_project_id 
                AND t.key = ts.task_key
            WHERE t.assignee_id IS NOT NULL AND TRIM(t.assignee_id) <> ''
            
            UNION
            
            -- Użytkownik przekazał zadanie komuś innemu w trakcie sprintu
            SELECT 
                s.name AS sprint_name,
                s.state AS sprint_state,
                s.start_date AS sprint_start_date,
                s.effective_end_date AS sprint_end_date,
                t.project_id,
                t.key,
                t.created AS task_created,
                t.status AS task_status,
                th_prev.from_value AS user_id,
                COALESCE(NULLIF(TRIM(t.content ->> 'estimate'), '')::NUMERIC, 0) AS estimate,
                FALSE AS is_current_assignee
            FROM recent_sprints s
            JOIN tasks_sprint ts 
                ON ts.sprint_project_id = s.project_id 
                AND ts.sprint_name = s.name
            JOIN task t 
                ON t.project_id = ts.task_project_id 
                AND t.key = ts.task_key
            JOIN task_history th_prev 
                ON th_prev.task_project_id = t.project_id 
                AND th_prev.task_key = t.key
                AND LOWER(th_prev.field_type) = 'assignee'
                AND th_prev.from_value IS NOT NULL 
                AND TRIM(th_prev.from_value) <> ''
                AND th_prev.from_value <> t.assignee_id
                AND (s.start_date IS NULL OR th_prev.created >= s.start_date)
                AND th_prev.created <= s.effective_end_date
        ),
        task_classification AS (
            SELECT 
                m.sprint_name,
                m.sprint_state,
                m.user_id AS assignee_id,
                m.estimate,
                
                -- Czy było na starcie (initial) czy dodane w trakcie
                CASE 
                    WHEN m.sprint_start_date IS NULL THEN TRUE
                    WHEN th_sprint.first_added IS NOT NULL THEN th_sprint.first_added <= m.sprint_start_date
                    WHEN m.task_created IS NOT NULL THEN m.task_created <= m.sprint_start_date
                    ELSE TRUE
                END AS is_initial,
                
                -- Uznane za wykonane: przekazane dalej w trakcie sprintu LUB zamknięte
                CASE 
                    WHEN th_handover.handed_over_at IS NOT NULL THEN TRUE
                    WHEN m.is_current_assignee AND m.task_status IN ('DONE', 'RESOLVED', 'CLOSED') THEN TRUE
                    ELSE FALSE
                END AS is_completed
            FROM sprint_task_user_matrix m
            LEFT JOIN LATERAL (
                SELECT MIN(h.created) AS first_added
                FROM task_history h
                WHERE h.task_project_id = m.project_id 
                  AND h.task_key = m.key
                  AND LOWER(h.field_type) = 'sprint'
                  AND (h.to_value = m.sprint_name OR h.to_value LIKE CONCAT('%', m.sprint_name, '%'))
            ) th_sprint ON TRUE
            LEFT JOIN LATERAL (
                SELECT MIN(h.created) AS handed_over_at
                FROM task_history h
                WHERE h.task_project_id = m.project_id 
                  AND h.task_key = m.key
                  AND LOWER(h.field_type) = 'assignee'
                  AND h.from_value = m.user_id
                  AND h.to_value <> m.user_id
                  AND (m.sprint_start_date IS NULL OR h.created >= m.sprint_start_date)
                  AND h.created <= m.sprint_end_date
            ) th_handover ON TRUE
        ),
        user_sprint_aggregates AS (
            SELECT 
                assignee_id,
                sprint_name,
                sprint_state,
                COUNT(*) AS total_tasks,
                SUM(estimate) AS total_est,
                COUNT(*) FILTER (WHERE is_initial) AS init_tasks,
                COALESCE(SUM(estimate) FILTER (WHERE is_initial), 0) AS init_est,
                COUNT(*) FILTER (WHERE NOT is_initial) AS added_tasks,
                COALESCE(SUM(estimate) FILTER (WHERE NOT is_initial), 0) AS added_est,
                COUNT(*) FILTER (WHERE is_completed) AS completed_tasks,
                CASE 
                    WHEN COUNT(*) > 0 
                    THEN ROUND(((COUNT(*) FILTER (WHERE is_completed))::numeric / COUNT(*)::numeric) * 100.0, 2)
                    ELSE 0.0
                END AS sprint_completion_rate
            FROM task_classification
            GROUP BY assignee_id, sprint_name, sprint_state
        )
        SELECT 
            assignee_id AS assigneeId,
            
            -- Średnie historyczne
            ROUND(AVG(total_tasks)::numeric, 2)::float8 AS avgTotalTasksPerSprint,
            ROUND(AVG(total_est)::numeric, 2) AS avgTotalEstimatePerSprint,
            ROUND(AVG(init_tasks)::numeric, 2)::float8 AS avgInitialTasksPerSprint,
            ROUND(AVG(init_est)::numeric, 2) AS avgInitialEstimatePerSprint,
            ROUND(AVG(added_tasks)::numeric, 2)::float8 AS avgAddedTasksPerSprint,
            ROUND(AVG(added_est)::numeric, 2) AS avgAddedEstimatePerSprint,
            ROUND(AVG(completed_tasks)::numeric, 2)::float8 AS avgCompletedTasksPerSprint,
            ROUND(AVG(sprint_completion_rate)::numeric, 2)::float8 AS avgCompletionRatePercentage,
            
            -- Metryki aktywnego sprintu
            MAX(sprint_name) FILTER (WHERE LOWER(sprint_state) = 'active') AS activeSprintName,
            MAX(total_tasks) FILTER (WHERE LOWER(sprint_state) = 'active') AS currentTotalTasks,
            COALESCE(MAX(total_est) FILTER (WHERE LOWER(sprint_state) = 'active'), 0) AS currentTotalEstimate,
            MAX(init_tasks) FILTER (WHERE LOWER(sprint_state) = 'active') AS currentInitialTasks,
            COALESCE(MAX(init_est) FILTER (WHERE LOWER(sprint_state) = 'active'), 0) AS currentInitialEstimate,
            MAX(added_tasks) FILTER (WHERE LOWER(sprint_state) = 'active') AS currentAddedTasks,
            COALESCE(MAX(added_est) FILTER (WHERE LOWER(sprint_state) = 'active'), 0) AS currentAddedEstimate,
            MAX(completed_tasks) FILTER (WHERE LOWER(sprint_state) = 'active') AS currentCompletedTasks,
            MAX(sprint_completion_rate) FILTER (WHERE LOWER(sprint_state) = 'active')::float8 AS currentCompletionRatePercentage
        FROM user_sprint_aggregates
        GROUP BY assignee_id
        ORDER BY avgTotalTasksPerSprint DESC
    """, nativeQuery = true)
    List<SprintCapacityAggregatedRow> findAggregatedCapacityForProjects(@Param("projectIds") List<String> projectIds);

    @Query(value = """
        SELECT COUNT(*) FROM (
            SELECT 1 FROM sprint 
            WHERE project_id IN (:projectIds) 
            ORDER BY start_date DESC NULLS LAST 
            LIMIT 10
        ) s
    """, nativeQuery = true)
    int countRecentSprintsForProjects(@Param("projectIds") List<String> projectIds);
}
