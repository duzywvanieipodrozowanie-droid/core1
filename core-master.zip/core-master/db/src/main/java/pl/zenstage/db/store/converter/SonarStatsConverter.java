package pl.zenstage.db.store.converter;

import com.fasterxml.jackson.core.type.TypeReference;
import jakarta.persistence.Converter;
import pl.zenstage.api.commit.zs.ZsSonarStats;

@Converter(autoApply = true)
public class SonarStatsConverter extends JacksonConverter<ZsSonarStats> {
    @Override
    protected TypeReference<ZsSonarStats> getType() {
        return new TypeReference<>() {
        };
    }
}
