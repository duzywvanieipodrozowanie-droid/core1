package pl.zenstage.db.store.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import pl.zenstage.api.commit.zs.ZsSonarStats;

import java.time.LocalDateTime;

@Data
@Entity
@IdClass(SonarEntity.Pk.class)
@Table(name = "sonar")
@NoArgsConstructor
@AllArgsConstructor
public class SonarEntity {
    @Id
    private String projectId;
    @Id
    private String moduleName;
    @Id
    private String commitId;
    @Column(columnDefinition = "TEXT")
    private ZsSonarStats stats;
    private LocalDateTime updateDate;

    public SonarEntity(String projectId, String moduleName, String commitId, ZsSonarStats stats) {
        this.projectId = projectId;
        this.moduleName = moduleName;
        this.commitId = commitId;
        this.stats = stats;
        this.updateDate = LocalDateTime.now();
    }

    public record Pk(
            @Id String projectId,
            @Id String moduleName,
            @Id String commitId
    ) {
    }
}
