package pl.zenstage.db.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import pl.zenstage.db.store.entity.git.TagEntity;

import java.util.Collection;
import java.util.List;

public interface TagRepository extends JpaRepository<TagEntity, TagEntity.Pk>, PagingAndSortingRepository<TagEntity, TagEntity.Pk> {
    List<TagEntity> findAllByProjectIdAndModuleNameAndCommitIdIn(String projectId, String moduleName, Collection<String> commitIds);
}
