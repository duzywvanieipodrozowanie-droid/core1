package pl.zenstage.db.store.repository.model;

import java.math.BigDecimal;

public interface SprintCapacityAggregatedRow {
    String getAssigneeId();

    // Metryki historyczne (średnie)
    Double getAvgTotalTasksPerSprint();
    BigDecimal getAvgTotalEstimatePerSprint();
    Double getAvgInitialTasksPerSprint();
    BigDecimal getAvgInitialEstimatePerSprint();
    Double getAvgAddedTasksPerSprint();
    BigDecimal getAvgAddedEstimatePerSprint();
    Double getAvgCompletedTasksPerSprint();
    Double getAvgCompletionRatePercentage();

    // Metryki obecnego/aktywnego sprintu
    String getActiveSprintName();
    Long getCurrentTotalTasks();
    BigDecimal getCurrentTotalEstimate();
    Long getCurrentInitialTasks();
    BigDecimal getCurrentInitialEstimate();
    Long getCurrentAddedTasks();
    BigDecimal getCurrentAddedEstimate();
    Long getCurrentCompletedTasks();
    Double getCurrentCompletionRatePercentage();
}
