package pl.zenstage.db.store.mapper;

import pl.zenstage.db.store.entity.task.TaskEntity;

public record UserTaskMapping(
        String creator,
        TaskEntity task
) {}
