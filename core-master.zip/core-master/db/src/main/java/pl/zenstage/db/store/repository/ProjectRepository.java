package pl.zenstage.db.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.zenstage.db.store.entity.release.ProjectEntity;

public interface ProjectRepository extends JpaRepository<ProjectEntity, String> {
}
