package pl.zenstage.db;

import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;

@Configuration
@ComponentScan("pl.zenstage.db")
@EntityScan(basePackages = "pl.zenstage")
@EnableJpaRepositories(basePackages = "pl.zenstage.db.store.**")
//@EnableR2dbcRepositories(basePackages = "pl.zenstage.db")
public class ZsDbAutoConfiguration {
}
