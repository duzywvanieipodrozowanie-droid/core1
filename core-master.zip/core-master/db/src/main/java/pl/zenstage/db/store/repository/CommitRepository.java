package pl.zenstage.db.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import pl.zenstage.db.store.entity.git.CommitEntity;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public interface CommitRepository extends JpaRepository<CommitEntity, CommitEntity.Pk>, PagingAndSortingRepository<CommitEntity, CommitEntity.Pk> {
    List<CommitEntity> findByProjectIdInAndCommitDateBetween(Collection<String> projectsId, LocalDateTime startDate, LocalDateTime endDate);

    List<CommitEntity> findAllByCommiterIdIsNullAndCommitDateAfter(LocalDateTime commitDate);

    List<CommitEntity> findByCommiterIdInAndCommitDateBetween(Collection<String> commiterIds, LocalDateTime startDate, LocalDateTime endDate);

    List<CommitEntity> findByCommiterIdAndCommitDateBetween(String commiterId, LocalDateTime startDate, LocalDateTime endDate);

    @Query("SELECT c.commitDate FROM CommitEntity c WHERE c.projectId = ?1 ORDER BY c.commitDate DESC LIMIT 1")
    LocalDateTime findLatestCommitDate(@Param("project") String project);

    @Query(value = """
            SELECT commit_date
                FROM commit
                WHERE project_id = :projectId
                  AND ',' || task_key || ',' LIKE '%,' || :taskKey || ',%'
                ORDER BY commit_date ASC
                LIMIT 1
            """, nativeQuery = true)
    Optional<LocalDateTime> firstCommitDateForTask(
            @Param("projectId") String projectId,
            @Param("taskKey") String taskKey
    );

    @Query(value = """
            SELECT *
                FROM commit
                WHERE project_id = :projectId
                  AND ',' || task_key || ',' LIKE '%,' || :taskKey || ',%'
                ORDER BY commit_date ASC
            """, nativeQuery = true)
    List<CommitEntity> findAllForTask(
            @Param("projectId") String projectId,
            @Param("taskKey") String taskKey
    );

    /**
     * Commits of the given projects mentioning the task: by the extracted task keys, or anywhere in the commit
     * (message) when the project's task regex does not match the Jira keys. The caller filters exact key matches.
     */
    @Query(value = """
            SELECT *
                FROM commit
                WHERE project_id IN (:projectIds)
                  AND commit_date >= :from
                  AND (',' || task_key || ',' LIKE '%,' || :taskKey || ',%'
                       OR UPPER(source) LIKE '%' || :taskKey || '%')
                ORDER BY commit_date ASC
            """, nativeQuery = true)
    List<CommitEntity> findAllMentioningTask(
            @Param("projectIds") Collection<String> projectIds,
            @Param("taskKey") String taskKey,
            @Param("from") LocalDateTime from
    );

    Set<CommitEntity> findTop50ByOrderByCommitDateDesc();
}
