package pl.zenstage.db.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import pl.zenstage.db.store.entity.git.MergeRequestEntity;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

public interface MergeRequestRepository extends JpaRepository<MergeRequestEntity, MergeRequestEntity.Pk> {
    List<MergeRequestEntity> findAllByProjectIdAndModuleNameAndCommitId(String projectId, String moduleName, String commitId);
    List<MergeRequestEntity> findByProjectIdInAndCreateDateBetween(Collection<String> projectsId, LocalDateTime startDate, LocalDateTime endDate);
    List<MergeRequestEntity> findByAuthorIdAndCreateDateBetween(String authorId, LocalDateTime startDate, LocalDateTime endDate);

    @Query("SELECT mr.createDate FROM MergeRequestEntity mr WHERE mr.projectId = ?1 ORDER BY mr.createDate DESC LIMIT 1")
    LocalDateTime findLatestDate(@Param("project") String project);

}
