package pl.zenstage.db.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import pl.zenstage.db.store.entity.SonarEntity;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface SonarRepository extends JpaRepository<SonarEntity, SonarEntity.Pk> {
    List<SonarEntity> findAllByProjectId(String projectId);

    @Query("""
            SELECT s FROM SonarEntity s, CommitEntity c
            WHERE c.projectId = s.projectId AND c.moduleName = s.moduleName AND c.commitId = s.commitId
              AND s.projectId = :projectId AND s.moduleName = :moduleName AND c.commitDate < :before
            ORDER BY c.commitDate DESC
            LIMIT 1
            """)
    Optional<SonarEntity> findPreviousScan(
            @Param("projectId") String projectId,
            @Param("moduleName") String moduleName,
            @Param("before") LocalDateTime before
    );
}
