package pl.zenstage.db.store.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import pl.zenstage.api.admin.EmpLevel;
import pl.zenstage.api.admin.EmpSkill;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@Entity
@Table(name = "person")
@NoArgsConstructor
@AllArgsConstructor
public class PersonEntity {

    @EqualsAndHashCode.Include
    @Id private String id;
    private String name;
    private String email;
    @Column(columnDefinition = "TEXT")
    private List<String> commiterEmails;
    private boolean technical;
    @Column(columnDefinition = "boolean DEFAULT FALSE")
    private boolean admin;
    @Enumerated(EnumType.STRING)
    private EmpLevel level;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "skills", columnDefinition = "jsonb")
    private Set<EmpSkill> skills = new HashSet<>();

}
