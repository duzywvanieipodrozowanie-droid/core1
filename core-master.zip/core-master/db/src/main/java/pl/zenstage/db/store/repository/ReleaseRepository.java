package pl.zenstage.db.store.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import pl.zenstage.db.store.entity.release.ReleaseEntity;

import java.time.LocalDateTime;
import java.util.List;

public interface ReleaseRepository extends JpaRepository<ReleaseEntity, Long> {
    Page<ReleaseEntity> findAllByProjectName(String projectName, Pageable pageable);

    List<ReleaseEntity> findAllByProjectNameInAndFinishDateBetween(List<String> projectName, LocalDateTime from, LocalDateTime to);
}
