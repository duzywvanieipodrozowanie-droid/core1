package pl.zenstage.db.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pl.zenstage.api.task.History;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.entity.task.TaskHistoryEntity;
import pl.zenstage.db.store.mapper.UserTaskMapping;
import pl.zenstage.db.store.repository.model.TaskHistoryUpdateProjection;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TaskHistoryRepository extends JpaRepository<TaskHistoryEntity, Long> {

    /**
     * Wyszukuje wpisy w historii modyfikacji utworzone przez wskazanego użytkownika
     * w określonym przedziale czasowym (włącznie z datami brzegowymi).
     *
     * @param personId identyfikator użytkownika (autora zmiany)
     * @param fromDate początek przedziału daty utworzenia wpisu (created)
     * @param toDate koniec przedziału daty utworzenia wpisu (created)
     * @return lista encji {@link TaskHistoryEntity} zarejestrowanych w danym okresie
     */
    List<TaskHistoryEntity> findByAuthorIdAndCreatedBetween(
            String personId,
            LocalDateTime fromDate,
            LocalDateTime toDate
    );

    /**
     * Wyszukuje unikalne encje zadań ({@link TaskEntity}), w których dany użytkownik
     * dokonał jakiejkolwiek modyfikacji w zadanym oknie czasowym.
     * <p>
     * Zastosowanie {@code DISTINCT h.task} zapobiega wielokrotnemu zwróceniu tego samego zadania,
     * jeśli użytkownik modyfikował je wielokrotnie w wybranym okresie. Zapytanie bazuje na nawigacji
     * po relacji {@code h.task}, zwracając docelowy model zadania bezpośrednio z tabeli historii.
     *
     * @param personId identyfikator użytkownika (autora zmian)
     * @param fromDate początek badanego przedziału czasowego
     * @param toDate koniec badanego przedziału czasowego
     * @return lista unikalnych encji {@link TaskEntity} zmodyfikowanych przez użytkownika
     */
    @Query("""
                SELECT DISTINCT h.task 
                FROM TaskHistoryEntity h 
                WHERE h.authorId = :personId 
                  AND h.created BETWEEN :fromDate AND :toDate
            """)
    List<TaskEntity> findTasksModifiedByUserInPeriod(
            @Param("personId") String personId,
            @Param("fromDate") LocalDateTime fromDate,
            @Param("toDate") LocalDateTime toDate
    );

    /**
     * Wyszukuje unikalne powiązania użytkowników i zmodyfikowanych przez nich zadań
     * dla grupy identyfikatorów kont w określonym okresie, rzutując wynik do dedykowanego DTO.
     * <p>
     * Wykorzystuje klauzulę konstruktora JPQL ({@code SELECT DISTINCT new ...}) oraz złączenie wewnętrzne
     * {@code JOIN h.task t}, co pozwala pobrać gotowe pary (autor, zadanie) w ramach pojedynczego zapytania SQL,
     * eliminując konieczność manualnego łączenia danych po stronie aplikacji.
     *
     * @param personId lista identyfikatorów użytkowników do weryfikacji
     * @param fromDate początek przedziału czasowego
     * @param toDate koniec przedziału czasowego
     * @return lista unikalnych mapowań {@link UserTaskMapping}
     */
    @Query("""
                SELECT DISTINCT new pl.zenstage.db.store.mapper.UserTaskMapping(h.authorId, h.task)
                FROM TaskHistoryEntity h
                JOIN h.task t
                WHERE h.authorId IN :personId
                  AND h.created BETWEEN :fromDate AND :toDate
            """)
    List<UserTaskMapping> findTasksModifiedByUsersInPeriod(
            @Param("personId") List<String> personId,
            @Param("fromDate") LocalDateTime fromDate,
            @Param("toDate") LocalDateTime toDate
    );

    /**
     * Sprawdza obecność jakiejkolwiek modyfikacji dokonanej przez wskazanego użytkownika
     * w wybranym przedziale czasowym.
     * <p>
     * Metoda generuje optymalne zapytanie bazodanowe typu {@code SELECT EXISTS (... LIMIT 1)},
     * które przerywa przeszukiwanie indeksu natychmiast po znalezieniu pierwszego pasującego rekordu,
     * nie alokując encji w pamięci.
     *
     * @param personId identyfikator użytkownika
     * @param fromDate początek badanego przedziału czasowego
     * @param toDate koniec badanego przedziału czasowego
     * @return {@code true}, jeśli użytkownik dokonał przynajmniej jednej modyfikacji; w przeciwnym razie {@code false}
     */
    boolean existsByAuthorIdAndCreatedBetween(
            String personId,
            LocalDateTime fromDate,
            LocalDateTime toDate
    );

    /**
     * Pobiera wszystkie rekordy historii zmian, które nie mają jeszcze przypisanego
     * identyfikatora autora (authorId IS NULL).
     * <p>
     * Używane przez procesy synchronizacyjne do uzupełniania brakujących powiązań z użytkownikami.
     *
     * @return lista wpisów historii oczekujących na uzupełnienie identyfikatora autora
     */
    List<TaskHistoryEntity> findByAuthorIdIsNull();

    /**
     * Pobiera lekką projekcję wpisów historii (jedynie identyfikator oraz zawartość JSON),
     * które nie mają jeszcze przypisanego identyfikatora autora (authorId IS NULL).
     * <p>
     * Zastosowanie projekcji DTO/interfejsu zapobiega ładowaniu całej encji TaskHistoryEntity
     * oraz powiązanej z nią relacji TaskEntity, co eliminuje narzut pamięciowy i zapobiega
     * problemom z dynamicznymi proxy w środowisku GraalVM Native Image.
     *
     * @return lista lekkich projekcji zawierających jedynie ID rekordu oraz obiekt History
     */
    @Query("SELECT th.id AS id, th.content AS content FROM TaskHistoryEntity th WHERE th.authorId IS NULL")
    List<TaskHistoryUpdateProjection> findPendingAuthorUpdates();

    /**
     * Bezpośrednio aktualizuje identyfikator autora dla wskazanego rekordu historii w bazie danych.
     * <p>
     * Wykonuje punktowe zapytanie SQL UPDATE z pominięciem cyklu życia encji JPA,
     * mechanizmu dirty checking oraz konieczności wcześniejszego ładowania obiektu do kontekstu persystencji.
     * Metoda wymaga aktywnej transakcji (@Transactional) w miejscu jej wywołania.
     *
     * @param id identyfikator rekordu w tabeli task_history
     * @param authorId nowy identyfikator przypisywanego autora
     */
    @Modifying
    @Query("UPDATE TaskHistoryEntity th SET th.authorId = :authorId WHERE th.id = :id")
    void updateAuthorId(@Param("id") Long id, @Param("authorId") String authorId);

    /**
     * Pobiera zawartość obiektów JSON (pole {@code content}) jedynie dla tych wpisów historii,
     * które nie mają jeszcze przypisanego identyfikatora autora zmiany (authorId IS NULL).
     * <p>
     * Zapytanie pomija mapowanie całej encji {@code TaskHistoryEntity} oraz jej powiązania
     * z {@code TaskEntity}, co zapobiega tworzeniu dynamicznych proxy Hibernate i jest w pełni
     * bezpieczne dla środowisk typu GraalVM Native Image.
     *
     * @return lista obiektów {@link History} oczekujących na uzupełnienie autora
     */
    @Query("SELECT th.content FROM TaskHistoryEntity th WHERE th.authorId IS NULL")
    List<History> findContentsWithUnassignedAuthor();
}
