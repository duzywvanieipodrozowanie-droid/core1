package pl.zenstage.db.store.converter;

import com.fasterxml.jackson.core.type.TypeReference;
import jakarta.persistence.Converter;
import pl.zenstage.api.mr.MergeRequest;

@Converter(autoApply = true)
public class MergeRequestConverter extends JacksonConverter<MergeRequest> {
    @Override
    protected TypeReference<MergeRequest> getType() {
        return new TypeReference<>() {
        };
    }
}
