package pl.zenstage.db.store.entity.release;

import com.fasterxml.jackson.core.type.TypeReference;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import pl.zenstage.api.project.ReleaseModule;
import pl.zenstage.db.store.converter.JacksonConverter;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Data
@Entity
@Table(name = "release")
@NoArgsConstructor
@AllArgsConstructor
public class ReleaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;
    private Long parentId;
    private String projectName;
    @Enumerated
    private Status status;
    private LocalDateTime createDate;
    private LocalDateTime acceptDate;
    private LocalDateTime startDate;
    private LocalDateTime finishDate;
    private LocalDateTime rollbackDate;
    @Column(columnDefinition = "TEXT")
    @Convert(converter = ReleaseContentConverter.class)
    private Content content;

    public static ReleaseEntity create(String projectName, Long parentId, Content content) {
        return new ReleaseEntity(null, parentId,
                projectName, ReleaseEntity.Status.NEW,
                LocalDateTime.now(),
                null, null, null, null,
                content
        );
    }

    @Data
    public static class Content {
        private String content;
        private List<ReleaseModule> modules;
    }

    @RequiredArgsConstructor
    public enum Status {
        NEW,
        REJECTED,
        READY,
        IN_PROGRESS,
        SUCCESS,
        FAILED,
        CANCELLED,
        ROLLED;
        private static final List<Status> CLOSED = Arrays.asList(SUCCESS, FAILED, CANCELLED, ROLLED);
        private static final Map<Status, List<Status>> availableStep = Map.of(
                NEW, List.of(READY, CANCELLED, REJECTED),
                READY, List.of(NEW, IN_PROGRESS, SUCCESS, FAILED, CANCELLED),
                REJECTED, List.of(READY, CANCELLED),
                IN_PROGRESS, List.of(SUCCESS, FAILED, CANCELLED),
                SUCCESS, List.of(ROLLED),
                FAILED, List.of(),
                CANCELLED, List.of(READY, IN_PROGRESS),
                ROLLED, List.of()
        );

        public boolean canSwitch(Status status) {
            return Optional.ofNullable(status).map(availableStep::get).map(it -> it.contains(status)).orElse(false);
        }

        public boolean isOpen() {
            return !CLOSED.contains(this);
        }
    }

    public static class ReleaseContentConverter extends JacksonConverter<Content> {
        @Override
        protected TypeReference<Content> getType() {
            return new TypeReference<>() {
            };
        }
    }
}
