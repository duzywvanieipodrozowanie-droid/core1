package pl.zenstage.api.rest;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.components.CommitMapper;
import pl.zenstage.api.components.PersonService;
import pl.zenstage.api.mr.MergeRequest;
import pl.zenstage.api.mr.PipelineRequest;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.git.MergeRequestEntity;
import pl.zenstage.db.store.entity.git.PipelineEntity;
import pl.zenstage.db.store.entity.git.TagEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.MergeRequestRepository;
import pl.zenstage.db.store.repository.PipelineRepository;
import pl.zenstage.db.store.repository.TagRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(Const.V1 + "/commit")
@RequiredArgsConstructor
public class CommitApiController {
    private final CommitRepository commitRepository;
    private final CommitMapper commitMapper;
    private final MergeRequestRepository mergeRequestRepository;
    private final TagRepository tagRepository;
    private final PipelineRepository pipelineRepository;
    private final PersonService personService;

    @GetMapping
    Flux<CommitEntity> getAll(
            @RequestParam(name = "page", required = false, defaultValue = "0") int page,
            @RequestParam(name = "size", required = false, defaultValue = "100") int size
    ) {
        return Mono.just(PageRequest.of(page, Math.min(size, Const.MAX_RESULTS))).publishOn(Schedulers.boundedElastic()).flatMapIterable(commitRepository::findAll);
    }

    @PutMapping
    Mono<CommitEntity> save(@RequestBody Commit commit) {
        return Mono.just(commit).publishOn(Schedulers.boundedElastic()).map(commitMapper::map).map(commitRepository::save);
    }

    @PutMapping("/refresh")
    Flux<CommitEntity> updateCommit(
            @RequestParam("project") String project,
            @RequestParam(name = "weeks", required = false, defaultValue = "1") int weeks
    ) {
        // the people as they are now, so a person added since the last minute maps the refreshed commits too
        return Mono.just(project).map(List::of).publishOn(Schedulers.boundedElastic())
                .doOnNext(it -> personService.reload())
                .flatMapIterable(it ->
                        commitRepository.findByProjectIdInAndCommitDateBetween(it,
                                LocalDateTime.now().minusWeeks(weeks), LocalDateTime.now()
                        )
                ).mapNotNull(commit ->
                        Optional.of(commit).map(CommitEntity::getSource)
                                .map(commitMapper::map).map(commitRepository::save).orElse(null)
                );
    }

    @PutMapping("/mr")
    Mono<MergeRequestEntity> save(@RequestBody MergeRequest commit) {
        return Mono.just(commit).publishOn(Schedulers.boundedElastic()).map(commitMapper::map).map(mergeRequestRepository::save);
    }

    @PutMapping("/mr/refresh")
    Flux<MergeRequestEntity> updateMr(
            @RequestParam("project") String project,
            @RequestParam(name = "weeks", required = false, defaultValue = "1") int weeks
    ) {
        // the people as they are now, so a person added since the last minute maps the refreshed commits too
        return Mono.just(project).map(List::of).publishOn(Schedulers.boundedElastic())
                .doOnNext(it -> personService.reload())
                .flatMapIterable(it ->
                        mergeRequestRepository.findByProjectIdInAndCreateDateBetween(it,
                                LocalDateTime.now().minusWeeks(weeks), LocalDateTime.now()
                        )
                ).mapNotNull(commit ->
                        Optional.of(commit).map(MergeRequestEntity::getSource)
                                .map(commitMapper::map).map(mergeRequestRepository::save).orElse(null)
                );
    }

    @PutMapping("/pp")
    Mono<PipelineEntity> save(@RequestBody PipelineRequest pp) {
        return Mono.just(pp).publishOn(Schedulers.boundedElastic()).map(commitMapper::map).map(pipelineRepository::save);
    }

    @GetMapping("/last-loaded")
    Mono<ResponseEntity<LocalDateTime>> lastLoaded(@RequestParam("project") String project) {
        return Mono.just(project).mapNotNull(commitRepository::findLatestCommitDate)
                .subscribeOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
    }

    @GetMapping("/last-loaded/mr")
    Mono<ResponseEntity<LocalDateTime>> lastLoadedMr(@RequestParam("project") String project) {
        return Mono.just(project).mapNotNull(mergeRequestRepository::findLatestDate)
                .subscribeOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
    }

    @GetMapping("/last-loaded/pp")
    Mono<ResponseEntity<LocalDateTime>> lastLoadedPp(@RequestParam("project") String project) {
        return Mono.just(project).mapNotNull(pipelineRepository::findLatestDate)
                .subscribeOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
    }

    @PutMapping("/tag")
    Flux<TagEntity> updateTag(@RequestBody List<TagEntity> tags) {
        return Mono.just(tags).publishOn(Schedulers.boundedElastic()).flatMapIterable(tagRepository::saveAll);
    }
}
