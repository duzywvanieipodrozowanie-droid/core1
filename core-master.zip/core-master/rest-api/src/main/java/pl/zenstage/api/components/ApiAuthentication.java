package pl.zenstage.api.components;

import lombok.extern.log4j.Log4j2;
import org.jspecify.annotations.NonNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.server.PathContainer;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import pl.zenstage.api.rest.Const;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Log4j2
@Component
public class ApiAuthentication implements WebFilter {
    private static final String AUTH_HEADER = "ZS-API-TOKEN";
    private static final String ENV_API_KEY = "ZENSTAGE_API_KEY";
    private final List<String> apiHeaders = loadApiKeys();
    @Value("${zenstage.debug.api:false}")
    private boolean debugApi;

    private static List<String> loadApiKeys() {
        String envValue = System.getenv(ENV_API_KEY);
        List<String> apiKeys = List.of("k6O1ugzEjx1Syg80sB46SqQmeld3");
        if (envValue != null && !envValue.isBlank()) {
            apiKeys = List.of(envValue);
        }
        log.info("Loaded API key: {}", apiKeys.getFirst());
        return apiKeys;
    }


    @Override
    public Mono<Void> filter(@NonNull ServerWebExchange exchange, @NonNull WebFilterChain chain) {
        Boolean apiPath = Optional.of(exchange).map(ServerWebExchange::getRequest).map(ServerHttpRequest::getPath)
                .map(PathContainer::value).map(it -> it.startsWith(Const.V1))
                .orElse(false);
        if (!apiPath) {
            return chain.filter(exchange);
        }

        String headerValue = exchange.getRequest().getHeaders().getFirst(AUTH_HEADER);
        boolean apiAuthenticated = Optional.ofNullable(headerValue).map(apiHeaders::contains).orElse(false);

        Mono<Boolean> sessionAuthenticated = ReactiveSecurityContextHolder.getContext()
                .mapNotNull(SecurityContext::getAuthentication)
                .map(Authentication::isAuthenticated)
                .map(it -> it && debugApi).defaultIfEmpty(false);

        return Mono.just(apiAuthenticated).zipWith(sessionAuthenticated)
                .filter(a-> a.getT1() || a.getT2())
                .flatMap(_ -> chain.filter(exchange))
                .switchIfEmpty(exchange.getResponse().writeWith(
                                Mono.just(exchange.getResponse().bufferFactory().wrap("Problem validating header: %s".formatted(AUTH_HEADER).getBytes()))
                        )
                );
    }
}
