package pl.zenstage.api.components;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.task.History;
import pl.zenstage.api.task.Sprint;
import pl.zenstage.api.task.Task;
import pl.zenstage.api.task.TaskStatus;
import pl.zenstage.db.store.entity.task.SprintEntity;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.entity.task.TaskHistoryEntity;
import pl.zenstage.db.store.repository.SprintRepository;
import pl.zenstage.db.store.repository.TaskHistoryRepository;
import pl.zenstage.db.store.repository.TaskRepository;
import pl.zenstage.db.store.repository.model.TaskHistoryUpdateProjection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ApiTaskService {

    private final TaskRepository taskRepository;
    private final TaskHistoryRepository taskHistoryRepository;
    private final SprintRepository sprintRepository;
    private final PersonService personService;

    @Transactional
    public TaskEntity saveTask(Task task) {
        String projectId = task.projectId().toLowerCase();

        TaskEntity entity = new TaskEntity();
        entity.setProjectId(projectId);
        entity.setUrl(task.url());
        entity.setKey(task.key());
        entity.setParentKey(task.parentKey());
        entity.setBau(task.bau());
        entity.setTechnical(task.technical());
        entity.setType(task.type());
        entity.setPriority(task.priority());
        entity.setStatus(TaskStatus.fromJiraName(task.status().toUpperCase()));
        entity.setLabels(task.labels());

        if (task.assignee() != null) entity.setAssigneeId(personService.findAllIdsByEmails(task.assignee().accountId()));
        if (task.creator() != null) entity.setCreatorId(personService.findAllIdsByEmails(task.creator().accountId()));

        entity.setUpdated(task.updated() != null ? task.updated() : task.created());
        entity.setCreated(task.created());
        entity.setContent(task);

        if (task.histories() != null && !task.histories().isEmpty()) {
            List<TaskHistoryEntity> historyEntities = task.histories().stream()
                    .map(h -> mapHistory(h, entity))
                    .toList();
            entity.setHistories(historyEntities);
        }

        if (task.sprints() != null && !task.sprints().isEmpty()) {
            List<SprintEntity> sprintEntities = task.sprints().stream()
                    .filter(s -> s.name() != null && !s.name().isBlank())
                    .map(s -> upsertSprint(projectId, s))
                    .collect(Collectors.toCollection(ArrayList::new));
            entity.setSprints(sprintEntities);
        }

        return taskRepository.save(entity);
    }

    /**
     * Usuwa zadania projektu, których klucza nie ma na liście z pełnego importu Jiry (np. usunięte, przeniesione
     * albo anulowane w Jirze), razem z ich historią i przypisaniem do sprintów. Pusta lista nie usuwa niczego.
     *
     * @return klucze usuniętych zadań
     */
    @Transactional
    public List<String> deleteMissing(String project, Collection<String> keys) {
        if (keys == null || keys.isEmpty()) return List.of();
        Set<String> kept = new HashSet<>(keys);
        List<TaskEntity> missing = taskRepository.findByProjectId(project.toLowerCase()).stream()
                .filter(t -> !kept.contains(t.getKey()))
                .toList();
        taskRepository.deleteAll(missing);
        return missing.stream().map(TaskEntity::getKey).toList();
    }

    /** Statuses of work started and not LIVE yet (Work flow WIP, Flow efficiency "Right now"). */
    private static final Set<TaskStatus> OPEN = Set.of(
            TaskStatus.ANALYSIS, TaskStatus.IN_PROGRESS, TaskStatus.IN_REVIEW, TaskStatus.DEVELOPED, TaskStatus.IN_TEST,
            TaskStatus.TO_TEST, TaskStatus.TESTED, TaskStatus.UAT, TaskStatus.IN_UAT, TaskStatus.PO_ACCEPTANCE,
            TaskStatus.ON_HOLD, TaskStatus.ON_HOLD_BLOCKED, TaskStatus.BLOCKED, TaskStatus.DONE
    );

    /** Keys of the project's tasks in progress or DONE, which the importer checks for being deleted in Jira. */
    public List<String> openKeys(String project) {
        return taskRepository.findByProjectIdInAndStatusIn(List.of(project.toLowerCase()), OPEN).stream()
                .map(TaskEntity::getKey).toList();
    }

    /** Jira status of each of the project's tasks in progress or DONE, by key. */
    public Map<String, String> openStatuses(String project) {
        Map<String, String> statuses = new LinkedHashMap<>();
        taskRepository.findByProjectIdInAndStatusIn(List.of(project.toLowerCase()), OPEN).forEach(it -> statuses.put(it.getKey(),
                Optional.ofNullable(it.getContent()).map(Task::status).orElse(it.getStatus().getJiraName())));
        return statuses;
    }

    /** Deletes one task with its history and sprint links; false when there is no such task. */
    @Transactional
    public boolean delete(String project, String key) {
        return taskRepository.findById(new TaskEntity.Pk(project.toLowerCase(), key)).map(it -> {
            taskRepository.delete(it);
            return true;
        }).orElse(false);
    }

    private TaskHistoryEntity mapHistory(History history, TaskEntity taskEntity) {
        TaskHistoryEntity taskHistoryEntity = new TaskHistoryEntity();
        taskHistoryEntity.setFieldType(history.fieldType());
        taskHistoryEntity.setFrom(history.from());
        taskHistoryEntity.setTo(history.to());
        taskHistoryEntity.setCreated(history.created());
        taskHistoryEntity.setContent(history);

        if (history.author() != null) {
            taskHistoryEntity.setAuthorId(personService.findAllIdsByEmails(history.author().accountId()));
        }
        taskHistoryEntity.setTask(taskEntity);
        return taskHistoryEntity;
    }

    private SprintEntity upsertSprint(String projectId, Sprint sprint) {
        SprintEntity.Pk sprintPk = new SprintEntity.Pk(projectId, sprint.name());

        SprintEntity sprintEntity = sprintRepository.findById(sprintPk)
                .orElseGet(() -> {
                    SprintEntity se = new SprintEntity();
                    se.setProjectId(projectId);
                    se.setName(sprint.name());
                    return se;
                });

        sprintEntity.setState(sprint.state());
        sprintEntity.setGoal(sprint.goal());
        sprintEntity.setStartDate(sprint.startDate());
        sprintEntity.setEndDate(sprint.endDate());
        sprintEntity.setContent(sprint);

        return sprintRepository.save(sprintEntity);
    }

    public int refreshCreator() {
        int updatedCount = 0;

        // ==========================================
        // 1. REFRESH (TASK)
        // ==========================================

        List<TaskEntity> taskToUpdate = taskRepository.findByAssigneeIdIsNullOrCreatorIdIsNull();

        for (TaskEntity entity : taskToUpdate) {
            Task task = entity.getContent();
            if (task == null) continue;

            boolean updated = false;

            if (entity.getAssigneeId() == null) {
                entity.setAssigneeId(personService.findAllIdsByEmails(task.assignee().accountId()));
                updated = true;
            }
            if (entity.getCreatorId() == null) {
                entity.setCreatorId(personService.findAllIdsByEmails(task.creator().accountId()));
                updated = true;
            }

            if (updated) {
                taskRepository.save(entity);
                updatedCount++;
            }
        }

        // ==========================================
        // 2. REFRESH (TASK_HISTORY)
        // ==========================================

        List<TaskHistoryUpdateProjection> taskHistoryToUpdate = taskHistoryRepository.findPendingAuthorUpdates();

        for (TaskHistoryUpdateProjection entry : taskHistoryToUpdate) {
            History history = entry.getContent();
            if (history == null || history.author() == null) continue;

            String authorId = personService.findAllIdsByEmails(history.author().accountId());
            if (authorId != null) {
                taskHistoryRepository.updateAuthorId(entry.getId(), authorId);
                updatedCount++;
            }
        }

        return updatedCount;
    }
}
