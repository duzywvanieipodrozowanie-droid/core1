package pl.zenstage.api.components;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

import java.util.Optional;

@Slf4j
@Getter
public class ZenStageException extends RuntimeException {
    private final HttpStatus status;
    private final String errorCode;

    public ZenStageException(HttpStatus status) {
        this(status, null, null, null);
    }

    public ZenStageException(HttpStatus status, String errorCode) {
        this(status, errorCode, errorCode, null);
    }

    public ZenStageException(HttpStatus status, String errorCode, String message) {
        this(status, errorCode, message, null);
    }

    public ZenStageException(HttpStatus status, String errorCode, String message, Throwable cause) {
        super(message, cause);
        this.status = status;
        this.errorCode = Optional.ofNullable(errorCode).orElse("UNKNOWN_ERROR");
    }

    public static <T> T exec(SafeRunnable<T> task) {
        try {
            return task.exec();
        } catch (Exception e) {
            throw new ZenStageException(HttpStatus.INTERNAL_SERVER_ERROR, "OTHER", e.getMessage(), e);
        }
    }

    public static <T> T execQuiet(SafeRunnable<T> task) {
        try {
            return task.exec();
        } catch (Exception e) {
            log.warn("Error executing task", e);
            return null;
        }
    }

    public interface SafeRunnable<T> {
        T exec() throws Exception;
    }
}
