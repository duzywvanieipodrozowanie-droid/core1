package pl.zenstage.api.rest;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.api.components.ZenStageException;
import pl.zenstage.api.project.ProjectDto;
import pl.zenstage.api.project.ReleaseModule;
import pl.zenstage.db.store.entity.release.EnvStateEntity;
import pl.zenstage.db.store.entity.release.ProjectEntity;
import pl.zenstage.db.store.repository.EnvStateRepository;
import pl.zenstage.db.store.repository.ProjectRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Log4j2
@RestController
@RequestMapping(Const.V1 + "/environment")
@RequiredArgsConstructor
public class EnvironmentApiController {
    private final EnvStateRepository envStateRepository;
    private final ProjectRepository projectRepository;
    private final Environment environment;

//    @GetMapping
//    Flux<ProjectDto> all() {
//        Flux<ProjectEntity> projects = Flux.fromIterable(projectRepository.findAll());
//        return projects.map(it -> new ProjectDto(
//                it.getName(),
//                it.getLabel(),
//                it.getEnvironments(),
//                it.getPriorityModules()
//        ));
//    }

    /**
     * The project of the service map, created when missing (importer job "architecture" from the ArgoCD deploy
     * repository): environments not known yet are added at the end, the order set in Settings stays.
     */
    @PutMapping("/project")
    Mono<ProjectDto> ensureProject(@RequestBody ProjectDto project) {
        if (project == null || project.id() == null || project.id().isBlank()) {
            return Mono.error(new ZenStageException(HttpStatus.BAD_REQUEST, "PROJECT_ID_REQUIRED", "Project id is required"));
        }
        return Mono.fromCallable(() -> {
            ProjectEntity entity = projectRepository.findById(project.id())
                    .orElseGet(() -> new ProjectEntity(project.id(), project.label(), project.taskRegex(), new ArrayList<>(), new ArrayList<>()));
            List<String> envs = new ArrayList<>(Optional.ofNullable(entity.getEnvironments()).orElseGet(List::of));
            Optional.ofNullable(project.envs()).orElseGet(List::of).stream()
                    .filter(Objects::nonNull).filter(it -> !envs.contains(it)).forEach(envs::add);
            entity.setEnvironments(envs);
            if (entity.getLabel() == null) entity.setLabel(project.label());
            if (entity.getPriorityModules() == null) entity.setPriorityModules(new ArrayList<>());
            ProjectEntity saved = projectRepository.save(entity);
            log.info("Project {} of the service map, environments {}", saved.getName(), saved.getEnvironments());
            return new ProjectDto(saved.getName(), saved.getLabel(), saved.getTaskRegex(), saved.getEnvironments(), saved.getPriorityModules());
        }).subscribeOn(Schedulers.boundedElastic());
    }

    @PutMapping("/release")
    Mono<EnvStateEntity> releaseModule(
            @RequestParam(name = "projectId") String projectId,
            @RequestParam(name = "env") String env,
            @RequestBody ReleaseModule releaseModule
    ) {
        Mono<ProjectEntity> project = Mono.just(projectId).map(projectRepository::findById).filter(Optional::isPresent).map(Optional::get)
                .switchIfEmpty(Mono.error(new ZenStageException(HttpStatus.NOT_FOUND, "Project %s not found".formatted(projectId))));
        Mono<EnvStateEntity> sameVersion = Mono.fromCallable(() ->
                        envStateRepository.findById(new EnvStateEntity.Pk(projectId, env, releaseModule.module()))
                ).subscribeOn(Schedulers.boundedElastic()).filter(Optional::isPresent).map(Optional::get)
                .filter(it ->
                        Objects.equals(it.getVersion(), releaseModule.version())
                                && Objects.equals(it.getImage(), releaseModule.image())
                );

        return project.map(p -> new EnvStateEntity(
                p.getName(),
                env,
                releaseModule.module(),
                releaseModule.image(),
                releaseModule.version()
        )).map(envStateRepository::save).publishOn(Schedulers.boundedElastic()).doOnNext(it ->
                sameVersion.hasElement().map(v -> !v).doOnNext(v -> {
                    log.info("Module {} changed, TODO emit event", it.getModule());
                }).subscribe()
        );
    }
}

