package pl.zenstage.api.components;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.commit.CommitTasks;
import pl.zenstage.api.mr.MergeRequest;
import pl.zenstage.api.mr.PipelineRequest;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.git.MergeRequestEntity;
import pl.zenstage.db.store.entity.git.PipelineEntity;
import pl.zenstage.db.store.repository.ProjectRepository;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Stream;

@Slf4j
@Service
public class CommitMapper {
    private static final BigDecimal MINUTE_IN_SECONDS = BigDecimal.valueOf(60);
    private final Map<String, Pattern> projectTaskRegex = new HashMap<>();
    private final PersonService personService;

    CommitMapper(ProjectRepository projectRepository, PersonService personService) {
        this.personService = personService;
        projectRepository.findAll().forEach(project -> {
            String regex = project.getTaskRegex();
            if (regex == null) {
                regex = project.getName() + "-\\d+";
            }
            try {
                projectTaskRegex.put(project.getName(), Pattern.compile(regex));
            } catch (PatternSyntaxException e) {
                log.warn("Invalid task regex for project {}: {}", project.getName(), regex, e);
            }
        });
        log.info("Loaded commit regex patterns: {}", projectTaskRegex);
    }

    public CommitEntity map(Commit commit) {
        return new CommitEntity(
                commit.project(),
                commit.module(),
                commit.id(),
                personService.findAllIdsByEmails(commit.authorName(), commit.authorEmail()),
                commit.committedDate().atZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime(),
                taskKey(commit),
                commit
        );
    }

    public MergeRequestEntity map(MergeRequest mr) {
        Instant pickupTime = Stream.of(
                mr.approvedAt(),
                mr.mergedAt()
        ).filter(Objects::nonNull).min(Instant::compareTo).orElseGet(mr::createdAt);
        Instant mrCloseTime = Stream.of(
                mr.mergedAt(),
                mr.closedAt()
        ).filter(Objects::nonNull).max(Instant::compareTo).orElseGet(mr::createdAt);
        long pickupSecondsBetween = Duration.between(mr.createdAt(), pickupTime).getSeconds();
        long reviewSecondsBetween = Duration.between(pickupTime, mrCloseTime).getSeconds();

        return new MergeRequestEntity(
                mr.project(),
                mr.module(),
                mr.id(),
                mr.mergeCommitSha(),
                personService.findAllIdsByEmails(mr.authorEmail()),
                mr.createdAt().atZone(ZoneId.systemDefault()).toLocalDateTime(),
                BigDecimal.valueOf(pickupSecondsBetween).divide(MINUTE_IN_SECONDS, 1, RoundingMode.CEILING),
                BigDecimal.valueOf(reviewSecondsBetween).divide(MINUTE_IN_SECONDS, 1, RoundingMode.CEILING),
                mr
        );
    }

    public PipelineEntity map(PipelineRequest pp) {
        return new PipelineEntity(
                pp.project(),
                pp.module(),
                pp.id(),
                pp.commitSha(),
                pp.ref(),
                pp.status(),
                pp.source(),
                pp.createdAt().atZone(ZoneId.systemDefault()).toLocalDateTime(),
                pp.updatedAt().atZone(ZoneId.systemDefault()).toLocalDateTime()
        );
    }

    private CommitTasks taskKey(Commit commit) {
        return Optional.of(commit).map(Commit::message)
                .map(projectTaskRegex::get).map(pattern -> {
                    Set<String> found = new TreeSet<>();
                    Matcher message = pattern.matcher(commit.message());
                    while (message.find()) {
                        found.add(message.group());
                    }
                    return found;
                }).map(CommitTasks::new).orElseGet(CommitTasks::new);
    }
}
