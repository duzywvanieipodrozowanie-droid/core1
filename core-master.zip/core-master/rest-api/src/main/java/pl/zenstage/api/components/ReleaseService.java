package pl.zenstage.api.components;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import pl.zenstage.db.store.entity.release.EnvStateEntity;
import pl.zenstage.db.store.entity.release.ProjectEntity;
import pl.zenstage.db.store.entity.release.ReleaseEntity;
import pl.zenstage.db.store.repository.EnvStateRepository;
import pl.zenstage.db.store.repository.ProjectRepository;
import pl.zenstage.db.store.repository.ReleaseRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;

@Log4j2
@Service
@RequiredArgsConstructor
public class ReleaseService {
    private final EnvStateRepository envStateRepository;
    private final ProjectRepository projectRepository;
    private final ReleaseRepository releaseRepository;

    public Flux<EnvStateEntity> releaseCandidate(String projectId) {
        Mono<ProjectEntity> project = Mono.just(projectId).map(projectRepository::findById).filter(Optional::isPresent).map(Optional::get);
        Mono<List<String>> env = project.filter(it -> it.getEnvironments() != null).flatMapIterable(ProjectEntity::getEnvironments)
                .takeLast(2).collectList().filter(it -> it.size() == 2);
        Mono<String> testEnvName = env.map(List::getFirst);
        Mono<String> prodEnvName = env.map(List::getLast);
        Flux<EnvStateEntity> projectEnvState = Mono.just(projectId).share().flatMapIterable(envStateRepository::findAllByProjectId);
        Flux<EnvStateEntity> testState = projectEnvState
                .filterWhen(es -> testEnvName.map(it -> it.equals(es.getEnvironment())));
        Mono<Map<String, String>> prodState = projectEnvState
                .filterWhen(es -> prodEnvName.map(it -> it.equals(es.getEnvironment())))
                .collectMap(EnvStateEntity::getModule, EnvStateEntity::getVersion);
        return testState.filterWhen(t -> prodState
                .mapNotNull(p -> p.get(t.getModule()))
                .map(it -> !t.getVersion().equals(it))
        );
    }

    public Mono<ReleaseEntity> updateStatus(Long releaseId, ReleaseEntity.Status status, ReleaseEntity.Content content) {
        return Mono.just(releaseId).map(releaseRepository::findById)
                .filter(Optional::isPresent).map(Optional::get)
                .switchIfEmpty(Mono.error(new ZenStageException(HttpStatus.NOT_FOUND)))
                .filter(it -> it.getStatus().canSwitch(status))
                .switchIfEmpty(Mono.error(new ZenStageException(HttpStatus.BAD_REQUEST, "status not reachable from current state")))
                .doOnNext(updateStatus(status))
                .doOnNext(it -> {
                    if (content == null) {
                        return;
                    }
                    it.setContent(content);
                }).map(releaseRepository::save);
    }

    private static Consumer<ReleaseEntity> updateStatus(ReleaseEntity.Status status) {
        return it -> {
            it.setStatus(status);
            switch (it.getStatus()) {
                case NEW -> log.trace("Do nothing");
                case READY -> {
                    it.setAcceptDate(LocalDateTime.now());
                    it.setFinishDate(null);
                }
                case REJECTED, SUCCESS, FAILED, CANCELLED -> it.setFinishDate(LocalDateTime.now());
                case IN_PROGRESS -> it.setStartDate(LocalDateTime.now());
                case ROLLED -> it.setRollbackDate(LocalDateTime.now());
            }
        };
    }
}
