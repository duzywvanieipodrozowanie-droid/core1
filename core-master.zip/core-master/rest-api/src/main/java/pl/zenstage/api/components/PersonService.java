package pl.zenstage.api.components;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import pl.zenstage.api.ImmutablePair;
import pl.zenstage.db.store.entity.PersonEntity;
import pl.zenstage.db.store.repository.PersonRepository;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Service
public class PersonService {
    // commit author (e-mail, name, id, lower case) -> person id; rebuilt every minute, so a person added or given
    // another e-mail in Users and access maps the commits imported or refreshed from then on (was built once at start)
    private volatile Map<String, String> commitersMapper;
    private final PersonRepository personRepository;
    protected List<String> adminUsers = null;

    PersonService(PersonRepository personRepository) {
        this.personRepository = personRepository;
        reload();
    }

    public void reload() {
        Map<String, String> mapper = personRepository.findAll().stream().flatMap(person -> {
                    Stream<String> commiterEmails = Optional.of(person).map(PersonEntity::getCommiterEmails).orElseGet(Collections::emptyList).stream();

                    Stream<String> extraMapping = Stream.of(
                            person.getEmail(),
                            person.getName(),
                            person.getId(),
                            escapeDomain(person.getId())
                    );
                    return Stream.concat(extraMapping, commiterEmails).filter(Objects::nonNull).map(String::toLowerCase)
                            .map(it -> new ImmutablePair<>(it, person.getId())).toList().stream();
                }
        ).collect(Collectors.toMap(ImmutablePair::key, ImmutablePair::value, (f, _) -> f));
        if (commitersMapper == null || commitersMapper.size() != mapper.size()) {
            log.info("Loaded {} commit author mappings", mapper.size());
        }
        commitersMapper = mapper;
    }

    @Scheduled(fixedRate = 60000)
    private void extracted() {
        adminUsers = this.personRepository.adminUsers();
        reload();
    }

    public String findAllIdsByEmails(String... email) {
        return Optional.ofNullable(email).stream().flatMap(Stream::of).filter(Objects::nonNull).map(String::toLowerCase)
                .map(commitersMapper::get).filter(Objects::nonNull).findAny().orElse(null);
    }

    public List<String> findAllIdsByEmails(List<String> emails) {
        return Optional.ofNullable(emails).orElseGet(Collections::emptyList).stream().filter(Objects::nonNull)
                .map(String::toLowerCase).map(commitersMapper::get).filter(Objects::nonNull).toList();
    }

    public boolean isAdmin(String uniqueName) {
        return adminUsers != null && (adminUsers.isEmpty() || adminUsers.contains(uniqueName));
    }

    private String escapeDomain(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        int domainEscapeIdx = value.lastIndexOf('\\') + 1;
        return value.substring(domainEscapeIdx);
    }
}
