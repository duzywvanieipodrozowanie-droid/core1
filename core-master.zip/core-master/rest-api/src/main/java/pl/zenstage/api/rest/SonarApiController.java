package pl.zenstage.api.rest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.api.commit.SonarScan;
import pl.zenstage.api.components.SonarParser;
import pl.zenstage.db.store.entity.SonarEntity;
import pl.zenstage.db.store.repository.SonarRepository;
import reactor.core.publisher.Mono;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import java.util.Map;

@Slf4j
@RestController
@RequestMapping(Const.V1 + "/sonar")
@RequiredArgsConstructor
public class SonarApiController {
    private final SonarParser sonarParser;
    private final SonarRepository sonarRepository;
    private final ObjectMapper objectMapper;

    @PutMapping("/old")
    public Mono<SonarEntity> save(
            @RequestBody SonarScan scan
    ) {
        return Mono.just(scan).map(s -> new SonarEntity(
                        s.project(),
                        s.module(),
                        s.commitId(),
                        scan.original()
                )
        ).mapNotNull(sonarRepository::save);
    }

    @PutMapping
    public Mono<SonarEntity> save(
            @RequestParam(name = "project") String project,
            @RequestParam(name = "module") String module,
            @RequestParam(name = "commitId") String commitId,
            @RequestBody JsonNode report
    ) {
        return Mono.just(report).map(s -> new SonarEntity(
                        project,
                        module,
                        commitId,
                        sonarParser.parse(report)
                )
        ).mapNotNull(sonarRepository::save);
    }
}
