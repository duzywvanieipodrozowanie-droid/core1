package pl.zenstage.api.rest;

public class Const {
    public static final String V1 = "/v1";
    public static final int MAX_RESULTS = 100;
}
