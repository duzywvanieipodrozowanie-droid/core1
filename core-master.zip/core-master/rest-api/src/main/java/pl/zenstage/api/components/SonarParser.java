package pl.zenstage.api.components;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.zs.ZsSonarStats;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SonarParser {
    private final ObjectMapper objectMapper;

    public ZsSonarStats parse(JsonNode report) {
        Map<String, BigDecimal> metrics = parseMetrics(report);
        return new ZsSonarStats(
                toIntSafe(metrics.get("new_bugs")),
                toIntSafe(metrics.get("new_duplicated_blocks")),
                toIntSafe(metrics.get("new_code_smells")),
                toIntSafe(metrics.get("new_technical_debt")),
                toIntSafe(metrics.get("new_violations")),
                toIntSafe(metrics.get("new_reliability_remediation_effort")),
                metrics.get("new_development_cost"),
                metrics.get("new_reliability_rating"),
                metrics.get("new_security_rating"),
                metrics.get("new_maintainability_rating"),
                metrics.get("new_duplicated_lines_density"),
                metrics.get("new_security_review_rating"),
                metrics.get("new_coverage"),
                toIntSafe(metrics.get("complexity")),
                toIntSafe(metrics.get("cognitive_complexity")),
                objectMapper.convertValue(report, new TypeReference<>() {
                })
        );
    }

    private Map<String, BigDecimal> parseMetrics(JsonNode report) {
        Map<String, BigDecimal> flattenMetrics = new HashMap<>();
        JsonNode measures = report.path("component").path("measures");
        if (measures.isArray()) {
            for (JsonNode metric : measures) {
                String key = metric.path("metric").asString("");
                if (key.isEmpty()) continue;
                BigDecimal value;
                if (key.startsWith("new_")) {
                    JsonNode periods = metric.path("periods");
                    if (periods.isArray() && !periods.isEmpty()) {
                        value = periods.get(0).path("value").asDecimal(null);
                    } else {
                        value = metric.path("period").path("value").asDecimal(null);
                    }
                } else {
                    value = metric.path("value").asDecimal(null);
                }
                flattenMetrics.put(key, value);
            }
        }
        return flattenMetrics;
    }

    private Integer toIntSafe(BigDecimal value) {
        return Optional.ofNullable(value).map(BigDecimal::intValue).orElse(null);
    }
}
