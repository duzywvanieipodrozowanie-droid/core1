package pl.zenstage.api.rest;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import pl.zenstage.api.components.ReleaseService;
import pl.zenstage.db.store.entity.release.ReleaseEntity;
import pl.zenstage.db.store.repository.ReleaseRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@org.springframework.web.bind.annotation.RestController
@RequestMapping(Const.V1 + "/release")
@RequiredArgsConstructor
public class ReleaseApiController {
    protected final ReleaseRepository releaseRepository;
    protected final ReleaseService releaseService;

    @GetMapping
    Flux<ReleaseEntity> get(
            @RequestParam(name = "projectName") String projectName,
            @RequestParam(name = "activeOnly", required = false, defaultValue = "true") Boolean activeOnly
    ) {
        return Mono.just(projectName).publishOn(Schedulers.boundedElastic()).flatMapIterable(p ->
                releaseRepository.findAllByProjectName(p, PageRequest.of(0, 10))
        ).filter(it -> !activeOnly || it.getStatus().isOpen());
    }

    @PutMapping("/create")
    Mono<ReleaseEntity> create(
            @RequestParam(name = "projectName") String projectName,
            @RequestParam(name = "bugfixParent", required = false) Long bugfixParent,
            @RequestBody ReleaseEntity.Content content
    ) {
//        if (bugfixParent != null) {
//            Mono<ReleaseEntity> parentRelease = Mono.just(bugfixParent).map(releaseRepository::findById)
//                    .filter(Optional::isPresent).map(Optional::get)
//                    .switchIfEmpty(Mono.error(new ZenStageException(HttpStatus.NOT_FOUND, "Parent not found")));
//            // TODO weryfikacja statusu
//            // parentRelease.filter(it -> it.getStatus().isOpen());
//        }
        return Mono.just(ReleaseEntity.create(projectName, bugfixParent, content))
                .map(releaseRepository::save);
    }

    @PutMapping("/updateStatus/{releaseId}/{status}")
    Mono<ReleaseEntity> update(
            @PathVariable("releaseId") Long releaseId,
            @PathVariable("status") ReleaseEntity.Status status,
            @RequestBody(required = false) ReleaseEntity.Content content
    ) {
        return releaseService.updateStatus(releaseId, status, content);
    }

    @PostMapping("/save")
    Mono<ReleaseEntity> save(
            @RequestBody ReleaseEntity content
    ) {
        return Mono.just(content).map(releaseRepository::save);
    }
}
