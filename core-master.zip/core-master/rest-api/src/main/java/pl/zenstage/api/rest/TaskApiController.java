package pl.zenstage.api.rest;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.api.components.ApiTaskService;
import pl.zenstage.api.task.Task;
import pl.zenstage.api.task.TaskStatus;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping(Const.V1 + "/task")
@RequiredArgsConstructor
public class TaskApiController {
    private final TaskRepository taskRepository;
    private final ApiTaskService apiTaskService;

    @GetMapping
    public Flux<TaskEntity> getAll(
            @RequestParam(name = "page", required = false, defaultValue = "0") int page,
            @RequestParam(name = "size", required = false, defaultValue = "100") int size
    ) {
        return Mono.just(PageRequest.of(page, size < Const.MAX_RESULTS ? size : Const.MAX_RESULTS)).flatMapIterable(taskRepository::findAll);
    }

    @PutMapping
    public Mono<TaskEntity> save(@RequestBody Task task) {
        return Mono.fromCallable(() -> apiTaskService.saveTask(task))
                .subscribeOn(Schedulers.boundedElastic());
    }

    @PutMapping("/{project}/{task}")
    public Mono<ResponseEntity<TaskEntity>> updateStatus(
            @PathVariable("project") String project,
            @PathVariable("task") String task,
            @RequestParam("status") TaskStatus status) {
        return Mono.just(new TaskEntity.Pk(project, task)).map(taskRepository::findById).filter(Optional::isPresent)
                .map(Optional::get).map(it -> {
                    it.setStatus(status);
                    return it;
                }).mapNotNull(taskRepository::save).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
    }

    /**
     * Po pełnym imporcie Jiry (ZS_TASKS_SINCE): usuwa zadania projektu, których kluczy nie ma w imporcie.
     */
    @PostMapping("/{project}/prune")
    public Mono<List<String>> prune(@PathVariable("project") String project, @RequestBody List<String> keys) {
        return Mono.fromCallable(() -> apiTaskService.deleteMissing(project, keys))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /** Keys of the project's tasks in progress or DONE (the importer checks whether they still exist in Jira). */
    @GetMapping("/{project}/open-keys")
    public Mono<List<String>> openKeys(@PathVariable("project") String project) {
        return Mono.fromCallable(() -> apiTaskService.openKeys(project))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /** Status of each of the project's tasks in progress or DONE (the importer re-imports the ones changed in Jira). */
    @GetMapping("/{project}/open-statuses")
    public Mono<Map<String, String>> openStatuses(@PathVariable("project") String project) {
        return Mono.fromCallable(() -> apiTaskService.openStatuses(project))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /** A task deleted (or moved to another key) in Jira. */
    @DeleteMapping("/{project}/{task}")
    public Mono<ResponseEntity<Void>> delete(@PathVariable("project") String project, @PathVariable("task") String task) {
        return Mono.fromCallable(() -> apiTaskService.delete(project, task))
                .subscribeOn(Schedulers.boundedElastic())
                .map(deleted -> deleted ? ResponseEntity.noContent().<Void>build() : ResponseEntity.notFound().<Void>build());
    }

    @GetMapping("/last-loaded")
    public Mono<LocalDateTime> lastLoaded(
            @RequestParam(name = "project", required = false) String project
    ) {
        return Mono.fromCallable(() -> taskRepository.findLatest(project.toLowerCase()))
                .subscribeOn(Schedulers.boundedElastic())
                .map(e -> e != null
                        ? (e.getUpdated() != null ? e.getUpdated() : e.getCreated())
                        : null
                );
    }


    @GetMapping("/refresh")
    public Mono<Integer> refresh() {
        return Mono.fromCallable(apiTaskService::refreshCreator)
                .subscribeOn(Schedulers.boundedElastic());
    }

}
