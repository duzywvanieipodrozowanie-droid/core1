package pl.zenstage.core.metrics.pr;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.mr.MergeRequest;
import pl.zenstage.api.mr.MrCommit;
import pl.zenstage.core.common.MathBigDecimal;
import pl.zenstage.core.metrics.commits.CommitCommonsService;
import pl.zenstage.core.metrics.commits.CommitService;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.response.ChartResponse;
import pl.zenstage.db.store.entity.PersonEntity;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.git.MergeRequestEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.PersonRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Service
@RequiredArgsConstructor
public class PullRequestService {
    public static final List<String> MR_ACTIVE_STATE = List.of("opened", "locked");
    private final CommitService commitService;
    private final CommitCommonsService commitCommonsService;
    private final PersonRepository personRepository;
    private final CommitRepository commitRepository;
    private final MrFlowService mrFlowService;

    public Mono<BigDecimal> prTp(String unitId, Interval.Range range) {
        return commitService.getUnitCommitsIfAllowed(unitId, range)
                .map(commits -> BigDecimal.valueOf(
                        CommitCommonsService.filterMergeCommits(commits)
                                .flatMap(commitCommonsService::findParentFeatureBranchCommit).count()
                ));
    }

    /** PR cycle time = lead time for changes (first commit -> merge into main/master), the same as on the DORA screen. */
    public Mono<BigDecimal> prCt(String unitId, Interval.Range range) {
        return mrFlowService.leadTime(unitId, range);
    }

    /**
     * Coding / pickup / review / merge per chart period, from merge requests merged into main/master (the same
     * {@link MrFlowService} phases as the DORA cycle time breakdown; together they add up to the lead time).
     * The summary is the average over the whole interval. Build time is not part of this breakdown (null).
     */
    public Mono<ChartResponse<PrChartTimeRecord>> cycleTimeChart(String unitId, Interval interval) {
        Interval.RangeFinder rangeFinder = interval.rangeFinder();
        return mrFlowService.flows(unitId, interval.range(0)).map(flows -> {
            Map<Interval.Range, List<MrFlowService.Flow>> byRange = flows.stream()
                    .collect(Collectors.groupingBy(it -> rangeFinder.findRange(it.mergedAt())));
            List<PrChartTimeRecord> values = rangeFinder.ranges().stream()
                    .map(range -> flowAverage(range.from().toLocalDate(), range.till().toLocalDate(), byRange.getOrDefault(range, List.of())))
                    .toList();
            // summary: previously built with the 6-argument constructor, which shifted every total by one field
            return new ChartResponse<>(values, flowAverage(null, null, flows));
        });
    }

    private static PrChartTimeRecord flowAverage(LocalDate from, LocalDate till, List<MrFlowService.Flow> flows) {
        return new PrChartTimeRecord(
                from,
                till,
                MathBigDecimal.avg(flows.stream().map(MrFlowService.Flow::coding).toList(), 1),
                MathBigDecimal.avg(flows.stream().map(MrFlowService.Flow::pickup).toList(), 1),
                MathBigDecimal.avg(flows.stream().map(MrFlowService.Flow::review).toList(), 1),
                null,
                MathBigDecimal.avg(flows.stream().map(MrFlowService.Flow::merge).toList(), 1)
        );
    }

    public Mono<ChartResponse<PrThroughputRecord>> throughputChart(String unitId, Interval interval) {
        return Flux.fromIterable(interval.rangeFinder().ranges()).flatMap(range -> dailyMergeFlow(unitId, range)).collectList()
                .map(values -> new ChartResponse<>(
                        values,
                        new PrThroughputRecord(
                                null, null,
                                MathBigDecimal.avg(values.stream().map(PrThroughputRecord::review).map(BigDecimal::valueOf).toList(), 0).intValue(),
                                MathBigDecimal.avg(values.stream().map(PrThroughputRecord::opened).map(BigDecimal::valueOf).toList(), 0).intValue(),
                                MathBigDecimal.avg(values.stream().map(PrThroughputRecord::merged).map(BigDecimal::valueOf).toList(), 0).intValue()
                        )
                ));
    }

    public Mono<PrFlow> prFlow(String unitId, Interval interval) {
        return Mono.zip(
                dailyMergeFlow(unitId, interval.range(1)),
                dailyMergeFlow(unitId, interval.range(0))
        ).map(it -> new PrFlow(
                it.getT2().opened(),
                it.getT2().opened() - it.getT1().opened(),
                it.getT2().merged(),
                it.getT2().merged() - it.getT1().merged(),
                it.getT2().review(),
                it.getT2().review() - it.getT1().review()

        ));
    }

    private Mono<PrThroughputRecord> dailyMergeFlow(String unitId, Interval.Range range) {
        return commitService.getUnitCommitsIfAllowed(unitId, range).zipWith(
                commitService.getUnitManageMrIfAllowed(unitId, range)
        ).map(t -> {
            List<CommitEntity> commits = t.getT1();
            List<MergeRequestEntity> mr = t.getT2();
            List<CommitEntity> mergedCommits = CommitCommonsService.filterMergeCommits(commits).toList();
            List<CommitEntity> activeFeatureBranches = commitCommonsService.filterActiveBranches(commits).toList();
            int active = (int) mr.stream().map(MergeRequestEntity::getSource).filter(it -> MR_ACTIVE_STATE.contains(it.state())).count();

            return new PrThroughputRecord(
                    range.from().toLocalDate(),
                    range.till().toLocalDate(),
                    active,
                    activeFeatureBranches.size(),
                    mergedCommits.size()
            );
        });
    }

    /**
     * The latest merge requests of the unit (by last activity) with their GitLab state.
     * "merged" means merged into a protected branch; an MR merged into an unprotected branch (e.g. a feature branch)
     * has not reached the first protected branch yet and is shown as "open". MRs imported before the target branch
     * was recorded (targetBranchProtected == null) count as merged when GitLab says so.
     */
    public Flux<PrLastItem> lastMergeRequests(String unitId, Interval interval) {
        return commitService.getUnitManageMrIfAllowed(unitId, interval.range(0)).flatMapIterable(mrs ->
                mrs.stream().filter(it -> it.getSource() != null)
                        .sorted(Comparator.comparing((MergeRequestEntity it) -> lastActivity(it.getSource())).reversed())
                        .limit(5)
                        .map(this::lastItem)
                        .toList()
        );
    }

    private PrLastItem lastItem(MergeRequestEntity entity) {
        MergeRequest mr = entity.getSource();
        boolean mergedInGitlab = "merged".equalsIgnoreCase(mr.state()) || mr.mergedAt() != null;
        PrState state = mergedInGitlab
                ? (Boolean.FALSE.equals(mr.targetBranchProtected()) ? PrState.open : PrState.merged)
                : "closed".equalsIgnoreCase(mr.state()) ? PrState.closed : PrState.open;
        String title = Optional.ofNullable(mr.title())
                .or(() -> Optional.ofNullable(entity.getCommitId())
                        .flatMap(sha -> commitRepository.findById(new CommitEntity.Pk(entity.getProjectId(), entity.getModuleName(), sha)))
                        .map(CommitEntity::getSource).map(Commit::title))
                .orElseGet(() -> "MR " + entity.getMrId());
        List<MrCommit> commits = Optional.ofNullable(mr.commits())
                .or(() -> Optional.ofNullable(entity.getCommitId())
                        .flatMap(sha -> commitRepository.findById(new CommitEntity.Pk(entity.getProjectId(), entity.getModuleName(), sha)))
                        .map(it -> List.of(new MrCommit(it.getCommitId(),
                                Optional.ofNullable(it.getSource()).map(Commit::title).orElse(null),
                                Optional.ofNullable(it.getSource()).map(Commit::authorName).orElse(null),
                                Optional.ofNullable(it.getSource()).map(Commit::committedDate).map(OffsetDateTime::toInstant).orElse(null)))))
                .orElse(List.of());
        String author = Optional.ofNullable(entity.getAuthorId()).flatMap(personRepository::findById).map(PersonEntity::getName)
                .orElseGet(() -> Optional.ofNullable(mr.authorEmail()).orElse(entity.getAuthorId()));
        return new PrLastItem(
                title,
                author,
                hoursSince(lastActivity(mr), Instant.now()),
                mr.mergedAt() != null && mr.createdAt() != null ? hoursSince(mr.createdAt(), mr.mergedAt()) : null,
                state,
                mr.targetBranch(),
                commits
        );
    }

    private static Instant lastActivity(MergeRequest mr) {
        return Stream.of(mr.mergedAt(), mr.closedAt(), mr.updatedAt(), mr.createdAt())
                .filter(Objects::nonNull).max(Instant::compareTo).orElse(Instant.EPOCH);
    }

    private static BigDecimal hoursSince(Instant from, Instant till) {
        return BigDecimal.valueOf(Duration.between(from, till).toMinutes()).divide(BigDecimal.valueOf(60), 1, RoundingMode.HALF_UP);
    }

}
