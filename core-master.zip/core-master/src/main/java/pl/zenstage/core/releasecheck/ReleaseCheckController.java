package pl.zenstage.core.releasecheck;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.releasecheck.ReleaseCheck.Comparison;
import pl.zenstage.core.releasecheck.ReleaseCheck.ReleaseTask;
import reactor.core.publisher.Mono;

import java.util.List;

/** Tests → Release check. */
@RestController
@RequestMapping("/release-check")
@RequiredArgsConstructor
public class ReleaseCheckController {
    private final ReleaseCheckService releaseCheckService;

    /** Environments of the service map (of the user's projects). */
    @GetMapping("/environments")
    public Mono<List<String>> environments() {
        return releaseCheckService.environments();
    }

    /** Release tasks of the unit in the status OPEN or DONE (DONE also LIVE, the last 20), the newest first. */
    @GetMapping("/releases")
    public Mono<List<ReleaseTask>> releases(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "OPEN") String status
    ) {
        return releaseCheckService.releases(unitId, status);
    }

    /** Environment against environment, e.g. ?from=alfa&to=beta. */
    @GetMapping("/environments/compare")
    public Mono<Comparison> compareEnvironments(
            @RequestParam(defaultValue = "alfa") String from,
            @RequestParam(defaultValue = "beta") String to
    ) {
        return releaseCheckService.environments(from, to);
    }

    /** Environment against the Fix Versions of a release task, e.g. ?key=REL-418&environment=beta. */
    @GetMapping("/release/compare")
    public Mono<Comparison> compareRelease(
            @RequestParam(required = false) String unitId,
            @RequestParam String key,
            @RequestParam(defaultValue = "beta") String environment
    ) {
        return releaseCheckService.release(unitId, key, environment);
    }
}
