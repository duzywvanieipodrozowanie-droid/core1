package pl.zenstage.core.metrics;

import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pl.zenstage.api.task.Task;
import pl.zenstage.api.task.TaskDto;
import pl.zenstage.api.task.TaskStatus;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.core.metrics.response.UnknownTasker;
import pl.zenstage.db.store.repository.TaskHistoryRepository;
import pl.zenstage.db.store.repository.model.SprintCapacityAggregatedRow;
import pl.zenstage.core.metrics.team.SprintTeamCapacityResponse;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.repository.SprintRepository;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class JiraTaskService {
    private final OrganizationService organizationService;
    private final TaskRepository taskRepository;
    private final TaskHistoryRepository taskHistoryRepository;
    private final SprintRepository sprintRepository;

    public Mono<Map<String, List<TaskDto>>> tree() {
        Flux<String> userProjects = organizationService.getUserProjects().flatMapIterable(Map::keySet)
                .switchIfEmpty(Mono.error(new ZenStageException(HttpStatus.FORBIDDEN)));

        return userProjects.publishOn(Schedulers.boundedElastic())
                .map(proj -> Pair.of(proj, buildHierarchy(proj.toUpperCase())))
                .filter(it -> it.getRight() != null).collect(Collectors.toMap(Pair::getLeft, Pair::getRight));
    }

    private List<TaskDto> buildHierarchy(String projectId) {
        List<TaskEntity> projectEntity = Optional.ofNullable(projectId).map(taskRepository::findByProjectId).orElse(Collections.emptyList());
        if (projectEntity.isEmpty()) {
            return Collections.emptyList();
        }
        List<Task> projectTasks = projectEntity.stream().map(TaskEntity::getContent).toList();

        Set<String> allKeys = projectTasks.stream().map(Task::key).collect(Collectors.toSet());
        Map<String, List<Task>> byParent = new HashMap<>();
        projectTasks.stream().filter(it -> it.parentKey() != null).forEach(task -> {
            byParent.computeIfAbsent(task.projectId(), t -> new LinkedList<>()).add(task);
        });

        List<Task> rootsCandidate = new LinkedList<>(projectTasks.stream()
                .filter(it -> it.parentKey() == null)
                .toList());
        rootsCandidate.addAll(
                byParent.keySet().stream().filter(it -> !allKeys.contains(it)).map(byParent::get).filter(Objects::nonNull)
                        .flatMap(Collection::stream).toList() // unknown parents - display as root
        );
        List<TaskDto> roots = new LinkedList<>(
                rootsCandidate.stream().filter(it -> byParent.containsKey(it.key())).map(r -> map(r, byParent)).toList()
        );
        roots.add(new TaskDto(
                projectId,
                "NONE",
                null,       // parentKey
                null,                // url
                "VIRTUAL",           // type (pseudo-wezel)
                null,                // priority
                null,                // assignee
                null,                // creator
                TaskStatus.OPEN,     // status
                List.of(),           // labels
                "Single tasks",      // summary
                List.of(),           // text
                BigDecimal.valueOf(1.0),// estimate
                null,                // updated
                null,                // created
                null,                // histories
                null,                // sprints
                rootsCandidate.stream()
                        .filter(it -> !byParent.containsKey(it.key()))
                        .map(it -> map(it, Collections.emptyMap()))
                        .toList()
        ));


        return roots;
    }

    private TaskDto map(Task task, Map<String, List<Task>> parentCache) {
        List<TaskDto> subTasks = Optional.of(task).map(Task::key).map(parentCache::get).orElse(Collections.emptyList()).stream()
                .map(it -> map(it, parentCache)).toList();
        return TaskDto.map(task, subTasks);
    }


    public Mono<SprintTeamCapacityResponse> getUnitCapacity(String unitId) {
        return organizationService.userManageAllowed(unitId)
                .publishOn(Schedulers.boundedElastic())
                .flatMapIterable(organizationService::getUnitProjects)
                .distinct()
                .collectList()
                .flatMap(projects -> calculateUnitCapacity(projects));
    }

    @Transactional(readOnly = true)
    public Mono<SprintTeamCapacityResponse> calculateUnitCapacity(List<String> projectIds) {
        if (projectIds == null || projectIds.isEmpty()) {
            return Mono.just(new SprintTeamCapacityResponse(List.of(), 0));
        }

        return Mono.fromCallable(() -> {
            List<SprintCapacityAggregatedRow> rows = sprintRepository.findAggregatedCapacityForProjects(projectIds);
            if (rows.isEmpty()) {
                return new SprintTeamCapacityResponse(List.of(), 0);
            }

            int totalAnalyzedSprints = sprintRepository.countRecentSprintsForProjects(projectIds);

            List<SprintTeamCapacityResponse.SprintUserComprehensiveDto> users = rows.stream()
                    .map(this::mapToUserDto)
                    .toList();

            return new SprintTeamCapacityResponse(users, totalAnalyzedSprints);
        }).subscribeOn(Schedulers.boundedElastic());
    }

    private SprintTeamCapacityResponse.SprintUserComprehensiveDto mapToUserDto(SprintCapacityAggregatedRow row) {
        // 1. Statystyki historyczne
        var historicalMetrics = new SprintTeamCapacityResponse.SprintUserComprehensiveDto.HistoricalSprintMetrics(
                row.getAvgTotalTasksPerSprint() != null ? row.getAvgTotalTasksPerSprint() : 0.0,
                row.getAvgTotalEstimatePerSprint() != null ? row.getAvgTotalEstimatePerSprint() : BigDecimal.ZERO,
                row.getAvgInitialTasksPerSprint() != null ? row.getAvgInitialTasksPerSprint() : 0.0,
                row.getAvgInitialEstimatePerSprint() != null ? row.getAvgInitialEstimatePerSprint() : BigDecimal.ZERO,
                row.getAvgAddedTasksPerSprint() != null ? row.getAvgAddedTasksPerSprint() : 0.0,
                row.getAvgAddedEstimatePerSprint() != null ? row.getAvgAddedEstimatePerSprint() : BigDecimal.ZERO,
                row.getAvgCompletedTasksPerSprint() != null ? row.getAvgCompletedTasksPerSprint() : 0.0,
                row.getAvgCompletionRatePercentage() != null ? row.getAvgCompletionRatePercentage() : 0.0
        );

        // 2. Statystyki obecnego sprintu (jeśli jest aktywny sprint i user ma w nim zadania)
        SprintTeamCapacityResponse.SprintUserComprehensiveDto.CurrentSprintMetrics currentMetrics = null;
        if (row.getActiveSprintName() != null && row.getCurrentTotalTasks() != null) {
            currentMetrics = new SprintTeamCapacityResponse.SprintUserComprehensiveDto.CurrentSprintMetrics(
                    row.getActiveSprintName(),
                    row.getCurrentTotalTasks(),
                    row.getCurrentTotalEstimate(),
                    row.getCurrentInitialTasks() != null ? row.getCurrentInitialTasks() : 0L,
                    row.getCurrentInitialEstimate(),
                    row.getCurrentAddedTasks() != null ? row.getCurrentAddedTasks() : 0L,
                    row.getCurrentAddedEstimate(),
                    row.getCurrentCompletedTasks() != null ? row.getCurrentCompletedTasks() : 0L,
                    row.getCurrentCompletionRatePercentage() != null ? row.getCurrentCompletionRatePercentage() : 0.0
            );
        }

        return new SprintTeamCapacityResponse.SprintUserComprehensiveDto(
                row.getAssigneeId(),
                historicalMetrics,
                currentMetrics
        );
    }

    public Flux<UnknownTasker> getUnknownTaskers() {
        // 1. Strumień nieznanych użytkowników z TaskEntity (creator + assignee)
        Flux<String> taskUsers = Mono.fromCallable(taskRepository::findContentsWithUnassignedUsers)
                .subscribeOn(Schedulers.boundedElastic()) // zapobiega blokowaniu wątku reaktywnego przy JDBC
                .flatMapIterable(list -> list)
                .flatMap(task -> {
                    List<String> accounts = new ArrayList<>();
                    if (task.creator() != null && task.creator().accountId() != null) {
                        accounts.add(task.creator().accountId());
                    }
                    if (task.assignee() != null && task.assignee().accountId() != null) {
                        accounts.add(task.assignee().accountId());
                    }
                    return Flux.fromIterable(accounts);
                });

        // 2. Strumień nieznanych autorów z TaskHistoryEntity
        Flux<String> historyUsers = Mono.fromCallable(taskHistoryRepository::findContentsWithUnassignedAuthor)
                .subscribeOn(Schedulers.boundedElastic())
                .flatMapIterable(list -> list)
                .filter(history -> history.author() != null && history.author().accountId() != null)
                .map(history -> history.author().accountId());

        // 3. Połączenie obu źródeł, odsianie duplikatów i zmapowanie do DTO
        return Flux.merge(taskUsers, historyUsers)
                .filter(accountId -> !accountId.isBlank())
                .distinct()
                .map(UnknownTasker::new);
    }
}
