
package pl.zenstage.core.metrics;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.api.task.TaskDto;
import pl.zenstage.core.metrics.commits.GitlabCommitersService;
import pl.zenstage.core.metrics.response.UnknownCommitter;
import pl.zenstage.core.metrics.response.UnknownTasker;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/metrics")
@RequiredArgsConstructor
public class MetricsController {
    private final GitlabCommitersService gitlabCommitersService;
    private final JiraTaskService jiraTaskService;

    /** Authors of the commits of the last {@code days} days (default 30) not assigned to any person. */
    @GetMapping("/alert/unknown-commiters")
    public Flux<UnknownCommitter> getUnknownEmails(@RequestParam(name = "days", defaultValue = "" + GitlabCommitersService.DEFAULT_DAYS) int days) {
        return gitlabCommitersService.getUnknownCommiters(days);
    }

    @GetMapping("/alert/unknown-taskers")
    public Flux<UnknownTasker> getUnknownTaskers() {
        return jiraTaskService.getUnknownTaskers();
    }

    @GetMapping("task/tree")
    public Mono<Map<String, List<TaskDto>>> getTaskTree() {
        return jiraTaskService.tree();
    }
}
