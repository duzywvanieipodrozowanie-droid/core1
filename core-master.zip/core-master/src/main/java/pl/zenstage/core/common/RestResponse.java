package pl.zenstage.core.common;

import lombok.Getter;

import java.time.ZonedDateTime;

@Getter
public class RestResponse<T> {
    private T content;
    private String error;

    public RestResponse(String error) {
        this.error = error;
    }

    public RestResponse(String error, T content) {
        this.error = error;
        this.content = content;
    }

    public RestResponse(T content) {
        this.content = content;
    }

    public ZonedDateTime getTimestamp() {
        return ZonedDateTime.now();
    }
}
