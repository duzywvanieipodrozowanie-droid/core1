package pl.zenstage.core.access;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.access.AccessService.MyAccess;
import pl.zenstage.core.access.AccessService.PageView;
import pl.zenstage.core.access.AccessService.Role;
import pl.zenstage.core.access.AccessService.UserView;
import pl.zenstage.core.admin.Const;
import pl.zenstage.core.common.ZsCommons;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.List;
import java.util.Map;
import java.util.Set;

/** Users and access: what the logged-in user may open, and (ADMIN only, under /admin) the roles of users and pages. */
@RestController
@RequiredArgsConstructor
public class AccessController {
    private final AccessService accessService;

    @GetMapping("/access")
    Mono<MyAccess> myAccess() {
        return ZsCommons.currentUserName().flatMap(accessService::currentAccess);
    }

    @GetMapping(Const.ADMIN + "/access/users")
    Mono<List<UserView>> users() {
        return Mono.fromCallable(accessService::users).subscribeOn(Schedulers.boundedElastic());
    }

    @PutMapping(Const.ADMIN + "/access/users/{userId}")
    Mono<UserView> updateUser(@PathVariable String userId, @RequestBody AccessService.UserUpdate update) {
        return Mono.fromCallable(() -> accessService.update(userId, update)).subscribeOn(Schedulers.boundedElastic());
    }

    @GetMapping(Const.ADMIN + "/access/pages")
    Mono<List<PageView>> pages() {
        return Mono.fromCallable(accessService::pages).subscribeOn(Schedulers.boundedElastic());
    }

    @PutMapping(Const.ADMIN + "/access/pages")
    Mono<List<PageView>> savePages(@RequestBody Map<String, Set<Role>> roles) {
        return Mono.fromCallable(() -> accessService.savePages(roles)).subscribeOn(Schedulers.boundedElastic());
    }
}
