package pl.zenstage.core.codemap;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.codemap.response.CodeMapIssues;
import pl.zenstage.core.codemap.response.CodeMapModule;
import pl.zenstage.core.organization.components.OrganizationService;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;

@RestController
@RequestMapping("/codemap")
@RequiredArgsConstructor
public class CodeMapController {
    private final CodeMapService codeMapService;
    private final OrganizationService organizationService;

    @GetMapping(produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    Flux<CodeMapModule> stream() {
        Flux<CodeMapModule> heartbeat = Flux.interval(Duration.ofSeconds(15))
                .map(_ -> new CodeMapModule(null, null, null));
        Flux<String> userContributedProjects = organizationService.getUserContributedProjects();
        Flux<CodeMapModule> userProjectsStream = codeMapService.live().filterWhen(it -> userContributedProjects.any(up -> up.equals(it.projectId())));
        return Flux.merge(heartbeat, codeMapService.init(), userProjectsStream);
    }

    /** Jira issues in one version (image tag) of a microservice: by Fix Version and by the release tasks with it. */
    @GetMapping(path = "/issues", produces = MediaType.APPLICATION_JSON_VALUE)
    Mono<CodeMapIssues> issues(@RequestParam String module, @RequestParam String tag) {
        return codeMapService.issues(module, tag);
    }

    /** The same modules once, as a JSON list (the service map screen; a proxy may buffer the event stream). */
    @GetMapping(path = "/modules", produces = MediaType.APPLICATION_JSON_VALUE)
    Flux<CodeMapModule> modules() {
        return codeMapService.init().subscribeOn(Schedulers.boundedElastic());
    }
}
