package pl.zenstage.core.investments;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.task.TaskDto;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.response.ChartResponse;
import pl.zenstage.core.metrics.response.InvestmentResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.IntStream;

@Service
@RequiredArgsConstructor
public class InvestmentService {

    private final TaskService taskService;

    public Mono<InvestmentResponse> total(String unitId, Interval.Range range) {
        Boolean bau = null;
        return taskService.getUnitSimpleTasksIfAllowed(unitId, range)
                .map(tasks -> {
                    List<Investment> investments = TaskCommonsService.filterTasks(tasks, bau);
                    InvestmentResponse.Percent percent = null;
                    List<TaskDto> bauTasks = List.of();
                    List<TaskDto> featureTasks = List.of();
                    if (bau == null && !tasks.isEmpty()) {
                        long bauCount = tasks.stream().filter(t -> Boolean.TRUE.equals(t.getBau())).count();
                        long featureCount = tasks.size() - bauCount;
                        percent = new InvestmentResponse.Percent(
                                (int) (bauCount * 100 / tasks.size()),
                                (int) (featureCount * 100 / tasks.size())
                        );
                        bauTasks = tasks.stream()
                                .filter(t -> Boolean.TRUE.equals(t.getBau()))
                                .map(t -> TaskDto.map(t.getContent()))
                                .toList();
                        featureTasks = tasks.stream()
                                .filter(t -> Boolean.FALSE.equals(t.getBau()) || t.getBau() == null)
                                .map(t -> TaskDto.map(t.getContent()))
                                .toList();
                    }
                    return new InvestmentResponse(investments, percent, bauTasks, featureTasks);
                });
    }

    public Mono<List<InvestmentTeam>> teams(String unitId, Interval.Range range) {
        return taskService.getUnitSimpleTasksIfAllowed(unitId, range)
                .map(tasks -> TaskCommonsService.filterTasksByTeams(tasks, null));
    }

    public Mono<ChartResponse<List<Investment>>> chartTotal(String unitId, Interval interval) {
        return Flux.fromIterable(
                        IntStream.rangeClosed(0, 3)
                                .mapToObj(offset -> interval.range(3 - offset))
                                .toList()
                )
                .concatMap(range -> total(unitId, range))
                .collectList()
                .map(values -> new ChartResponse<>(
                        values.stream().map(InvestmentResponse::investments).toList(),
                        values.stream()
                                .flatMap(r -> r.investments().stream())
                                .toList()
                ));
    }

}
