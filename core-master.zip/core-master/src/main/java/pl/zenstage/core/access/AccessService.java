package pl.zenstage.core.access;

import lombok.extern.log4j.Log4j2;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.authorization.AuthorizationResult;
import org.springframework.security.authorization.ReactiveAuthorizationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.server.authorization.AuthorizationContext;
import org.springframework.stereotype.Service;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.organization.dto.Unit;
import pl.zenstage.db.store.entity.AppUserEntity;
import pl.zenstage.db.store.entity.PersonEntity;
import pl.zenstage.db.store.entity.UserConfigEntity;
import pl.zenstage.db.store.repository.AppUserRepository;
import pl.zenstage.db.store.repository.PersonRepository;
import pl.zenstage.db.store.repository.UserConfigRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Users and access (Settings → Users and access): the {@code app_user} table with every person and every user who
 * logged in, their roles and the roles allowed on every menu page.
 * <ul>
 *     <li>ADMIN - flag in {@code app_user}; sees every page; while nobody is an admin, everyone is (first start of a new installation)</li>
 *     <li>MANAGER - flag in {@code app_user}, and every manager of a unit of the organization</li>
 *     <li>DOMAIN_LEADER (IT Domain Leader), PO, TECH_LEAD - flags in {@code app_user}</li>
 *     <li>DEVELOPER - flag in {@code app_user}, on for new users</li>
 * </ul>
 * A page is open for the roles set for it (any of them is enough) and always for ADMIN.
 * Roles are checked on every request, so a change in Settings works without logging in again.
 */
@Log4j2
@Service
public class AccessService {
    static final String PAGES_CONFIG_KEY = "zenstage:page-access";
    private static final String CREATE_TABLE = """
            CREATE TABLE IF NOT EXISTS app_user (
                id VARCHAR(255) PRIMARY KEY,
                name VARCHAR(255),
                email VARCHAR(255),
                admin BOOLEAN NOT NULL DEFAULT FALSE,
                developer BOOLEAN NOT NULL DEFAULT TRUE,
                tech_lead BOOLEAN NOT NULL DEFAULT FALSE,
                manager BOOLEAN NOT NULL DEFAULT FALSE,
                po BOOLEAN NOT NULL DEFAULT FALSE,
                domain_leader BOOLEAN NOT NULL DEFAULT FALSE,
                created TIMESTAMP,
                last_login TIMESTAMP
            )""";
    // app_user created before the roles; a column added by ddl-auto update can be nullable and hold nulls
    private static final List<String> ADD_COLUMNS = List.of("tech_lead", "manager", "po", "domain_leader").stream()
            .flatMap(it -> Stream.of(
                    "ALTER TABLE app_user ADD COLUMN IF NOT EXISTS " + it + " BOOLEAN NOT NULL DEFAULT FALSE",
                    "UPDATE app_user SET " + it + " = FALSE WHERE " + it + " IS NULL",
                    "ALTER TABLE app_user ALTER COLUMN " + it + " SET DEFAULT FALSE",
                    "ALTER TABLE app_user ALTER COLUMN " + it + " SET NOT NULL"))
            .toList();
    // the format of the stored page roles: 1 (no version) every page with its minimal role, 2 the minimal roles
    // differing from the defaults, 3 the sets of roles differing from the defaults
    private static final String PAGES_VERSION = "_version";
    // defaults changed since the pages were stored with every role: an old default stored is no choice
    private static final Map<String, Role> OLD_DEFAULTS = Map.of("deliver", Role.ADMIN, "task-timeline", Role.ADMIN);

    public enum Role {ADMIN, DOMAIN_LEADER, MANAGER, PO, TECH_LEAD, DEVELOPER}

    private static final Set<Role> EVERYONE = Collections.unmodifiableSet(EnumSet.complementOf(EnumSet.of(Role.ADMIN)));
    private static final Set<Role> ADMIN_ONLY = Collections.unmodifiableSet(EnumSet.noneOf(Role.class));
    private static final Set<Role> LEADS = Collections.unmodifiableSet(EnumSet.of(Role.DOMAIN_LEADER, Role.MANAGER, Role.PO, Role.TECH_LEAD));

    /** A menu page of the GUI; {@code apiPaths} are core endpoints of the page guarded with the same rule. */
    public record Page(String key, String name, Set<Role> defaultRoles, List<String> apiPaths) {
    }

    public static final List<Page> PAGES = List.of(
            new Page("overview", "Overview", EVERYONE, List.of()),
            new Page("product", "Product overview", EnumSet.of(Role.DOMAIN_LEADER, Role.MANAGER, Role.PO), List.of("/product/**")),
            new Page("dora", "DORA Metrics", EVERYONE, List.of()),
            new Page("investments", "Investments", EVERYONE, List.of()),
            new Page("roadmap", "Roadmap", LEADS, List.of("/metrics/roadmap", "/metrics/roadmap/**")),
            new Page("team", "Team", EVERYONE, List.of()),
            new Page("gitlab-details", "GitLab Details", EVERYONE, List.of()),
            new Page("my-metrics", "My Metrics", EVERYONE, List.of()),
            new Page("deliver", "Deliver", LEADS, List.of("/metrics/deliver/**")),
            new Page("production-support", "Production support", EVERYONE, List.of()),
            new Page("release", "Release", EVERYONE, List.of()),
            new Page("deployments", "Deployments", EVERYONE, List.of()),
            new Page("code-impact", "Code Impact", ADMIN_ONLY, List.of("/metrics/code-impact/**")),
            new Page("service-map", "Service Map", EVERYONE, List.of("/codemap", "/codemap/**")),
            new Page("architecture", "Architecture (C4)", EVERYONE, List.of("/architecture", "/architecture/**")),
            new Page("release-check", "Release check", EVERYONE, List.of("/release-check/**")),
            new Page("task-timeline", "Task Timeline", LEADS, List.of("/metrics/task-timeline/**")),
            new Page("vendor-assessment", "Vendor Assessment", ADMIN_ONLY, List.of("/vendor-assessment/**"))
    );

    /** Flags of a user to change, {@code null} = unchanged. */
    public record UserUpdate(Boolean admin, Boolean developer, Boolean techLead, Boolean manager, Boolean po, Boolean domainLeader) {
    }

    /** {@code manager} is the flag, {@code managedUnits} the units the user manages (MANAGER also without the flag). */
    public record UserView(String id, String name, String email, boolean admin, boolean developer, boolean techLead, boolean manager,
                           boolean po, boolean domainLeader, List<String> managedUnits, Set<Role> roles,
                           LocalDateTime created, LocalDateTime lastLogin) {
    }

    public record PageView(String key, String name, Set<Role> roles, Set<Role> defaultRoles) {
    }

    /** What the logged-in user may see: roles and the keys of the allowed pages. */
    public record MyAccess(String userId, Set<Role> roles, List<String> pages) {
    }

    private final AppUserRepository appUserRepository;
    private final PersonRepository personRepository;
    private final UserConfigRepository userConfigRepository;
    private final OrganizationService organizationService;
    private final JdbcTemplate jdbcTemplate;
    private final Map<String, AppUserEntity> users = new ConcurrentHashMap<>();
    private volatile Map<String, Set<Role>> pageRoles = Map.of();
    private volatile boolean ready;

    AccessService(AppUserRepository appUserRepository, PersonRepository personRepository, UserConfigRepository userConfigRepository,
                  OrganizationService organizationService, JdbcTemplate jdbcTemplate) {
        this.appUserRepository = appUserRepository;
        this.personRepository = personRepository;
        this.userConfigRepository = userConfigRepository;
        this.organizationService = organizationService;
        this.jdbcTemplate = jdbcTemplate;
    }

    @EventListener(ApplicationReadyEvent.class)
    void init() {
        jdbcTemplate.execute(CREATE_TABLE);
        ADD_COLUMNS.forEach(jdbcTemplate::execute);
        loadPageRoles();
        importPersons();
        ready = true;
    }

    /** Every person not in {@code app_user} yet (also the ones added in the organization setup) gets in, as a developer. */
    @Scheduled(fixedRate = 300_000, initialDelay = 300_000)
    public synchronized void importPersons() {
        appUserRepository.findAll().forEach(it -> users.put(it.getId(), it));
        List<AppUserEntity> added = new ArrayList<>();
        for (PersonEntity person : personRepository.findAll()) {
            if (person.getId() == null || users.containsKey(person.getId())) continue;
            // person.admin is where admins were kept before, so they stay admins
            added.add(new AppUserEntity(person.getId(), person.getName(), person.getEmail(), person.isAdmin(), LocalDateTime.now()));
        }
        if (!added.isEmpty()) {
            appUserRepository.saveAll(added).forEach(it -> users.put(it.getId(), it));
            log.info("Users and access: {} persons added to app_user", added.size());
        }
    }

    /** At login: a new user gets into {@code app_user} as a developer, a known one gets the time of the login. */
    public synchronized void loggedIn(String userId, String name, String email) {
        if (userId == null || userId.isBlank()) return;
        AppUserEntity user = Optional.ofNullable(users.get(userId)).or(() -> appUserRepository.findById(userId))
                .orElseGet(() -> {
                    PersonEntity person = personRepository.findById(userId).orElse(null);
                    return new AppUserEntity(userId, person != null ? person.getName() : null, person != null ? person.getEmail() : null,
                            person != null && person.isAdmin(), LocalDateTime.now());
                });
        if (user.getName() == null) user.setName(name);
        if (user.getEmail() == null) user.setEmail(email);
        user.setLastLogin(LocalDateTime.now());
        users.put(userId, appUserRepository.save(user));
    }

    public Set<Role> roles(String userId) {
        Set<Role> roles = EnumSet.noneOf(Role.class);
        if (userId == null) return roles;
        AppUserEntity user = users.get(userId);
        // while nobody is an admin, everyone is one (as before); nobody until the table is loaded at start
        if ((ready && noAdmins()) || (user != null && user.isAdmin())) roles.add(Role.ADMIN);
        if ((user != null && user.isManager()) || organizationService.managedUnits(userId).findAny().isPresent()) roles.add(Role.MANAGER);
        if (user != null && user.isDomainLeader()) roles.add(Role.DOMAIN_LEADER);
        if (user != null && user.isPo()) roles.add(Role.PO);
        if (user != null && user.isTechLead()) roles.add(Role.TECH_LEAD);
        if (user == null || user.isDeveloper()) roles.add(Role.DEVELOPER);
        return roles;
    }

    private boolean noAdmins() {
        return users.values().stream().noneMatch(AppUserEntity::isAdmin);
    }

    static boolean allowed(Set<Role> roles, Set<Role> pageRoles) {
        return roles.contains(Role.ADMIN) || roles.stream().anyMatch(pageRoles::contains);
    }

    public Set<Role> pageRoles(String key) {
        return Optional.ofNullable(pageRoles.get(key))
                .orElseGet(() -> PAGES.stream().filter(it -> it.key().equals(key)).map(Page::defaultRoles).findFirst().orElse(ADMIN_ONLY));
    }

    public MyAccess myAccess(String userId) {
        Set<Role> roles = roles(userId);
        return new MyAccess(userId, roles, PAGES.stream().map(Page::key).filter(key -> allowed(roles, pageRoles(key))).toList());
    }

    /** Guard of core endpoints: the user needs a role of the page (or ADMIN for {@code null}). */
    public ReactiveAuthorizationManager<AuthorizationContext> requirePage(String pageKey) {
        return (authentication, context) -> authentication
                .filter(Authentication::isAuthenticated)
                .publishOn(Schedulers.boundedElastic())
                .map(it -> new AuthorizationDecision(allowed(roles(it.getName()), pageKey == null ? ADMIN_ONLY : pageRoles(pageKey))))
                .defaultIfEmpty(new AuthorizationDecision(false))
                .cast(AuthorizationResult.class);
    }

    public List<UserView> users() {
        return users.values().stream()
                .map(this::view)
                .sorted(Comparator.comparing((UserView it) -> Objects.toString(it.name(), it.id()), String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    private UserView view(AppUserEntity user) {
        List<String> managed = organizationService.managedUnits(user.getId()).map(Unit::name).toList();
        return new UserView(user.getId(), user.getName(), user.getEmail(), user.isAdmin(), user.isDeveloper(), user.isTechLead(),
                user.isManager(), user.isPo(), user.isDomainLeader(), managed, roles(user.getId()), user.getCreated(), user.getLastLogin());
    }

    public synchronized UserView update(String userId, UserUpdate update) {
        Boolean admin = update.admin();
        AppUserEntity user = Optional.ofNullable(users.get(userId))
                .orElseThrow(() -> new ZenStageException(HttpStatus.NOT_FOUND, "USER_NOT_FOUND", "No user " + userId));
        // without any admin everyone would become one, so the last admin stays
        if (Boolean.FALSE.equals(admin) && user.isAdmin() && appUserRepository.countByAdminTrue() <= 1) {
            throw new ZenStageException(HttpStatus.CONFLICT, "LAST_ADMIN", "At least one user has to stay an admin");
        }
        if (admin != null) user.setAdmin(admin);
        if (update.developer() != null) user.setDeveloper(update.developer());
        if (update.techLead() != null) user.setTechLead(update.techLead());
        if (update.manager() != null) user.setManager(update.manager());
        if (update.po() != null) user.setPo(update.po());
        if (update.domainLeader() != null) user.setDomainLeader(update.domainLeader());
        AppUserEntity saved = appUserRepository.save(user);
        users.put(userId, saved);
        return view(saved);
    }

    public List<PageView> pages() {
        return PAGES.stream().map(it -> new PageView(it.key(), it.name(), pageRoles(it.key()), it.defaultRoles())).toList();
    }

    public synchronized List<PageView> savePages(Map<String, Set<Role>> roles) {
        // only the roles differing from the defaults, so a changed default works for the pages nobody changed
        Map<String, Object> stored = new LinkedHashMap<>();
        stored.put(PAGES_VERSION, 3);
        PAGES.forEach(page -> {
            Set<Role> chosen = Optional.ofNullable(roles.get(page.key())).map(AccessService::withoutAdmin).orElse(pageRoles(page.key()));
            if (!chosen.equals(page.defaultRoles())) stored.put(page.key(), chosen.stream().map(Enum::name).sorted().toList());
        });
        userConfigRepository.save(new UserConfigEntity(PAGES_CONFIG_KEY, stored));
        loadPageRoles();
        return pages();
    }

    private static Set<Role> withoutAdmin(Set<Role> roles) {
        Set<Role> result = EnumSet.noneOf(Role.class);
        result.addAll(roles);
        result.remove(Role.ADMIN);
        return result;
    }

    /** A minimal role stored before the sets: the roles that were at least that role then. */
    private static Set<Role> fromMinimal(Role minimal) {
        return switch (minimal) {
            case ADMIN -> ADMIN_ONLY;
            case MANAGER -> EnumSet.of(Role.MANAGER);
            case TECH_LEAD -> EnumSet.of(Role.MANAGER, Role.TECH_LEAD);
            default -> EVERYONE;
        };
    }

    private void loadPageRoles() {
        Map<String, Object> stored = userConfigRepository.findById(PAGES_CONFIG_KEY).map(UserConfigEntity::getConfig).orElseGet(Collections::emptyMap);
        Map<String, Set<Role>> result = new LinkedHashMap<>();
        boolean everyPage = !stored.containsKey(PAGES_VERSION);
        stored.forEach((key, value) -> {
            if (key.equals(PAGES_VERSION)) return;
            try {
                if (value instanceof Collection<?> list) {
                    result.put(key, withoutAdmin(list.stream().map(it -> Role.valueOf(Objects.toString(it).toUpperCase()))
                            .collect(Collectors.toCollection(() -> EnumSet.noneOf(Role.class)))));
                    return;
                }
                Role role = Role.valueOf(Objects.toString(value, "").toUpperCase());
                if (everyPage && role == OLD_DEFAULTS.get(key)) return;
                result.put(key, fromMinimal(role));
            } catch (IllegalArgumentException e) {
                log.warn("Users and access: unknown role {} of page {}", value, key);
            }
        });
        pageRoles = Map.copyOf(result);
    }

    public Mono<MyAccess> currentAccess(String userId) {
        return Mono.fromCallable(() -> myAccess(userId)).subscribeOn(Schedulers.boundedElastic());
    }
}
