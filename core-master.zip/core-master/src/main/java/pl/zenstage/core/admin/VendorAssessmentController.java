package pl.zenstage.core.admin;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.admin.service.PeoplesAdminService;
import pl.zenstage.core.common.ZsCommons;
import pl.zenstage.core.organization.dto.Person;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

/**
 * The people of the organization for the Vendor Assessment page, guarded with the role of the page
 * (Settings → Users and access) instead of ADMIN as everything under {@code /admin}.
 */
@RestController
@RequiredArgsConstructor
public class VendorAssessmentController {
    private final PeoplesAdminService peoplesAdminService;

    @GetMapping("/vendor-assessment/peoples")
    Flux<Person> peoples() {
        return ZsCommons.currentUser().publishOn(Schedulers.boundedElastic())
                .map(peoplesAdminService::getPeoples)
                .flatMapIterable(it -> it);
    }
}
