package pl.zenstage.core.metrics;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.benchmark.BenchmarkResponse;
import pl.zenstage.core.metrics.benchmark.BenchmarkService;
import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/metrics/benchmark")
@RequiredArgsConstructor
public class BenchmarkController {
    private final BenchmarkService benchmarkService;

    /** Overview widgets of the unit against the average of all units of its type in the organization. */
    @GetMapping("/overview")
    public Mono<ResponseEntity<BenchmarkResponse>> overview(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return benchmarkService.overviewBenchmark(unitId, interval).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    /** DORA widgets of the unit against the average of all units of its type. */
    @GetMapping("/dora")
    public Mono<ResponseEntity<BenchmarkResponse>> dora(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return benchmarkService.doraBenchmark(unitId, interval).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }
}
