package pl.zenstage.core.license;

public record License(
        String license,
        String signature
) {
}

