package pl.zenstage.core.organization.dto;

import java.util.List;
import java.util.Map;

public record ZsUserSessionDto(
        String givenName,
        String userId,
        List<String> authorities,
        Map<String, ProjectScope> grants
) {

}
