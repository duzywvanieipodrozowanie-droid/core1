package pl.zenstage.core.metrics.codeimpact;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/metrics/code-impact")
@RequiredArgsConstructor
public class CodeImpactController {
    private final CodeImpactService codeImpactService;

    @GetMapping
    public Mono<CodeImpactResponse> codeImpact(
            @RequestParam(required = false) String unitId,
            // ownership needs a long history, hence the 12 months default
            @RequestParam(required = false, defaultValue = "MONTHS_12") Interval interval
    ) {
        return codeImpactService.codeImpact(unitId, interval);
    }
}
