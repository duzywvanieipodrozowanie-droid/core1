package pl.zenstage.core.metrics.commits;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.core.common.MathBigDecimal;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.git.MergeRequestEntity;
import pl.zenstage.db.store.entity.git.PipelineEntity;
import pl.zenstage.db.store.repository.MergeRequestRepository;
import pl.zenstage.db.store.repository.PipelineRepository;

import java.math.BigDecimal;
import java.math.MathContext;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class CommitCommonsService {
    private static final long HOUR_IN_MILLS = 3600000;
    private static final BigDecimal MAX_CODING_HOURS = BigDecimal.valueOf(8);
    private static final int MAX_PARENT_DEPTH = 200;
    private final CommitService commitService;
    private final MergeRequestRepository mergeRequestRepository;
    private final PipelineRepository pipelineRepository;

    public static Stream<CommitEntity> filterMergeCommits(List<CommitEntity> commits) {
        return commits.stream().filter(it ->
                Optional.of(it).map(CommitEntity::getSource).map(Commit::parentIds).map(List::size).orElse(1) > 1
        ).filter(it -> Optional.of(it).map(CommitEntity::getSource).map(Commit::mergeCommit).orElse(false));
    }

    public Stream<CommitEntity> filterActiveBranches(List<CommitEntity> commits) {
        Set<String> parentsIds = commits.stream().map(CommitEntity::getSource).filter(Objects::nonNull).map(Commit::parentIds).filter(Objects::nonNull)
                .flatMap(Collection::stream).collect(Collectors.toSet());
        return commits.stream().filter(it -> Optional.of(it).map(CommitEntity::getSource)
                .map(s -> !s.mergeCommit() && !parentsIds.contains(it.getCommitId())).orElse(false));
    }

    public Stream<CommitEntity> findParentFeatureBranchCommit(CommitEntity commit) {
        return commitService.findParentCommits(commit).stream().filter(it ->
                Optional.of(it).map(CommitEntity::getSource).map(s -> !s.mergeCommit()).orElse(false)
        );
    }

    public BigDecimal buildTime(CommitEntity mc) {
        return Optional.of(mc)
                .map(it -> {
                    List<PipelineEntity> pipelines = pipelineRepository.findAllByProjectIdAndModuleNameAndCommitId(it.getProjectId(), it.getModuleName(), it.getCommitId());
                    return pipelines.stream().map(PipelineEntity::getUpdateDate).max(LocalDateTime::compareTo).orElse(mc.getCommitDate());
                }).map(build -> hoursBetween(mc.getCommitDate(), build)).orElse(BigDecimal.ZERO).abs();
    }

    public List<MergeRequestEntity> findMergeRequests(CommitEntity mc) {
        return Optional.ofNullable(mc).map(it ->
                mergeRequestRepository.findAllByProjectIdAndModuleNameAndCommitId(
                        it.getProjectId(),
                        it.getModuleName(),
                        it.getCommitId()
                )
        ).orElseGet(Collections::emptyList);
    }

    public BigDecimal mergeTime(CommitEntity mc) {
        return mergeTime(mc, findMergeRequests(mc));
    }

    public BigDecimal mergeTime(CommitEntity mc, List<MergeRequestEntity> mergeRequests) {
        return Optional.of(mc)
                .map(it -> {
                    Optional<LocalDateTime> lastMr = mergeRequests.stream()
                            .max(Comparator.comparing(MergeRequestEntity::getCreateDate)).map(MergeRequestEntity::getCreateDate);
                    Optional<LocalDateTime> lastCommit = commitService.findParentCommits(mc).stream().filter(pe ->
                            Optional.of(pe).map(CommitEntity::getSource).map(s -> !s.mergeCommit()).orElse(false)
                    ).max(Comparator.comparing(CommitEntity::getCommitDate)).map(CommitEntity::getCommitDate);
                    return lastMr.or(() -> lastCommit).orElseGet(mc::getCommitDate);
                }).map(merge -> hoursBetween(mc.getCommitDate(), merge)).orElse(BigDecimal.ZERO).abs();
    }

    public BigDecimal codingTime(CommitEntity mc) {
        CommitEntity firstCommit = mc;
        CommitEntity lastCommit = null;
        Optional<CommitEntity> parent;
        int depth = 0;
        do {
            // result is capped at MAX_CODING_HOURS, so walking further back cannot change it;
            // without this the loop followed mainline history to the very first commit
            if (lastCommit != null && (depth++ >= MAX_PARENT_DEPTH
                    || hoursBetween(firstCommit.getCommitDate(), lastCommit.getCommitDate()).compareTo(MAX_CODING_HOURS) >= 0)) {
                break;
            }
            parent = commitService.findParentCommits(firstCommit).stream().filter(it ->
                    Optional.of(it).map(CommitEntity::getSource).map(s -> !s.mergeCommit()).orElse(false)
            ).max((o1, o2) -> Objects.compare(
                    o1.getCommitDate(),
                    o2.getCommitDate(),
                    LocalDateTime::compareTo
            ));
            if (parent.isPresent()) {
                firstCommit = parent.get();
                if (lastCommit == null) {
                    lastCommit = parent.get();
                }
            }
        } while (parent.isPresent());

        if (firstCommit == lastCommit || lastCommit == null) {
            return BigDecimal.ONE;
        }

        return hoursBetweenMaxDay(firstCommit.getCommitDate(), lastCommit.getCommitDate());
    }

    public BigDecimal pickupTime(CommitEntity mc) {
        return pickupTime(findMergeRequests(mc));
    }

    public BigDecimal pickupTime(List<MergeRequestEntity> mergeRequests) {
        return minutesToHours(MathBigDecimal.sum(mergeRequests.stream().map(MergeRequestEntity::getPickupTimeMinutes).toList()));
    }

    public BigDecimal reviewTime(CommitEntity mc) {
        return reviewTime(findMergeRequests(mc));
    }

    public BigDecimal reviewTime(List<MergeRequestEntity> mergeRequests) {
        return minutesToHours(MathBigDecimal.sum(mergeRequests.stream().map(MergeRequestEntity::getReviewTimeMinutes).toList()));
    }

    public static BigDecimal hoursBetween(LocalDateTime first, LocalDateTime second) {
        return BigDecimal.valueOf(Duration.between(first, second).toMillis()).divide(BigDecimal.valueOf(HOUR_IN_MILLS), MathContext.DECIMAL128);
    }

    public static BigDecimal hoursBetweenMaxDay(LocalDateTime first, LocalDateTime second) {
        return Stream.of(
                MAX_CODING_HOURS,
                BigDecimal.valueOf(Duration.between(first, second).toMillis()).divide(BigDecimal.valueOf(HOUR_IN_MILLS), MathContext.DECIMAL128)
        ).min(BigDecimal::compareTo).orElse(BigDecimal.ZERO);
    }

    private static BigDecimal minutesToHours(BigDecimal minutes) {
        return minutes.divide(BigDecimal.valueOf(HOUR_IN_MILLS), MathContext.DECIMAL128);
    }
}
