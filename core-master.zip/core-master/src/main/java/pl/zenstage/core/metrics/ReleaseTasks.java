package pl.zenstage.core.metrics;

import java.util.Locale;

/**
 * Jira release tasks (an issue type containing "release", e.g. "Release", "Release Request") only mark deployments:
 * they count in the deployment frequency and are left out of the other metrics (flow, investments, AI data).
 */
public final class ReleaseTasks {

    private ReleaseTasks() {
    }

    public static boolean isRelease(String type) {
        return type != null && type.toLowerCase(Locale.ROOT).contains("release");
    }
}
