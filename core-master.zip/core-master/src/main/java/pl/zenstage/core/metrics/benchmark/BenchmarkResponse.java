package pl.zenstage.core.metrics.benchmark;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Metrics of one unit compared with the average of all units of the same type in the organization (e.g. a squad
 * against all squads), for the same period.
 *
 * @param unitType  type of the compared units
 * @param peerUnits number of units of that type in the organization
 * @param metrics   metric key (as the widget on the screen) -> comparison
 */
public record BenchmarkResponse(String unitType, int peerUnits, Map<String, Item> metrics) {
    /**
     * @param value         the unit's value in the period
     * @param orgAverage    average over the units of that type which have data for this metric (value other than 0)
     * @param unitsWithData number of units in that average
     * @param diffPct       (value - orgAverage) / orgAverage in %, null without an average
     * @param better        whether the unit is better than the average (lower is better for times and failure rates)
     */
    public record Item(BigDecimal value, BigDecimal orgAverage, int unitsWithData, BigDecimal diffPct, Boolean better) {
    }
}
