package pl.zenstage.core.product;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.deliver.DeliverResponse.EpicSummary;
import pl.zenstage.core.metrics.deliver.DeliverResponse.Health;
import pl.zenstage.core.metrics.deliver.DeliverService;
import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.List;

/**
 * Product overview (page "product", for a product owner): the epics of the unit with their progress and delivery
 * health only - no people, commits or the work items of the Deliver screen (which stays for admins).
 */
@RestController
@RequestMapping("/product")
@RequiredArgsConstructor
public class ProductController {
    private final DeliverService deliverService;

    public record ProductEpic(
            String key,
            String summary,
            String url,
            String status,
            LocalDate plannedDelivery,
            LocalDate deliveryDate,
            boolean deliveryForecast,
            Health health,
            Long delayDays,
            int items,
            int itemsDone,
            int progressPct
    ) {
        static ProductEpic of(EpicSummary epic) {
            return new ProductEpic(epic.key(), epic.summary(), epic.url(), epic.status(), epic.plannedDelivery(),
                    epic.deliveryDate(), epic.deliveryForecast(), epic.health(), epic.delayDays(), epic.items(),
                    epic.itemsDone(), epic.progressPct());
        }
    }

    public record ProductEpics(List<ProductEpic> epics) {
    }

    @GetMapping("/epics")
    public Mono<ResponseEntity<ProductEpics>> epics(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "MONTHS_3") Interval interval
    ) {
        return deliverService.epics(unitId, interval)
                .map(list -> new ProductEpics(list.epics().stream().map(ProductEpic::of).toList()))
                .map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }
}
