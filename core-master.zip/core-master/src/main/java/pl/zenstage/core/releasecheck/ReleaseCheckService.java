package pl.zenstage.core.releasecheck;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.task.Task;
import pl.zenstage.core.codemap.CodeMapService;
import pl.zenstage.core.codemap.CodeMapService.EnvTag;
import pl.zenstage.core.metrics.ReleaseTasks;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.releasecheck.ReleaseCheck.Comparison;
import pl.zenstage.core.releasecheck.ReleaseCheck.ReleaseTask;
import pl.zenstage.core.releasecheck.ReleaseCheck.Result;
import pl.zenstage.core.releasecheck.ReleaseCheck.Row;
import pl.zenstage.core.releasecheck.ReleaseCheck.Side;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.api.task.TaskStatus;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * Tests → Release check: the image tags of the microservices (service map) of one environment against another
 * (alfa -> beta), or of an environment against the Fix Versions of a release task ("payment-service 2.4.1").
 */
@Service
@RequiredArgsConstructor
public class ReleaseCheckService {
    /** Done release tasks listed, the newest first. */
    static final int MAX_DONE = 20;
    private static final Map<String, List<TaskStatus>> STATUSES = Map.of(
            "OPEN", List.of(TaskStatus.OPEN),
            "DONE", List.of(TaskStatus.DONE, TaskStatus.LIVE)
    );
    private static final List<Result> ORDER = List.of(Result.DIFFERENT, Result.MISSING, Result.EXTRA, Result.SAME);

    private final CodeMapService codeMapService;
    private final OrganizationService organizationService;
    private final TaskRepository taskRepository;

    public Mono<List<String>> environments() {
        return codeMapService.environments();
    }

    /** The release tasks (issue type with "release") of the unit's Jira projects in the status (OPEN / DONE), the newest first. */
    public Mono<List<ReleaseTask>> releases(String unitId, String status) {
        List<TaskStatus> statuses = STATUSES.getOrDefault(Objects.toString(status, "OPEN").toUpperCase(Locale.ROOT), STATUSES.get("OPEN"));
        return organizationService.userManageProjectsMembers(unitId).publishOn(Schedulers.boundedElastic()).map(pm -> {
            if (pm.projects().isEmpty()) return List.<ReleaseTask>of();
            Map<String, TaskEntity> byKey = new LinkedHashMap<>();
            taskRepository.findByProjectIdInAndStatusIn(pm.projects(), statuses).stream()
                    .filter(it -> ReleaseTasks.isRelease(it.getType()) || (it.getContent() != null && ReleaseTasks.isRelease(it.getContent().type())))
                    .sorted(Comparator.comparing(ReleaseCheckService::lastChange, Comparator.nullsLast(Comparator.reverseOrder())))
                    .forEach(it -> byKey.putIfAbsent(it.getKey(), it));
            return byKey.values().stream().limit(statuses.contains(TaskStatus.DONE) ? MAX_DONE : Long.MAX_VALUE)
                    .map(ReleaseCheckService::task).toList();
        });
    }

    /** The microservices of environment {@code from} (alfa) against {@code to} (beta). */
    public Mono<Comparison> environments(String from, String to) {
        return Mono.zip(codeMapService.tagsOn(from), codeMapService.tagsOn(to))
                .map(t -> compareEnvironments(from, to, t.getT1(), t.getT2()));
    }

    /** The microservices on the environment against the Fix Versions of the release task {@code key} of the unit. */
    public Mono<Comparison> release(String unitId, String key, String environment) {
        String releaseKey = Objects.toString(key, "").trim().toUpperCase(Locale.ROOT);
        Mono<List<TaskEntity>> release = organizationService.userManageProjectsMembers(unitId).publishOn(Schedulers.boundedElastic())
                .map(pm -> taskRepository.findByKey(releaseKey).stream()
                        .filter(it -> pm.projects().contains(it.getProjectId()) && it.getContent() != null).limit(1).toList());
        return Mono.zip(release, codeMapService.tagsOn(environment))
                .map(t -> compareRelease(environment, t.getT1().stream().findFirst().orElse(null), t.getT2(), releaseKey));
    }

    static Comparison compareEnvironments(String from, String to, List<EnvTag> source, List<EnvTag> target) {
        Map<String, EnvTag> sources = byModule(source);
        Map<String, EnvTag> targets = byModule(target);
        Set<String> keys = new HashSet<>(sources.keySet());
        keys.addAll(targets.keySet());
        List<Row> rows = new ArrayList<>();
        for (String key : keys) {
            EnvTag a = sources.get(key);
            EnvTag b = targets.get(key);
            EnvTag any = a != null ? a : b;
            Result result = a == null ? Result.EXTRA : b == null ? Result.MISSING
                    : sameVersion(version(a), b) ? Result.SAME : Result.DIFFERENT;
            rows.add(new Row(any.module(), any.projectId(), side(a), side(b), result, null));
        }
        String note = source.isEmpty() && target.isEmpty() ? "No microservice on '" + from + "' nor '" + to + "' in the service map."
                : source.isEmpty() ? "No microservice on '" + from + "' in the service map."
                : target.isEmpty() ? "No microservice on '" + to + "' in the service map." : null;
        return new Comparison(from, to, matched(source, target), sorted(rows), List.of(), note);
    }

    /**
     * Every Fix Version against the tag of its microservice on the environment (the longest module name starting the
     * Fix Version, as CodeMapService.versionOf), and the microservices of the same service map projects on the
     * environment that no Fix Version names (EXTRA).
     */
    static Comparison compareRelease(String environment, TaskEntity release, List<EnvTag> tags, String key) {
        if (release == null) {
            return new Comparison(environment, key, matched(tags, List.of()), List.of(), List.of(),
                    "No release task " + key + " in the unit's Jira projects.");
        }
        List<String> fixVersions = Optional.ofNullable(release.getContent().fixVersions()).orElse(List.of()).stream()
                .filter(Objects::nonNull).filter(it -> !it.isBlank()).toList();
        List<Row> rows = new ArrayList<>();
        Set<EnvTag> named = new HashSet<>();
        Set<String> projects = new HashSet<>();
        for (String fixVersion : fixVersions) {
            List<EnvTag> matches = tags.stream().filter(it -> it.module() != null && CodeMapService.versionOf(fixVersion, it.module()) != null).toList();
            int longest = matches.stream().mapToInt(it -> it.module().length()).max().orElse(0);
            List<EnvTag> modules = matches.stream().filter(it -> it.module().length() == longest).toList();
            if (modules.isEmpty()) {
                String microservice = microservice(fixVersion);
                rows.add(new Row(microservice, null, side(null),
                        new Side(Optional.ofNullable(CodeMapService.versionOf(fixVersion, microservice)).orElse(fixVersion), null, null, fixVersion),
                        Result.MISSING, release.getKey()));
                continue;
            }
            for (EnvTag tag : modules) {
                String version = CodeMapService.versionOf(fixVersion, tag.module());
                named.add(tag);
                projects.add(tag.projectId());
                rows.add(new Row(tag.module(), tag.projectId(), side(tag), new Side(version, null, null, fixVersion),
                        sameVersion(version, tag) ? Result.SAME : Result.DIFFERENT, release.getKey()));
            }
        }
        tags.stream().filter(it -> !named.contains(it) && projects.contains(it.projectId()) && it.module() != null)
                .forEach(it -> rows.add(new Row(it.module(), it.projectId(), side(it), side(null), Result.EXTRA, release.getKey())));
        String note = fixVersions.isEmpty() ? "The release task " + release.getKey() + " has no Fix Version."
                : tags.isEmpty() ? "No microservice on an environment named like '" + environment + "' in the service map." : null;
        return new Comparison(environment, release.getKey(), matched(tags, List.of()), sorted(rows), List.of(task(release)), note);
    }

    /** "payment-service 2.1.0" -> "payment-service". */
    static String microservice(String fixVersion) {
        return Objects.toString(fixVersion, "").trim().replaceFirst("(?i)(?:[\\s_@:/-]+v?|v)\\d+(\\.\\d+)*([-+.][\\w.]+)?$", "").trim();
    }

    /** The version equals the tag, also when the tag has a "v" or carries the name ("payment-service-2.1.0"). */
    private static boolean sameVersion(String version, EnvTag tag) {
        if (version == null) return false;
        return version.equalsIgnoreCase(CodeMapService.normalizeVersion(tag.tag()))
                || version.equalsIgnoreCase(Objects.toString(CodeMapService.versionOf(Objects.toString(tag.tag(), ""), tag.module()), ""));
    }

    private static String version(EnvTag tag) {
        String fromName = tag.module() == null ? null : CodeMapService.versionOf(Objects.toString(tag.tag(), ""), tag.module());
        return CodeMapService.normalizeVersion(fromName != null ? fromName : tag.tag());
    }

    private static Side side(EnvTag tag) {
        return tag == null ? null : new Side(tag.tag(), tag.image(), tag.environment(), null);
    }

    private static Map<String, EnvTag> byModule(List<EnvTag> tags) {
        Map<String, EnvTag> map = new LinkedHashMap<>();
        tags.stream().filter(it -> it.module() != null)
                .forEach(it -> map.putIfAbsent(Objects.toString(it.projectId(), "") + "/" + it.module().toLowerCase(Locale.ROOT), it));
        return map;
    }

    private static List<String> matched(List<EnvTag> a, List<EnvTag> b) {
        return java.util.stream.Stream.concat(a.stream(), b.stream()).map(EnvTag::environment).filter(Objects::nonNull)
                .distinct().sorted().toList();
    }

    private static List<Row> sorted(List<Row> rows) {
        return rows.stream().sorted(Comparator.comparing((Row it) -> ORDER.indexOf(it.result()))
                .thenComparing(Row::microservice, Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER))).toList();
    }

    private static LocalDateTime lastChange(TaskEntity task) {
        return Optional.ofNullable(task.getUpdated()).orElse(task.getCreated());
    }

    private static ReleaseTask task(TaskEntity entity) {
        Task task = entity.getContent();
        return new ReleaseTask(
                entity.getKey(),
                task == null ? null : task.summary(),
                task == null ? Objects.toString(entity.getStatus(), null) : task.status(),
                task == null || task.assignee() == null ? null : task.assignee().displayName(),
                entity.getUrl(),
                task == null ? List.of() : Optional.ofNullable(task.fixVersions()).orElse(List.of()),
                task == null ? null : task.dueDate(),
                entity.getUpdated(),
                entity.getCreated()
        );
    }
}
