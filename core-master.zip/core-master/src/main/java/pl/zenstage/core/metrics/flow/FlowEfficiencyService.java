package pl.zenstage.core.metrics.flow;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.task.History;
import pl.zenstage.api.task.Task;
import pl.zenstage.api.task.TaskStatus;
import pl.zenstage.core.metrics.flow.FlowEfficiencyResponse.Bucket;
import pl.zenstage.core.metrics.flow.FlowEfficiencyResponse.CurrentStatus;
import pl.zenstage.core.metrics.flow.FlowEfficiencyResponse.ItemEfficiency;
import pl.zenstage.core.metrics.flow.FlowEfficiencyResponse.StatusShare;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Flow efficiency ("Flow efficiency" on Overview) from the Jira status history: for each work item that went LIVE in
 * the period, the time from its first in-progress status until LIVE split by status into active work and waiting
 * (queues, blocked, DONE waiting for deployment...). Only items with a Fix Version count towards the indicator.
 */
@Service
@RequiredArgsConstructor
public class FlowEfficiencyService {
    private static final String STATUS_FIELD_TYPE = "status";
    /** Statuses in which someone works on the item; every other status between start and LIVE is waiting. */
    static final Set<TaskStatus> ACTIVE = Set.of(
            TaskStatus.ANALYSIS, TaskStatus.IN_PROGRESS, TaskStatus.IN_REVIEW, TaskStatus.IN_TEST, TaskStatus.UAT, TaskStatus.IN_UAT
    );
    private static final int BUCKET_PCT = 10;
    private static final int SLOWEST_ITEMS = 10;
    /** DONE items count as "waiting for LIVE" only when they got DONE recently (teams without LIVE never leave DONE). */
    private static final int DONE_WAITING_MAX_DAYS = 90;

    private final OrganizationService organizationService;
    private final TaskRepository taskRepository;

    private record Period(String status, boolean active, long minutes) {
    }

    private record Finished(Task task, List<Period> periods, long activeMinutes, long totalMinutes) {
        BigDecimal efficiencyPct() {
            return totalMinutes == 0 ? BigDecimal.valueOf(100) : pct(activeMinutes, totalMinutes);
        }
    }

    public Mono<FlowEfficiencyResponse> efficiency(String unitId, Interval interval) {
        Interval.Range range = interval.range(0);
        LocalDateTime now = LocalDateTime.now();
        Set<TaskStatus> currentStatuses = new HashSet<>(FlowService.IN_PROGRESS);
        currentStatuses.add(TaskStatus.DONE);

        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(pm -> {
                    Map<String, Finished> finished = new LinkedHashMap<>();
                    Set<String> withoutFixVersion = new HashSet<>();
                    for (TaskEntity entity : taskRepository.findByProjectIdInAndUpdatedAfter(pm.projects(), range.from())) {
                        String id = entity.getProjectId() + "|" + entity.getKey();
                        if (!finished.containsKey(id) && FlowService.countedType(entity.getType()) && entity.getContent() != null) {
                            finished(entity.getContent(), range).ifPresent(it -> {
                                if (hasFixVersion(it.task())) {
                                    finished.put(id, it);
                                } else {
                                    withoutFixVersion.add(id);
                                }
                            });
                        }
                    }
                    Map<String, TaskEntity> current = new LinkedHashMap<>();
                    taskRepository.findByProjectIdInAndStatusIn(pm.projects(), currentStatuses).stream()
                            .filter(it -> FlowService.countedType(it.getType()) && it.getContent() != null)
                            .forEach(it -> current.putIfAbsent(it.getProjectId() + "|" + it.getKey(), it));
                    return response(List.copyOf(finished.values()), withoutFixVersion.size(), List.copyOf(current.values()), now);
                });
    }

    /** The item's periods from its first in-progress status to its first LIVE in the range, if it went LIVE then. */
    private static Optional<Finished> finished(Task task, Interval.Range range) {
        List<History> changes = statusChanges(task);
        int start = -1;
        for (int i = 0; i < changes.size() && start < 0; i++) {
            if (FlowService.IN_PROGRESS.contains(FlowService.status(changes.get(i).to()))) {
                start = i;
            }
        }
        if (start < 0) {
            return Optional.empty();
        }
        LocalDateTime started = changes.get(start).created();
        LocalDateTime live = changes.stream().skip(start)
                .filter(h -> FlowService.status(h.to()) == TaskStatus.LIVE)
                .map(History::created)
                .filter(it -> !it.isBefore(range.from()) && it.isBefore(range.till()) && !it.isBefore(started))
                .findFirst().orElse(null);
        if (live == null) {
            return Optional.empty();
        }
        List<Period> periods = new ArrayList<>();
        long active = 0;
        long total = 0;
        for (int i = start; i < changes.size(); i++) {
            LocalDateTime from = changes.get(i).created();
            if (!from.isBefore(live)) {
                break;
            }
            LocalDateTime till = i + 1 < changes.size() && changes.get(i + 1).created().isBefore(live)
                    ? changes.get(i + 1).created() : live;
            long minutes = Math.max(0, Duration.between(from, till).toMinutes());
            String status = statusName(changes.get(i).to());
            boolean isActive = ACTIVE.contains(FlowService.status(changes.get(i).to()));
            periods.add(new Period(status, isActive, minutes));
            total += minutes;
            active += isActive ? minutes : 0;
        }
        return Optional.of(new Finished(task, periods, active, total));
    }

    private static FlowEfficiencyResponse response(List<Finished> finished, int withoutFixVersion, List<TaskEntity> current,
                                                   LocalDateTime now) {
        long active = finished.stream().mapToLong(Finished::activeMinutes).sum();
        long total = finished.stream().mapToLong(Finished::totalMinutes).sum();
        BigDecimal avg = finished.isEmpty() ? null
                : finished.stream().map(Finished::efficiencyPct).reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(BigDecimal.valueOf(finished.size()), 1, RoundingMode.HALF_UP);

        int[] counts = new int[100 / BUCKET_PCT];
        finished.forEach(it -> counts[Math.min(counts.length - 1, it.efficiencyPct().intValue() / BUCKET_PCT)]++);
        List<Bucket> histogram = new ArrayList<>();
        for (int i = 0; i < counts.length; i++) {
            histogram.add(new Bucket(i * BUCKET_PCT, (i + 1) * BUCKET_PCT, counts[i]));
        }

        // status -> [minutes, items], in order of first appearance
        Map<String, long[]> byStatus = new LinkedHashMap<>();
        Map<String, Boolean> activeStatus = new LinkedHashMap<>();
        for (Finished item : finished) {
            Set<String> seen = new HashSet<>();
            for (Period period : item.periods()) {
                long[] acc = byStatus.computeIfAbsent(period.status(), k -> new long[2]);
                acc[0] += period.minutes();
                if (seen.add(period.status())) {
                    acc[1]++;
                }
                activeStatus.putIfAbsent(period.status(), period.active());
            }
        }
        List<StatusShare> statuses = byStatus.entrySet().stream()
                .map(e -> new StatusShare(
                        e.getKey(),
                        activeStatus.get(e.getKey()),
                        days(e.getValue()[0]),
                        total == 0 ? BigDecimal.ZERO : pct(e.getValue()[0], total),
                        days(e.getValue()[0] / Math.max(1, e.getValue()[1])),
                        (int) e.getValue()[1]
                ))
                .sorted(Comparator.comparing(StatusShare::days).reversed())
                .toList();
        String bottleneck = statuses.stream().filter(it -> !it.active() && it.days().signum() > 0)
                .findFirst().map(StatusShare::status).orElse(null);

        List<ItemEfficiency> slowest = finished.stream()
                .sorted(Comparator.comparingLong((Finished it) -> it.totalMinutes() - it.activeMinutes()).reversed())
                .limit(SLOWEST_ITEMS)
                .map(it -> {
                    Map<String, Long> waits = new LinkedHashMap<>();
                    it.periods().stream().filter(p -> !p.active()).forEach(p -> waits.merge(p.status(), p.minutes(), Long::sum));
                    Map.Entry<String, Long> longest = waits.entrySet().stream().max(Map.Entry.comparingByValue()).orElse(null);
                    Task task = it.task();
                    return new ItemEfficiency(
                            task.key(), task.summary(), task.url(), task.type(),
                            it.efficiencyPct(),
                            days(it.totalMinutes()),
                            days(it.totalMinutes() - it.activeMinutes()),
                            longest == null ? null : longest.getKey(),
                            longest == null ? null : days(longest.getValue())
                    );
                })
                .toList();

        return new FlowEfficiencyResponse(
                finished.size(), withoutFixVersion, avg, days(active), days(total - active), histogram, statuses, bottleneck,
                current(current, now), slowest
        );
    }

    /** Current work items by status (DONE split by Fix Version), with the average time since they entered it. */
    private static List<CurrentStatus> current(List<TaskEntity> entities, LocalDateTime now) {
        record Group(String status, Boolean fixVersion) {
        }
        Map<Group, List<Long>> byStatus = new LinkedHashMap<>();
        Map<Group, Boolean> activeStatus = new LinkedHashMap<>();
        for (TaskEntity entity : entities) {
            Task task = entity.getContent();
            List<History> changes = statusChanges(task);
            LocalDateTime since = changes.isEmpty() ? task.created() : changes.getLast().created();
            long minutes = since == null ? 0 : Math.max(0, Duration.between(since, now).toMinutes());
            if (entity.getStatus() == TaskStatus.DONE && minutes > DONE_WAITING_MAX_DAYS * 24L * 60) {
                continue;
            }
            Group group = new Group(entity.getStatus().getJiraName(),
                    entity.getStatus() == TaskStatus.DONE ? hasFixVersion(task) : null);
            byStatus.computeIfAbsent(group, k -> new ArrayList<>()).add(minutes);
            activeStatus.putIfAbsent(group, ACTIVE.contains(entity.getStatus()));
        }
        return byStatus.entrySet().stream()
                .map(e -> new CurrentStatus(
                        e.getKey().status(),
                        activeStatus.get(e.getKey()),
                        e.getKey().fixVersion(),
                        e.getValue().size(),
                        days(e.getValue().stream().mapToLong(Long::longValue).sum() / e.getValue().size())
                ))
                .sorted(Comparator.comparingInt(CurrentStatus::items).reversed())
                .toList();
    }

    private static boolean hasFixVersion(Task task) {
        return task.fixVersions() != null && task.fixVersions().stream().anyMatch(it -> it != null && !it.isBlank());
    }

    private static List<History> statusChanges(Task task) {
        return Optional.ofNullable(task.histories()).orElse(List.of()).stream()
                .filter(h -> h != null && h.created() != null && STATUS_FIELD_TYPE.equalsIgnoreCase(h.fieldType()))
                .sorted(Comparator.comparing(History::created))
                .toList();
    }

    /** Known statuses by their Jira name, others as written in Jira (upper case). */
    private static String statusName(String value) {
        TaskStatus status = FlowService.status(value);
        if (status != TaskStatus.UNKNOWN) {
            return status.getJiraName();
        }
        return value == null || value.isBlank() ? TaskStatus.UNKNOWN.getJiraName() : value.trim().toUpperCase(Locale.ROOT);
    }

    private static BigDecimal days(long minutes) {
        return BigDecimal.valueOf(minutes).divide(BigDecimal.valueOf(24 * 60), 1, RoundingMode.HALF_UP);
    }

    private static BigDecimal pct(long part, long whole) {
        return BigDecimal.valueOf(part * 100).divide(BigDecimal.valueOf(whole), 1, RoundingMode.HALF_UP);
    }
}
