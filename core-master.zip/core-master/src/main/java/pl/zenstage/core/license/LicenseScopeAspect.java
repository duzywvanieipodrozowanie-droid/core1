package pl.zenstage.core.license;

import lombok.RequiredArgsConstructor;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import pl.zenstage.core.common.ZenStageException;

import java.lang.reflect.Method;
import java.util.Optional;

@Aspect
@Component
@RequiredArgsConstructor
public class LicenseScopeAspect {
    private static final String LICENSE_ERROR = "LICENSE_ERROR";
    private final ZsLicense zsLicense;

    @Pointcut("@annotation(pl.zenstage.core.license.ZsScope)")
    public void methodWithLicenseScope() {
    }

    @Pointcut("@within(pl.zenstage.core.license.ZsScope)")
    public void classWithLicenseScope() {
    }

    @Before("methodWithLicenseScope() || classWithLicenseScope()")
    public void beforeLicensedMethod(JoinPoint joinPoint) {
        Method method = ((MethodSignature) joinPoint.getSignature()).getMethod();
        Class<?> targetClass = joinPoint.getTarget().getClass();

        ZsScope annotation = Optional.of(method).map(it -> it.getAnnotation(ZsScope.class)).orElseGet(
                () -> targetClass.getAnnotation(ZsScope.class)
        );
        if (annotation == null || annotation.value() == null) {
            return;
        }
        boolean forbidden = !annotation.value().assignableFrom(zsLicense);
        if (forbidden) {
            throw new ZenStageException(HttpStatus.FORBIDDEN, LICENSE_ERROR,
                    "Required license: %s but your license is %s(%s)"
                            .formatted(annotation.value(), zsLicense.type(), zsLicense.expireDate())
            );
        }
    }
}
