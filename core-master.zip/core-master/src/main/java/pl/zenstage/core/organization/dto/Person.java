package pl.zenstage.core.organization.dto;

import pl.zenstage.api.admin.EmpLevel;
import pl.zenstage.api.admin.EmpSkill;

import java.util.List;
import java.util.Set;

public record Person(
        String id,
        String name,
        String email,
        List<String> commiterEmails,
        boolean technical,
        boolean admin,
        EmpLevel level,
        Set<EmpSkill> skills
) {
}
