package pl.zenstage.core.metrics.codeimpact;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.core.metrics.codeimpact.CodeImpactResponse.AreaImpact;
import pl.zenstage.core.metrics.codeimpact.CodeImpactResponse.AuthorShare;
import pl.zenstage.core.metrics.codeimpact.CodeImpactResponse.Criticality;
import pl.zenstage.core.metrics.codeimpact.CodeImpactResponse.DeveloperImpact;
import pl.zenstage.core.metrics.codeimpact.CodeImpactResponse.Risk;
import pl.zenstage.core.metrics.codeimpact.CodeImpactResponse.ServiceImpact;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationCache;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.organization.dto.Person;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CodeImpactService {
    private static final int TOP_AUTHORS = 8;
    private static final int TOP_DIRECTORIES = 10;
    private static final int TOP_SILOS = 10;
    private static final int MAIN_SERVICES = 3;
    private static final int DIRECTORY_DEPTH = 2;
    // a file is a knowledge silo when one person wrote at least this share of a non-trivial file
    private static final long SILO_SHARE_PCT = 80;
    private static final long SILO_MIN_LINES = 50;

    private final OrganizationService organizationService;
    private final OrganizationCache organizationCache;
    private final CommitRepository commitRepository;

    public Mono<CodeImpactResponse> codeImpact(String unitId, Interval interval) {
        Interval.Range range = interval.range(0);
        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(it -> calculate(it.projects(), new HashSet<>(it.members()), range));
    }

    private record Author(String key, String name, String personId, boolean current, boolean known) {
        AuthorShare share(long lines, long total) {
            return new AuthorShare(key, name, personId, lines, pct(lines, total), current, known);
        }
    }

    /** Added lines per author for a service, its directories and files. */
    private static final class Ownership {
        final String project;
        final String service;
        final Map<String, Long> byAuthor = new HashMap<>();
        final Map<String, Map<String, Long>> byDirectory = new HashMap<>();
        final Map<String, Map<String, Long>> byFile = new HashMap<>();

        Ownership(String project, String service) {
            this.project = project;
            this.service = service;
        }

        void add(String path, String author, long lines) {
            byAuthor.merge(author, lines, Long::sum);
            byDirectory.computeIfAbsent(directory(path), k -> new HashMap<>()).merge(author, lines, Long::sum);
            byFile.computeIfAbsent(path, k -> new HashMap<>()).merge(author, lines, Long::sum);
        }

        long total() {
            return sum(byAuthor);
        }
    }

    private CodeImpactResponse calculate(Collection<String> projects, Set<String> members, Interval.Range range) {
        if (projects.isEmpty()) {
            return new CodeImpactResponse(0, 0, 0, BigDecimal.ZERO, List.of(), List.of());
        }
        List<CommitEntity> commits = commitRepository.findByProjectIdInAndCommitDateBetween(projects, range.from(), range.till());

        // a service = one GitLab repository (module) of the unit's projects that the unit's members commit to;
        // all its authors are counted, including people outside the unit
        Map<String, List<CommitEntity>> byService = commits.stream()
                .collect(Collectors.groupingBy(it -> it.getProjectId() + "/" + it.getModuleName()));
        Map<String, Author> authors = new HashMap<>();
        List<Ownership> services = new ArrayList<>();
        long analyzed = 0;
        long withoutFiles = 0;
        for (List<CommitEntity> serviceCommits : byService.values()) {
            if (serviceCommits.stream().noneMatch(it -> it.getCommiterId() != null && members.contains(it.getCommiterId()))) {
                continue;
            }
            CommitEntity first = serviceCommits.getFirst();
            Ownership ownership = new Ownership(first.getProjectId(), first.getModuleName());
            for (CommitEntity commit : serviceCommits) {
                analyzed++;
                Map<String, Integer> files = Optional.ofNullable(commit.getSource()).map(Commit::files).orElse(null);
                if (files == null) {
                    withoutFiles++;
                    continue;
                }
                Author author = authors.computeIfAbsent(authorKey(commit), key -> author(key, commit, members));
                files.forEach((path, lines) -> {
                    if (path != null && lines != null && lines > 0) {
                        ownership.add(path, author.key(), lines);
                    }
                });
            }
            if (ownership.total() > 0) {
                services.add(ownership);
            }
        }

        long totalLines = services.stream().mapToLong(Ownership::total).sum();
        Map<String, Long> linesByAuthor = new HashMap<>();
        services.forEach(it -> it.byAuthor.forEach((author, lines) -> linesByAuthor.merge(author, lines, Long::sum)));
        long departedLines = linesByAuthor.entrySet().stream().filter(it -> !authors.get(it.getKey()).current())
                .mapToLong(Map.Entry::getValue).sum();

        List<ServiceImpact> serviceImpacts = services.stream()
                .map(it -> serviceImpact(it, authors))
                .sorted(Comparator.comparing(ServiceImpact::risk).thenComparing(Comparator.comparingLong(ServiceImpact::totalLines).reversed()))
                .toList();

        return new CodeImpactResponse(
                totalLines,
                analyzed,
                withoutFiles,
                pct(departedLines, totalLines),
                serviceImpacts,
                developers(services, serviceImpacts, authors, linesByAuthor, totalLines)
        );
    }

    private ServiceImpact serviceImpact(Ownership ownership, Map<String, Author> authors) {
        long total = ownership.total();
        int busFactor = busFactor(ownership.byAuthor, authors);
        long departed = ownership.byAuthor.entrySet().stream().filter(it -> !authors.get(it.getKey()).current())
                .mapToLong(Map.Entry::getValue).sum();
        BigDecimal departedPct = pct(departed, total);
        Risk risk = busFactor <= 1 || departedPct.compareTo(BigDecimal.valueOf(50)) >= 0 ? Risk.HIGH
                : busFactor == 2 || departedPct.compareTo(BigDecimal.valueOf(25)) >= 0 ? Risk.MEDIUM
                : Risk.LOW;
        return new ServiceImpact(
                ownership.project,
                ownership.service,
                total,
                busFactor,
                risk,
                departedPct,
                sortedShares(ownership.byAuthor, authors).stream().limit(TOP_AUTHORS).toList(),
                ownership.byDirectory.entrySet().stream()
                        .map(it -> area(it.getKey(), it.getValue(), authors))
                        .sorted(Comparator.comparingLong(AreaImpact::lines).reversed())
                        .limit(TOP_DIRECTORIES).toList(),
                silos(ownership, authors).stream().limit(TOP_SILOS).toList()
        );
    }

    private List<AreaImpact> silos(Ownership ownership, Map<String, Author> authors) {
        return ownership.byFile.entrySet().stream()
                .map(it -> area(it.getKey(), it.getValue(), authors))
                .filter(it -> it.lines() >= SILO_MIN_LINES && it.topAuthor() != null
                        && it.topAuthor().pct().compareTo(BigDecimal.valueOf(SILO_SHARE_PCT)) >= 0)
                .sorted(Comparator.comparingLong(AreaImpact::lines).reversed())
                .toList();
    }

    private List<DeveloperImpact> developers(List<Ownership> services, List<ServiceImpact> impacts,
                                             Map<String, Author> authors, Map<String, Long> linesByAuthor, long totalLines) {
        Map<String, Integer> owned = new HashMap<>();
        Map<String, Integer> soleOwner = new HashMap<>();
        Map<String, Integer> siloFiles = new HashMap<>();
        Map<String, Map<String, Long>> serviceLines = new HashMap<>();
        for (Ownership service : services) {
            List<AuthorShare> shares = sortedShares(service.byAuthor, authors);
            if (!shares.isEmpty()) {
                owned.merge(shares.getFirst().key(), 1, Integer::sum);
            }
            if (busFactor(service.byAuthor, authors) == 1) {
                shares.stream().filter(AuthorShare::current).findFirst()
                        .ifPresent(it -> soleOwner.merge(it.key(), 1, Integer::sum));
            }
            silos(service, authors).forEach(it -> siloFiles.merge(it.topAuthor().key(), 1, Integer::sum));
            service.byAuthor.forEach((author, lines) ->
                    serviceLines.computeIfAbsent(author, k -> new HashMap<>()).merge(service.service, lines, Long::sum));
        }

        return linesByAuthor.entrySet().stream().map(entry -> {
            Author author = authors.get(entry.getKey());
            BigDecimal pct = pct(entry.getValue(), totalLines);
            int servicesOwned = owned.getOrDefault(author.key(), 0);
            int sole = soleOwner.getOrDefault(author.key(), 0);
            int silos = siloFiles.getOrDefault(author.key(), 0);
            Criticality criticality = !author.current() ? Criticality.DEPARTED
                    : sole > 0 ? Criticality.CRITICAL
                    : servicesOwned > 0 || pct.compareTo(BigDecimal.valueOf(25)) >= 0 ? Criticality.HIGH
                    : silos > 0 || pct.compareTo(BigDecimal.valueOf(10)) >= 0 ? Criticality.MEDIUM
                    : Criticality.LOW;
            return new DeveloperImpact(
                    author.key(),
                    author.name(),
                    author.personId(),
                    author.current(),
                    author.known(),
                    entry.getValue(),
                    pct,
                    servicesOwned,
                    sole,
                    silos,
                    serviceLines.getOrDefault(author.key(), Map.of()).entrySet().stream()
                            .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                            .limit(MAIN_SERVICES).map(Map.Entry::getKey).toList(),
                    criticality
            );
        }).sorted(Comparator.comparing(DeveloperImpact::criticality).thenComparing(Comparator.comparingLong(DeveloperImpact::lines).reversed())).toList();
    }

    private AreaImpact area(String path, Map<String, Long> byAuthor, Map<String, Author> authors) {
        List<AuthorShare> shares = sortedShares(byAuthor, authors);
        return new AreaImpact(path, sum(byAuthor), busFactor(byAuthor, authors), byAuthor.size(), shares.isEmpty() ? null : shares.getFirst());
    }

    private static List<AuthorShare> sortedShares(Map<String, Long> byAuthor, Map<String, Author> authors) {
        long total = sum(byAuthor);
        return byAuthor.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .map(it -> authors.get(it.getKey()).share(it.getValue(), total))
                .toList();
    }

    /**
     * Minimal number of current unit members who together wrote at least half of the lines.
     * Authors who left do not count, so 0 means that less than half of the code is known by anyone still in the unit.
     */
    private static int busFactor(Map<String, Long> byAuthor, Map<String, Author> authors) {
        long total = sum(byAuthor);
        if (total == 0) {
            return 0;
        }
        List<Long> current = byAuthor.entrySet().stream().filter(it -> authors.get(it.getKey()).current())
                .map(Map.Entry::getValue).sorted(Comparator.reverseOrder()).toList();
        long covered = 0;
        for (int i = 0; i < current.size(); i++) {
            covered += current.get(i);
            if (covered * 2 >= total) {
                return i + 1;
            }
        }
        return 0;
    }

    private Author author(String key, CommitEntity commit, Set<String> members) {
        String personId = commit.getCommiterId();
        Optional<Commit> source = Optional.ofNullable(commit.getSource());
        String name = Optional.ofNullable(personId).map(organizationCache::findPerson).map(Person::name)
                .or(() -> source.map(Commit::authorName))
                .or(() -> source.map(Commit::authorEmail))
                .orElse(key);
        return new Author(key, name, personId, personId != null && members.contains(personId), personId != null);
    }

    /** Person id when the commit e-mail is mapped to a person, otherwise the (lower-cased) author e-mail or name. */
    private static String authorKey(CommitEntity commit) {
        if (commit.getCommiterId() != null) {
            return commit.getCommiterId();
        }
        Optional<Commit> source = Optional.ofNullable(commit.getSource());
        return "~" + source.map(Commit::authorEmail).or(() -> source.map(Commit::authorName))
                .map(it -> it.toLowerCase(Locale.ROOT)).orElse("unknown");
    }

    /** First {@link #DIRECTORY_DEPTH} directories of the path, "(root)" for top-level files. */
    private static String directory(String path) {
        int lastSlash = path.lastIndexOf('/');
        if (lastSlash <= 0) {
            return "(root)";
        }
        String[] parts = path.substring(0, lastSlash).split("/");
        return String.join("/", Arrays.copyOf(parts, Math.min(parts.length, DIRECTORY_DEPTH)));
    }

    private static long sum(Map<String, Long> values) {
        return values.values().stream().filter(Objects::nonNull).mapToLong(Long::longValue).sum();
    }

    private static BigDecimal pct(long part, long total) {
        return total == 0 ? BigDecimal.ZERO
                : BigDecimal.valueOf(part).multiply(BigDecimal.valueOf(100)).divide(BigDecimal.valueOf(total), 1, RoundingMode.HALF_UP);
    }
}
