package pl.zenstage.core.config;

import lombok.extern.log4j.Log4j2;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.web.server.SecurityWebFilterChain;
import pl.zenstage.api.rest.Const;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.PersonEntity;
import pl.zenstage.db.store.repository.PersonRepository;
import reactor.core.publisher.Mono;

import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@ConditionalOnExpression("#{${spring.security.disabled:false}}")
@Log4j2
@Configuration
@EnableWebFluxSecurity
public class DevSecurityConfig {
    private final Map<String, PersonEntity> persons;

    public DevSecurityConfig(PersonRepository personRepository) {
        persons = personRepository.findAll().stream().collect(Collectors.toMap(PersonEntity::getId, it -> it));
    }

    @Bean
    public SecurityWebFilterChain testConfig(ServerHttpSecurity http,
                                             OrganizationService organizationService
    ) {
        log.info("### Security WebFlux disabled rule (Mock Auth)");
        return http
                .cors(ServerHttpSecurity.CorsSpec::disable)
                .csrf(ServerHttpSecurity.CsrfSpec::disable)
                .httpBasic(Customizer.withDefaults())
                .authenticationManager(auth -> {
                    Optional<PersonEntity> per = Optional.of(auth).map(Principal::getName).map(persons::get)
                            .or(() -> Optional.of("91154c40-4edf-4c05-b92f-ac52a0075829").map(persons::get));
                    return Mono.just(per.map(person -> {
                                List<SimpleGrantedAuthority> grants = Stream.of(
                                        "ADMIN", "DEVELOPER",
                                        organizationService.managedUnits(person.getId()).findAny().isPresent() ? "MANAGER" : null
                                ).filter(Objects::nonNull).map(SimpleGrantedAuthority::new).toList();

                                return new UsernamePasswordAuthenticationToken(
                                        person.getId(),
                                        null,
                                        grants
                                );
                            }).orElseThrow()
                    );
                })
                .formLogin(ServerHttpSecurity.FormLoginSpec::disable)
                .authorizeExchange(exchanges -> exchanges
                        .pathMatchers("/hc", Const.V1).permitAll()
                        .pathMatchers("/admin/**").hasAuthority("ADMIN")
                        .anyExchange().authenticated()
                )
                .build();
    }
}
