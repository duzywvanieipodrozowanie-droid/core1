package pl.zenstage.core.metrics.flow;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Flow metrics of the unit's Jira work items (stories, tasks, defects - no sub-tasks or epics): a work item starts
 * at its first move to an in-progress status and finishes when it goes LIVE. Durations are in days.
 */
public record FlowResponse(
        CycleTime cycleTime,
        Forecast forecast,
        Wip wip,
        List<PaceWeek> pace
) {
    /** pct = share of work items finished within that many days. */
    public record Percentile(int pct, BigDecimal value) {
    }

    /** Work items finished in the period: cycle time percentiles and histogram (days -> items). */
    public record CycleTime(int finished, List<Percentile> percentiles, List<Bucket> histogram) {
    }

    /** from inclusive, till exclusive; the last bucket is open-ended. */
    public record Bucket(int from, Integer till, int count) {
    }

    /**
     * Monte Carlo "how many items in the next {@code days}": pct = chance of finishing at least {@code value} items,
     * from daily throughput of the last {@code sampleDays} days.
     */
    public record Forecast(int days, int sampleDays, int simulations, List<Percentile> percentiles, List<Bucket> distribution) {
    }

    /** Work in progress now: age = days since its first in-progress status. */
    public record Wip(
            int count,
            BigDecimal avgAgeDays,
            int olderThanP85,
            int noMoveOver14Days,
            BigDecimal perPerson,
            List<WipItem> items
    ) {
    }

    public record WipItem(
            String key,
            String summary,
            String url,
            String type,
            String status,
            String assignee,
            BigDecimal ageDays,
            BigDecimal daysSinceLastMove
    ) {
    }

    /** Work items started (first in-progress) and finished (LIVE) in the week starting on Monday {@code week}. */
    public record PaceWeek(LocalDate week, int started, int finished) {
    }
}
