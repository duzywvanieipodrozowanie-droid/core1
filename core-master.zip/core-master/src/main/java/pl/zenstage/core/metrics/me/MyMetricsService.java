package pl.zenstage.core.metrics.me;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.commit.CommitStats;
import pl.zenstage.api.commit.CommitTasks;
import pl.zenstage.api.commit.zs.ZsSonarStats;
import pl.zenstage.api.components.PersonService;
import pl.zenstage.api.mr.MergeRequest;
import pl.zenstage.core.common.MathBigDecimal;
import pl.zenstage.core.common.ZsCommons;
import pl.zenstage.core.metrics.commits.CommitService;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationCache;
import pl.zenstage.core.organization.dto.Person;
import pl.zenstage.core.organization.dto.Unit;
import pl.zenstage.db.store.entity.SonarEntity;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.git.MergeRequestEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.MergeRequestRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MyMetricsService {
    private static final int TOP_LANGUAGES = 6;
    private static final int TOP_REVIEWERS = 5;
    private static final int RECENT_COMMITS = 5;
    private static final BigDecimal MINUTES_IN_HOUR = BigDecimal.valueOf(60);
    private static final BigDecimal HUNDRED = BigDecimal.valueOf(100);

    private final CommitRepository commitRepository;
    private final MergeRequestRepository mergeRequestRepository;
    private final CommitService commitService;
    private final OrganizationCache organizationCache;
    private final PersonService personService;

    public Mono<MyMetricsResponse> myMetrics(Interval interval) {
        return ZsCommons.currentUserName()
                .publishOn(Schedulers.boundedElastic())
                .map(userId -> calculate(userId, interval));
    }

    private MyMetricsResponse calculate(String userId, Interval interval) {
        Interval.Range range = interval.range(0);
        Interval.Range prevRange = interval.range(1);

        List<CommitEntity> commits = commitRepository.findByCommiterIdAndCommitDateBetween(userId, range.from(), range.till());
        long commitsPrev = commitRepository.findByCommiterIdAndCommitDateBetween(userId, prevRange.from(), prevRange.till()).size();
        List<MergeRequestEntity> mrs = mergeRequestRepository.findByAuthorIdAndCreateDateBetween(userId, range.from(), range.till());
        long mrsPrev = mergeRequestRepository.findByAuthorIdAndCreateDateBetween(userId, prevRange.from(), prevRange.till()).size();

        LocalDate firstDay = range.from().toLocalDate();
        LocalDate lastDay = range.till().toLocalDate().minusDays(1);
        Map<LocalDate, Long> perDay = commits.stream().filter(it -> it.getCommitDate() != null)
                .collect(Collectors.groupingBy(it -> it.getCommitDate().toLocalDate(), Collectors.counting()));
        List<MyMetricsResponse.DayCount> commitsPerDay = firstDay.datesUntil(lastDay.plusDays(1))
                .map(day -> new MyMetricsResponse.DayCount(day, perDay.getOrDefault(day, 0L)))
                .toList();
        BigDecimal workingDays = Interval.countWorkingDays(firstDay, lastDay);

        List<Commit> sources = commits.stream().map(CommitEntity::getSource).filter(Objects::nonNull).toList();
        List<MergeRequest> merged = mrs.stream().map(MergeRequestEntity::getSource).filter(Objects::nonNull)
                .filter(it -> it.mergedAt() != null && it.createdAt() != null).toList();

        return new MyMetricsResponse(
                profile(userId),
                commits.size(),
                commitsPrev,
                commitsPerDay.isEmpty() ? BigDecimal.ZERO
                        : BigDecimal.valueOf(commits.size()).divide(BigDecimal.valueOf(commitsPerDay.size()), 1, RoundingMode.HALF_UP),
                perDay.size(),
                workingDays,
                MathBigDecimal.sum(sources.stream().map(Commit::stats).filter(Objects::nonNull).map(CommitStats::additions)
                        .filter(Objects::nonNull).map(BigDecimal::valueOf).toList()),
                MathBigDecimal.sum(sources.stream().map(Commit::stats).filter(Objects::nonNull).map(CommitStats::deletions)
                        .filter(Objects::nonNull).map(BigDecimal::valueOf).toList()),
                mrs.size(),
                mrsPrev,
                merged.size(),
                minutesToHours(mrs.stream().map(MergeRequestEntity::getPickupTimeMinutes).filter(Objects::nonNull).toList()),
                minutesToHours(mrs.stream().map(MergeRequestEntity::getReviewTimeMinutes).filter(Objects::nonNull).toList()),
                MathBigDecimal.avg(merged.stream().map(it -> BigDecimal.valueOf(Duration.between(it.createdAt(), it.mergedAt()).toMinutes())
                        .divide(MINUTES_IN_HOUR, 2, RoundingMode.HALF_UP)).toList(), 1),
                quality(commits),
                commitsPerDay,
                languages(sources),
                sources.stream().filter(it -> it.languages() != null).count(),
                reviewers(mrs),
                commits.stream().filter(it -> it.getCommitDate() != null)
                        .sorted(Comparator.comparing(CommitEntity::getCommitDate).reversed())
                        .limit(RECENT_COMMITS)
                        .map(it -> new MyMetricsResponse.RecentCommit(
                                it.getCommitId(),
                                Optional.ofNullable(it.getSource()).map(Commit::title).orElse(null),
                                Optional.ofNullable(it.getTaskKey()).map(CommitTasks::tasks).orElseGet(Set::of),
                                it.getProjectId(),
                                it.getModuleName(),
                                it.getCommitDate()
                        )).toList()
        );
    }

    private MyMetricsResponse.Profile profile(String userId) {
        Optional<Person> person = Optional.ofNullable(organizationCache.findPerson(userId));
        String level = person.map(Person::level).map(it -> it.getLabel().split("/")[0].trim()).orElse(null);
        Optional<Unit> squad = squad(userId);
        String tribe = squad.map(it -> organizationCache.getParentUnits(it.id()).stream()
                .filter(parent -> typeContains(parent, "tribe"))
                .max(Comparator.comparingInt(organizationCache::level))
                .map(Unit::name).orElse(null)
        ).orElse(null);
        return new MyMetricsResponse.Profile(
                userId,
                person.map(Person::name).orElse(null),
                person.map(Person::email).orElse(null),
                level,
                level == null ? null : level + " Engineer",
                squad.map(Unit::name).orElse(null),
                tribe
        );
    }

    /** The deepest unit the user is a member of (falls back to units the user manages). */
    private Optional<Unit> squad(String userId) {
        Comparator<Unit> deepest = Comparator.comparingInt(organizationCache::level);
        return organizationCache.getUnits().stream()
                .filter(it -> it.members() != null && it.members().contains(userId))
                .max(deepest)
                .or(() -> organizationCache.getUnits().stream()
                        .filter(it -> it.managers() != null && it.managers().contains(userId))
                        .max(deepest));
    }

    private static boolean typeContains(Unit unit, String type) {
        return unit.type() != null && unit.type().toLowerCase(Locale.ROOT).contains(type);
    }

    private MyMetricsResponse.Quality quality(List<CommitEntity> commits) {
        List<ZsSonarStats> scans = commitService.loadScansForCommits(commits).stream()
                .map(SonarEntity::getStats).filter(Objects::nonNull).toList();
        return new MyMetricsResponse.Quality(
                scans.size(),
                avgInt(scans, ZsSonarStats::newBugs),
                avgInt(scans, ZsSonarStats::newViolations),
                avgInt(scans, ZsSonarStats::newCodeSmells),
                MathBigDecimal.avg(scans.stream().map(ZsSonarStats::newCoverage).filter(Objects::nonNull).toList(), 1),
                avgInt(scans, ZsSonarStats::newDuplicatedBlocks)
        );
    }

    private static BigDecimal avgInt(List<ZsSonarStats> scans, Function<ZsSonarStats, Integer> field) {
        return MathBigDecimal.avg(scans.stream().map(field).filter(Objects::nonNull).map(BigDecimal::valueOf).toList(), 1);
    }

    private List<MyMetricsResponse.LanguageShare> languages(List<Commit> commits) {
        Map<String, Long> lines = new HashMap<>();
        commits.stream().map(Commit::languages).filter(Objects::nonNull)
                .flatMap(it -> it.entrySet().stream())
                .filter(it -> it.getKey() != null && it.getValue() != null && it.getValue() > 0)
                .forEach(it -> lines.merge(it.getKey(), it.getValue().longValue(), Long::sum));
        long total = lines.values().stream().mapToLong(Long::longValue).sum();
        if (total == 0) {
            return List.of();
        }
        List<Map.Entry<String, Long>> sorted = lines.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed()).toList();
        Map<String, Long> top = new LinkedHashMap<>();
        sorted.stream().limit(TOP_LANGUAGES).forEach(it -> top.put(it.getKey(), it.getValue()));
        long other = sorted.stream().skip(TOP_LANGUAGES).mapToLong(Map.Entry::getValue).sum();
        if (other > 0) {
            top.merge("Other", other, Long::sum);
        }
        return top.entrySet().stream().map(it -> new MyMetricsResponse.LanguageShare(it.getKey(), it.getValue(), pct(it.getValue(), total))).toList();
    }

    private List<MyMetricsResponse.ReviewerShare> reviewers(List<MergeRequestEntity> mrs) {
        List<List<String>> approvers = mrs.stream().map(MergeRequestEntity::getSource).filter(Objects::nonNull)
                .map(MergeRequest::approverEmails).filter(Objects::nonNull)
                .map(personService::findAllIdsByEmails).map(it -> it.stream().distinct().toList())
                .toList();
        long reviewedMrs = approvers.stream().filter(it -> !it.isEmpty()).count();
        if (reviewedMrs == 0) {
            return List.of();
        }
        Map<String, Long> perReviewer = approvers.stream().flatMap(Collection::stream)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        return perReviewer.entrySet().stream()
                .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                .limit(TOP_REVIEWERS)
                .map(it -> new MyMetricsResponse.ReviewerShare(
                        it.getKey(),
                        Optional.ofNullable(organizationCache.findPerson(it.getKey())).map(Person::name).orElse(it.getKey()),
                        it.getValue(),
                        pct(it.getValue(), reviewedMrs)
                )).toList();
    }

    private static BigDecimal minutesToHours(List<BigDecimal> minutes) {
        return MathBigDecimal.avg(minutes, 2).divide(MINUTES_IN_HOUR, 1, RoundingMode.HALF_UP);
    }

    private static BigDecimal pct(long part, long total) {
        return BigDecimal.valueOf(part).multiply(HUNDRED).divide(BigDecimal.valueOf(total), 1, RoundingMode.HALF_UP);
    }
}
