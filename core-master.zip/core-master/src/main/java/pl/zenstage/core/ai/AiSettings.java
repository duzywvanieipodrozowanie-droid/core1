package pl.zenstage.core.ai;

import java.time.Duration;

/**
 * Effective configuration of the AI agent: set by an administrator in Settings → AI agent, otherwise the
 * {@code zenstage.ai.*} defaults ({@link AiProperties}).
 *
 * @param baseUrl full URL of the OpenAI-compatible API root, e.g. {@code https://llm.example.com/v1}
 */
public record AiSettings(
        boolean enabled,
        String baseUrl,
        String apiKey,
        String model,
        boolean toolsEnabled,
        int maxToolRounds,
        double temperature,
        Duration timeout,
        Proxy proxy,
        Tls tls
) {
    /**
     * HTTP proxy for the calls to the model.
     *
     * @param nonProxyHosts hosts called directly, separated by {@code |} or {@code ,}, {@code *} as a wildcard
     */
    public record Proxy(boolean enabled, String host, Integer port, String username, String password, String nonProxyHosts) {
        public static final Proxy NONE = new Proxy(false, null, null, null, null, null);

        public boolean active() {
            return enabled && host != null && !host.isBlank() && port != null && port > 0;
        }
    }

    /**
     * TLS trust for an {@code https} model URL.
     *
     * @param caCertificates extra trusted CA certificates in PEM (e.g. the company CA), on top of the JVM ones
     * @param skipVerify     accept any certificate and host name (testing only)
     */
    public record Tls(String caCertificates, boolean skipVerify) {
        public static final Tls NONE = new Tls(null, false);
    }
}
