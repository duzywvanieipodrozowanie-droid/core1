package pl.zenstage.core.releasecheck;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/** Tests → Release check: microservice images of one environment against another or against a release task. */
public final class ReleaseCheck {

    private ReleaseCheck() {
    }

    /** DIFFERENT: other version; MISSING: not on the checked environment; EXTRA: only there; SAME. */
    public enum Result { DIFFERENT, MISSING, EXTRA, SAME }

    /** A microservice on an environment, or its version in a Fix Version (image and environment empty). */
    public record Side(String version, String image, String environment, String fixVersion) {
    }

    /**
     * @param left  release mode: the environment (beta); environments mode: the source (alfa)
     * @param right release mode: the Fix Version; environments mode: the target (beta)
     */
    public record Row(String microservice, String serviceMapProject, Side left, Side right, Result result, String release) {
    }

    public record Comparison(String leftName, String rightName, List<String> environmentsMatched, List<Row> rows,
                             List<ReleaseTask> releases, String note) {
    }

    public record ReleaseTask(String key, String summary, String status, String assignee, String url,
                              List<String> fixVersions, LocalDate dueDate, LocalDateTime updated, LocalDateTime created) {
    }
}
