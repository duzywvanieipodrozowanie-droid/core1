package pl.zenstage.core.metrics.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import pl.zenstage.core.metrics.request.Interval;

import java.util.List;

public record TeamMetricsResponse(
        Interval interval,
        String id,
        Type type,
        List<EmployeeMetricsResponse> metricsPrev,
        List<EmployeeMetricsResponse> metrics
) {
    @JsonProperty
    public TotalMetrics total() {
        return TotalMetrics.sum(metrics.stream().map(EmployeeMetricsResponse::total).toList());
    }

    @JsonProperty
    public AvgMetrics avg() {
        return AvgMetrics.fromTotal(interval, total());
    }

    @JsonProperty
    public TotalMetrics totalPrev() {
        return TotalMetrics.sum(metricsPrev.stream().map(EmployeeMetricsResponse::total).toList());
    }

    @JsonProperty
    public AvgMetrics avgPrev() {
        return AvgMetrics.fromTotal(interval, totalPrev());
    }

    public enum Type {
        UNIT,
        PPROJECT,
    }
}

