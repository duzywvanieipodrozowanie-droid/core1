package pl.zenstage.core.metrics.flow;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/metrics/flow")
@RequiredArgsConstructor
public class FlowController {
    private final FlowService flowService;
    private final FlowEfficiencyService flowEfficiencyService;

    /** "Przepływ pracy" popup on Overview: cycle time, forecast, WIP and pace from the unit's Jira work items. */
    @GetMapping
    public Mono<ResponseEntity<FlowResponse>> flow(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_4") Interval interval
    ) {
        return flowService.flow(unitId, interval).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    /** "Flow efficiency" popup on Overview: active vs waiting time by Jira status of the work items gone LIVE. */
    @GetMapping("/efficiency")
    public Mono<ResponseEntity<FlowEfficiencyResponse>> efficiency(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_4") Interval interval
    ) {
        return flowEfficiencyService.efficiency(unitId, interval).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }
}
