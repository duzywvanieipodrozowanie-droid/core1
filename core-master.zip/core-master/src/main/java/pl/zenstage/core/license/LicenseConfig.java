package pl.zenstage.core.license;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.stream.Collectors;

@Configuration
public class LicenseConfig {
    private final ObjectMapper objectMapper;

    public LicenseConfig() {
        this.objectMapper = new ObjectMapper();
        this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        this.objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    @Bean
    ZsLicense lic(
            @Value("${zs.license:#{null}}") String licenseKey
    ) {
        if (licenseKey == null || licenseKey.isBlank()) {
            return ZsLicense.community();
        }
        byte[] decoded = Base64.getDecoder().decode(licenseKey.getBytes());
        License license;
        try {
            license = objectMapper.readValue(decoded, License.class);
            byte[] sig = Base64.getDecoder().decode(license.signature());
            boolean status = verifySignature(license.license().getBytes(), sig);
            if (!status) {
                return ZsLicense.community();
            }
            ZsLicense zsLicense = objectMapper.readValue(license.license(), ZsLicense.class);
            System.out.println(zsLicense);
            return zsLicense;
        } catch (IOException e) {
            return ZsLicense.community();
        }
    }

    @SneakyThrows
    private boolean verifySignature(byte[] data, byte[] signature) {
        PublicKey pubKey = loadPublicKeyFromResource();
        Signature verifier = Signature.getInstance("SHA256withECDSA");
        verifier.initVerify(pubKey);
        verifier.update(data);
        return verifier.verify(signature);
    }

    private PublicKey loadPublicKeyFromResource() throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        final String key;
        try (InputStream is = new ClassPathResource("sig/zs.pem").getInputStream();
             BufferedReader reader = new BufferedReader(
                     new InputStreamReader(is, StandardCharsets.UTF_8)
             )
        ) {
            key = reader.lines().filter(line -> !line.contains("BEGIN") && !line.contains("END"))
                    .collect(Collectors.joining(""));
            byte[] derKey = Base64.getDecoder().decode(key.getBytes());
            X509EncodedKeySpec spec = new X509EncodedKeySpec(derKey);
            return KeyFactory.getInstance("EC").generatePublic(spec);
        }
    }

}

