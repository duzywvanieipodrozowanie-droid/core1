package pl.zenstage.core.organization.components;

import org.springframework.stereotype.Service;
import pl.zenstage.core.common.ZsCommons;
import pl.zenstage.core.organization.dto.Person;
import pl.zenstage.core.organization.dto.Unit;
import pl.zenstage.db.store.entity.PersonEntity;
import pl.zenstage.db.store.repository.PersonRepository;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class OrganizationCache {
    private static final long RELOAD_INTERVAL_MS = 60_000;
    private final OrganizationYamlLoader loader;
    private volatile long lastReload;
    private final Map<String, Person> byLogin = new ConcurrentHashMap<>();
    // units, people and managers are read from the database (unit, person) and reloaded when older than a minute or
    // after a change in the admin screens; the lists are replaced as a whole, so a reader never sees one half-filled
    private volatile Map<String, Set<String>> managedUnits = Map.of();
    private volatile List<Unit> units = List.of();
    private final PersonRepository personRepository;

    OrganizationCache(OrganizationYamlLoader loader, PersonRepository personRepository) {
        this.loader = loader;
        this.personRepository = personRepository;
        reloadCache();
    }

    public List<Unit> getUnits() {
        reloadIfStale();
        return units;
    }

    public synchronized void refresh() {
        reloadCache();
    }

    private void reloadIfStale() {
        if (System.currentTimeMillis() - lastReload > RELOAD_INTERVAL_MS) {
            synchronized (this) {
                if (System.currentTimeMillis() - lastReload > RELOAD_INTERVAL_MS) {
                    reloadCache();
                }
            }
        }
    }

    private synchronized void reloadCache() {
        lastReload = System.currentTimeMillis();
        this.loader.organizationRebuild();
        Map<String, Person> peoples = new HashMap<>();
        personRepository.findAll().stream().map(OrganizationCache::mapPerson).forEach(it -> peoples.put(it.id(), it));
        this.byLogin.keySet().retainAll(peoples.keySet());
        this.byLogin.putAll(peoples);
        this.managedUnits = matchManagedUnits();
        this.units = List.copyOf(this.loader.getOrganization().unitsDeep());
    }

    public List<Person> allPeoples() {
        reloadIfStale();
        return new ArrayList<>(byLogin.values());
    }

    public Person findPerson(String employeeId) {
        reloadIfStale();
        return employeeId == null ? null : byLogin.get(employeeId);
    }

    public Optional<Person> findUser(String userId) {
        return Optional.ofNullable(userId).map(this::findPerson);
    }

    public Unit getRoot() {
        return this.loader.getOrganization();
    }

    /** After a change of the units: the units, their managers and members as they are in the database now. */
    public Unit getRootReload() {
        reloadCache();
        return this.loader.getOrganization();
    }

    public Mono<Boolean> isManager(Unit unit) {
        return ZsCommons.currentUserName().filter(it -> unit != null)
                .mapNotNull(this.managedUnits::get).map(it -> it.contains(unit.id()));
    }

    public Person findUserOrNull(String userId) {
        return findUser(userId).orElse(null);
    }

    public Optional<Unit> findUnit(String unitId) {
        return loader.getOrganization().unitsDeep().stream().filter(it -> Objects.equals(it.id(), unitId)).findAny();
    }


    private Map<String, Set<String>> matchManagedUnits() {
        Map<String, Set<String>> managedUnits = new ConcurrentHashMap<>();
        List<Unit> unitsWithManagers = this.loader.getOrganization().unitsDeep().stream().filter(it -> it.managers() != null).toList();
        for (Unit unit : unitsWithManagers) {
            List<String> unitsRecursive = unit.unitsDeep().stream().map(Unit::id).toList();
            unit.managers().forEach(managerId -> {
                managedUnits.computeIfAbsent(managerId, k -> ConcurrentHashMap.newKeySet()).addAll(unitsRecursive);
            });
        }
        ConcurrentHashMap<String, Set<String>> result = new ConcurrentHashMap<>();
        managedUnits.forEach((k, v) -> result.put(k, Collections.unmodifiableSet(v)));
        return result;
    }

    public int level(Unit it) {
        Optional<String> unit = Optional.ofNullable(it).map(Unit::id);
        int level = 0;
        while ((unit = unit.map(loader::parentUnit)).isPresent()) level++;
        return level;
    }

    public Set<Unit> getParentUnits(String unitId) {
        HashSet<Unit> parents = new HashSet<>();
        Optional<String> id = Optional.ofNullable(unitId);
        while ((id = id.map(loader::parentUnit)).isPresent()) id.flatMap(this::findUnit).ifPresent(parents::add);
        return parents;
    }

    private static Person mapPerson(PersonEntity person) {
        return new Person(person.getId(), person.getName(), person.getEmail(), person.getCommiterEmails(), person.isTechnical(), person.isAdmin(), person.getLevel(), person.getSkills());
    }
}
