package pl.zenstage.core.metrics.roadmap;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.deliver.DeliverResponse.EpicList;
import pl.zenstage.core.metrics.deliver.DeliverService;
import reactor.core.publisher.Mono;

import java.time.LocalDate;

@RestController
@RequestMapping("/metrics/roadmap")
@RequiredArgsConstructor
public class RoadmapController {
    private final DeliverService deliverService;

    /** Epics of the unit planned for a quarter of the year (Deliver screen), with their progress and delivery health. */
    @GetMapping
    public Mono<ResponseEntity<EpicList>> roadmap(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false) Integer year
    ) {
        return deliverService.roadmap(unitId, year == null ? LocalDate.now().getYear() : year).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }
}
