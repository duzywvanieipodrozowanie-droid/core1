package pl.zenstage.core.metrics;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.response.MetricValue;
import pl.zenstage.core.metrics.deploy.DeployMetricService;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/metrics/deploy")
@RequiredArgsConstructor
public class DeployMetricsController {
    private final DeployMetricService deployService;

    @GetMapping("/frequency")
    public Mono<ResponseEntity<MetricValue>> frequency(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, true, deployService::frequency).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/failRate")
    public Mono<ResponseEntity<MetricValue>> failRate(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, deployService::failRate).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }
}
