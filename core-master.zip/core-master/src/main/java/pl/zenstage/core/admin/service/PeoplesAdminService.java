package pl.zenstage.core.admin.service;

import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import pl.zenstage.core.access.AccessService;
import pl.zenstage.core.organization.components.OrganizationCache;
import pl.zenstage.core.organization.dto.Person;
import pl.zenstage.db.store.entity.PersonEntity;
import pl.zenstage.db.store.repository.PersonRepository;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class PeoplesAdminService {
    private final OrganizationCache organizationCache;
    private final PersonRepository personRepository;
    private final AccessService accessService;

    public List<Person> getPeoples(Authentication user, String query) {
        String lowerQuery = StringUtils.isBlank(query) ? null : query.trim().toLowerCase();
        return getPeoples(user).stream()
                .filter(p ->
                        lowerQuery == null
                                || Stream.of(p.name(), p.email(), p.id()).filter(Objects::nonNull)
                                .map(String::toLowerCase).anyMatch(it -> it.contains(lowerQuery))
                ).sorted((f, s) -> Objects.compare(f.name(), s.name(), String::compareTo))
                .limit(20)
                .toList();
    }

    public List<Person> getPeoples(Authentication user) {
        return organizationCache.allPeoples();
    }

    public List<Person> delete(Authentication user, @PathVariable String personId) {
        personRepository.deleteById(personId);
        organizationCache.refresh();
        return getPeoples(user);
    }

    public List<Person> save(Authentication user, Person person) {
        PersonEntity personEntity = Optional.of(person).map(Person::id).flatMap(personRepository::findById)
                .orElseGet(PersonEntity::new);
        personEntity.setId(person.id());
        personEntity.setName(person.name());
        personEntity.setEmail(person.email());
        personEntity.setCommiterEmails(person.commiterEmails());
        personEntity.setTechnical(person.technical());
        personEntity.setAdmin(person.admin());
        personEntity.setLevel(person.level());
        personEntity.setSkills(person.skills());
        personRepository.save(personEntity);
        organizationCache.refresh();
        // a new person gets into Settings → Users and access right away
        accessService.importPersons();
        return getPeoples(user);
    }
}
