package pl.zenstage.core.app;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
public class AppController {
    @Value("${spring.webflux.base-path:}")
    private String contextPath;
    @Value("${zenstage.app-name}")
    private String appName;
    @Value("${zenstage.logo-file}")
    private String logoFile;

    @GetMapping
    ResponseEntity<Object> base() {
        return ResponseEntity.status(HttpStatus.FOUND)
                .header("Location", contextPath.isEmpty() ? "/user" : "/")
                .build();
    }

    @GetMapping("/hc")
    ResponseEntity<String> logged(Authentication authentication) {
        return ResponseEntity.status(
                Optional.ofNullable(authentication).filter(Authentication::isAuthenticated)
                        .map(it -> HttpStatus.OK).orElse(HttpStatus.UNAUTHORIZED)
        ).body("");
    }

    @GetMapping(value = "/name", produces = "text/html")
    public String appName() {
        return appName;
    }

    @GetMapping(value = "/logo", produces = "image/png")
    public byte[] logo() throws IOException {
        String image = "logo/zeni_logo.png";
        if (logoFile != null && !logoFile.isBlank()) {
            image = "logo/ol_logo.jpg";
        }
        return new ClassPathResource(image).getInputStream().readAllBytes();
    }
}
