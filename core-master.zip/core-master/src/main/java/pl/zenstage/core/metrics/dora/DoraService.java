package pl.zenstage.core.metrics.dora;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import pl.zenstage.api.task.Task;
import pl.zenstage.core.common.MathBigDecimal;
import pl.zenstage.core.investments.TaskCommonsService;
import pl.zenstage.core.investments.TaskService;
import pl.zenstage.core.metrics.commits.CommitCommonsService;
import pl.zenstage.core.metrics.commits.CommitService;
import pl.zenstage.core.metrics.pr.PrChartTimeRecord;
import pl.zenstage.core.metrics.pr.PrFlow;
import pl.zenstage.core.metrics.pr.MrFlowService;
import pl.zenstage.core.metrics.pr.PrLastItem;
import pl.zenstage.core.metrics.pr.PrState;
import pl.zenstage.core.metrics.pr.PrThroughputRecord;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.response.ChartResponse;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.task.TaskEntity;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Slf4j
@Service
@RequiredArgsConstructor
public class DoraService {
    private final TaskService taskService;
    private final MrFlowService mrFlowService;
    private final TaskCommonsService taskCommonsService;

    // Jira issue types of release tasks (a type containing one of the words), e.g. "Release", "Release Request"
    @Value("${zenstage.dora.release-types:release}")
    private List<String> releaseTypes = List.of("release");

    /**
     * Deployment frequency: the unit's Jira release tasks moved to LIVE in the range. Every release task counts once
     * (on the first move to LIVE in the range), whatever its status now.
     */
    public Mono<BigDecimal> development(String unitId, Interval.Range range) {
        return releasesPerDay(unitId, range)
                .map(perDay -> BigDecimal.valueOf(perDay.values().stream().mapToInt(Integer::intValue).sum()));
    }

    /** Release tasks moved to LIVE per day of the range (days without a release are missing). */
    public Mono<Map<LocalDate, Integer>> releasesPerDay(String unitId, Interval.Range range) {
        return taskService.getUnitTasksUpdatedSince(unitId, range.from()).map(tasks -> {
            Map<String, LocalDateTime> liveAtByKey = new HashMap<>();
            tasks.stream()
                    .map(TaskEntity::getContent)
                    .filter(it -> it != null && isRelease(it.type()))
                    .forEach(task -> taskCommonsService.liveTransitions(task, range).min(Comparator.naturalOrder())
                            .ifPresent(at -> liveAtByKey.merge(task.key(), at, (a, b) -> a.isBefore(b) ? a : b)));
            return liveAtByKey.values().stream()
                    .collect(Collectors.groupingBy(LocalDateTime::toLocalDate, TreeMap::new, Collectors.summingInt(it -> 1)));
        });
    }

    boolean isRelease(String type) {
        String t = Objects.toString(type, "").toLowerCase(Locale.ROOT);
        return !t.isBlank() && releaseTypes.stream().map(it -> it.trim().toLowerCase(Locale.ROOT))
                .anyMatch(it -> !it.isEmpty() && t.contains(it));
    }

    /**
     * Average calendar hours from IN PROGRESS to LIVE over the unit's Jira tasks that went LIVE in the range
     * (each task once, sub-tasks included; tasks never IN PROGRESS are skipped).
     */
    public Mono<BigDecimal> inProgressToLive(String unitId, Interval.Range range) {
        return taskService.getUnitSimpleTasksIfAllowed(unitId, range)
                .map(tasks -> MathBigDecimal.avg(
                        TaskCommonsService.filterTasksLeadTime(tasks)
                                .collect(Collectors.toMap(Task::key, it -> it, (a, b) -> a, LinkedHashMap::new))
                                .values().stream()
                                .map(it -> taskCommonsService.inProgressToLiveHours(it, range))
                                .filter(Objects::nonNull)
                                .toList(),
                        1
                ));
    }

    /**
     * Lead time for changes in hours: first commit -> merge into main/master, averaged over the unit's merge requests
     * merged in the range (see {@link MrFlowService}). Previously task-based (until LIVE in Jira) and in weeks,
     * while the screen labels it hours.
     */
    public Mono<BigDecimal> leadTime(String unitId, Interval.Range range) {
        return mrFlowService.leadTime(unitId, range);
    }

    public Mono<BigDecimal> failureRate(String unitId, Interval.Range range) {
        return taskService.getUnitSimpleTasksIfAllowed(unitId, range)
                .map(tasks -> MathBigDecimal.avg(
                        TaskCommonsService.filterFailureRate(tasks)
                                .map(taskCommonsService::failureRate).toList(),
                        1
                ));
    }

    public Mono<BigDecimal> mttr(String unitId, Interval.Range range) {
        return taskService.getUnitSimpleTasksIfAllowed(unitId, range)
                .map(tasks -> MathBigDecimal.avg(
                        TaskCommonsService.filterMeanTimeToRecovery(tasks)
                                .map(taskCommonsService::recoveryTime).toList(),
                        1
                ));
    }


    /** Release tasks moved to LIVE on every day of the period (also the days without any), oldest first. */
    public Mono<ChartResponse<DoraChartTimeRecord>> chartDeployment(String unitId, Interval interval) {
        Interval.Range range = interval.range(0);
        LocalDate first = range.from().toLocalDate();
        LocalDate end = range.till().toLocalDate();
        return releasesPerDay(unitId, range).map(perDay -> {
            List<DoraChartTimeRecord> values = first.datesUntil(end)
                    .map(day -> new DoraChartTimeRecord(day, day, perDay.getOrDefault(day, 0)))
                    .toList();
            return new ChartResponse<>(values, new DoraChartTimeRecord(first, end.minusDays(1),
                    values.stream().mapToInt(DoraChartTimeRecord::value).sum()));
        });
    }

    public Mono<ChartResponse<DoraChartTimeRecord>> chartLeadTime(String unitId, Interval interval) {
        return Flux.fromIterable(
                        IntStream.rangeClosed(0, 3)
                                .mapToObj(offset -> interval.range(3 - offset))
                                .toList()
                )
                .concatMap(range -> leadTime(unitId, range)
                        .map(value -> new DoraChartTimeRecord(
                                range.from().toLocalDate(),
                                range.till().toLocalDate(),
                                value.setScale(0, RoundingMode.HALF_UP).intValue()
                        ))
                )
                .collectList()
                .map(values -> new ChartResponse<>(
                        values,
                        new DoraChartTimeRecord(
                                values.getFirst().startDate(),
                                values.getLast().endDate(),
                                values.stream().mapToInt(DoraChartTimeRecord::value).sum()
                        )
                ));
    }

}
