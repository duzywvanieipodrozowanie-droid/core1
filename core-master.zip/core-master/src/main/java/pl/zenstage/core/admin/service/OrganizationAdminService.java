package pl.zenstage.core.admin.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import pl.zenstage.core.admin.dto.AddUnit;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.core.organization.components.OrganizationCache;
import pl.zenstage.core.organization.dto.Unit;
import pl.zenstage.db.store.entity.UnitEntity;
import pl.zenstage.db.store.repository.PersonRepository;
import pl.zenstage.db.store.repository.UnitRepository;

import java.util.Collections;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OrganizationAdminService {
    private final OrganizationCache organizationCache;
    private final UnitRepository unitRepository;
    private final PersonRepository personRepository;

    public Unit getRoot(Authentication user) {
        return organizationCache.getRoot();
    }

    public Unit delete(Authentication user, @PathVariable String unitId) {
        Optional<Unit> unitToDelete = organizationCache.findUnit(unitId);
        if (unitToDelete.isEmpty()) {
            throw new ZenStageException(HttpStatus.NOT_FOUND);
        }
        boolean containsSubunits = unitToDelete.map(Unit::units).filter(it -> !it.isEmpty()).isPresent();
        if (containsSubunits) {
            throw new ZenStageException(HttpStatus.BAD_REQUEST, "Can't delete subunits");
        }
        unitRepository.deleteById(unitId);
        return organizationCache.getRootReload();
    }

    public Unit add(Authentication user, AddUnit unit) {
        boolean rootExists = !unitRepository.findAll().isEmpty();
        Optional<UnitEntity> parentUnit = Optional.of(unit).map(AddUnit::parentUnitId).flatMap(unitRepository::findById);
        if (rootExists && parentUnit.isEmpty()) {
            throw new ZenStageException(HttpStatus.BAD_REQUEST, "Parent unit not found for id " + unit.parentUnitId() + ", only one root allowed !!");
        }
        Optional.of(unit).map(it -> new UnitEntity(
                null,
                it.name(),
                it.type(),
                Collections.emptySet(),
                Collections.emptySet(),
                Collections.emptySet(),
                parentUnit.orElse(null)
        )).map(unitRepository::save);
        return organizationCache.getRootReload();
    }

    public Unit addManager(Authentication it, String unitId, String manager) {
        personRepository.findById(manager).orElseThrow(() -> new ZenStageException(HttpStatus.BAD_REQUEST, "Employee with id " + manager + " not found !!"));
        Optional.of(unitId).flatMap(unitRepository::findById).ifPresent(unit -> {
            unit.getManagers().add(manager);
            unitRepository.save(unit);
        });
        return organizationCache.getRootReload();
    }

    public Unit deleteManager(Authentication it, String unitId, String manager) {
        Optional.of(unitId).flatMap(unitRepository::findById).ifPresent(unit -> {
            unit.getManagers().remove(manager);
            unitRepository.save(unit);
        });
        return organizationCache.getRootReload();
    }

    public Unit addMember(Authentication it, String unitId, String member) {
        personRepository.findById(member).orElseThrow(() -> new ZenStageException(HttpStatus.BAD_REQUEST, "Employee with id " + member + " not found !!"));
        Optional.of(unitId).flatMap(unitRepository::findById).ifPresent(unit -> {
            unit.getMembers().add(member);
            unitRepository.save(unit);
        });
        return organizationCache.getRootReload();
    }

    public Unit deleteMember(Authentication it, String unitId, String member) {
        Optional.of(unitId).flatMap(unitRepository::findById).ifPresent(unit -> {
            unit.getMembers().remove(member);
            unitRepository.save(unit);
        });
        return organizationCache.getRootReload();
    }

    public Unit addProject(Authentication it, String unitId, String project) {
//        personRepository.findById(member).orElseThrow(() -> new ZenStageException(HttpStatus.BAD_REQUEST, "Employee with id " + member + " not found !!"));
        Optional.of(unitId).flatMap(unitRepository::findById).ifPresent(unit -> {
            unit.getProjects().add(project);
            unitRepository.save(unit);
        });
        return organizationCache.getRootReload();
    }

    public Unit deleteProject(Authentication it, String unitId, String project) {
        Optional.of(unitId).flatMap(unitRepository::findById).ifPresent(unit -> {
            unit.getProjects().remove(project);
            unitRepository.save(unit);
        });
        return organizationCache.getRootReload();
    }
}
