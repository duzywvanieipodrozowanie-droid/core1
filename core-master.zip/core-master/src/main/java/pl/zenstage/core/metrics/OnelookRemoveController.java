package pl.zenstage.core.metrics;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.response.MetricValue;
import reactor.core.publisher.Mono;

// TODO remove
@RestController
@RequiredArgsConstructor
public class OnelookRemoveController {
    private final PullRequestController prc;

    @GetMapping("/metrics/pr/t")
    public Mono<ResponseEntity<MetricValue>> prTpOL(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return prc.prTp(unitId, interval);
    }

    @GetMapping("/metrics/pr/c")
    public Mono<ResponseEntity<MetricValue>> prCtOl(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return prc.prCt(unitId, interval);
    }
}
