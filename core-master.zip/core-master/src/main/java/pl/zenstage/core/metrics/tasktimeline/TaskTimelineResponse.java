package pl.zenstage.core.metrics.tasktimeline;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Full path of one Jira task: time in workflow phases (from the Jira status history), commits with the task key,
 * merge requests linked to the task, their approvals and pipelines, and one chronological list of events.
 */
public record TaskTimelineResponse(
        String key,
        String projectId,
        String summary,
        String type,
        String priority,
        String status,
        String url,
        String assignee,
        String creator,
        String parentKey,
        List<String> sprints,
        LocalDateTime created,
        // first entry into a DONE phase status the task is still in; null while the task is not done
        LocalDateTime doneAt,
        // created -> doneAt (or now when not done)
        BigDecimal leadTimeHours,
        // time per phase from Jira statuses, except REVIEW = pickup + review time of the linked MRs (GitLab)
        List<PhaseTime> phases,
        LocalDateTime firstCommitAt,
        // merge of the first MR merged into a protected branch
        LocalDateTime mergedAt,
        // first commit -> merge
        BigDecimal codeCycleHours,
        BigDecimal pickupHours,
        BigDecimal reviewHours,
        Pipeline pipeline,
        List<Event> events,
        List<StatusChange> statusChanges,
        List<MergeRequestInfo> mergeRequests,
        List<CommitInfo> commits
) {
    public enum Phase { BACKLOG, ANALYSIS, CODING, REVIEW, TEST, WAITING, DONE }

    public enum Source { JIRA, GITLAB }

    public record PhaseTime(Phase phase, BigDecimal hours, List<String> statuses) {
    }

    public record Event(
            LocalDateTime at,
            Source source,
            String kind,
            String title,
            String detail,
            Phase phase
    ) {
    }

    public record StatusChange(
            String from,
            String to,
            String author,
            LocalDateTime at,
            // time spent in the "from" status
            BigDecimal hoursInFrom,
            Phase toPhase
    ) {
    }

    public record ApprovalInfo(String name, LocalDateTime at) {
    }

    public record Pipeline(String status, BigDecimal minutes, long failedBefore) {
    }

    public record MergeRequestInfo(
            String id,
            String title,
            String repository,
            String targetBranch,
            Boolean targetBranchProtected,
            String state,
            String author,
            LocalDateTime createdAt,
            LocalDateTime mergedAt,
            LocalDateTime firstCommitAt,
            BigDecimal pickupHours,
            BigDecimal reviewHours,
            Integer comments,
            Integer changedFiles,
            List<ApprovalInfo> approvals,
            Pipeline pipeline
    ) {
    }

    public record CommitInfo(
            String id,
            String title,
            String author,
            String repository,
            LocalDateTime date,
            Integer additions,
            Integer deletions,
            boolean mergeCommit
    ) {
    }
}
