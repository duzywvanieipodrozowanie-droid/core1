package pl.zenstage.core.admin;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.api.project.ProjectDto;
import pl.zenstage.core.admin.service.ProjectAdminService;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.core.common.ZsCommons;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.List;

@RestController
@RequestMapping(Const.ADMIN + "/organization/project")
@RequiredArgsConstructor
public class AdminProjectsController {
    private final ProjectAdminService projectAdminService;

    @GetMapping
    Flux<ProjectDto> getAll() {
        return ZsCommons.currentUser().map(projectAdminService::getProjects).flatMapIterable(it -> it);
    }

    @DeleteMapping("/{projectId}")
    Mono<ResponseEntity<List<ProjectDto>>> delete(@PathVariable String projectId) {
        return ZsCommons.currentUser().map(it -> projectAdminService.delete(it, projectId))
                .publishOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .onErrorResume(
                        ZenStageException.class,
                        e -> Mono.just(ResponseEntity.status(e.getStatus()).build())
                );
    }

    @PutMapping("/save")
    Mono<ResponseEntity<List<ProjectDto>>> save(@RequestBody ProjectDto project) {
        return ZsCommons.currentUser().map(it -> projectAdminService.save(it, project))
                .publishOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .onErrorResume(
                        ZenStageException.class,
                        e -> Mono.just(ResponseEntity.status(e.getStatus()).build())
                );
    }
}
