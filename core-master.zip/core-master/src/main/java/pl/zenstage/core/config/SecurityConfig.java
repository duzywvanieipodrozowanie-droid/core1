package pl.zenstage.core.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcReactiveOAuth2UserService;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.userinfo.ReactiveOAuth2UserService;
import org.springframework.security.oauth2.core.oidc.OidcIdToken;
import org.springframework.security.oauth2.core.oidc.OidcUserInfo;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.web.server.SecurityWebFilterChain;
import reactor.core.scheduler.Schedulers;
import pl.zenstage.core.access.AccessService;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@ConditionalOnExpression("#{!${spring.security.disabled:false}}")
@Log4j2
@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {
    @Bean
    public SecurityWebFilterChain ssoConfig(ServerHttpSecurity http, AccessService accessService) {
        log.info("### Security WebFlux SSO rule");
        return http
                .cors(ServerHttpSecurity.CorsSpec::disable)
                .csrf(ServerHttpSecurity.CsrfSpec::disable)
                .httpBasic(ServerHttpSecurity.HttpBasicSpec::disable)
                .formLogin(ServerHttpSecurity.FormLoginSpec::disable)
                .oauth2Login(Customizer.withDefaults())
                .oauth2Client(Customizer.withDefaults())
                .authorizeExchange(exchanges -> {
                    exchanges.pathMatchers("/hc", "/v1/**", "/logo").permitAll();
                    // roles are checked live (Settings → Users and access), not taken from the login session
                    exchanges.pathMatchers("/admin/**").access(accessService.requirePage(null));
                    // project setup (environments, task regex): reading is for everyone, changing for admins
                    exchanges.pathMatchers(HttpMethod.PUT, "/environment", "/environment/**").access(accessService.requirePage(null));
                    // endpoints of the menu pages restricted in Settings → Users and access (Deliver, Code Impact, Task Timeline...)
                    AccessService.PAGES.stream().filter(page -> !page.apiPaths().isEmpty()).forEach(page ->
                            exchanges.pathMatchers(page.apiPaths().toArray(String[]::new)).access(accessService.requirePage(page.key())));
                    exchanges.anyExchange().authenticated();
                }).build();
    }

    @Bean
    public ReactiveOAuth2UserService<OidcUserRequest, OidcUser> oidcUserService(
            @Value("${spring.security.oauth2.client.provider.external.user-name-attribute:sub}") String usernameAttribute,
            @Value("${zenstage.oauth.domain_regex:#{null}}") String domainRegex,
            AccessService accessService
    ) {
        OidcReactiveOAuth2UserService delegate = new OidcReactiveOAuth2UserService();
        return userRequest -> delegate.loadUser(userRequest)
                // app_user is written at login (JPA, blocking)
                .publishOn(Schedulers.boundedElastic())
                .map(oidcUser -> {
                    String uniqueName = Optional.of(oidcUser).map(OidcUser::getIdToken)
                            .map(it -> it.getClaimAsString(usernameAttribute)).orElseGet(oidcUser::getName);
                    if (domainRegex != null) {
                        uniqueName = uniqueName.replaceAll(domainRegex, "");
                        log.trace("### Security domain regex found: {}, escaped username: {}", domainRegex, uniqueName);
                    }
                    // a new user gets into app_user (Settings → Users and access); the roles in the session are only
                    // a snapshot, requests are authorized with the live roles (AccessService)
                    accessService.loggedIn(uniqueName, oidcUser.getFullName(), oidcUser.getEmail());
                    List<SimpleGrantedAuthority> grants = accessService.roles(uniqueName).stream()
                            .map(Enum::name).map(SimpleGrantedAuthority::new).toList();

                    return new ZsUser(
                            uniqueName,
                            grants,
                            oidcUser.getIdToken(),
                            oidcUser.getUserInfo(),
                            usernameAttribute
                    );
                });
    }

    public static class ZsUser extends DefaultOidcUser {
        private final String prettyName;

        public ZsUser(String prettyName, List<SimpleGrantedAuthority> grants, OidcIdToken idToken, OidcUserInfo userInfo, String usernameAttribute) {
            super(grants, idToken, userInfo, usernameAttribute);
            this.prettyName = prettyName;
        }

        @Override
        public String getName() {
            return prettyName;
        }
    }
}
