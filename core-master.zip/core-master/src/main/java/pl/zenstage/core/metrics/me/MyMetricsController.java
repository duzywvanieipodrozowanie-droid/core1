package pl.zenstage.core.metrics.me;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/metrics/me")
@RequiredArgsConstructor
public class MyMetricsController {
    private final MyMetricsService myMetricsService;

    @GetMapping
    public Mono<MyMetricsResponse> myMetrics(
            @RequestParam(required = false, defaultValue = "WEEKS_4") Interval interval
    ) {
        return myMetricsService.myMetrics(interval);
    }
}
