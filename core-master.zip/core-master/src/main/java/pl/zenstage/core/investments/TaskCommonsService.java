package pl.zenstage.core.investments;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.task.History;
import pl.zenstage.api.task.Task;
import pl.zenstage.api.task.TaskStatus;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.repository.CommitRepository;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class TaskCommonsService {

    private final static String UNKNOWN = "Other";
    private static final String STATUS_FIELD_TYPE = "status";
    private static final BigDecimal SECONDS_IN_WEEK = BigDecimal.valueOf(7 * 24 * 60 * 60);

    private static final Set<TaskStatus> IGNORED_DEPLOYMENT_TIME_STATUSES = Set.of(
            TaskStatus.TODO,
            TaskStatus.ANALYSIS,
            TaskStatus.IN_REVIEW,
            TaskStatus.REFINEMENT,
            TaskStatus.READY_FOR_DEVELOPMENT
    );

    private final CommitRepository commitRepository;


    //Created by AI. Do przepisania ;)
    public static List<Investment> filterTasks(List<TaskEntity> tasks, Boolean bau) {
        int totalTasks = tasks.size();

        if (totalTasks == 0) {
            return List.of();
        }

        if (bau != null) {
            Map<String, Integer> labelsCount = tasks.stream()
                    .flatMap(task -> {
                        List<String> labels = task.getLabels();

                        if (labels == null || labels.stream().noneMatch(label -> label != null && !label.isBlank())) {
                            return Stream.of(UNKNOWN);
                        }

                        return labels.stream()
                                .filter(label -> label != null && !label.isBlank());
                    })
                    .collect(Collectors.groupingBy(
                            label -> label,
                            Collectors.summingInt(label -> 1)
                    ));

            return labelsCount.entrySet().stream()
                    .map(entry -> new Investment(
                            entry.getKey(),
                            BigDecimal.valueOf(entry.getValue() * 100 / totalTasks)
                    ))
                    .toList();
        } else {
            Map<String, Integer> bauCount = tasks.stream()
                    .collect(Collectors.groupingBy(
                            task -> {
                                Boolean b = task.getBau();
                                if (b == null || !b) {
                                    return "feature";
                                }
                                return "bau";
                            },
                            Collectors.summingInt(task -> 1)
                    ));

            return bauCount.entrySet().stream()
                    .map(entry -> new Investment(
                            entry.getKey(),
                            BigDecimal.valueOf(entry.getValue() * 100 / totalTasks)
                    ))
                    .toList();
        }
    }

    public static List<InvestmentTeam> filterTasksByTeams(List<TaskEntity> tasks, Boolean bau) {
        return tasks.stream()
                .collect(Collectors.groupingBy(TaskEntity::getProjectId))
                .entrySet()
                .stream()
                .map(entry -> new InvestmentTeam(
                        entry.getKey(),
                        filterTasks(entry.getValue(), bau)
                ))
                .toList();
    }

    public static Stream<Task> filterTasksDeploymentFrequency(List<TaskEntity> tasks) {
        return tasks.stream()
                .map(TaskEntity::getContent)
                .filter(it -> !it.histories().isEmpty());
    }

    public static Stream<Task> filterTasksLeadTime(List<TaskEntity> tasks) {
        return tasks.stream()
                .map(TaskEntity::getContent)
                .filter(it -> !it.histories().isEmpty());
    }

    public static Stream<Task> filterFailureRate(List<TaskEntity> tasks) {
        return tasks.stream()
                .map(TaskEntity::getContent)
                .filter(it -> !it.histories().isEmpty());
    }

    public static Stream<Task> filterMeanTimeToRecovery(List<TaskEntity> tasks) {
        return tasks.stream()
                .map(TaskEntity::getContent)
                .filter(it -> !it.histories().isEmpty());
    }

    public BigDecimal leadTime(Task task) {
        if (task == null || task.histories() == null) {
            return BigDecimal.ZERO;
        }

        LocalDateTime firstCommitAt = commitRepository.firstCommitDateForTask(task.projectId(), task.key()).orElse(null);
        LocalDateTime activeFrom = null;
        long seconds = 0;

        for (History history : task.histories().stream()
                .filter(history -> history != null
                        && history.created() != null
                        && STATUS_FIELD_TYPE.equalsIgnoreCase(history.fieldType()))
                .sorted(Comparator.comparing(History::created))
                .toList()) {
            TaskStatus status = toStatus(history.to());

            if (status == TaskStatus.LIVE) {
                return activeFrom == null
                        ? BigDecimal.ZERO
                        : BigDecimal.valueOf(seconds + Duration.between(activeFrom, history.created()).getSeconds())
                          .divide(SECONDS_IN_WEEK, 1, RoundingMode.HALF_UP);
            }

            if (IGNORED_DEPLOYMENT_TIME_STATUSES.contains(status)) {
                if (activeFrom != null) {
                    seconds += Duration.between(activeFrom, history.created()).getSeconds();
                    activeFrom = null;
                }
            } else if (status != TaskStatus.UNKNOWN && activeFrom == null) {
                activeFrom = firstCommitAt != null && firstCommitAt.isBefore(history.created())
                        ? firstCommitAt
                        : history.created();
            }
        }

        return BigDecimal.ZERO;
    }

    private static TaskStatus toStatus(String value) {
        if (value == null || value.isBlank()) {
            return TaskStatus.UNKNOWN;
        }

        String normalizedValue = value.trim();

        for (TaskStatus status : TaskStatus.values()) {
            if (status.name().equalsIgnoreCase(normalizedValue)
                    || status.getJiraName().equalsIgnoreCase(normalizedValue)) {
                return status;
            }
        }

        return TaskStatus.fromJiraName(normalizedValue);
    }


    /**
     * Calendar hours from the first move to IN PROGRESS until the task went LIVE within the range;
     * null when it did not go LIVE in the range or never was IN PROGRESS before that.
     */
    public BigDecimal inProgressToLiveHours(Task task, Interval.Range range) {
        if (task == null || task.histories() == null) {
            return null;
        }
        LocalDateTime inProgressAt = null;
        for (History history : task.histories().stream()
                .filter(history -> history != null
                        && history.created() != null
                        && STATUS_FIELD_TYPE.equalsIgnoreCase(history.fieldType()))
                .sorted(Comparator.comparing(History::created))
                .toList()) {
            TaskStatus status = toStatus(history.to());
            if (status == TaskStatus.IN_PROGRESS && inProgressAt == null) {
                inProgressAt = history.created();
            } else if (status == TaskStatus.LIVE && inProgressAt != null
                    && !history.created().isBefore(range.from()) && history.created().isBefore(range.till())) {
                return BigDecimal.valueOf(Duration.between(inProgressAt, history.created()).toMinutes())
                        .divide(BigDecimal.valueOf(60), 1, RoundingMode.HALF_UP);
            }
        }
        return null;
    }

    /** Moments the task moved to LIVE within the range (status transitions from its Jira history). */
    public Stream<LocalDateTime> liveTransitions(Task task, Interval.Range range) {
        if (task == null || task.histories() == null) {
            return Stream.empty();
        }
        return task.histories().stream()
                .filter(history -> history != null
                        && history.created() != null
                        && !history.created().isBefore(range.from())
                        && history.created().isBefore(range.till())
                        && STATUS_FIELD_TYPE.equalsIgnoreCase(history.fieldType())
                        && isStatus(history.to(), TaskStatus.LIVE))
                .map(History::created);
    }

    /**
     * Number of unique deployments: tasks going LIVE within {@code gap} of the previous one belong to the same
     * deployment (one release of several services / tasks), a longer pause starts a new deployment.
     */
    public static int countDeployments(Stream<LocalDateTime> liveTimes, Duration gap) {
        List<LocalDateTime> sorted = liveTimes.sorted().toList();
        int deployments = 0;
        LocalDateTime previous = null;
        for (LocalDateTime time : sorted) {
            if (previous == null || Duration.between(previous, time).compareTo(gap) > 0) {
                deployments++;
            }
            previous = time;
        }
        return deployments;
    }

    private static boolean isStatus(String value, TaskStatus expectedStatus) {
        return toStatus(value) == expectedStatus;
    }

    public BigDecimal failureRate(Task task) {
        //todo
        return BigDecimal.ZERO;
    }

    public BigDecimal recoveryTime(Task task) {
        //todo
        return BigDecimal.ZERO;
    }

}
