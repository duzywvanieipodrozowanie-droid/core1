package pl.zenstage.core.metrics.benchmark;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import pl.zenstage.core.common.MathBigDecimal;
import pl.zenstage.core.metrics.build.PipelineMetricService;
import pl.zenstage.core.metrics.dora.DoraService;
import pl.zenstage.core.metrics.pr.PullRequestService;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.organization.dto.Unit;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;

/**
 * "Local benchmark" on Overview and DORA: every widget's value of the selected unit against the average of all units
 * of the same type in the whole organization, in the same period. Organization averages are computed without the
 * current user's management rights (see {@link OrganizationService#ORG_WIDE_ACCESS}) and cached for a while, as they
 * need the metric of every unit.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BenchmarkService {
    private static final Duration AVERAGE_CACHE = Duration.ofMinutes(15);
    // units computed at once for an organization average
    private static final int CONCURRENCY = 4;
    private static final int MAX_CACHED_AVERAGES = 500;

    private final PullRequestService pullRequestService;
    private final PipelineMetricService pipelineMetricService;
    private final DoraService doraService;
    private final OrganizationService organizationService;

    private final Map<String, Mono<Average>> averages = new ConcurrentHashMap<>();

    private record Metric(String key, boolean lessBetter, BiFunction<String, Interval.Range, Mono<BigDecimal>> value) {
    }

    private record Average(BigDecimal value, int units) {
    }

    /** Widgets of the Overview screen, keys as in the response. */
    private List<Metric> overviewMetrics() {
        return List.of(
                new Metric("prCycle", true, pullRequestService::prCt),
                new Metric("prThroughput", false, pullRequestService::prTp),
                new Metric("deployFreq", false, doraService::development),
                new Metric("buildFailRate", true, pipelineMetricService::failRate),
                new Metric("inProgressToLive", true, doraService::inProgressToLive)
        );
    }

    /** Widgets of the DORA screen. */
    private List<Metric> doraMetrics() {
        return List.of(
                new Metric("deployFreq", false, doraService::development),
                new Metric("leadTime", true, doraService::leadTime),
                new Metric("changeFailure", true, doraService::failureRate),
                new Metric("mttr", true, doraService::mttr)
        );
    }

    public Mono<BenchmarkResponse> overviewBenchmark(String unitId, Interval interval) {
        return benchmark(unitId, interval, overviewMetrics());
    }

    public Mono<BenchmarkResponse> doraBenchmark(String unitId, Interval interval) {
        return benchmark(unitId, interval, doraMetrics());
    }

    private Mono<BenchmarkResponse> benchmark(String unitId, Interval interval, List<Metric> metrics) {
        Interval.Range range = interval.range(0);
        // the selected unit, or without one the first unit the user manages; empty when not allowed
        return organizationService.userManageAllowed(unitId).next().flatMap(unit -> {
            List<Unit> peers = organizationService.peerUnits(unit);
            return Flux.fromIterable(metrics)
                    .concatMap(metric -> Mono.zip(
                            metric.value().apply(unitId, range).defaultIfEmpty(BigDecimal.ZERO),
                            average(metric, unit, peers, interval, range)
                    ).map(t -> Map.entry(metric.key(), item(metric, t.getT1(), t.getT2()))))
                    .collectList()
                    .map(entries -> {
                        Map<String, BenchmarkResponse.Item> items = new LinkedHashMap<>();
                        entries.forEach(e -> items.put(e.getKey(), e.getValue()));
                        return new BenchmarkResponse(unit.type(), peers.size(), items);
                    });
        });
    }

    private Mono<Average> average(Metric metric, Unit unit, List<Unit> peers, Interval interval, Interval.Range range) {
        String key = metric.key() + "|" + interval + "|" + range.from() + "|" + unit.type();
        if (averages.size() > MAX_CACHED_AVERAGES) {
            // keys contain the period start, so old days pile up
            averages.clear();
        }
        return averages.computeIfAbsent(key, k -> Flux.fromIterable(peers)
                .flatMap(peer -> metric.value().apply(peer.id(), range)
                                .contextWrite(OrganizationService.orgWideAccess())
                                .onErrorResume(e -> {
                                    log.warn("Benchmark {} for unit {} failed: {}", metric.key(), peer.id(), e.getMessage());
                                    return Mono.empty();
                                }),
                        CONCURRENCY)
                // units without data for the metric (0) would only pull the average down
                .filter(value -> value != null && value.signum() != 0)
                .collectList()
                .map(values -> new Average(values.isEmpty() ? null : MathBigDecimal.avg(values, 2), values.size()))
                .cache(value -> AVERAGE_CACHE, error -> Duration.ZERO, () -> Duration.ZERO));
    }

    private static BenchmarkResponse.Item item(Metric metric, BigDecimal value, Average average) {
        BigDecimal avg = average.value();
        if (avg == null || avg.signum() == 0) {
            return new BenchmarkResponse.Item(value, avg, average.units(), null, null);
        }
        BigDecimal diffPct = value.subtract(avg).multiply(BigDecimal.valueOf(100)).divide(avg, 0, RoundingMode.HALF_UP);
        int cmp = value.compareTo(avg);
        Boolean better = cmp == 0 ? Boolean.TRUE : metric.lessBetter() ? cmp < 0 : cmp > 0;
        return new BenchmarkResponse.Item(value, avg.setScale(1, RoundingMode.HALF_UP), average.units(), diffPct, better);
    }
}
