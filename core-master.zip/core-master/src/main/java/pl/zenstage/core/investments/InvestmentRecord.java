package pl.zenstage.core.investments;

import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Mono;

import java.util.List;

@FunctionalInterface
public interface InvestmentRecord {
    Mono<List<Investment>> match(String unitId, Interval.Range range);
}
