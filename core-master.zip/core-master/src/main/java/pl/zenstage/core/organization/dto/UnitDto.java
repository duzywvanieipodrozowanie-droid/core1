package pl.zenstage.core.organization.dto;

import pl.zenstage.core.metrics.team.TeamPerson;

import java.util.List;

public record UnitDto(
        String id,
        String name,
        String type,
        Boolean manager,
        List<TeamPerson> members,
        List<UnitDto> units
) {
}
