package pl.zenstage.core.codemap.response;

import java.util.List;

/**
 * Jira issues in one version of a microservice: the ones with the Fix Version of that version and the ones linked to a
 * release task with it. {@code fixVersions}: the matching Fix Version names; {@code otherVersions}: other Fix Versions
 * of the microservice in Jira (to show when nothing matches, e.g. another naming).
 */
public record CodeMapIssues(
        String module,
        String tag,
        List<String> fixVersions,
        List<Issue> issues,
        List<String> otherVersions
) {
    /** {@code source}: FIX_VERSION, or the key of the release task the issue is linked to. */
    public record Issue(
            String key,
            String summary,
            String type,
            String status,
            String assignee,
            String url,
            String source
    ) {
    }
}
