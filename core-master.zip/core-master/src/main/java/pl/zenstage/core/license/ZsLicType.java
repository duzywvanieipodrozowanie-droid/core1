package pl.zenstage.core.license;

import java.time.LocalDate;
import java.util.Optional;

public enum ZsLicType {
    COMMUNITY,
    PREMIUM,
    ULTRA,
    ;

    public boolean assignableFrom(ZsLicense userLicense) {
        boolean valid = Optional.ofNullable(userLicense).map(ZsLicense::expireDate)
                .map(it -> it.isAfter(LocalDate.now().minusDays(1)))
                .orElse(false);
        if (userLicense == null || !valid) {
            return this == COMMUNITY;
        } else {
            return this.ordinal() <= userLicense.type().ordinal();
        }
    }
}
