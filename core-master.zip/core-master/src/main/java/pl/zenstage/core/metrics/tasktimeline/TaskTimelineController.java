package pl.zenstage.core.metrics.tasktimeline;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.util.Map;

@RestController
@RequestMapping("/metrics/task-timeline")
@RequiredArgsConstructor
public class TaskTimelineController {
    private final TaskTimelineService taskTimelineService;

    /**
     * 200 with the timeline; 404 with {"error": "TASK_NOT_FOUND"} when the task is not in the database, or
     * {"error": "NO_PROJECT_ACCESS", "projectIds": [...]} when its project is outside the user's units. The error body
     * lets the screen tell these apart from a 404 of a backend without this endpoint.
     */
    @GetMapping
    public Mono<ResponseEntity<Object>> timeline(@RequestParam("key") String key) {
        return taskTimelineService.timeline(key)
                .map(it -> it.timeline() != null
                        ? ResponseEntity.ok((Object) it.timeline())
                        : ResponseEntity.status(HttpStatus.NOT_FOUND)
                                .body((Object) Map.of("error", it.error(), "projectIds", it.projectIds())));
    }
}
