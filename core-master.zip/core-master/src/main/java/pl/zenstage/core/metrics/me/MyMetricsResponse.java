package pl.zenstage.core.metrics.me;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

/**
 * Personal metrics of the logged-in user for the selected interval ("prev" fields cover the preceding interval).
 */
public record MyMetricsResponse(
        Profile profile,
        long commits,
        long commitsPrev,
        BigDecimal dailyAvgCommits,
        long activeDays,
        BigDecimal workingDays,
        BigDecimal additions,
        BigDecimal deletions,
        long mrsCreated,
        long mrsCreatedPrev,
        long mrsMerged,
        BigDecimal avgPickupHours,
        BigDecimal avgReviewHours,
        BigDecimal avgCycleHours,
        Quality quality,
        List<DayCount> commitsPerDay,
        List<LanguageShare> languages,
        long commitsWithLanguages,
        List<ReviewerShare> reviewers,
        List<RecentCommit> recentCommits
) {
    public record Profile(
            String id,
            String name,
            String email,
            String level,
            String role,
            String squad,
            String tribe
    ) {
    }

    /** Averages over the user's commits that have a Sonar scan. */
    public record Quality(
            long scannedCommits,
            BigDecimal avgNewBugs,
            BigDecimal avgNewViolations,
            BigDecimal avgNewCodeSmells,
            BigDecimal avgNewCoverage,
            BigDecimal avgNewDuplicatedBlocks
    ) {
    }

    public record DayCount(LocalDate day, long commits) {
    }

    public record LanguageShare(String name, long lines, BigDecimal pct) {
    }

    public record ReviewerShare(String id, String name, long mrs, BigDecimal pct) {
    }

    public record RecentCommit(
            String id,
            String title,
            Set<String> tasks,
            String project,
            String module,
            LocalDateTime date
    ) {
    }
}
