package pl.zenstage.core.codemap;

import java.util.List;

public record TagDiff(
        List<String> issues,
        List<String> commits,
        List<String> tags
) {
}
