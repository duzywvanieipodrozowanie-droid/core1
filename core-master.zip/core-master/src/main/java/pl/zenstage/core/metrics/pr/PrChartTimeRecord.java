package pl.zenstage.core.metrics.pr;

import pl.zenstage.core.common.IChartLabel;

import java.math.BigDecimal;
import java.time.LocalDate;

public record PrChartTimeRecord(
        LocalDate startDate,
        LocalDate endDate,
        BigDecimal coding,
        BigDecimal pickup,
        BigDecimal review,
        BigDecimal build,
        BigDecimal merge
) implements IChartLabel {
    public PrChartTimeRecord(LocalDate commitDate, BigDecimal coding, BigDecimal pickup, BigDecimal review, BigDecimal build, BigDecimal merge) {
        this(commitDate, null, coding, pickup, review, build, merge);
    }
}
