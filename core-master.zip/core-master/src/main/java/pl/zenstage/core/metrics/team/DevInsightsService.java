package pl.zenstage.core.metrics.team;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.mr.MergeRequest;
import pl.zenstage.core.common.MathBigDecimal;
import pl.zenstage.core.metrics.commits.CommitService;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.git.MergeRequestEntity;
import pl.zenstage.db.store.entity.git.PipelineEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.PipelineRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DevInsightsService {
    private static final Set<String> FINISHED_PIPELINE = Set.of("success", "failed", "canceled");
    // git revert writes "This reverts commit <full sha>." into the message
    private static final Pattern REVERTED_SHA = Pattern.compile("This reverts commit ([0-9a-f]{40})");

    private final CommitService commitService;
    private final OrganizationService organizationService;
    private final CommitRepository commitRepository;
    private final PipelineRepository pipelineRepository;

    public Flux<DevInsights> insights(String unitId, Interval interval) {
        Interval.Range range = interval.range(0);
        return Mono.zip(
                commitService.getUnitCommitsIfAllowed(unitId, range),
                commitService.getUnitManageMrIfAllowed(unitId, range),
                organizationService.userManageProjectsMembers(unitId)
        ).publishOn(Schedulers.boundedElastic()).flatMapIterable(t ->
                calculate(t.getT1(), t.getT2(), t.getT3().projects(), range)
        );
    }

    private List<DevInsights> calculate(List<CommitEntity> commits, List<MergeRequestEntity> mrs, Collection<String> projects, Interval.Range range) {
        Map<CommitEntity.Pk, CommitEntity> commitsByPk = commits.stream()
                .collect(Collectors.toMap(DevInsightsService::pk, Function.identity(), (f, s) -> f));

        // pipelines of the unit's projects, attributed to the author of the commit they ran for
        Map<String, List<PipelineEntity>> pipelinesByPerson = new HashMap<>();
        if (!projects.isEmpty()) {
            pipelineRepository.findByProjectIdInAndCreateDateBetween(projects, range.from(), range.till()).forEach(pp ->
                    Optional.ofNullable(commitsByPk.get(new CommitEntity.Pk(pp.getProjectId(), pp.getModuleName(), pp.getCommitId())))
                            .map(CommitEntity::getCommiterId)
                            .ifPresent(personId -> pipelinesByPerson.computeIfAbsent(personId, k -> new ArrayList<>()).add(pp))
            );
        }

        Map<String, Long> revertsMade = new HashMap<>();
        Set<CommitEntity.Pk> revertedPks = new HashSet<>();
        for (CommitEntity commit : commits) {
            Commit source = commit.getSource();
            if (source == null || source.title() == null || !source.title().startsWith("Revert ")) {
                continue;
            }
            revertsMade.merge(commit.getCommiterId(), 1L, Long::sum);
            Matcher matcher = REVERTED_SHA.matcher(Optional.ofNullable(source.message()).orElse(""));
            while (matcher.find()) {
                revertedPks.add(new CommitEntity.Pk(commit.getProjectId(), commit.getModuleName(), matcher.group(1)));
            }
        }
        // reverted commits may be older than the interval, so the ones not loaded yet are fetched by id
        List<CommitEntity.Pk> missing = revertedPks.stream().filter(it -> !commitsByPk.containsKey(it)).toList();
        Map<CommitEntity.Pk, CommitEntity> revertedCommits = new HashMap<>(commitsByPk);
        if (!missing.isEmpty()) {
            commitRepository.findAllById(missing).forEach(it -> revertedCommits.put(pk(it), it));
        }
        Map<String, Long> commitsReverted = revertedPks.stream().map(revertedCommits::get).filter(Objects::nonNull)
                .map(CommitEntity::getCommiterId).filter(Objects::nonNull)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        Map<String, List<MergeRequestEntity>> mrsByPerson = mrs.stream().filter(it -> it.getAuthorId() != null)
                .collect(Collectors.groupingBy(MergeRequestEntity::getAuthorId));

        Set<String> people = new HashSet<>();
        commits.stream().map(CommitEntity::getCommiterId).filter(Objects::nonNull).forEach(people::add);
        people.addAll(mrsByPerson.keySet());

        return people.stream().map(personId -> {
            List<PipelineEntity> pipelines = pipelinesByPerson.getOrDefault(personId, List.of());
            List<MergeRequest> personMrs = mrsByPerson.getOrDefault(personId, List.of()).stream()
                    .map(MergeRequestEntity::getSource).filter(Objects::nonNull).toList();
            List<MergeRequest> withStats = personMrs.stream()
                    .filter(it -> it.userNotesCount() != null || it.changesCount() != null).toList();
            return new DevInsights(
                    personId,
                    pipelines.size(),
                    pipelines.stream().filter(it -> "failed".equals(lower(it.getStatus()))).count(),
                    MathBigDecimal.avg(pipelines.stream()
                            .filter(it -> FINISHED_PIPELINE.contains(lower(it.getStatus())))
                            .filter(it -> it.getCreateDate() != null && it.getUpdateDate() != null && !it.getUpdateDate().isBefore(it.getCreateDate()))
                            .map(it -> BigDecimal.valueOf(Duration.between(it.getCreateDate(), it.getUpdateDate()).toSeconds())
                                    .divide(BigDecimal.valueOf(60), 2, RoundingMode.HALF_UP))
                            .toList(), 1),
                    revertsMade.getOrDefault(personId, 0L),
                    commitsReverted.getOrDefault(personId, 0L),
                    mrsByPerson.getOrDefault(personId, List.of()).size(),
                    MathBigDecimal.avg(withStats.stream().map(MergeRequest::userNotesCount).filter(Objects::nonNull).map(BigDecimal::valueOf).toList(), 1),
                    MathBigDecimal.avg(withStats.stream().map(MergeRequest::changesCount).filter(Objects::nonNull).map(BigDecimal::valueOf).toList(), 1),
                    withStats.size()
            );
        }).toList();
    }

    private static CommitEntity.Pk pk(CommitEntity commit) {
        return new CommitEntity.Pk(commit.getProjectId(), commit.getModuleName(), commit.getCommitId());
    }

    private static String lower(String value) {
        // never null: Set.of(...).contains(null) throws
        return value == null ? "" : value.toLowerCase(Locale.ROOT);
    }
}
