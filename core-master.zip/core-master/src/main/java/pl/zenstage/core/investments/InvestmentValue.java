package pl.zenstage.core.investments;

import lombok.NoArgsConstructor;
import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.IntStream;

@NoArgsConstructor
public class InvestmentValue {

    public static Mono<List<Investment>> current(String unitId, Interval interval, InvestmentRecord producer) {
        return producer.match(unitId, interval.range(0));
    }

    public static Mono<List<InvestmentTeam>> current(String unitId, Interval interval, InvestmentTeamRecord producer) {
        return producer.match(unitId, interval.range(0));
    }

    public static Mono<List<List<Investment>>> from(String unitId, Interval interval, InvestmentRecord producer) {
        return Flux.fromIterable(
                        IntStream.rangeClosed(0, 3)
                                .mapToObj(offset -> interval.range(3 - offset))
                                .toList()
                )
                .concatMap(range -> producer.match(unitId, range))
                .collectList();
    }

    public static Mono<List<List<InvestmentTeam>>> from(String unitId, Interval interval, InvestmentTeamRecord producer) {
        return Flux.fromIterable(
                        IntStream.rangeClosed(0, 3)
                                .mapToObj(offset -> interval.range(3 - offset))
                                .toList()
                )
                .concatMap(range -> producer.match(unitId, range))
                .collectList();
    }

}
