package pl.zenstage.core.codemap.response;

import pl.zenstage.core.codemap.TagDiff;

public record CodeMapEnv(
        String name,
        String image,
        String tag,
        TagDiff diff
) {

}
