package pl.zenstage.core.metrics;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.commits.CommitService;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.response.ChartResponse;
import pl.zenstage.core.metrics.response.MetricValue;
import pl.zenstage.core.metrics.team.ContribRecord;
import pl.zenstage.core.metrics.team.DevInsights;
import pl.zenstage.core.metrics.team.DevInsightsService;
import pl.zenstage.core.metrics.team.SprintTeamCapacityResponse;
import pl.zenstage.core.metrics.team.TeamCommitsCheck;
import pl.zenstage.core.metrics.team.TeamHealth;
import pl.zenstage.core.metrics.team.TeamMetricsService;
import pl.zenstage.core.metrics.team.TeamPerson;
import pl.zenstage.core.metrics.team.TotalCommitsRecord;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/metrics/team")
@RequiredArgsConstructor
public class TeamController {
    private final TeamMetricsService teamMetricsService;
    private final JiraTaskService jiraTaskService;
    private final DevInsightsService devInsightsService;
    private final CommitService commitService;

    @GetMapping("/commits")
    public Mono<ResponseEntity<MetricValue>> totalCommits(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, true, teamMetricsService::totalCommits).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/chart/ca")
    public Mono<ResponseEntity<ChartResponse<TotalCommitsRecord>>> caChart(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return teamMetricsService.commitActivityChart(unitId, interval).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/chart/contrib")
    public Mono<ResponseEntity<ChartResponse<ContribRecord>>> contribChart(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return teamMetricsService.contribChart(unitId, interval).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/details")
    public Flux<TeamPerson> details(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return teamMetricsService.getTeam(unitId, interval);
    }

    /** Why the commits do (not) count in the Team details: unit projects, commits of the members outside them, authors without a person. */
    @GetMapping("/commits-check")
    public Mono<TeamCommitsCheck> commitsCheck(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return commitService.commitsCheck(unitId, interval);
    }

    @GetMapping("/dev-insights")
    public Flux<DevInsights> devInsights(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return devInsightsService.insights(unitId, interval);
    }

    @GetMapping("/health")
    public Mono<ResponseEntity<TeamHealth>> health(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return teamMetricsService.health(unitId, interval).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/task-capacity")
    public Mono<ResponseEntity<SprintTeamCapacityResponse>> getTeamCapacity(
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval,
            @RequestParam(required = false, name = "unitId") String unitId
    ) {
        return jiraTaskService.getUnitCapacity(unitId)
                .map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

}
