package pl.zenstage.core.common;

import java.time.LocalDate;

public interface IChartLabel {
    LocalDate startDate();
    LocalDate endDate();
    default String getLabel() {
        return ChartDateToLabelFormatter.getLabel(startDate(), endDate());
    }
}
