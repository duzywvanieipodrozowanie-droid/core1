package pl.zenstage.core.metrics.response;

public record UnknownTasker(String id) {}
