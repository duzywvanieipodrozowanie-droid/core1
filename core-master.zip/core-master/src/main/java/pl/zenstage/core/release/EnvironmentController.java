package pl.zenstage.core.release;

import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.api.project.ProjectDto;
import pl.zenstage.db.store.entity.release.EnvStateEntity;
import pl.zenstage.db.store.entity.release.ProjectEntity;
import pl.zenstage.db.store.repository.EnvStateRepository;
import pl.zenstage.db.store.repository.ProjectRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.GroupedFlux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@RestController
@RequestMapping("/environment")
@RequiredArgsConstructor
public class EnvironmentController {
    private final EnvStateRepository envStateRepository;
    private final ProjectRepository projectRepository;

    @GetMapping
    Flux<ProjectDto> all() {
        Flux<ProjectEntity> projects = Flux.fromIterable(projectRepository.findAll());
        return projects.map(it -> new ProjectDto(
                it.getName(),
                it.getLabel(),
                it.getTaskRegex(),
                it.getEnvironments(),
                it.getPriorityModules()
        ));
    }

    @PutMapping
    Mono<ProjectDto> saveProject(@RequestBody Mono<ProjectDto> projectDto) {
        return projectDto.map(it -> new ProjectEntity(
                it.id(),
                it.label(),
                it.taskRegex(),
                it.envs(),
                it.priorityModules()
        )).map(projectRepository::save).map(p -> new ProjectDto(
                p.getName(),
                p.getLabel(),
                p.getTaskRegex(),
                p.getEnvironments(),
                p.getPriorityModules()
        ));
    }

    @GetMapping("/{projectId}")
    Flux<Pair<String, Iterable<EnvStateEntity>>> getProject(@PathVariable String projectId) {
//        Mono<ProjectEntity> project = projectId.map(projectRepository::findById).filter(Optional::isPresent).map(Optional::get);
        Flux<GroupedFlux<String, EnvStateEntity>> projectEnvState = Mono.just(projectId)
                .flatMapIterable(envStateRepository::findAllByProjectId).groupBy(EnvStateEntity::getEnvironment);

        return projectEnvState.publishOn(Schedulers.boundedElastic()).map(it ->
                new ImmutablePair<>(it.key(), it.toIterable())
        );
    }
}
