package pl.zenstage.core.investments;

import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Mono;

import java.util.List;

@FunctionalInterface
public interface InvestmentTeamRecord {
    Mono<List<InvestmentTeam>> match(String unitId, Interval.Range range);
}
