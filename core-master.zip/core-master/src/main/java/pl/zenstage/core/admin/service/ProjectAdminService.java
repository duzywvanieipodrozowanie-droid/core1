package pl.zenstage.core.admin.service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import pl.zenstage.api.project.ProjectDto;
import pl.zenstage.db.store.entity.release.ProjectEntity;
import pl.zenstage.db.store.repository.ProjectRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProjectAdminService {
    private final ProjectRepository projectRepository;

    public List<ProjectDto> getProjects(Authentication authentication) {
        return projectRepository.findAll().stream().map(it -> new ProjectDto(
                it.getName(),
                it.getLabel(),
                it.getTaskRegex(),
                it.getEnvironments(),
                it.getPriorityModules()
        )).toList();
    }

    public List<ProjectDto> delete(Authentication authentication, String projectId) {
        projectRepository.deleteById(projectId);
        return getProjects(authentication);
    }

    public List<ProjectDto> save(Authentication authentication, ProjectDto project) {
        projectRepository.save(new ProjectEntity(
                project.id(),
                project.label(),
                project.taskRegex(),
                project.envs(),
                project.priorityModules()
        ));
        return getProjects(authentication);
    }
}
