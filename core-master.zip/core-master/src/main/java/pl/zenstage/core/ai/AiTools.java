package pl.zenstage.core.ai;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;
import pl.zenstage.api.task.History;
import pl.zenstage.api.task.Task;
import pl.zenstage.api.task.TaskStatus;
import pl.zenstage.core.codemap.CodeMapService;
import pl.zenstage.core.codemap.CodeMapService.EnvTag;
import pl.zenstage.core.common.ZsCommons;
import pl.zenstage.core.metrics.ReleaseTasks;
import pl.zenstage.core.metrics.benchmark.BenchmarkResponse;
import pl.zenstage.core.metrics.benchmark.BenchmarkService;
import pl.zenstage.core.metrics.deliver.DeliverResponse;
import pl.zenstage.core.metrics.deliver.DeliverService;
import pl.zenstage.core.metrics.me.MyMetricsResponse;
import pl.zenstage.core.metrics.me.MyMetricsService;
import pl.zenstage.core.metrics.pr.PrLastItem;
import pl.zenstage.core.metrics.pr.PullRequestService;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.team.PersonMetric;
import pl.zenstage.core.metrics.team.TeamMetricsService;
import pl.zenstage.core.metrics.team.TeamPerson;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.Phase;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineService;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.organization.dto.Person;
import pl.zenstage.core.organization.dto.Unit;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.Normalizer;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Functions the assistant may call. Every one goes through the regular metric services in the reactive context of the
 * logged-in user, so the model sees only the units and people the user may open on the screens.
 */
@Log4j2
@Component
public class AiTools {
    private static final Duration TOOL_TIMEOUT = Duration.ofSeconds(90);
    // tool results are cut to keep the context of smaller models
    private static final int MAX_RESULT_CHARS = 12_000;
    private static final int MAX_ROWS = 40;
    private static final Set<Phase> WORK_PHASES = Set.of(Phase.ANALYSIS, Phase.CODING, Phase.REVIEW, Phase.TEST, Phase.WAITING);
    // work items untouched for longer are not "in progress" any more, only forgotten in Jira
    private static final int WIP_LOOKBACK_DAYS = 180;
    private static final int STALE_DAYS = 5;
    // releases are listed from at least this far back, so "when was the last release" has an answer in a short period
    private static final int RELEASE_LOOKBACK_DAYS = 90;
    private static final int MAX_RELEASES = 20;
    // without a unit the Jira tools cover all the units the user manages
    private static final String ALL_UNITS = "all units managed by the user";
    // the environment an open release is compared with when the question names none
    static final String RELEASE_CHECK_ENV = "beta";

    private final ObjectMapper objectMapper;
    private final OrganizationService organizationService;
    private final BenchmarkService benchmarkService;
    private final PullRequestService pullRequestService;
    private final TeamMetricsService teamMetricsService;
    private final MyMetricsService myMetricsService;
    private final DeliverService deliverService;
    private final TaskTimelineService taskTimelineService;
    private final TaskRepository taskRepository;
    private final CodeMapService codeMapService;
    private final Map<String, Tool> tools = new LinkedHashMap<>();

    /** The screen the question was asked from: defaults for tool arguments the model leaves out. */
    public record Context(String unitId, Interval interval) {
    }

    private record Tool(String description, String parameters, BiFunction<JsonNode, Context, Mono<?>> handler) {
    }

    record UnitInfo(String id, String name, String type, int members, List<String> subUnits) {
    }

    record PersonRow(String id, String name, BigDecimal commits, BigDecimal prCreated, BigDecimal prMerged,
                     BigDecimal reviews, BigDecimal avgCycleTimeHours, BigDecimal linesAdded, BigDecimal linesRemoved,
                     BigDecimal repositories, BigDecimal avgNewBugs, BigDecimal avgNewCodeSmells, BigDecimal avgNewCoverage) {
    }

    record DeveloperResult(String unitId, String unitName, int teamSize, String period, PersonRow developer,
                           Map<String, BigDecimal> teamAverage) {
    }

    AiTools(ObjectMapper objectMapper, OrganizationService organizationService, BenchmarkService benchmarkService,
            PullRequestService pullRequestService, TeamMetricsService teamMetricsService, MyMetricsService myMetricsService,
            DeliverService deliverService, TaskTimelineService taskTimelineService, TaskRepository taskRepository,
            CodeMapService codeMapService) {
        this.objectMapper = objectMapper;
        this.organizationService = organizationService;
        this.benchmarkService = benchmarkService;
        this.pullRequestService = pullRequestService;
        this.teamMetricsService = teamMetricsService;
        this.myMetricsService = myMetricsService;
        this.deliverService = deliverService;
        this.taskTimelineService = taskTimelineService;
        this.taskRepository = taskRepository;
        this.codeMapService = codeMapService;

        String unitAndPeriod = """
                {"type":"object","properties":{
                  "unitId":{"type":"string","description":"Unit id from list_units; defaults to the unit selected on the screen"},
                  "period":{"type":"string","enum":[%s],"description":"Period ending today; defaults to the period selected on the screen"}
                }}""".formatted(enumValues());
        tools.put("list_units", new Tool(
                "Lists the organization units (tribes, squads, teams) the user manages, with their ids, types and sub-units. Call first when the unit id is unknown.",
                "{\"type\":\"object\",\"properties\":{}}",
                (args, ctx) -> listUnits()));
        tools.put("unit_overview", new Tool(
                "Key delivery metrics of a unit (PR cycle time, PR throughput, deployments, build failure rate, in-progress-to-live, DORA lead time, change failure rate) "
                        + "each compared with the average of all units of the same type in the organization, plus the merge request flow (opened / merged / in review vs previous period).",
                unitAndPeriod,
                (args, ctx) -> unitOverview(unitId(args, ctx), interval(args, ctx))));
        tools.put("team_members", new Tool(
                "Per-developer metrics of a unit in the period: commits, PRs created / merged, reviews done, average PR cycle time, lines changed, repositories, Sonar quality of new code.",
                unitAndPeriod,
                (args, ctx) -> teamMembers(unitId(args, ctx), interval(args, ctx))));
        tools.put("developer_metrics", new Tool(
                "Metrics of one developer (found by name, e-mail or id among the people the user manages) compared with the average of their team.",
                """
                        {"type":"object","properties":{
                          "person":{"type":"string","description":"Name, surname, e-mail or id of the developer"},
                          "period":{"type":"string","enum":[%s]}
                        },"required":["person"]}""".formatted(enumValues()),
                (args, ctx) -> developerMetrics(args.path("person").asString(""), interval(args, ctx))));
        tools.put("recent_merge_requests", new Tool(
                "Latest merge requests of a unit with author, state, hours since last activity and merge time - concrete examples for long or stuck reviews.",
                unitAndPeriod,
                (args, ctx) -> recentMergeRequests(unitId(args, ctx), interval(args, ctx))));
        tools.put("my_metrics", new Tool(
                "Personal metrics of the logged-in user: commits, active days, PRs, pickup / review / cycle hours, code quality, languages, who reviews their work.",
                "{\"type\":\"object\",\"properties\":{\"period\":{\"type\":\"string\",\"enum\":[%s]}}}".formatted(enumValues()),
                (args, ctx) -> myMetrics(interval(args, ctx))));
        tools.put("jira_work_in_progress", new Tool(
                "Jira work of a unit: open work items (analysis, coding, review, test, waiting/blocked) with assignee and days in the current status, "
                        + "counts per status, type and person, stale items per person, open defects and production defects (oldest first), "
                        + "and the items finished in the period (count per type, average lead time).",
                unitAndPeriod,
                (args, ctx) -> jiraWorkInProgress(unitId(args, ctx), interval(args, ctx))));
        tools.put("jira_releases", new Tool(
                "Releases of a unit (Jira release tasks), newest first: when each went LIVE, the Jira issues deployed with it "
                        + "(the issues linked to the release task) and the microservices (names from the Fix Version/s of the release task, versions in fixVersions); "
                        + "also the releases not LIVE yet. Covers the period, at least the last " + RELEASE_LOOKBACK_DAYS + " days.",
                unitAndPeriod,
                (args, ctx) -> jiraReleases(unitId(args, ctx), interval(args, ctx))));
        tools.put("release_vs_environment", new Tool(
                "Compares the open Jira release tasks (issue type Release, status Open) with an environment of the service map (default beta): "
                        + "for every Fix Version of the release (\"payment-service 2.1.0\") the image tag of that microservice on the environment; "
                        + "result SAME, DIFFERENT (another image / tag deployed there) or MISSING (the microservice is not on the environment). "
                        + "Differences first. Use it for: is the release on beta, which images differ between the release and beta.",
                """
                        {"type":"object","properties":{
                          "environment":{"type":"string","description":"Environment of the service map, default beta"},
                          "key":{"type":"string","description":"One release task key (any status); default all open release tasks"},
                          "unitId":{"type":"string","description":"Unit id from list_units; defaults to the unit selected on the screen, or all managed units"}
                        }}""",
                (args, ctx) -> releaseVsEnvironment(unitId(args, ctx), args.path("environment").asString(""), args.path("key").asString(""))));
        tools.put("jira_epics", new Tool(
                "Jira epics (initiatives) of a unit this year: status, health (ON_TRACK / AT_RISK / DELIVERED_LATE ...), planned vs actual or forecast delivery, delay and its reason, progress of work items.",
                "{\"type\":\"object\",\"properties\":{\"unitId\":{\"type\":\"string\",\"description\":\"Unit id from list_units; defaults to the unit selected on the screen, or all managed units\"}}}",
                (args, ctx) -> jiraEpics(unitId(args, ctx), interval(args, ctx))));
        tools.put("jira_epic", new Tool(
                "Details of one Jira epic of a unit: stats (stories, sub-tasks, open defects, story points, commits, people) and its work items with status, assignee and days per phase.",
                """
                        {"type":"object","properties":{
                          "key":{"type":"string","description":"Epic key, e.g. ABC-123"},
                          "unitId":{"type":"string","description":"Unit id from list_units; defaults to the unit selected on the screen"}
                        },"required":["key"]}""",
                (args, ctx) -> jiraEpic(unitId(args, ctx), args.path("key").asString(""))));
        tools.put("jira_task", new Tool(
                "Full path of one Jira task by key: time per workflow phase, status changes, lead time, linked merge requests (pickup / review hours), pipeline - to explain why a task took long.",
                "{\"type\":\"object\",\"properties\":{\"key\":{\"type\":\"string\",\"description\":\"Task key, e.g. ABC-123\"}},\"required\":[\"key\"]}",
                (args, ctx) -> jiraTask(args.path("key").asString(""))));
    }

    /** Definitions in the OpenAI {@code tools} format. */
    public ArrayNode definitions() {
        ArrayNode result = objectMapper.createArrayNode();
        tools.forEach((name, tool) -> {
            ObjectNode function = objectMapper.createObjectNode();
            function.put("name", name);
            function.put("description", tool.description());
            function.set("parameters", objectMapper.readTree(tool.parameters()));
            ObjectNode item = result.addObject();
            item.put("type", "function");
            item.set("function", function);
        });
        return result;
    }

    /**
     * Runs a tool and returns its result as JSON text for the model. Failures are returned as {@code {"error": ...}}
     * so that the model can explain them instead of the whole answer failing.
     */
    public Mono<String> execute(String name, String arguments, Context ctx) {
        Tool tool = tools.get(name);
        if (tool == null) {
            return Mono.just(error("Unknown tool " + name + ". Available: " + String.join(", ", tools.keySet())));
        }
        JsonNode args = parseArguments(arguments);
        log.info("AI tool {} {}", name, args);
        return tool.handler().apply(args, ctx)
                .map(this::toJson)
                .defaultIfEmpty(error("No data, or the user has no access to this unit. Use list_units to see available units."))
                .timeout(TOOL_TIMEOUT)
                .onErrorResume(e -> {
                    log.warn("AI tool {} failed: {}", name, e.toString());
                    return Mono.just(error(name + " failed: " + e.getMessage()));
                });
    }

    /** Data for models without function calling: overview, team and Jira work of the selected unit, as prompt text. */
    public Mono<String> prefetch(Context ctx) {
        if (ctx.unitId() == null) {
            return Mono.zip(execute("list_units", "{}", ctx), jira(ctx)).map(t -> "list_units: " + t.getT1() + "\n\n" + t.getT2());
        }
        String args = "{}";
        return Mono.zip(execute("unit_overview", args, ctx), execute("team_members", args, ctx),
                        execute("jira_work_in_progress", args, ctx), execute("jira_epics", args, ctx))
                .map(t -> "unit_overview: " + t.getT1() + "\n\nteam_members: " + t.getT2()
                        + "\n\njira_work_in_progress: " + t.getT3() + "\n\njira_epics: " + t.getT4());
    }

    /** Open work and epics of the unit (all managed units without one), as prompt text. */
    public Mono<String> jira(Context ctx) {
        return Mono.zip(execute("jira_work_in_progress", "{}", ctx), execute("jira_epics", "{}", ctx))
                .map(t -> "jira_work_in_progress: " + t.getT1() + "\n\njira_epics: " + t.getT2());
    }

    /** Open release tasks against beta, loaded up front for questions comparing a release with an environment. */
    public Mono<String> releaseCheck(Context ctx) {
        return execute("release_vs_environment", "{}", ctx).map(it -> "release_vs_environment: " + it);
    }

    /** Releases of the screen's unit, loaded up front for questions about releases and deployments. */
    public Mono<String> releases(Context ctx) {
        return execute("jira_releases", "{}", ctx).map(it -> "jira_releases: " + it);
    }

    private Mono<List<UnitInfo>> listUnits() {
        return ZsCommons.currentUserName()
                .flatMapMany(organizationService::getManagedOrganization)
                .distinct(Unit::id)
                .map(u -> new UnitInfo(u.id(), u.name(), u.type(), size(u.members()),
                        Optional.ofNullable(u.units()).orElse(List.of()).stream().map(Unit::name).toList()))
                .take(100)
                .collectList();
    }

    private Mono<Map<String, Object>> unitOverview(String unitId, Interval interval) {
        if (unitId == null) return Mono.just(Map.of("error", "No unit selected - pass unitId (see list_units)."));
        Mono<Map<String, BenchmarkResponse.Item>> overview = benchmarkService.overviewBenchmark(unitId, interval)
                .map(BenchmarkResponse::metrics);
        Mono<Map<String, BenchmarkResponse.Item>> dora = benchmarkService.doraBenchmark(unitId, interval)
                .map(BenchmarkResponse::metrics).defaultIfEmpty(Map.of());
        Mono<Object> flow = pullRequestService.prFlow(unitId, interval).map(Object.class::cast).defaultIfEmpty(Map.of());
        Mono<String> unitName = organizationService.userManageAllowed(unitId).next().map(Unit::name).defaultIfEmpty("");
        return Mono.zip(overview, dora, flow, unitName).map(t -> {
            Map<String, BenchmarkResponse.Item> metrics = new LinkedHashMap<>(t.getT1());
            t.getT2().forEach(metrics::putIfAbsent);
            // MTTR is not computed yet (always 0), it would only mislead the model
            metrics.remove("mttr");
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("unitId", unitId);
            result.put("unitName", t.getT4());
            result.put("period", interval.name());
            result.put("metrics", metrics);
            result.put("mergeRequestFlow", t.getT3());
            return result;
        });
    }

    private Mono<List<PersonRow>> teamMembers(String unitId, Interval interval) {
        return teamMetricsService.getTeam(unitId, interval).map(AiTools::row).take(MAX_ROWS).collectList();
    }

    private Mono<?> developerMetrics(String query, Interval interval) {
        if (query.isBlank()) return Mono.just(Map.of("error", "Pass the developer's name, e-mail or id."));
        return organizationService.getManagedPeoples(null).collectList().flatMap(people -> {
            List<Person> found = people.stream().filter(it -> matches(it, query)).distinct().toList();
            if (found.isEmpty()) {
                return Mono.just(Map.of("error", "No developer matching '" + query + "' among the people the user manages."));
            }
            if (found.size() > 1) {
                return Mono.just(Map.of("error", "Several developers match, ask which one",
                        "candidates", found.stream().limit(10).map(it -> Map.of("id", it.id(), "name", it.name())).toList()));
            }
            Person person = found.getFirst();
            return ZsCommons.currentUserName().flatMap(user -> organizationService.getManagedOrganization(user)
                    .filter(u -> contains(u.members(), person.id()) || contains(u.managers(), person.id()))
                    // the most specific unit: the one with the fewest sub-units
                    .sort(Comparator.comparingInt(u -> u.unitsDeep().size()))
                    .next()
                    .flatMap(unit -> teamMetricsService.getTeam(unit.id(), interval).map(AiTools::row).collectList()
                            .map(team -> new DeveloperResult(unit.id(), unit.name(), team.size(), interval.name(),
                                    team.stream().filter(it -> Objects.equals(it.id(), person.id())).findAny()
                                            .orElse(new PersonRow(person.id(), person.name(), null, null, null, null, null, null, null, null, null, null, null)),
                                    teamAverage(team)))));
        });
    }

    private Mono<List<Map<String, Object>>> recentMergeRequests(String unitId, Interval interval) {
        return pullRequestService.lastMergeRequests(unitId, interval).take(15).map(AiTools::mergeRequest).collectList();
    }

    private Mono<MyMetricsResponse> myMetrics(Interval interval) {
        return myMetricsService.myMetrics(interval).map(it -> new MyMetricsResponse(
                it.profile(), it.commits(), it.commitsPrev(), it.dailyAvgCommits(), it.activeDays(), it.workingDays(),
                it.additions(), it.deletions(), it.mrsCreated(), it.mrsCreatedPrev(), it.mrsMerged(),
                it.avgPickupHours(), it.avgReviewHours(), it.avgCycleHours(), it.quality(),
                // per-day series and full lists are only for the charts
                List.of(), first(it.languages(), 5), it.commitsWithLanguages(), first(it.reviewers(), 5), first(it.recentCommits(), 5)
        ));
    }

    private Mono<Map<String, Object>> jiraWorkInProgress(String unitId, Interval interval) {
        Interval.Range range = interval.range(0);
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime since = range.from().isBefore(now.minusDays(WIP_LOOKBACK_DAYS)) ? range.from() : now.minusDays(WIP_LOOKBACK_DAYS);
        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(pm -> {
                    List<TaskEntity> tasks = pm.projects().isEmpty() ? List.of() : taskRepository.findByProjectIdInAndUpdatedAfter(pm.projects(), since);
                    List<Map<String, Object>> open = new ArrayList<>();
                    // defects not done yet, also those still in the backlog
                    List<Map<String, Object>> openDefects = new ArrayList<>();
                    Map<String, Long> doneByType = new LinkedHashMap<>();
                    List<Long> leadDays = new ArrayList<>();
                    for (TaskEntity entity : tasks) {
                        Task task = entity.getContent();
                        if (task == null || "Epic".equalsIgnoreCase(task.type()) || ReleaseTasks.isRelease(task.type())) continue;
                        List<History> statusHistory = statusHistory(task);
                        Phase phase = taskTimelineService.phaseOf(task.status());
                        if (phase != Phase.DONE && isDefect(task.type())) {
                            LocalDateTime created = Optional.ofNullable(entity.getCreated()).orElse(task.created());
                            Map<String, Object> defect = new LinkedHashMap<>();
                            defect.put("key", task.key());
                            defect.put("summary", task.summary());
                            defect.put("type", task.type());
                            defect.put("production", isProductionDefect(task.type()));
                            defect.put("status", task.status());
                            defect.put("priority", task.priority());
                            defect.put("assignee", task.assignee() == null ? null : task.assignee().displayName());
                            defect.put("daysOpen", created == null ? null : ChronoUnit.DAYS.between(created, now));
                            openDefects.add(defect);
                        }
                        if (WORK_PHASES.contains(phase)) {
                            LocalDateTime inStatusSince = statusHistory.isEmpty()
                                    ? Optional.ofNullable(entity.getCreated()).orElse(task.created())
                                    : statusHistory.getLast().created();
                            Map<String, Object> item = new LinkedHashMap<>();
                            item.put("key", task.key());
                            item.put("summary", task.summary());
                            item.put("type", task.type());
                            item.put("status", task.status());
                            item.put("phase", phase);
                            item.put("assignee", task.assignee() == null ? null : task.assignee().displayName());
                            item.put("daysInStatus", inStatusSince == null ? null : ChronoUnit.DAYS.between(inStatusSince, now));
                            item.put("parentKey", task.parentKey());
                            open.add(item);
                        } else if (phase == Phase.DONE && !statusHistory.isEmpty()) {
                            LocalDateTime doneAt = statusHistory.getLast().created();
                            if (!doneAt.isBefore(range.from()) && !doneAt.isAfter(range.till())) {
                                doneByType.merge(Objects.toString(task.type(), "?"), 1L, Long::sum);
                                LocalDateTime created = Optional.ofNullable(entity.getCreated()).orElse(task.created());
                                if (created != null) leadDays.add(ChronoUnit.DAYS.between(created, doneAt));
                            }
                        }
                    }
                    open.sort(Comparator.comparing((Map<String, Object> it) -> (Long) it.get("daysInStatus"),
                            Comparator.nullsLast(Comparator.reverseOrder())));
                    Map<String, Object> result = new LinkedHashMap<>();
                    result.put("unitId", Objects.toString(unitId, ALL_UNITS));
                    result.put("period", interval.name());
                    result.put("jiraProjects", pm.projects());
                    result.put("openItems", open.size());
                    result.put("openByStatus", countBy(open, "status"));
                    result.put("openByAssignee", countBy(open, "assignee"));
                    result.put("staleItems (>" + STALE_DAYS + " days in status)", open.stream()
                            .filter(it -> it.get("daysInStatus") instanceof Long d && d > STALE_DAYS).count());
                    result.put("openByType", countBy(open, "type"));
                    result.put("staleByAssignee", countBy(open.stream()
                            .filter(it -> it.get("daysInStatus") instanceof Long d && d > STALE_DAYS).toList(), "assignee"));
                    result.put("openDefects", openDefects.size());
                    result.put("openProductionDefects", openDefects.stream().filter(it -> Boolean.TRUE.equals(it.get("production"))).count());
                    result.put("openDefectsOldestFirst", openDefects.stream()
                            .sorted(Comparator.comparing((Map<String, Object> it) -> !Boolean.TRUE.equals(it.get("production")))
                                    .thenComparing(it -> (Long) it.get("daysOpen"), Comparator.nullsLast(Comparator.reverseOrder())))
                            .limit(20).toList());
                    result.put("finishedInPeriod", doneByType.values().stream().mapToLong(Long::longValue).sum());
                    result.put("finishedByType", doneByType);
                    result.put("avgLeadTimeDaysOfFinished", leadDays.isEmpty() ? null
                            : BigDecimal.valueOf(leadDays.stream().mapToLong(Long::longValue).average().orElse(0)).setScale(1, RoundingMode.HALF_UP));
                    result.put("openItemsLongestInStatus", open.stream().limit(MAX_ROWS).toList());
                    return result;
                });
    }

    /** Release tasks of the unit: LIVE ones newest first with the deployed issues ("contains" links) and Fix Versions (microservices). */
    private Mono<Map<String, Object>> jiraReleases(String unitId, Interval interval) {
        Interval.Range range = interval.range(0);
        LocalDateTime lookback = LocalDateTime.now().minusDays(RELEASE_LOOKBACK_DAYS);
        LocalDateTime since = range.from().isBefore(lookback) ? range.from() : lookback;
        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(pm -> {
                    List<TaskEntity> tasks = pm.projects().isEmpty() ? List.of() : taskRepository.findByProjectIdInAndUpdatedAfter(pm.projects(), since);
                    Map<String, Map<String, Object>> live = new LinkedHashMap<>();
                    Map<String, Map<String, Object>> notLive = new LinkedHashMap<>();
                    for (TaskEntity entity : tasks) {
                        Task task = entity.getContent();
                        if (task == null || !ReleaseTasks.isRelease(task.type()) || live.containsKey(task.key()) || notLive.containsKey(task.key())) continue;
                        // the first move to LIVE is the deployment, a later reopen does not move it
                        LocalDateTime liveAt = statusHistory(task).stream()
                                .filter(it -> TaskStatus.LIVE.getJiraName().equalsIgnoreCase(Objects.toString(it.to(), "").trim()))
                                .map(History::created).findFirst().orElse(null);
                        Map<String, Object> release = new LinkedHashMap<>();
                        release.put("key", task.key());
                        release.put("summary", task.summary());
                        release.put("status", task.status());
                        release.put("liveAt", liveAt);
                        List<String> fixVersions = Optional.ofNullable(task.fixVersions()).orElse(List.of());
                        release.put("microservices", fixVersions.stream().map(AiTools::microservice).filter(it -> !it.isEmpty()).distinct().toList());
                        release.put("fixVersions", fixVersions);
                        // every issue linked to the release task is deployed with it
                        release.put("deployedIssues", Optional.ofNullable(task.links()).orElse(List.of()).stream()
                                .filter(it -> it != null && it.key() != null)
                                .map(it -> {
                                    Map<String, Object> issue = new LinkedHashMap<>();
                                    issue.put("key", it.key());
                                    issue.put("summary", it.summary());
                                    issue.put("status", it.status());
                                    return issue;
                                }).distinct().toList());
                        if (task.links() == null && task.fixVersions() == null) {
                            release.put("note", "saved without Jira links and Fix Versions (imported by an older version) - deployed issues and microservices unknown until the Jira import runs again");
                        }
                        (liveAt == null ? notLive : live).put(task.key(), release);
                    }
                    List<Map<String, Object>> released = live.values().stream()
                            .sorted(Comparator.comparing((Map<String, Object> it) -> (LocalDateTime) it.get("liveAt")).reversed())
                            .toList();
                    Map<String, Object> result = new LinkedHashMap<>();
                    result.put("unitId", Objects.toString(unitId, ALL_UNITS));
                    result.put("since", since.toLocalDate());
                    result.put("jiraProjects", pm.projects());
                    result.put("lastReleaseAt", released.isEmpty() ? null : released.getFirst().get("liveAt"));
                    result.put("releasesLive", released.size());
                    result.put("releasesLiveInPeriod", released.stream()
                            .filter(it -> !((LocalDateTime) it.get("liveAt")).isBefore(range.from())).count());
                    result.put("releasesNewestFirst", released.stream().limit(MAX_RELEASES).toList());
                    result.put("releasesNotLiveYet", notLive.values().stream().limit(MAX_RELEASES).toList());
                    return result;
                });
    }

    /** The open release tasks (or the one of {@code key}) of the unit against the image tags on the environment. */
    private Mono<Map<String, Object>> releaseVsEnvironment(String unitId, String environment, String key) {
        String env = environment.isBlank() ? RELEASE_CHECK_ENV : environment.trim();
        String releaseKey = key.trim().toUpperCase(Locale.ROOT);
        Mono<List<TaskEntity>> releases = organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(pm -> {
                    if (pm.projects().isEmpty()) return List.<TaskEntity>of();
                    List<TaskEntity> found = releaseKey.isEmpty()
                            ? taskRepository.findByProjectIdInAndStatus(pm.projects(), TaskStatus.OPEN)
                            : taskRepository.findByKey(releaseKey).stream().filter(it -> pm.projects().contains(it.getProjectId())).toList();
                    Map<String, TaskEntity> byKey = new LinkedHashMap<>();
                    found.stream().filter(it -> it.getContent() != null && ReleaseTasks.isRelease(it.getContent().type()))
                            .forEach(it -> byKey.putIfAbsent(it.getKey(), it));
                    return List.copyOf(byKey.values());
                });
        return Mono.zip(releases, codeMapService.tagsOn(env)).map(t -> {
            Map<String, Object> result = compareReleases(t.getT1(), t.getT2(), env);
            result.put("unitId", Objects.toString(unitId, ALL_UNITS));
            if (!releaseKey.isEmpty() && t.getT1().isEmpty()) {
                result.put("note", "No release task " + releaseKey + " in the unit's Jira projects.");
            }
            return result;
        });
    }

    /**
     * Every Fix Version of the release tasks against the tag of its microservice on the environment: the microservice
     * whose name starts the Fix Version (CodeMapService.versionOf), the same version also when the tag carries the name
     * ("payment-service-2.1.0") or a "v".
     */
    static Map<String, Object> compareReleases(List<TaskEntity> releases, List<EnvTag> tags, String environment) {
        List<Map<String, Object>> rows = new ArrayList<>();
        List<Map<String, Object>> withoutFixVersion = new ArrayList<>();
        for (TaskEntity entity : releases) {
            Task task = entity.getContent();
            List<String> fixVersions = Optional.ofNullable(task.fixVersions()).orElse(List.of()).stream().filter(Objects::nonNull).toList();
            if (fixVersions.isEmpty()) {
                withoutFixVersion.add(Map.of("release", entity.getKey(), "summary", Objects.toString(task.summary(), "")));
                continue;
            }
            for (String fixVersion : fixVersions) {
                List<EnvTag> matches = tags.stream().filter(it -> it.module() != null && CodeMapService.versionOf(fixVersion, it.module()) != null).toList();
                int longest = matches.stream().mapToInt(it -> it.module().length()).max().orElse(0);
                List<EnvTag> modules = matches.stream().filter(it -> it.module().length() == longest).toList();
                if (modules.isEmpty()) {
                    rows.add(row(entity, fixVersion, microservice(fixVersion), CodeMapService.versionOf(fixVersion, microservice(fixVersion)), null, "MISSING"));
                    continue;
                }
                for (EnvTag tag : modules) {
                    String version = CodeMapService.versionOf(fixVersion, tag.module());
                    String deployed = CodeMapService.normalizeVersion(tag.tag());
                    boolean same = version.equalsIgnoreCase(deployed)
                            || version.equalsIgnoreCase(Objects.toString(CodeMapService.versionOf(Objects.toString(tag.tag(), ""), tag.module()), ""));
                    rows.add(row(entity, fixVersion, tag.module(), version, tag, same ? "SAME" : "DIFFERENT"));
                }
            }
        }
        List<String> order = List.of("DIFFERENT", "MISSING", "SAME");
        rows.sort(Comparator.comparing((Map<String, Object> it) -> order.indexOf((String) it.get("result")))
                .thenComparing(it -> (String) it.get("microservice"), Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER)));
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("environment", environment);
        result.put("environmentsMatched", tags.stream().map(EnvTag::environment).distinct().sorted().toList());
        result.put("microservicesOnEnvironment", tags.size());
        result.put("openReleaseTasks", releases.stream().map(it -> Map.of("key", it.getKey(),
                "summary", Objects.toString(it.getContent().summary(), ""), "status", Objects.toString(it.getContent().status(), ""),
                "fixVersions", Optional.ofNullable(it.getContent().fixVersions()).orElse(List.of()))).toList());
        result.put("different", rows.stream().filter(it -> "DIFFERENT".equals(it.get("result"))).count());
        result.put("missing", rows.stream().filter(it -> "MISSING".equals(it.get("result"))).count());
        result.put("same", rows.stream().filter(it -> "SAME".equals(it.get("result"))).count());
        result.put("comparison", rows);
        if (!withoutFixVersion.isEmpty()) result.put("releasesWithoutFixVersion", withoutFixVersion);
        if (releases.isEmpty()) result.put("note", "No open release task (issue type Release, status Open) in the unit's Jira projects.");
        else if (tags.isEmpty()) result.put("note", "No microservice on an environment named like '" + environment + "' in the service map.");
        return result;
    }

    private static Map<String, Object> row(TaskEntity release, String fixVersion, String microservice, String version, EnvTag tag, String result) {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("release", release.getKey());
        row.put("microservice", microservice);
        row.put("fixVersion", fixVersion);
        row.put("releaseVersion", version);
        row.put("environmentTag", tag == null ? null : tag.tag());
        row.put("environmentImage", tag == null ? null : tag.image());
        row.put("environmentName", tag == null ? null : tag.environment());
        row.put("serviceMapProject", tag == null ? null : tag.projectId());
        row.put("result", result);
        return row;
    }

    /** Microservice name of a Fix Version without its version number, e.g. "payment-service 2.1.0" -> "payment-service". */
    static String microservice(String fixVersion) {
        return Objects.toString(fixVersion, "").trim().replaceFirst("(?i)(?:[\\s_@:/-]+v?|v)\\d+(\\.\\d+)*([-+.][\\w.]+)?$", "").trim();
    }

    private Mono<List<Map<String, Object>>> jiraEpics(String unitId, Interval interval) {
        return deliverService.epics(unitId, interval).map(list -> list.epics().stream().limit(30).map(AiTools::epic).toList());
    }

    private Mono<Map<String, Object>> jiraEpic(String unitId, String key) {
        if (key.isBlank()) return Mono.just(Map.of("error", "Pass the epic key, e.g. ABC-123 (see jira_epics)."));
        return deliverService.epic(unitId, key).map(detail -> {
            Map<String, Object> result = new LinkedHashMap<>(epic(detail.epic()));
            result.put("stats", detail.stats());
            result.put("items", detail.items().stream().limit(MAX_ROWS).map(it -> {
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("key", it.key());
                item.put("summary", it.summary());
                item.put("type", it.type());
                item.put("status", it.status());
                item.put("assignee", it.assignee());
                item.put("storyPoints", it.storyPoints());
                item.put("started", it.started());
                item.put("finished", it.finished());
                item.put("daysPerPhase", it.phaseDays());
                item.put("commits", it.commits());
                return item;
            }).toList());
            return result;
        });
    }

    private Mono<Map<String, Object>> jiraTask(String key) {
        if (key.isBlank()) return Mono.just(Map.of("error", "Pass the task key, e.g. ABC-123."));
        return taskTimelineService.timeline(key).map(lookup -> {
            if (lookup.timeline() == null) {
                return Map.of("error", "Task " + key + ": " + ("NO_PROJECT_ACCESS".equals(lookup.error())
                        ? "the user has no access to its project" : "not found in the imported Jira data"));
            }
            TaskTimelineResponse t = lookup.timeline();
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("key", t.key());
            result.put("summary", t.summary());
            result.put("type", t.type());
            result.put("priority", t.priority());
            result.put("status", t.status());
            result.put("assignee", t.assignee());
            result.put("parentKey", t.parentKey());
            result.put("sprints", t.sprints());
            result.put("created", t.created());
            result.put("doneAt", t.doneAt());
            result.put("leadTimeHours", t.leadTimeHours());
            result.put("hoursPerPhase", t.phases());
            result.put("firstCommitAt", t.firstCommitAt());
            result.put("mergedAt", t.mergedAt());
            result.put("codeCycleHours", t.codeCycleHours());
            result.put("pickupHours", t.pickupHours());
            result.put("reviewHours", t.reviewHours());
            result.put("pipeline", t.pipeline());
            result.put("statusChanges", last(t.statusChanges(), 20));
            result.put("mergeRequests", size(t.mergeRequests()));
            result.put("commits", size(t.commits()));
            return result;
        });
    }

    private static Map<String, Object> epic(DeliverResponse.EpicSummary e) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("key", e.key());
        result.put("summary", e.summary());
        result.put("status", e.status());
        result.put("assignee", e.assignee());
        result.put("health", e.health());
        result.put("plannedStart", e.plannedStart());
        result.put("actualStart", e.actualStart());
        result.put("plannedDelivery", e.plannedDelivery());
        result.put(e.deliveryForecast() ? "deliveryForecast" : "deliveryDate", e.deliveryDate());
        result.put("delayDays", e.delayDays());
        result.put("delayReason", e.delayReason());
        result.put("items", e.items());
        result.put("itemsDone", e.itemsDone());
        result.put("progressPct", e.progressPct());
        return result;
    }

    private static boolean isDefect(String type) {
        String t = Objects.toString(type, "").toLowerCase(Locale.ROOT);
        return t.contains("bug") || t.contains("defect");
    }

    private static boolean isProductionDefect(String type) {
        String t = Objects.toString(type, "").toLowerCase(Locale.ROOT);
        return isDefect(type) && (t.contains("prod") || t.contains("incident"));
    }

    private static List<History> statusHistory(Task task) {
        return Optional.ofNullable(task.histories()).orElse(List.of()).stream()
                .filter(it -> it.created() != null && "status".equalsIgnoreCase(it.fieldType()))
                .sorted(Comparator.comparing(History::created))
                .toList();
    }

    private static Map<String, Long> countBy(List<Map<String, Object>> items, String field) {
        return items.stream().collect(Collectors.groupingBy(it -> Objects.toString(it.get(field), "unassigned"),
                LinkedHashMap::new, Collectors.counting()));
    }

    private static <T> List<T> last(List<T> values, int limit) {
        if (values == null) return List.of();
        return values.subList(Math.max(0, values.size() - limit), values.size());
    }

    private static PersonRow row(TeamPerson person) {
        PersonMetric m = person.metric();
        return new PersonRow(person.id(), person.name(), m.commits(), m.prCreated(), m.prMerged(), m.reviews(),
                m.avgCycleTime(), m.linesA(), m.linesR(), m.repositories(), m.bugs(), m.codeSmells(), m.coverage());
    }

    private static Map<String, BigDecimal> teamAverage(List<PersonRow> team) {
        Map<String, Function<PersonRow, BigDecimal>> fields = new LinkedHashMap<>();
        fields.put("commits", PersonRow::commits);
        fields.put("prCreated", PersonRow::prCreated);
        fields.put("prMerged", PersonRow::prMerged);
        fields.put("reviews", PersonRow::reviews);
        fields.put("avgCycleTimeHours", PersonRow::avgCycleTimeHours);
        fields.put("linesAdded", PersonRow::linesAdded);
        fields.put("avgNewBugs", PersonRow::avgNewBugs);
        fields.put("avgNewCoverage", PersonRow::avgNewCoverage);
        Map<String, BigDecimal> result = new LinkedHashMap<>();
        fields.forEach((key, getter) -> {
            List<BigDecimal> values = team.stream().map(getter).filter(Objects::nonNull).toList();
            if (!values.isEmpty()) {
                result.put(key, values.stream().reduce(BigDecimal.ZERO, BigDecimal::add)
                        .divide(BigDecimal.valueOf(values.size()), 1, RoundingMode.HALF_UP));
            }
        });
        return result;
    }

    private static Map<String, Object> mergeRequest(PrLastItem mr) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("title", mr.title());
        result.put("author", mr.author());
        result.put("state", mr.state());
        result.put("hoursSinceLastActivity", mr.hoursAgo());
        result.put("mergeTimeHours", mr.mergeTime());
        result.put("targetBranch", mr.targetBranch());
        result.put("commits", mr.commits() == null ? 0 : mr.commits().size());
        return result;
    }

    private static boolean matches(Person person, String query) {
        String q = normalize(query);
        if (q.equals(normalize(person.id())) || q.equals(normalize(person.email()))) return true;
        String name = normalize(person.name());
        return !name.isEmpty() && Stream.of(q.split("\\s+")).allMatch(name::contains);
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value, Normalizer.Form.NFD).replaceAll("\\p{M}", "")
                .replace('ł', 'l').replace('Ł', 'l').toLowerCase(Locale.ROOT).trim();
    }

    private String unitId(JsonNode args, Context ctx) {
        String unitId = args.path("unitId").asString("");
        return unitId.isBlank() ? ctx.unitId() : unitId;
    }

    private Interval interval(JsonNode args, Context ctx) {
        String period = args.path("period").asString("");
        return Arrays.stream(Interval.values()).filter(it -> it.name().equalsIgnoreCase(period)).findAny().orElse(ctx.interval());
    }

    private JsonNode parseArguments(String arguments) {
        try {
            JsonNode node = arguments == null || arguments.isBlank() ? null : objectMapper.readTree(arguments);
            return node != null && node.isObject() ? node : objectMapper.createObjectNode();
        } catch (RuntimeException e) {
            return objectMapper.createObjectNode();
        }
    }

    private String toJson(Object value) {
        String json = objectMapper.writeValueAsString(value);
        return json.length() > MAX_RESULT_CHARS ? json.substring(0, MAX_RESULT_CHARS) + "...(truncated)" : json;
    }

    private String error(String message) {
        return objectMapper.writeValueAsString(Map.of("error", message));
    }

    private static String enumValues() {
        return String.join(",", Arrays.stream(Interval.values()).map(it -> "\"" + it.name() + "\"").toList());
    }

    private static int size(Collection<?> values) {
        return values == null ? 0 : values.size();
    }

    private static boolean contains(Collection<String> values, String value) {
        return values != null && values.contains(value);
    }

    private static <T> List<T> first(List<T> values, int limit) {
        return values == null ? List.of() : values.stream().limit(limit).toList();
    }
}
