package pl.zenstage.core.architecture;

import lombok.extern.log4j.Log4j2;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import pl.zenstage.core.common.ZenStageException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * C4 model of a project (containers with their components and the links between them) from the importer job
 * "architecture", which scans the GitLab repositories of the project and its ArgoCD deploy repository.
 * Kept as the JSON the importer sent, one row per project.
 */
@Log4j2
@Service
public class ArchitectureService {
    private static final String CREATE_TABLE = """
            CREATE TABLE IF NOT EXISTS architecture (
                project_id VARCHAR(255) PRIMARY KEY,
                content TEXT NOT NULL,
                updated TIMESTAMP
            )""";

    public record ProjectArchitecture(String projectId, LocalDateTime updated) {
    }

    private final JdbcTemplate jdbcTemplate;
    private final ObjectMapper objectMapper;

    ArchitectureService(JdbcTemplate jdbcTemplate, ObjectMapper objectMapper) {
        this.jdbcTemplate = jdbcTemplate;
        this.objectMapper = objectMapper;
    }

    @EventListener(ApplicationReadyEvent.class)
    void init() {
        jdbcTemplate.execute(CREATE_TABLE);
    }

    /** Replaces the model of the project; it has to be a JSON object with containers and links. */
    public ProjectArchitecture save(String projectId, String json) {
        JsonNode model;
        try {
            model = objectMapper.readTree(json);
        } catch (RuntimeException e) {
            throw new ZenStageException(HttpStatus.BAD_REQUEST, "INVALID_ARCHITECTURE", "The model is not JSON");
        }
        if (model == null || !model.isObject() || !model.path("containers").isArray() || !model.path("links").isArray()) {
            throw new ZenStageException(HttpStatus.BAD_REQUEST, "INVALID_ARCHITECTURE", "The model needs the containers and links lists");
        }
        LocalDateTime now = LocalDateTime.now();
        String content = model.toString();
        int updated = jdbcTemplate.update("UPDATE architecture SET content = ?, updated = ? WHERE project_id = ?",
                content, Timestamp.valueOf(now), projectId);
        if (updated == 0) {
            jdbcTemplate.update("INSERT INTO architecture (project_id, content, updated) VALUES (?, ?, ?)",
                    projectId, content, Timestamp.valueOf(now));
        }
        log.info("Architecture of {}: {} containers, {} links", projectId, model.path("containers").size(), model.path("links").size());
        return new ProjectArchitecture(projectId, now);
    }

    public List<ProjectArchitecture> projects() {
        return jdbcTemplate.query("SELECT project_id, updated FROM architecture ORDER BY project_id",
                (rs, _) -> new ProjectArchitecture(rs.getString("project_id"),
                        Optional.ofNullable(rs.getTimestamp("updated")).map(Timestamp::toLocalDateTime).orElse(null)));
    }

    /** The model as the importer sent it (JSON), empty when the project was not scanned yet. */
    public Optional<String> model(String projectId) {
        return jdbcTemplate.query("SELECT content FROM architecture WHERE project_id = ?",
                (rs, _) -> rs.getString("content"), projectId).stream().findFirst();
    }
}
