package pl.zenstage.core.metrics.team;

import java.math.BigDecimal;

public record PersonMetric(
        BigDecimal commits,
        BigDecimal prCreated,
        BigDecimal prMerged,
        BigDecimal reviews,
        BigDecimal avgCycleTime,
        BigDecimal linesA,
        BigDecimal linesR,
        BigDecimal repositories,
        BigDecimal bugs,
        BigDecimal vulnerabilities,
        BigDecimal codeSmells,
        BigDecimal coverage,
        BigDecimal duplication,
        BigDecimal complexityDelta,
        BigDecimal cognitiveComplexityDelta
){}
