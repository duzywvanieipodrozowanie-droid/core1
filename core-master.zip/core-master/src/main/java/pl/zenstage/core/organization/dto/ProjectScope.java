package pl.zenstage.core.organization.dto;

public enum ProjectScope {
    manager,
    user,
}
