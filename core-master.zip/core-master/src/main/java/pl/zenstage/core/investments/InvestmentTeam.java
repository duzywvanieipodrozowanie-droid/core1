package pl.zenstage.core.investments;

import java.util.List;

record InvestmentTeam(
        String label,
        List<Investment> investments
) {
}
