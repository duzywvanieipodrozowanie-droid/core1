package pl.zenstage.core.app;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.organization.components.UserService;
import pl.zenstage.core.organization.dto.ZsUserSessionDto;
import pl.zenstage.db.store.entity.UserConfigEntity;
import pl.zenstage.db.store.repository.UserConfigRepository;
import reactor.core.publisher.Mono;

import java.security.Principal;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
public class UserController {
    private final UserConfigRepository userConfigRepository;
    private final UserService userService;

    @GetMapping("/user")
    Mono<ZsUserSessionDto> whoami() {
        return userService.details();
    }

    @GetMapping("/config")
    public Map<String, Object> getConfig(Authentication authentication) {
        return Optional.of(authentication).map(Principal::getName).flatMap(userConfigRepository::findById)
                .map(UserConfigEntity::getConfig).orElseGet(Collections::emptyMap);
    }

    @PutMapping("/config")
    public Map<String, Object> saveConfig(Authentication authentication, @RequestBody Map<String, Object> data) {
        return userConfigRepository.save(new UserConfigEntity(authentication.getName(), data)).getConfig();
    }
}
