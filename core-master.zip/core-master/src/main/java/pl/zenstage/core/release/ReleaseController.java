package pl.zenstage.core.release;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import pl.zenstage.api.components.ReleaseService;
import pl.zenstage.api.rest.ReleaseApiController;
import pl.zenstage.db.store.entity.release.EnvStateEntity;
import pl.zenstage.db.store.repository.ReleaseRepository;
import reactor.core.publisher.Flux;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/release")
public class ReleaseController extends ReleaseApiController {
    private final ReleaseService releaseService;

    public ReleaseController(ReleaseRepository releaseRepository, ReleaseService releaseService) {
        super(releaseRepository, releaseService);
        this.releaseService = releaseService;
    }

    @GetMapping("/rc/{projectId}")
    Flux<EnvStateEntity> rc(@PathVariable String projectId) {
        return releaseService.releaseCandidate(projectId);
    }
}
