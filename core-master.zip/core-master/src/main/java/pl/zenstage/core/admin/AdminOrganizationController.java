package pl.zenstage.core.admin;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.admin.dto.AddUnit;
import pl.zenstage.core.admin.service.OrganizationAdminService;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.core.common.ZsCommons;
import pl.zenstage.core.organization.dto.Unit;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@RestController
@RequestMapping(Const.ADMIN + "/organization")
@RequiredArgsConstructor
public class AdminOrganizationController {
    private final OrganizationAdminService organizationAdminService;

    @GetMapping
    Mono<Unit> getAll() {
        return ZsCommons.currentUser().map(organizationAdminService::getRoot);
    }

    @DeleteMapping("/{unitId}")
    Mono<ResponseEntity<Unit>> delete(@PathVariable String unitId) {
        return ZsCommons.currentUser().map(it -> organizationAdminService.delete(it, unitId))
                .publishOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .onErrorResume(
                        ZenStageException.class,
                        e -> Mono.just(ResponseEntity.status(e.getStatus()).build())
                );
    }

    @PutMapping("/add")
    Mono<ResponseEntity<Unit>> add(@RequestBody AddUnit unit) {
        return ZsCommons.currentUser().map(it -> organizationAdminService.add(it, unit))
                .publishOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .onErrorResume(
                        ZenStageException.class,
                        e -> Mono.just(ResponseEntity.status(e.getStatus()).build())
                );
    }

    @PutMapping("/{unitId}/manager")
    Mono<ResponseEntity<Unit>> addManager(@PathVariable String unitId, @RequestBody String manager) {
        return ZsCommons.currentUser().map(it -> organizationAdminService.addManager(it, unitId, manager))
                .publishOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .onErrorResume(
                        ZenStageException.class,
                        e -> Mono.just(ResponseEntity.status(e.getStatus()).build())
                );
    }

    @DeleteMapping("/{unitId}/manager")
    Mono<ResponseEntity<Unit>> deleteManager(@PathVariable String unitId, @RequestBody String manager) {
        return ZsCommons.currentUser().map(it -> organizationAdminService.deleteManager(it, unitId, manager))
                .publishOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .onErrorResume(
                        ZenStageException.class,
                        e -> Mono.just(ResponseEntity.status(e.getStatus()).build())
                );
    }

    @PutMapping("/{unitId}/member")
    Mono<ResponseEntity<Unit>> addMember(@PathVariable String unitId, @RequestBody String member) {
        return ZsCommons.currentUser().map(it -> organizationAdminService.addMember(it, unitId, member))
                .publishOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .onErrorResume(
                        ZenStageException.class,
                        e -> Mono.just(ResponseEntity.status(e.getStatus()).build())
                );
    }

    @DeleteMapping("/{unitId}/member")
    Mono<ResponseEntity<Unit>> deleteMember(@PathVariable String unitId, @RequestBody String member) {
        return ZsCommons.currentUser().map(it -> organizationAdminService.deleteMember(it, unitId, member))
                .publishOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .onErrorResume(
                        ZenStageException.class,
                        e -> Mono.just(ResponseEntity.status(e.getStatus()).build())
                );
    }

    @PutMapping("/{unitId}/project")
    Mono<ResponseEntity<Unit>> addProject(@PathVariable String unitId, @RequestBody String project) {
        return ZsCommons.currentUser().map(it -> organizationAdminService.addProject(it, unitId, project))
                .publishOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .onErrorResume(
                        ZenStageException.class,
                        e -> Mono.just(ResponseEntity.status(e.getStatus()).build())
                );
    }

    @DeleteMapping("/{unitId}/project")
    Mono<ResponseEntity<Unit>> deleteProject(@PathVariable String unitId, @RequestBody String project) {
        return ZsCommons.currentUser().map(it -> organizationAdminService.deleteProject(it, unitId, project))
                .publishOn(Schedulers.boundedElastic())
                .map(ResponseEntity::ok)
                .onErrorResume(
                        ZenStageException.class,
                        e -> Mono.just(ResponseEntity.status(e.getStatus()).build())
                );
    }
}
