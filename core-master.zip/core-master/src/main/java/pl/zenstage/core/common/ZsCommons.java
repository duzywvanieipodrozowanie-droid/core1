package pl.zenstage.core.common;

import lombok.experimental.UtilityClass;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.context.SecurityContext;
import reactor.core.publisher.Mono;

import java.security.Principal;

@UtilityClass
public class ZsCommons {
    public Mono<Authentication> currentUser() {
        return ReactiveSecurityContextHolder.getContext()
                .mapNotNull(SecurityContext::getAuthentication)
                .switchIfEmpty(Mono.error(new ZenStageException(HttpStatus.FORBIDDEN)));
    }

    public Mono<String> currentUserName() {
        return currentUser().map(Principal::getName);
    }
}
