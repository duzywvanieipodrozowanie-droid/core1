package pl.zenstage.core.common;

import lombok.experimental.UtilityClass;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collection;
import java.util.Objects;

@UtilityClass
public class MathBigDecimal {
    public BigDecimal avg(Collection<BigDecimal> values, int scale) {
        if (values.isEmpty()) {
            return BigDecimal.ZERO;
        }
        return sum(values).divide(BigDecimal.valueOf(values.size()), scale, RoundingMode.CEILING);
    }

    public BigDecimal sum(Collection<BigDecimal> values) {
        return values.stream().filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
