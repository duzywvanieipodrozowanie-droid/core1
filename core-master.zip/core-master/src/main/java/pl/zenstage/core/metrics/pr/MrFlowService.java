package pl.zenstage.core.metrics.pr;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.mr.Approval;
import pl.zenstage.api.mr.MergeRequest;
import pl.zenstage.api.mr.MrCommit;
import pl.zenstage.core.common.MathBigDecimal;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.git.MergeRequestEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.MergeRequestRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Stream;

/**
 * Lead time for changes and its breakdown, from merge requests merged into main/master:
 * <pre>
 *   first commit ──coding──▶ MR opened ──pickup──▶ first approval ──review──▶ last approval ──merge──▶ merged
 * </pre>
 * The four phases of one MR always add up to its lead time (first commit → merge). Without approvals the whole
 * time from opening to merge is pickup. MRs imported before the first commit was recorded start at MR creation.
 */
@Service
@RequiredArgsConstructor
public class MrFlowService {
    private static final Set<String> MAIN_BRANCHES = Set.of("main", "master");
    // MRs merged in the range may have been opened long before it
    private static final int OPENED_LOOKBACK_DAYS = 180;

    private final OrganizationService organizationService;
    private final MergeRequestRepository mergeRequestRepository;
    private final CommitRepository commitRepository;

    public record Flow(LocalDateTime mergedAt, BigDecimal coding, BigDecimal pickup, BigDecimal review, BigDecimal merge) {
        public BigDecimal leadTime() {
            return coding.add(pickup).add(review).add(merge);
        }
    }

    public Mono<BigDecimal> leadTime(String unitId, Interval.Range range) {
        return average(unitId, range, Flow::leadTime);
    }

    public Mono<BigDecimal> coding(String unitId, Interval.Range range) {
        return average(unitId, range, Flow::coding);
    }

    public Mono<BigDecimal> pickup(String unitId, Interval.Range range) {
        return average(unitId, range, Flow::pickup);
    }

    public Mono<BigDecimal> review(String unitId, Interval.Range range) {
        return average(unitId, range, Flow::review);
    }

    public Mono<BigDecimal> merge(String unitId, Interval.Range range) {
        return average(unitId, range, Flow::merge);
    }

    /** Average in hours over the unit's MRs merged into main/master within the range; empty when not allowed. */
    private Mono<BigDecimal> average(String unitId, Interval.Range range, Function<Flow, BigDecimal> phase) {
        return flows(unitId, range).map(flows -> MathBigDecimal.avg(flows.stream().map(phase).toList(), 1));
    }

    public Mono<List<Flow>> flows(String unitId, Interval.Range range) {
        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(it -> {
                    Set<String> members = new HashSet<>(it.members());
                    return mergeRequestRepository
                            .findByProjectIdInAndCreateDateBetween(it.projects(), range.from().minusDays(OPENED_LOOKBACK_DAYS), range.till())
                            .stream()
                            .filter(mr -> mr.getSource() != null && mr.getSource().createdAt() != null && members.contains(mr.getAuthorId()))
                            .filter(mr -> mergedWithin(mr.getSource(), range))
                            .filter(this::mergedIntoMain)
                            .map(mr -> flow(mr.getSource()))
                            .toList();
                });
    }

    private static boolean mergedWithin(MergeRequest mr, Interval.Range range) {
        LocalDateTime merged = local(mr.mergedAt());
        return merged != null && !merged.isBefore(range.from()) && merged.isBefore(range.till());
    }

    /**
     * Target branch main/master. MRs imported before the target branch was recorded count when their merge commit is
     * in the database - the importer only loads commits of the default branch.
     */
    public boolean mergedIntoMain(MergeRequestEntity mr) {
        String target = mr.getSource().targetBranch();
        if (target != null) {
            return MAIN_BRANCHES.contains(target.toLowerCase(Locale.ROOT));
        }
        return mr.getCommitId() != null
                && commitRepository.existsById(new CommitEntity.Pk(mr.getProjectId(), mr.getModuleName(), mr.getCommitId()));
    }

    public static Flow flow(MergeRequest mr) {
        LocalDateTime created = local(mr.createdAt());
        LocalDateTime merged = local(mr.mergedAt());
        LocalDateTime firstCommit = Stream.concat(
                        Stream.of(local(mr.firstCommitAt())),
                        Optional.ofNullable(mr.commits()).orElse(List.of()).stream().map(MrCommit::committedAt).map(MrFlowService::local))
                .filter(Objects::nonNull).min(LocalDateTime::compareTo).orElse(created);
        // commits rebased after opening the MR can be "younger" than the MR itself
        LocalDateTime start = firstCommit.isBefore(created) ? firstCommit : created;

        List<LocalDateTime> approvals = Optional.ofNullable(mr.approvals())
                .map(list -> list.stream().map(Approval::approvedAt).map(MrFlowService::local))
                .orElseGet(() -> Stream.of(local(mr.approvedAt())))
                .filter(Objects::nonNull)
                .map(it -> clamp(it, created, merged))
                .sorted()
                .toList();

        if (approvals.isEmpty()) {
            return new Flow(merged, hours(start, created), hours(created, merged), BigDecimal.ZERO, BigDecimal.ZERO);
        }
        LocalDateTime firstApproval = approvals.getFirst();
        LocalDateTime lastApproval = approvals.getLast();
        return new Flow(
                merged,
                hours(start, created),
                hours(created, firstApproval),
                hours(firstApproval, lastApproval),
                hours(lastApproval, merged)
        );
    }

    private static LocalDateTime clamp(LocalDateTime value, LocalDateTime min, LocalDateTime max) {
        return value.isBefore(min) ? min : value.isAfter(max) ? max : value;
    }

    private static BigDecimal hours(LocalDateTime from, LocalDateTime till) {
        return BigDecimal.valueOf(Math.max(0, Duration.between(from, till).toMinutes()))
                .divide(BigDecimal.valueOf(60), 2, RoundingMode.HALF_UP);
    }

    private static LocalDateTime local(Instant instant) {
        return instant == null ? null : LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
    }
}
