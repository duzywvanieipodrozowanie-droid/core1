package pl.zenstage.core.codemap;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.task.Task;
import pl.zenstage.core.codemap.response.CodeMapEnv;
import pl.zenstage.core.codemap.response.CodeMapIssues;
import pl.zenstage.core.metrics.ReleaseTasks;
import pl.zenstage.core.common.ZsCommons;
import pl.zenstage.core.codemap.response.CodeMapModule;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.git.TagEntity;
import pl.zenstage.db.store.entity.release.EnvStateEntity;
import pl.zenstage.db.store.entity.release.ProjectEntity;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.EnvStateRepository;
import pl.zenstage.db.store.repository.ProjectRepository;
import pl.zenstage.db.store.repository.TagRepository;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Sinks;
import reactor.core.scheduler.Schedulers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Log4j2
@Service
@RequiredArgsConstructor
public class CodeMapService {
    private final Sinks.Many<CodeMapModule> sink = Sinks.many().replay().latest();
    private final CommitRepository commitRepository;
    private final EnvStateRepository envStateRepository;
    private final OrganizationService organizationService;
    private final ProjectRepository projectRepository;
    private final TagRepository tagRepository;
    private final TaskRepository taskRepository;
    // the commits between two commits never change, so a diff walked once (one query per commit) is kept, the oldest dropped first
    private final Map<List<String>, List<CommitEntity>> diffCache = Collections.synchronizedMap(new LinkedHashMap<>(256, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<List<String>, List<CommitEntity>> eldest) {
            return size() > 5000;
        }
    });

//    void emit(CodeMapModule module) {
//        sink.tryEmitNext(module);
//    }

    public Flux<CodeMapModule> live() {
        return sink.asFlux();
    }

    public Flux<CodeMapModule> init() {
        return userProjects().sort((f, s) -> Objects.compare(f.getLabel(), s.getLabel(), String::compareToIgnoreCase))
                // the projects in parallel (blocking JPA), in the order of the labels
                .flatMapSequential(it -> Flux.defer(() -> mapProject(it)).subscribeOn(Schedulers.boundedElastic()));
    }

    /** Projects of the units of the user; an admin sees every project of the service map (also one no unit has yet). */
    private Flux<ProjectEntity> userProjects() {
        Flux<String> projectIds = ZsCommons.currentUser()
                .map(auth -> auth.getAuthorities().stream().anyMatch(it -> "ADMIN".equals(it.getAuthority())))
                .onErrorReturn(false)
                .flatMapMany(admin -> admin
                        ? Flux.concat(organizationService.getUserContributedProjects(),
                        Flux.defer(() -> Flux.fromIterable(projectRepository.findAll())).map(ProjectEntity::getName))
                        : organizationService.getUserContributedProjects())
                .distinct();
        return projectIds.map(projectRepository::findById)
                .filter(Optional::isPresent).map(Optional::get);
    }

    /** The image and tag of a microservice on one environment of the service map. */
    public record EnvTag(String projectId, String module, String environment, String image, String tag) {
    }

    /**
     * Image and tag of every microservice of the user's projects on one environment (the service map without the
     * diffs): the environment of that name (any case), else the one whose name contains it ("beta" -> "fxp-beta").
     */
    public Mono<List<EnvTag>> tagsOn(String environment) {
        String wanted = Objects.toString(environment, "").trim().toLowerCase(Locale.ROOT);
        return userProjects().publishOn(Schedulers.boundedElastic()).flatMapIterable(project -> {
            List<EnvStateEntity> states = envStateRepository.findAllByProjectId(project.getName());
            Set<String> names = states.stream().map(EnvStateEntity::getEnvironment).filter(Objects::nonNull).collect(Collectors.toSet());
            Set<String> chosen = names.stream().filter(it -> it.equalsIgnoreCase(wanted)).collect(Collectors.toSet());
            if (chosen.isEmpty()) {
                chosen = names.stream().filter(it -> it.toLowerCase(Locale.ROOT).contains(wanted)).collect(Collectors.toSet());
            }
            Set<String> envs = chosen;
            return states.stream().filter(it -> envs.contains(it.getEnvironment()))
                    .map(it -> new EnvTag(project.getName(), it.getModule(), it.getEnvironment(), it.getImage(), it.getVersion()))
                    .toList();
        }).collectList();
    }

    /** Names of the environments of the user's projects in the service map, sorted. */
    public Mono<List<String>> environments() {
        return userProjects().publishOn(Schedulers.boundedElastic())
                .flatMapIterable(project -> envStateRepository.findAllByProjectId(project.getName()))
                .mapNotNull(EnvStateEntity::getEnvironment).distinct().sort(String.CASE_INSENSITIVE_ORDER).collectList();
    }

    public Flux<CodeMapModule> mapProject(ProjectEntity projectEntity) {
        List<String> priorityModules = Optional.of(projectEntity).map(ProjectEntity::getPriorityModules).orElseGet(Collections::emptyList);
        List<String> envOrder = Optional.ofNullable(projectEntity.getEnvironments()).orElseGet(Collections::emptyList);
        // environments in the order of the project (e.g. dev -> test -> prod), unknown ones at the end
        Comparator<String> byEnvOrder = Comparator.comparingInt((String env) -> {
            int idx = envOrder.indexOf(env);
            return idx == -1 ? Integer.MAX_VALUE : idx;
        }).thenComparing(Comparator.naturalOrder());
        Mono<Map<String, List<EnvStateEntity>>> envState = Mono.just(projectEntity).mapNotNull(ProjectEntity::getName)
                .map(envStateRepository::findAllByProjectId)
                .map(it -> it.stream().collect(Collectors.groupingBy(EnvStateEntity::getModule)));

        return envState.flatMapIterable(esm -> esm.entrySet().stream().map(entry -> {
            String module = entry.getKey();
            // the diff of an environment goes to the next one, so they have to be in the order of the project
            List<EnvStateEntity> envs = entry.getValue().stream().sorted(Comparator.comparing(EnvStateEntity::getEnvironment, byEnvOrder)).toList();
            Map<String, String> nextEnvVersion = new HashMap<>();
            for (int i = 0; i < envs.size() - 1; i++) {
                nextEnvVersion.put(
                        envs.get(i).getEnvironment(),
                        envs.get(i + 1).getVersion()
                );
            }
            List<CodeMapEnv> environment = envs.stream().map(ese -> {
                        String targetTag = nextEnvVersion.get(ese.getEnvironment());
                        if (Optional.of(envs).map(List::getLast).map(EnvStateEntity::getEnvironment)
                                .map(ese.getEnvironment()::equals).orElse(false)) {
                            targetTag = ese.getVersion();
                        }
                        return new CodeMapEnv(
                                ese.getEnvironment(),
                                ese.getImage(),
                                ese.getVersion(),
                                safeDiff(projectEntity.getName(), module, ese.getVersion(), targetTag)
                        );
                    }).toList();
            return new CodeMapModule(
                    projectEntity.getName(),
                    module,
                    environment
            );
        }).sorted(Comparator.comparingInt((CodeMapModule m) -> {
                    int idx = priorityModules.indexOf(m.module());
                    return idx == -1 ? Integer.MAX_VALUE : idx;
                }).thenComparing(CodeMapModule::module)
        ).toList());
    }

    /** The diff of one module; incomplete data (a commit without a date or a message) must not break the whole map. */
    private TagDiff safeDiff(String project, String module, String tag1, String tag2) {
        try {
            return findDiff(project, module, tag1, tag2);
        } catch (RuntimeException e) {
            log.warn("No diff of {}/{} {} -> {}: {}", project, module, tag1, tag2, e.toString());
            return new TagDiff(List.of(), List.of(), List.of());
        }
    }

    private TagDiff findDiff(String project, String module, String tag1, String tag2) {
        List<String> commitIds = Stream.of(tag1, tag2).filter(Objects::nonNull)
                .map(tag -> new TagEntity.Pk(project, module, tag))
                .map(tagRepository::findById).filter(Optional::isPresent).map(Optional::get)
                .map(TagEntity::getCommitId).toList();
        List<CommitEntity> diff = cachedCommitDiff(project, module, commitIds);
        List<String> commitIdOrder = diff.stream().map(CommitEntity::getCommitId).toList();

        List<String> commits = diff.stream().map(CommitEntity::getSource).filter(Objects::nonNull).map(Commit::message)
                .filter(Objects::nonNull).toList();

        Pattern pattern = Pattern.compile("[A-Za-z]+-\\d+");
        List<String> issues = commits.stream()
                .flatMap(msg -> {
                    Matcher matcher = pattern.matcher(msg);
                    List<String> matches = new java.util.ArrayList<>();
                    while (matcher.find()) {
                        matches.add(matcher.group());
                    }
                    return matches.stream();
                })
                .distinct()
                .toList();

        List<String> tags = tagRepository.findAllByProjectIdAndModuleNameAndCommitIdIn(project, module,
                        diff.stream().map(CommitEntity::getCommitId).collect(Collectors.toSet())
                ).stream().sorted(Comparator.comparingInt(o -> commitIdOrder.indexOf(o.getCommitId())))
                .map(TagEntity::getTagName).toList();

        return new TagDiff(
                issues,
                commits,
                tags
        );
    }

    private List<CommitEntity> cachedCommitDiff(String project, String module, List<String> commitIds) {
        List<String> key = Stream.concat(Stream.of(project, module), commitIds.stream()).toList();
        List<CommitEntity> cached = diffCache.get(key);
        if (cached != null) return cached;
        List<CommitEntity> diff = commitDiff(project, module, commitIds).stream()
                .sorted(Comparator.comparing(CommitEntity::getCommitDate, Comparator.nullsFirst(Comparator.naturalOrder()))).toList();
        // only a diff of two known commits; one with a commit not imported yet is walked again next time
        if (commitIds.size() == 2 && commitIds.stream().allMatch(it -> commitRepository.existsById(new CommitEntity.Pk(project, module, it)))) {
            diffCache.put(key, diff);
        }
        return diff;
    }

    private Set<CommitEntity> commitDiff(String project, String module, List<String> commitIds) {
        if (commitIds.size() > 2) {
            log.error("Too many commits to show diff!");
            return Collections.emptySet();
        }
        Set<CommitEntity> diff = new HashSet<>();
        Set<CommitEntity> heads = commitIds.stream().map(commitId -> new CommitEntity.Pk(project, module, commitId))
                .map(commitRepository::findById).filter(Optional::isPresent).map(Optional::get).collect(Collectors.toSet());
        if (heads.size() == 1 && commitIds.size() == 1) {
            // one of the versions has no known tag: the diff is unknown (formerly the 50 newest commits of any repository)
            return Collections.emptySet();
        }
        while (heads.size() > 1) {
            Optional<CommitEntity> newest = heads.stream().max(Comparator.comparing(CommitEntity::getCommitDate, Comparator.nullsFirst(Comparator.naturalOrder())));
            newest.ifPresent(heads::remove);
            newest.ifPresent(diff::add);
            heads.addAll(newest.map(CommitEntity::getSource).map(Commit::parentIds).orElseGet(Collections::emptyList).stream()
                    .map(commitId -> new CommitEntity.Pk(project, module, commitId)).map(commitRepository::findById)
                    .filter(Optional::isPresent).map(Optional::get).collect(Collectors.toSet())
            );
        }
        return diff;
    }

    /**
     * Jira issues in {@code tag} of {@code module}: issues with a Fix Version naming that version ("orders-service 1.4.2",
     * "orders-service-v1.4.2") and the issues linked to a release task with it. Only tasks of the user's projects
     * (an admin: all).
     */
    public Mono<CodeMapIssues> issues(String module, String tag) {
        String name = Objects.toString(module, "").trim();
        String version = normalizeVersion(tag);
        if (name.isEmpty() || version.isEmpty()) {
            return Mono.just(new CodeMapIssues(name, tag, List.of(), List.of(), List.of()));
        }
        Mono<Boolean> admin = ZsCommons.currentUser()
                .map(auth -> auth.getAuthorities().stream().anyMatch(it -> "ADMIN".equals(it.getAuthority())))
                .onErrorReturn(false)
                .defaultIfEmpty(false);
        Mono<Set<String>> projects = organizationService.getUserContributedProjects().map(it -> it.toLowerCase(Locale.ROOT))
                .collect(Collectors.toSet());
        return Mono.zip(admin, projects).publishOn(Schedulers.boundedElastic()).map(access -> {
            String prefix = name.toLowerCase(Locale.ROOT).replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%";
            List<TaskEntity> tasks = taskRepository.findByFixVersionLike(prefix).stream()
                    .filter(it -> access.getT1() || access.getT2().contains(Objects.toString(it.getProjectId(), "").toLowerCase(Locale.ROOT)))
                    .filter(it -> it.getContent() != null)
                    .toList();
            Set<String> matched = new LinkedHashSet<>();
            Set<String> other = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
            Map<String, CodeMapIssues.Issue> issues = new LinkedHashMap<>();
            List<Task.Link> released = new ArrayList<>();
            List<String> releaseKeys = new ArrayList<>();
            for (TaskEntity entity : tasks) {
                Task task = entity.getContent();
                List<String> versions = Optional.ofNullable(task.fixVersions()).orElse(List.of()).stream()
                        .filter(fv -> fv != null && versionOf(fv, name) != null).toList();
                List<String> hits = versions.stream().filter(fv -> version.equalsIgnoreCase(versionOf(fv, name))).toList();
                versions.stream().filter(fv -> !hits.contains(fv)).forEach(other::add);
                if (hits.isEmpty()) {
                    continue;
                }
                matched.addAll(hits);
                if (ReleaseTasks.isRelease(entity.getType())) {
                    Optional.ofNullable(task.links()).orElse(List.of()).stream().filter(it -> it.key() != null).forEach(link -> {
                        released.add(link);
                        releaseKeys.add(entity.getKey());
                    });
                } else {
                    issues.putIfAbsent(entity.getKey(), issue(entity, "FIX_VERSION"));
                }
            }
            // issues of the release tasks: details from the imported task when there is one, else from the link
            for (int i = 0; i < released.size(); i++) {
                Task.Link link = released.get(i);
                String source = releaseKeys.get(i);
                issues.computeIfAbsent(link.key(), key -> taskRepository.findByKey(key).stream().findFirst()
                        .map(it -> issue(it, source))
                        .orElse(new CodeMapIssues.Issue(key, link.summary(), null, link.status(), null, null, source)));
            }
            List<String> otherVersions = other.stream().limit(30).toList();
            return new CodeMapIssues(name, tag, List.copyOf(matched), List.copyOf(issues.values()), otherVersions);
        });
    }

    private static CodeMapIssues.Issue issue(TaskEntity entity, String source) {
        Task task = entity.getContent();
        return new CodeMapIssues.Issue(
                entity.getKey(),
                task == null ? null : task.summary(),
                entity.getType(),
                task == null ? null : task.status(),
                task == null || task.assignee() == null ? null : task.assignee().displayName(),
                Optional.ofNullable(entity.getUrl()).orElse(task == null ? null : task.url()),
                source
        );
    }

    /** The version a Fix Version names for the microservice ("orders-service 1.4.2" -> "1.4.2"), null when it is another one. */
    public static String versionOf(String fixVersion, String module) {
        String fv = fixVersion.trim();
        if (fv.length() <= module.length() || !fv.substring(0, module.length()).equalsIgnoreCase(module)) {
            return null;
        }
        String rest = fv.substring(module.length());
        if (!rest.matches("^[\\s_@:/-]+v?\\d.*") && !rest.matches("^[vV]\\d.*")) {
            return null; // "orders-service-api 1.0" is another microservice
        }
        return normalizeVersion(rest.replaceFirst("^[\\s_@:/-]+", ""));
    }

    public static String normalizeVersion(String version) {
        return Objects.toString(version, "").trim().replaceFirst("^[vV](?=\\d)", "");
    }
}
