package pl.zenstage.core.admin;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.api.admin.EmpLevel;
import pl.zenstage.api.admin.EmpSkill;
import pl.zenstage.core.admin.service.PeoplesAdminService;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.core.common.ZsCommons;
import pl.zenstage.core.organization.dto.Init;
import pl.zenstage.core.organization.dto.Person;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping(Const.ADMIN + "/organization/peoples")
@RequiredArgsConstructor
public class AdminPeoplesController {
    private final PeoplesAdminService peoplesAdminService;

    @GetMapping("/init")
    Mono<Init> getInit() {
        return Mono.just(new Init(
                Arrays.stream(EmpLevel.values()).collect(Collectors.toSet()),
                Arrays.stream(EmpSkill.values()).collect(Collectors.toSet())
        ));
    }

    @GetMapping("/peoples")
    Flux<Person> getAllPeoples(@RequestParam(required = false) String query) {
        return ZsCommons.currentUser().publishOn(Schedulers.boundedElastic())
                .map(user -> peoplesAdminService.getPeoples(user, query))
                .flatMapIterable(it -> it);
    }

    @DeleteMapping("/{personId}")
    Mono<ResponseEntity<List<Person>>> delete(@PathVariable String personId) {
        return ZsCommons.currentUser().publishOn(Schedulers.boundedElastic())
                .map(it -> peoplesAdminService.delete(it, personId))
                .map(ResponseEntity::ok)
                .onErrorResume(
                        ZenStageException.class,
                        e -> Mono.just(ResponseEntity.status(e.getStatus()).build())
                );
    }

    @PutMapping("/save")
    Mono<ResponseEntity<List<Person>>> save(@RequestBody Person person) {
        return ZsCommons.currentUser().publishOn(Schedulers.boundedElastic())
                .map(it -> peoplesAdminService.save(it, person))
                .map(ResponseEntity::ok)
                .onErrorResume(
                        ZenStageException.class,
                        e -> Mono.just(ResponseEntity.status(e.getStatus()).build())
                );
    }
}
