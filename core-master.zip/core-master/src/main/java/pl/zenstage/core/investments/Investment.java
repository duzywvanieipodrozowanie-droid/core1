package pl.zenstage.core.investments;

import java.math.BigDecimal;

public record Investment(
        String label,
        BigDecimal percent
) {}
