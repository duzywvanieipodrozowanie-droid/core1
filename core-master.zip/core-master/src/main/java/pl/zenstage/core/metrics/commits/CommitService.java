package pl.zenstage.core.metrics.commits;

import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.commit.zs.ZsSonarStats;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.team.TeamCommitsCheck;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.organization.dto.Person;
import pl.zenstage.db.store.entity.SonarEntity;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.git.MergeRequestEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.MergeRequestRepository;
import pl.zenstage.db.store.repository.SonarRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
@RequiredArgsConstructor
public class CommitService {
    private final CommitRepository commitRepository;
    private final MergeRequestRepository mergeRequestRepository;
    private final OrganizationService organizationService;
    private final SonarRepository sonarRepository;

    @Transactional(readOnly = true)
    public Mono<List<CommitEntity>> getUnitCommitsIfAllowed(String unitId, Interval.Range range) {
        return organizationService.userManageProjectsMembers(unitId).publishOn(Schedulers.boundedElastic()).map(it -> {
                    Set<String> members = new HashSet<>(it.members());
                    List<CommitEntity> commits = commitRepository.findByProjectIdInAndCommitDateBetween(it.projects(), range.from(), range.till());
                    return commits.stream().filter(ce -> members.contains(ce.getCommiterId())).toList();
                }
        );
    }

//    @Transactional(readOnly = true)
//    public Mono<List<CommitEntity>> getUnitCommitsIfAllowed(String unitId, Interval.Range range) {
//        return organizationService.userManageAllowed(unitId).publishOn(Schedulers.boundedElastic())
//                .flatMapIterable(organizationService::getUnitProjects).distinct().collectList()
//                .map(projects ->
//                        commitRepository.findByProjectIdInAndCommitDateBetween(projects, range.from(), range.till())
//                );
//    }

    @Transactional(readOnly = true)
    public Mono<List<MergeRequestEntity>> getUnitManageMrIfAllowed(String unitId, Interval.Range range) {
        return organizationService.userManageProjectsMembers(unitId).publishOn(Schedulers.boundedElastic())
                .map(it -> {
                    Set<String> members = new HashSet<>(it.members());
                    return mergeRequestRepository
                            .findByProjectIdInAndCreateDateBetween(it.projects(), range.from(), range.till()).stream()
                            .filter(mr -> members.contains(mr.getAuthorId())).toList();
                });
    }

    @Transactional(readOnly = true)
    public Mono<Map<Interval.Range, List<CommitEntity>>> getUnitCommitsIfAllowed(String unitId, Interval.RangeFinder rangesFinder) {
        List<Interval.Range> ranges = rangesFinder.ranges();
        Interval.Range range = new Interval.Range(
                ranges.stream().map(Interval.Range::from).min(LocalDateTime::compareTo).orElseGet(LocalDateTime::now),
                ranges.stream().map(Interval.Range::till).max(LocalDateTime::compareTo).orElseGet(LocalDateTime::now)
        );
        return getUnitCommitsIfAllowed(unitId, range).map(commits ->
                commits.stream().collect(Collectors.groupingBy(it -> rangesFinder.findRange(it.getCommitDate())))
        ).map(grouped -> ranges.stream()
                .collect(Collectors.toMap(
                        it -> it,
                        it -> Optional.of(it).map(grouped::get).orElseGet(ArrayList::new),
                        (f, s) -> f, TreeMap::new)
                )
        );
    }

    /** Why the commits of the interval do (not) count for the members of the unit (see {@link TeamCommitsCheck}). */
    @Transactional(readOnly = true)
    public Mono<TeamCommitsCheck> commitsCheck(String unitId, Interval interval) {
        Interval.Range range = interval.range(0);
        return organizationService.userManageProjectsMembers(unitId)
                .zipWith(organizationService.getManagedPeoples(unitId).collectMap(Person::id, it -> Optional.ofNullable(it.name()).orElse("")))
                .publishOn(Schedulers.boundedElastic()).map(t -> {
                    Set<String> projects = new HashSet<>(t.getT1().projects());
                    List<String> members = t.getT1().members().stream().filter(Objects::nonNull).distinct().toList();
                    Set<String> memberSet = new HashSet<>(members);
                    Map<String, String> people = t.getT2();
                    List<CommitEntity> inUnit = projects.isEmpty() ? List.of()
                            : commitRepository.findByProjectIdInAndCommitDateBetween(projects, range.from(), range.till());
                    List<CommitEntity> ofMembers = members.isEmpty() ? List.of()
                            : commitRepository.findByCommiterIdInAndCommitDateBetween(members, range.from(), range.till());
                    List<TeamCommitsCheck.Member> rows = members.stream().map(id -> new TeamCommitsCheck.Member(
                            id,
                            people.get(id),
                            people.containsKey(id),
                            (int) inUnit.stream().filter(it -> id.equals(it.getCommiterId())).count(),
                            counts(ofMembers.stream().filter(it -> id.equals(it.getCommiterId()) && !projects.contains(it.getProjectId())).toList(),
                                    CommitEntity::getProjectId)
                    )).sorted(Comparator.comparing(TeamCommitsCheck.Member::counted).reversed()).toList();
                    return new TeamCommitsCheck(
                            range.from(), range.till(), projects.stream().sorted().toList(), inUnit.size(), rows,
                            counts(inUnit.stream().filter(it -> it.getCommiterId() == null).toList(), CommitService::author),
                            counts(inUnit.stream().filter(it -> it.getCommiterId() != null && !memberSet.contains(it.getCommiterId())).toList(),
                                    CommitEntity::getCommiterId)
                    );
                });
    }

    private static String author(CommitEntity commit) {
        Commit source = commit.getSource();
        if (source == null) return "?";
        return Optional.ofNullable(source.authorEmail()).filter(it -> !it.isBlank())
                .or(() -> Optional.ofNullable(source.authorName())).orElse("?");
    }

    /** Commits by the key, the most first, at most 50. */
    private static Map<String, Integer> counts(List<CommitEntity> commits, Function<CommitEntity, String> key) {
        return commits.stream().collect(Collectors.groupingBy(it -> Optional.ofNullable(key.apply(it)).orElse("?"), Collectors.summingInt(it -> 1)))
                .entrySet().stream().sorted(Map.Entry.<String, Integer>comparingByValue().reversed()).limit(50)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> a, LinkedHashMap::new));
    }

    public List<CommitEntity> findParentCommits(CommitEntity commit) {
        List<CommitEntity.Pk> parentIds = commit.getSource().parentIds().stream().map(it -> new CommitEntity.Pk(
                commit.getProjectId(), commit.getModuleName(), it
        )).toList();
        return commitRepository.findAllById(parentIds);
    }

    /**
     * Unit commits in the interval with their Sonar scan, grouped by commiter id.
     * Loads commits and scans once for the whole unit instead of once per person.
     */
    @Transactional(readOnly = true)
    public Mono<Map<String, List<ImmutablePair<CommitEntity, ZsSonarStats>>>> getCommitsByPerson(String unitId, Interval interval) {
        return getUnitCommitsIfAllowed(unitId, interval.range(0)).map(allCommits -> {
            List<CommitEntity> commits = allCommits.stream().filter(it -> it.getCommiterId() != null).toList();
            Map<SonarEntity.Pk, ZsSonarStats> scans = new HashMap<>();
            loadScansForCommits(commits).forEach(scan -> scans.put(
                    new SonarEntity.Pk(scan.getProjectId(), scan.getModuleName(), scan.getCommitId()), scan.getStats()
            ));
            return commits.stream().collect(Collectors.groupingBy(
                    CommitEntity::getCommiterId,
                    Collectors.mapping(commit -> new ImmutablePair<>(commit, scans.get(
                            new SonarEntity.Pk(commit.getProjectId(), commit.getModuleName(), commit.getCommitId())
                    )), Collectors.toList())
            ));
        });
    }

    /**
     * Complexity change per scanned commit: compared with the scan of the first parent commit,
     * or, when the parent was not scanned, with the latest earlier scan of the same project/module.
     * Commits without a baseline scan are left out.
     */
    @Transactional(readOnly = true)
    public Map<CommitEntity.Pk, ComplexityDelta> complexityDeltas(List<ImmutablePair<CommitEntity, ZsSonarStats>> commits) {
        List<ImmutablePair<CommitEntity, ZsSonarStats>> scanned = commits.stream()
                .filter(it -> it.getLeft() != null && it.getRight() != null)
                .toList();
        Map<SonarEntity.Pk, ZsSonarStats> parentScans = loadScans(scanned.stream()
                .map(ImmutablePair::getLeft)
                .flatMap(commit -> firstParentId(commit).map(parentId ->
                        new SonarEntity.Pk(commit.getProjectId(), commit.getModuleName(), parentId)).stream())
                .distinct()
                .toList()
        ).stream().filter(it -> it.getStats() != null).collect(Collectors.toMap(
                it -> new SonarEntity.Pk(it.getProjectId(), it.getModuleName(), it.getCommitId()),
                SonarEntity::getStats
        ));

        Map<CommitEntity.Pk, ComplexityDelta> deltas = new HashMap<>();
        for (ImmutablePair<CommitEntity, ZsSonarStats> it : scanned) {
            CommitEntity commit = it.getLeft();
            ZsSonarStats current = it.getRight();
            firstParentId(commit)
                    .map(parentId -> parentScans.get(new SonarEntity.Pk(commit.getProjectId(), commit.getModuleName(), parentId)))
                    .or(() -> Optional.ofNullable(commit.getCommitDate())
                            .flatMap(date -> sonarRepository.findPreviousScan(commit.getProjectId(), commit.getModuleName(), date))
                            .map(SonarEntity::getStats))
                    .ifPresent(previous -> deltas.put(
                            new CommitEntity.Pk(commit.getProjectId(), commit.getModuleName(), commit.getCommitId()),
                            new ComplexityDelta(
                                    diff(current.complexity(), previous.complexity()),
                                    diff(current.cognitiveComplexity(), previous.cognitiveComplexity())
                            )
                    ));
        }
        return deltas;
    }

    private static Optional<String> firstParentId(CommitEntity commit) {
        return Optional.ofNullable(commit.getSource())
                .map(Commit::parentIds)
                .filter(ids -> !ids.isEmpty())
                .map(ids -> ids.get(0));
    }

    private static Integer diff(Integer current, Integer previous) {
        return current != null && previous != null ? current - previous : null;
    }

    public List<SonarEntity> loadScansForCommits(List<CommitEntity> commits) {
        return loadScans(commits.stream()
                .map(it -> new SonarEntity.Pk(it.getProjectId(), it.getModuleName(), it.getCommitId()))
                .toList());
    }

    private List<SonarEntity> loadScans(List<SonarEntity.Pk> pks) {
        List<List<SonarEntity.Pk>> batches = IntStream.range(0, (pks.size() + 499) / 500)
                .mapToObj(i -> pks.subList(i * 500, Math.min((i + 1) * 500, pks.size())))
                .toList();
        List<SonarEntity> allScans = new ArrayList<>();
        for (List<SonarEntity.Pk> batch : batches) {
            allScans.addAll(sonarRepository.findAllById(batch));
        }
        return allScans;
    }
}
