package pl.zenstage.core.metrics.response;


import pl.zenstage.api.task.TaskDto;
import pl.zenstage.core.investments.Investment;

import java.util.List;

public record InvestmentResponse(
        List<Investment> investments,
        Percent percent,
        List<TaskDto> bau,
        List<TaskDto> feature
) {
    public record Percent(
            Integer bau,
            Integer feature
    ) {
    }
}
