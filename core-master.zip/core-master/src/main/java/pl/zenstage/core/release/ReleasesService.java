package pl.zenstage.core.release;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.response.ReleaseItem;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.organization.dto.ProjectScope;
import pl.zenstage.db.store.entity.release.ProjectEntity;
import pl.zenstage.db.store.repository.ProjectRepository;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class ReleasesService {
    public static final List<String> MASTER = List.of("master", "main");
    private final OrganizationService organizationService;
    private final ProjectRepository projectRepository;

    public Object releases(Interval interval, String projectCode) {
        Mono<ProjectEntity> project = organizationService.getUserProjects().mapNotNull(it -> it.get(projectCode))
                .switchIfEmpty(Mono.error(new ZenStageException(HttpStatus.FORBIDDEN)))
                .filter(it -> it == ProjectScope.manager).switchIfEmpty(Mono.error(new ZenStageException(HttpStatus.FORBIDDEN)))
                .map(_ -> projectCode).map(projectRepository::findById)
                .filter(Optional::isPresent).map(Optional::get).switchIfEmpty(Mono.error(new ZenStageException(HttpStatus.NOT_FOUND)));
        project.map(it->it.getEnvironments());
//        projectScope.

//        Environment prodEnv = appService.getDataCache().orElseGet(Collections::emptyList).stream()
//                .filter(it -> Objects.equals(it.getProjectName(), projectCode)).findFirst().map(AppProject::getEnvironments)
//                .orElse(Collections.emptyList()).stream().filter(
//                        it -> MASTER.contains(it.getDeployBranchName())
//                ).filter(it ->
//                        Optional.of(it).map(Environment::getDeploy).map(DeployProject::getRepository).isPresent()
//                ).findAny().orElseThrow(() -> new ZenStageException(HttpStatus.NOT_FOUND));
//
//        GitlabRepositoryResponse resp = DeployService.getDeployProject(prodEnv);
//        GitlabClient client = prodEnv.getGitlab().getClient();
//        List<Commit> commits = client.allPageableResults(page -> client.getCommits(resp.id(), page, prodEnv.getDeployBranchName(), interval.from(LocalDate.now()).atStartOfDay(), LocalDateTime.now()));
//
        Map<LocalDate, Map<String, List<ReleaseItem>>> releases = new HashMap<>();
//        commits.forEach(commit -> client.getCommitContent(resp.id(), commit.id()).stream()
//                .map(it -> new ImmutablePair<>(
//                        Optional.ofNullable(it.newPath()).orElse(it.oldPath()),
//                        it.diff()
//                )).filter(it -> Objects.nonNull(it.getKey()))
//                .filter(it -> it.getKey().startsWith("bases")) // zadrutowane, jeszcze myslę jak to zrobić
//                .map(it -> new String[]{
//                        it.getKey().split("/")[1],
//                        releasedImage(it.getValue()),
//                        it.getValue()
//                }).forEach(release ->
//                        releases.computeIfAbsent(commit.committedDate().toLocalDate(), d -> new HashMap<>())
//                                .computeIfAbsent(release[0], m -> new LinkedList<>()).add(new ReleaseItem(release[1], release[2]))
//                ));
        return releases;
    }

    private static String releasedImage(String commitDiff) {
        String image = commitDiff.lines()
                .filter(line -> line.startsWith("+") && line.contains("image"))
                .findFirst().orElse("");
        Pattern pattern = Pattern.compile(".*:(?<version>.*)$");
        Matcher matcher = pattern.matcher(image);

        return matcher.find() ? matcher.group("version") : null;
    }
}
