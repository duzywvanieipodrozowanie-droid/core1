package pl.zenstage.core.investments;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pl.zenstage.api.task.TaskStatus;
import pl.zenstage.core.metrics.ReleaseTasks;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.mapper.UserTaskMapping;
import pl.zenstage.db.store.repository.TaskHistoryRepository;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TaskService {

    private final TaskRepository taskRepository;
    private final TaskHistoryRepository taskHistoryRepository;
    private final OrganizationService organizationService;

    public Mono<List<TaskEntity>> getUnitSimpleTasksIfAllowed(String unitId, Interval.Range range) {
        return organizationService.userManageAllowed(unitId)
                .publishOn(Schedulers.boundedElastic())
                .flatMapIterable(organizationService::getUnitProjects)
                .distinct()
                .collectList()
                .flatMap(projects -> fetchTasksAndSubtasksFromDb(projects, range))
                // release tasks only mark deployments (see DoraService#releasesPerDay)
                .map(tasks -> tasks.stream().filter(it -> !ReleaseTasks.isRelease(it.getType())).toList());
    }

    /** The unit's tasks changed since the given moment, whatever their status now (what happened is in their history). */
    public Mono<List<TaskEntity>> getUnitTasksUpdatedSince(String unitId, LocalDateTime since) {
        return organizationService.userManageAllowed(unitId)
                .publishOn(Schedulers.boundedElastic())
                .flatMapIterable(organizationService::getUnitProjects)
                .distinct()
                .collectList()
                .map(projects -> projects.isEmpty() ? List.<TaskEntity>of() : taskRepository.findByProjectIdInAndUpdatedAfter(projects, since));
    }

    @Transactional(readOnly = true)
    protected Mono<List<TaskEntity>> fetchTasksFromDb(List<String> projects, Interval.Range range, Boolean bau) {
        return Mono.fromCallable(() ->
                taskRepository.findTasksWithOptionalBau(
                        projects, bau, TaskStatus.LIVE, range.from(), range.till()
                )
        ).subscribeOn(Schedulers.boundedElastic());
    }

    @Transactional(readOnly = true)
    protected Mono<List<TaskEntity>> fetchTasksAndSubtasksFromDb(List<String> projects, Interval.Range range) {
        return Mono.fromCallable(() ->
                        taskRepository.findTasksWithOptionalBau(
                                projects, null, TaskStatus.LIVE, range.from(), range.till()
                        )
                )
                .subscribeOn(Schedulers.boundedElastic())
                .flatMap(epics -> {
                    if (epics.isEmpty()) {
                        return Mono.just(List.of());
                    }

                    List<String> parentKeys = epics.stream()
                            .map(TaskEntity::getKey)
                            .distinct()
                            .toList();

                    return Mono.fromCallable(() -> taskRepository.findByParentKeyIn(parentKeys))
                            .subscribeOn(Schedulers.boundedElastic())
                            .map(subtasks -> {
                                Map<String, Boolean> parentBauMap = new HashMap<>();
                                for (TaskEntity epic : epics) {
                                    parentBauMap.putIfAbsent(epic.getKey(), epic.getBau());
                                }
                                List<TaskEntity> allTasks = new ArrayList<>(epics);

                                for (TaskEntity subtask : subtasks) {
                                    if (subtask.getBau() == null) {
                                        Boolean parentBau = parentBauMap.get(subtask.getParentKey());
                                        if (parentBau != null) {
                                            subtask.setBau(parentBau);
                                        }
                                    }
                                    allTasks.add(subtask);
                                }
                                return allTasks;
                            });
                });
    }

    @Transactional
    public Map<String, List<TaskEntity>> getTasksGroupedByUsers(
            List<String> personIds,
            Interval.Range range
    ) {
        List<UserTaskMapping> mappings = taskHistoryRepository.findTasksModifiedByUsersInPeriod(
                personIds,
                range.from(),
                range.till()
        );

        return mappings.stream()
                .collect(Collectors.groupingBy(
                        UserTaskMapping::creator,
                        Collectors.mapping(UserTaskMapping::task, Collectors.toList())
                ));
    }

}
