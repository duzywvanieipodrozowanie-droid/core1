package pl.zenstage.core.metrics.commits;

/**
 * Change of Sonar complexity metrics introduced by a single commit,
 * relative to the previous scan of the same project/module.
 */
public record ComplexityDelta(
        Integer complexity,
        Integer cognitiveComplexity
) {
}
