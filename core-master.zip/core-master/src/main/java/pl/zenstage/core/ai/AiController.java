package pl.zenstage.core.ai;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/ai")
@RequiredArgsConstructor
public class AiController {
    private final AiAssistantService assistantService;

    @GetMapping("/status")
    public AiAssistantService.Status status() {
        return assistantService.status();
    }

    @PostMapping("/chat")
    public Mono<AiAssistantService.ChatResponse> chat(@RequestBody AiAssistantService.ChatRequest request) {
        return assistantService.chat(request);
    }
}
