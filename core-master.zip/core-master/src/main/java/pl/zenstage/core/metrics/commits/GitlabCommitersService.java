package pl.zenstage.core.metrics.commits;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.db.store.entity.PersonEntity;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.PersonRepository;
import pl.zenstage.core.metrics.response.UnknownCommitter;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.TreeSet;
import java.util.stream.Stream;

/**
 * Authors of the commits without a person (commiterId is null): the import assigns a person by the commit's author
 * name / e-mail (PersonService), so the unknown ones are grouped by the author too, not by the committer (GitLab for
 * a merge or a web edit).
 */
@Service
@RequiredArgsConstructor
public class GitlabCommitersService {
    public static final int DEFAULT_DAYS = 30;
    private static final int MAX_DAYS = 365;
    private static final int MAX_REPOSITORIES = 5;

    private final CommitRepository commitRepository;
    private final PersonRepository personRepository;

    public Flux<UnknownCommitter> getUnknownCommiters(int days) {
        int span = Math.max(1, Math.min(MAX_DAYS, days));
        return Mono.fromCallable(() -> unknown(commitRepository.findAllByCommiterIdIsNullAndCommitDateAfter(LocalDateTime.now().minusDays(span)), known()))
                .subscribeOn(Schedulers.boundedElastic())
                .flatMapIterable(it -> it);
    }

    /** E-mail / name / id (lower case) -> person id, as the import maps commit authors (PersonService), but current. */
    private Map<String, String> known() {
        Map<String, String> known = new HashMap<>();
        for (PersonEntity person : personRepository.findAll()) {
            String id = person.getId();
            String escaped = id == null ? null : id.substring(id.lastIndexOf('\\') + 1);
            Stream.concat(Stream.of(person.getEmail(), person.getName(), id, escaped),
                            Optional.ofNullable(person.getCommiterEmails()).orElse(List.of()).stream())
                    .filter(it -> it != null && !it.isBlank())
                    .forEach(it -> known.putIfAbsent(it.toLowerCase(Locale.ROOT), id));
        }
        return known;
    }

    static List<UnknownCommitter> unknown(List<CommitEntity> commits, Map<String, String> known) {
        record Acc(String email, String name, List<LocalDateTime> dates, TreeSet<String> repositories) {
        }
        Map<String, Acc> byAuthor = new LinkedHashMap<>();
        for (CommitEntity commit : commits) {
            Commit source = commit.getSource();
            if (source == null) continue;
            String email = Stream.of(source.authorEmail(), source.committerEmail()).filter(it -> it != null && !it.isBlank()).findFirst().orElse(null);
            String name = Stream.of(source.authorName(), source.committerName()).filter(it -> it != null && !it.isBlank()).findFirst().orElse(null);
            if (email == null && name == null) continue;
            String key = Objects.toString(email, name).toLowerCase(Locale.ROOT);
            Acc acc = byAuthor.computeIfAbsent(key, _ -> new Acc(email, name, new ArrayList<>(), new TreeSet<>()));
            acc.dates().add(commit.getCommitDate());
            Optional.ofNullable(commit.getModuleName()).or(() -> Optional.ofNullable(source.module())).ifPresent(acc.repositories()::add);
        }
        return byAuthor.values().stream()
                .map(acc -> new UnknownCommitter(acc.email(), acc.name(), acc.dates().size(),
                        acc.dates().stream().filter(Objects::nonNull).max(Comparator.naturalOrder()).orElse(null),
                        acc.repositories().stream().limit(MAX_REPOSITORIES).toList(),
                        Stream.of(acc.email(), acc.name()).filter(Objects::nonNull).map(it -> known.get(it.toLowerCase(Locale.ROOT)))
                                .filter(Objects::nonNull).findFirst().orElse(null)))
                .sorted(Comparator.comparingInt(UnknownCommitter::commits).reversed().thenComparing(it -> Objects.toString(it.email(), "")))
                .toList();
    }
}
