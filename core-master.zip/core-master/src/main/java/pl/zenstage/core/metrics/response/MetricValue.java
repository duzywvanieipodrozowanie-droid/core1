package pl.zenstage.core.metrics.response;

import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.math.RoundingMode;

public record MetricValue(
        BigDecimal value,
        BigDecimal change,
        boolean positive
) {
    public static Mono<MetricValue> from(String unitId, Interval interval, UnitMetricRecord producer) {
        return from(unitId, interval, false, producer);
    }

    public static Mono<MetricValue> from(String unitId, Interval interval, boolean lessBetter, UnitMetricRecord producer) {
        return Mono.zip(
                producer.match(unitId, interval.range(1)),
                producer.match(unitId, interval.range(0)),
                MetricValue::matchMetric
        ).map(it -> it.inverse(lessBetter));
    }

    public static Mono<MetricValue> benchmark(boolean lessBetter, Mono<BigDecimal> unitValue, Mono<BigDecimal> unitCompareValue) {
        return Mono.zip(
                unitValue,
                unitCompareValue,
                MetricValue::matchMetric
        ).map(it -> it.inverse(!lessBetter));
    }

    private static MetricValue matchMetric(BigDecimal first, BigDecimal second) {
        BigDecimal change;
        if (first.compareTo(BigDecimal.ZERO) == 0) {
            change = BigDecimal.ZERO;
        } else {
            change = second.subtract(first)
                    .divide(first, 1, RoundingMode.CEILING)
                    .multiply(BigDecimal.valueOf(100));
        }
        return new MetricValue(second, change, change.compareTo(BigDecimal.ZERO) >= 0);
    }

    private MetricValue inverse(boolean lessBetter) {
        if (lessBetter) {
            return new MetricValue(this.value, this.change, !this.positive || this.change.equals(BigDecimal.ZERO));
        }
        return this;
    }
}

