package pl.zenstage.core.metrics.team;

import java.math.BigDecimal;

public record TeamHealth(
        BigDecimal reviewParticipation,
        BigDecimal workloadBalance,
        BigDecimal knowledgeSharing,
        BigDecimal collaborationScore
) {
}
