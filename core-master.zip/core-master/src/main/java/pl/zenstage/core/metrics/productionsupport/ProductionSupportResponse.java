package pl.zenstage.core.metrics.productionsupport;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Production support: the unit's production defects from Jira (issue types like "Production defect"), how many are
 * open vs closed and how fast they get closed. Durations are in days.
 */
public record ProductionSupportResponse(
        Summary summary,
        Summary previous,
        List<Week> weeks,
        List<AgeBucket> aging,
        List<PriorityStats> byPriority,
        List<OpenDefect> open,
        List<ClosedDefect> recentlyClosed
) {
    /**
     * open / openOver30Days: now; reported, closed, rejected (closed as cancelled/rejected), times: in the period.
     * daysToClose = reported -> closed (rejected ones excluded), daysToStart = reported -> first in-progress status.
     */
    public record Summary(
            int open,
            int openOver30Days,
            int reported,
            int closed,
            int rejected,
            BigDecimal avgDaysToClose,
            BigDecimal medianDaysToClose,
            BigDecimal p85DaysToClose,
            BigDecimal avgDaysToStart
    ) {
    }

    /** Defects reported and closed in the week, and open at its end. */
    public record Week(LocalDate weekStart, int reported, int closed, int open) {
    }

    /** Open defects by age: from inclusive, till exclusive (null = open-ended), in days. */
    public record AgeBucket(int from, Integer till, int count) {
    }

    public record PriorityStats(String priority, int open, int closed, BigDecimal avgDaysToClose) {
    }

    public record OpenDefect(
            String key,
            String summary,
            String url,
            String status,
            String priority,
            String assignee,
            LocalDateTime reported,
            BigDecimal ageDays,
            BigDecimal daysInStatus
    ) {
    }

    public record ClosedDefect(
            String key,
            String summary,
            String url,
            String status,
            String priority,
            String assignee,
            LocalDateTime reported,
            LocalDateTime closed,
            BigDecimal daysToClose
    ) {
    }
}
