package pl.zenstage.core.metrics.team;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * Why commits do (not) reach the Team details (GET /metrics/team/commits-check): a commit counts for a person
 * only when it is in a project of the unit (unit.projects in the database, or of a unit above it) and its commiterId is a member of the unit.
 *
 * @param members          per member of the unit: commits counted, commits in projects outside the unit
 * @param withoutPerson    authors of the commits in the unit projects with no person (commiterId empty), e-mail -> commits
 * @param otherPeople      person ids of the commits in the unit projects that are not members of the unit -> commits
 */
public record TeamCommitsCheck(
        LocalDateTime from,
        LocalDateTime till,
        List<String> unitProjects,
        int commitsInUnitProjects,
        List<Member> members,
        Map<String, Integer> withoutPerson,
        Map<String, Integer> otherPeople
) {
    /** @param outsideUnitProjects project of the commit -> commits, not counted as the project is not the unit's */
    public record Member(String id, String name, boolean personFound, int counted, Map<String, Integer> outsideUnitProjects) {
    }
}
