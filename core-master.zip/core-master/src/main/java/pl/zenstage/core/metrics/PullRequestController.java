package pl.zenstage.core.metrics;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.pr.PrChartTimeRecord;
import pl.zenstage.core.metrics.pr.PrFlow;
import pl.zenstage.core.metrics.pr.PrLastItem;
import pl.zenstage.core.metrics.pr.PrThroughputRecord;
import pl.zenstage.core.metrics.pr.PullRequestService;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.response.ChartResponse;
import pl.zenstage.core.metrics.response.MetricValue;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/metrics/pr")
@RequiredArgsConstructor
public class PullRequestController {
    private final PullRequestService pullRequestService;

    @GetMapping("/tp")
    public Mono<ResponseEntity<MetricValue>> prTp(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, pullRequestService::prTp).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/ct")
    public Mono<ResponseEntity<MetricValue>> prCt(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, true, pullRequestService::prCt).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/chart/ct")
    public Mono<ChartResponse<PrChartTimeRecord>> prChartTime(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return pullRequestService.cycleTimeChart(unitId, interval);
    }

    @GetMapping("/chart/tp")
    public Mono<ChartResponse<PrThroughputRecord>> prThroughput(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return pullRequestService.throughputChart(unitId, interval);
    }

    @GetMapping("/flow")
    public Mono<PrFlow> prFlow(
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval,
            @RequestParam(required = false) String unitId
    ) {
        return pullRequestService.prFlow(unitId, interval);
    }

    @GetMapping("/last")
    public Flux<PrLastItem> prLast(
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval,
            @RequestParam(required = false) String unitId
    ) {
        return pullRequestService.lastMergeRequests(unitId, interval);
    }
}
