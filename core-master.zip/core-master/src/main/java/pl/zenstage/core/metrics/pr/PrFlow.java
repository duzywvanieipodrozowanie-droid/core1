package pl.zenstage.core.metrics.pr;

import java.math.BigDecimal;
import java.math.RoundingMode;

public record PrFlow(
        int opened,
        int openedDiff,
        int merged,
        int mergedDiff,
        int review,
        int reviewDiff
) {
    public BigDecimal getOpenedRateChange() {
        if(openedDiff == 0) {
            return BigDecimal.ZERO;
        }
        return BigDecimal.valueOf(openedDiff * 50L).divide(BigDecimal.valueOf(opened), 0, RoundingMode.CEILING);
    }

    public BigDecimal getMergedRateChange() {
        if(openedDiff == 0) {
            return BigDecimal.ZERO;
        }
        return BigDecimal.valueOf(mergedDiff * 50L).divide(BigDecimal.valueOf(opened), 0, RoundingMode.CEILING);
    }
}

