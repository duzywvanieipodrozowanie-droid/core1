package pl.zenstage.core.metrics.gitlab;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.gitlab.CommitHeatmapResponse.GroupBy;
import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Mono;

import java.time.DateTimeException;
import java.time.ZoneId;
import java.util.Set;

@RestController
@RequestMapping("/metrics/gitlab")
@RequiredArgsConstructor
public class GitlabDetailsController {
    private static final Set<Integer> SLOT_HOURS = Set.of(1, 2, 3, 4, 6);
    private static final String DEFAULT_ZONE = "Europe/Warsaw";

    private final GitlabDetailsService gitlabDetailsService;

    @GetMapping("/details")
    public Mono<ResponseEntity<GitlabDetailsResponse>> details(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_4") Interval interval
    ) {
        return gitlabDetailsService.details(unitId, interval).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    /** slotHours: 1, 2, 3, 4 or 6; tz: IANA zone of the hours on the chart (the browser's), Europe/Warsaw by default. */
    @GetMapping("/commit-heatmap")
    public Mono<ResponseEntity<CommitHeatmapResponse>> commitHeatmap(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "MONTHS_3") Interval interval,
            @RequestParam(required = false, defaultValue = "WEEK") GroupBy groupBy,
            @RequestParam(required = false, defaultValue = "3") int slotHours,
            @RequestParam(required = false, defaultValue = DEFAULT_ZONE) String tz
    ) {
        if (!SLOT_HOURS.contains(slotHours)) {
            return Mono.just(ResponseEntity.badRequest().build());
        }
        ZoneId zone;
        try {
            zone = ZoneId.of(tz);
        } catch (DateTimeException e) {
            zone = ZoneId.of(DEFAULT_ZONE);
        }
        return gitlabDetailsService.commitHeatmap(unitId, interval, groupBy, slotHours, zone).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }
}
