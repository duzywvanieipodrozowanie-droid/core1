package pl.zenstage.core.metrics.deliver;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.commit.CommitTasks;
import pl.zenstage.api.task.History;
import pl.zenstage.api.task.Task;
import pl.zenstage.api.task.TaskStatus;
import pl.zenstage.core.metrics.ReleaseTasks;
import pl.zenstage.core.metrics.deliver.DeliverResponse.Breakdown;
import pl.zenstage.core.metrics.deliver.DeliverResponse.Burnup;
import pl.zenstage.core.metrics.deliver.DeliverResponse.BurnupWeek;
import pl.zenstage.core.metrics.deliver.DeliverResponse.EpicDetail;
import pl.zenstage.core.metrics.deliver.DeliverResponse.EpicList;
import pl.zenstage.core.metrics.deliver.DeliverResponse.EpicSummary;
import pl.zenstage.core.metrics.deliver.DeliverResponse.Health;
import pl.zenstage.core.metrics.deliver.DeliverResponse.Item;
import pl.zenstage.core.metrics.deliver.DeliverResponse.Segment;
import pl.zenstage.core.metrics.deliver.DeliverResponse.Stats;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.roadmap.RoadmapStore;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.Phase;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineService;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Deliver screen: Jira epics of the unit with their work items (children and their sub-tasks), planned dates
 * (Jira "Target start" / "Target end"), actual start (first work item in progress), first code (first commit mentioning
 * the epic or one of its items) and delivery (epic done, otherwise a forecast from the pace of closing its items).
 */
@Service
@RequiredArgsConstructor
public class DeliverService {
    private static final String EPIC_TYPE = "Epic";
    private static final Set<Phase> WORK_PHASES = Set.of(Phase.CODING, Phase.REVIEW, Phase.TEST, Phase.WAITING);
    // commits are matched from this long before the earliest start of the shown epics
    private static final int COMMIT_LOOKBACK_DAYS = 30;
    private static final int MAX_COMMIT_HISTORY_DAYS = 365;
    private static final int SPARKLINE_WEEKS = 8;
    // forecast pace: weighted progress gained in this many recent days (falls back to the pace since the actual start)
    private static final int FORECAST_PACE_DAYS = 21;
    // a forecast further than this is shown at this distance (a pace near zero would overflow the date)
    private static final int MAX_FORECAST_DAYS = 3650;
    // gained progress below this is rounding noise of the sums, not movement
    private static final double MIN_GAIN = 1e-6;
    // health: behind the plan (pp) for AT_RISK / OFF_TRACK, forecast days after the due date for OFF_TRACK
    private static final int BEHIND_PLAN_PP = 10;
    private static final int OFF_TRACK_PP = 25;
    private static final int OFF_TRACK_DAYS = 14;
    // warning signals of an epic in progress
    private static final int STALLED_DAYS = 10;
    private static final int STUCK_IN_TEST_DAYS = 10;
    private static final int SCOPE_GROWTH_DAYS = 14;
    // burn-up velocity: average of this many last full weeks
    private static final int VELOCITY_WEEKS = 6;
    private static final List<String> LIVE_STATUSES = List.of("LIVE", "RELEASED", "PRODUCTION", "CLOSED");
    private static final Pattern TASK_KEY = Pattern.compile("[A-Z][A-Z0-9]+-\\d+");

    private final OrganizationService organizationService;
    private final TaskRepository taskRepository;
    private final CommitRepository commitRepository;
    private final TaskTimelineService taskTimelineService;
    private final RoadmapStore roadmapStore;

    /** An epic with all its work items (children and their sub-tasks) and the commits mentioning any of them. */
    private record EpicData(TaskEntity epic, List<TaskEntity> children, List<TaskEntity> subtasks, List<CommitEntity> commits,
                            Map<String, Integer> commitsPerKey) {
        List<TaskEntity> items() {
            return Stream.concat(children.stream(), subtasks.stream()).toList();
        }
    }

    /**
     * Epics of the current year: created, started or delivered since 1 January (older epics still open but untouched
     * this year are left out). The interval is kept for API compatibility and no longer narrows the list.
     */
    public Mono<EpicList> epics(String unitId, Interval interval) {
        LocalDate yearStart = LocalDate.now().withDayOfYear(1);
        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(pm -> {
                    List<TaskEntity> epics = taskRepository.findByProjectIdInAndTypeIgnoreCase(pm.projects(), EPIC_TYPE);
                    List<EpicData> data = load(epics, pm.projects());
                    LocalDateTime now = LocalDateTime.now();
                    Marks marks = marks();
                    Map<String, LocalDateTime> createdByKey = new HashMap<>();
                    epics.forEach(it -> createdByKey.putIfAbsent(it.getKey(), it.getCreated()));
                    List<EpicSummary> summaries = data.stream()
                            .map(it -> summary(it, now, marks))
                            .filter(it -> sinceYearStart(createdByKey.get(it.key()), yearStart)
                                    || it.actualStart() != null && !it.actualStart().toLocalDate().isBefore(yearStart)
                                    || it.deliveryDate() != null && !it.deliveryDate().isBefore(yearStart))
                            .sorted(Comparator.comparing((EpicSummary it) -> healthOrder(it.health()))
                                    .thenComparing(it -> Optional.ofNullable(it.delayDays()).orElse(0L), Comparator.reverseOrder())
                                    .thenComparing(EpicSummary::key))
                            .toList();
                    return new EpicList(summaries);
                });
    }

    /** Epics of the unit planned for a quarter of {@code year} (whenever created), in the order of the quarters. */
    public Mono<EpicList> roadmap(String unitId, int year) {
        String prefix = year + "-Q";
        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(pm -> {
                    Marks marks = marks();
                    List<TaskEntity> epics = distinctByKey(taskRepository.findByProjectIdInAndTypeIgnoreCase(pm.projects(), EPIC_TYPE).stream()
                            .filter(it -> Optional.ofNullable(marks.quarters().get(it.getKey())).map(q -> q.startsWith(prefix)).orElse(false))
                            .toList());
                    LocalDateTime now = LocalDateTime.now();
                    return new EpicList(load(epics, pm.projects()).stream()
                            .map(it -> summary(it, now, marks))
                            .sorted(Comparator.comparing(EpicSummary::quarter)
                                    .thenComparing(it -> Optional.ofNullable(it.plannedStart()).orElse(LocalDate.MAX))
                                    .thenComparing(EpicSummary::key))
                            .toList());
                });
    }

    /** The roadmap quarters and the technical / business marks of the epics (Deliver screen). */
    private record Marks(Map<String, String> quarters, Map<String, Boolean> technical) {
    }

    private Marks marks() {
        return new Marks(roadmapStore.quarters(), roadmapStore.technical());
    }

    /** Puts an epic of the unit's projects on the roadmap quarter (or takes it off); empty when it is not such an epic. */
    public Mono<String> setQuarter(String unitId, String key, String quarter) {
        String value = quarter == null || quarter.isBlank() ? null : quarter.trim().toUpperCase(Locale.ROOT);
        if (value != null && !RoadmapStore.QUARTER.matcher(value).matches()) {
            return Mono.error(new IllegalArgumentException("Quarter like 2026-Q3 expected: " + quarter));
        }
        return unitEpic(unitId, key).map(epicKey -> {
            roadmapStore.set(epicKey, value);
            return Objects.toString(value, "");
        });
    }

    /** Marks an epic of the unit's projects technical / business ({@code null}: the Jira field again); empty when it is not such an epic. */
    public Mono<Optional<Boolean>> setTechnical(String unitId, String key, Boolean technical) {
        return unitEpic(unitId, key).map(epicKey -> {
            roadmapStore.setTechnical(epicKey, technical);
            return Optional.ofNullable(technical);
        });
    }

    /** The key of an epic of the unit's projects; empty when it is not such an epic. */
    private Mono<String> unitEpic(String unitId, String key) {
        String epicKey = key == null ? "" : key.trim().toUpperCase(Locale.ROOT);
        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .mapNotNull(pm -> taskRepository.findByKey(epicKey).stream()
                        .anyMatch(it -> pm.projects().contains(it.getProjectId()) && EPIC_TYPE.equalsIgnoreCase(it.getType())) ? epicKey : null);
    }

    private static boolean sinceYearStart(LocalDateTime at, LocalDate yearStart) {
        return at != null && !at.toLocalDate().isBefore(yearStart);
    }

    public Mono<EpicDetail> epic(String unitId, String key) {
        String epicKey = key == null ? "" : key.trim().toUpperCase(Locale.ROOT);
        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .mapNotNull(pm -> taskRepository.findByKey(epicKey).stream()
                        .filter(it -> pm.projects().contains(it.getProjectId()))
                        .findFirst()
                        .map(epic -> detail(load(List.of(epic), pm.projects()).getFirst(), LocalDateTime.now(), marks()))
                        .orElse(null));
    }

    private List<EpicData> load(List<TaskEntity> epics, Collection<String> projects) {
        if (epics.isEmpty()) {
            return List.of();
        }
        // children and sub-tasks belong to the unit's epic even when Jira keeps them in another project
        // (e.g. epics in a portfolio project, stories in team projects), so they are not filtered by project
        // release tasks under an epic only mark its deployment, they are not part of the epic's work
        Map<String, List<TaskEntity>> childrenByEpic = distinctByKey(taskRepository.findByParentKeyIn(epics.stream().map(TaskEntity::getKey).toList()))
                .stream().filter(it -> !ReleaseTasks.isRelease(it.getType())).collect(Collectors.groupingBy(TaskEntity::getParentKey));
        List<String> childKeys = childrenByEpic.values().stream().flatMap(List::stream).map(TaskEntity::getKey).toList();
        Map<String, List<TaskEntity>> subtasksByParent = childKeys.isEmpty() ? Map.of()
                : distinctByKey(taskRepository.findByParentKeyIn(childKeys)).stream()
                .collect(Collectors.groupingBy(TaskEntity::getParentKey));

        // task key -> epic key, to attribute commits
        Map<String, String> epicOfKey = new HashMap<>();
        LocalDateTime earliest = LocalDateTime.now();
        for (TaskEntity epic : epics) {
            epicOfKey.put(epic.getKey(), epic.getKey());
            for (TaskEntity child : childrenByEpic.getOrDefault(epic.getKey(), List.of())) {
                epicOfKey.put(child.getKey(), epic.getKey());
                subtasksByParent.getOrDefault(child.getKey(), List.of()).forEach(sub -> epicOfKey.put(sub.getKey(), epic.getKey()));
            }
            LocalDateTime created = Optional.ofNullable(epic.getCreated()).orElse(earliest);
            if (created.isBefore(earliest)) {
                earliest = created;
            }
        }
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime commitsFrom = earliest.minusDays(COMMIT_LOOKBACK_DAYS);
        if (commitsFrom.isBefore(now.minusDays(MAX_COMMIT_HISTORY_DAYS))) {
            commitsFrom = now.minusDays(MAX_COMMIT_HISTORY_DAYS);
        }
        Map<String, List<CommitEntity>> commitsByEpic = new HashMap<>();
        Map<String, Integer> commitsPerKey = new HashMap<>();
        for (CommitEntity commit : commitRepository.findByProjectIdInAndCommitDateBetween(projects, commitsFrom, now)) {
            Set<String> keys = keysOf(commit);
            Set<String> commitEpics = new HashSet<>();
            for (String k : keys) {
                String epicKey = epicOfKey.get(k);
                if (epicKey != null) {
                    commitEpics.add(epicKey);
                    commitsPerKey.merge(k, 1, Integer::sum);
                }
            }
            commitEpics.forEach(e -> commitsByEpic.computeIfAbsent(e, x -> new ArrayList<>()).add(commit));
        }

        return epics.stream().map(epic -> {
            List<TaskEntity> children = childrenByEpic.getOrDefault(epic.getKey(), List.of());
            List<TaskEntity> subtasks = children.stream()
                    .flatMap(c -> subtasksByParent.getOrDefault(c.getKey(), List.of()).stream())
                    .toList();
            List<CommitEntity> commits = commitsByEpic.getOrDefault(epic.getKey(), List.of()).stream()
                    .sorted(Comparator.comparing(CommitEntity::getCommitDate, Comparator.nullsLast(Comparator.naturalOrder())))
                    .toList();
            return new EpicData(epic, children, subtasks, commits, commitsPerKey);
        }).toList();
    }

    /** One entity per Jira key (the same issue can be stored under more than one project). */
    private static List<TaskEntity> distinctByKey(List<TaskEntity> tasks) {
        Map<String, TaskEntity> byKey = new LinkedHashMap<>();
        tasks.forEach(it -> byKey.putIfAbsent(it.getKey(), it));
        return List.copyOf(byKey.values());
    }

    /** Task keys of a commit: the ones extracted on import plus any key-like text in its message. */
    private static Set<String> keysOf(CommitEntity commit) {
        Set<String> keys = new HashSet<>(Optional.ofNullable(commit.getTaskKey()).map(CommitTasks::tasks).orElse(Set.of()));
        String message = Optional.ofNullable(commit.getSource()).map(Commit::message).orElse(null);
        if (message != null) {
            Matcher m = TASK_KEY.matcher(message.toUpperCase(Locale.ROOT));
            while (m.find()) {
                keys.add(m.group());
            }
        }
        return keys;
    }

    private EpicSummary summary(EpicData data, LocalDateTime now, Marks marks) {
        TaskEntity epicEntity = data.epic();
        Task epic = epicEntity.getContent();
        // cancelled / rejected work items are not part of the epic's work
        List<TaskEntity> counted = (data.children().isEmpty() ? data.subtasks() : data.children()).stream()
                .filter(it -> !cancelled(it)).toList();
        int done = (int) counted.stream().filter(this::done).count();
        int total = counted.size();

        LocalDateTime actualStart = Stream.concat(Stream.of(epicEntity), data.items().stream())
                .map(this::firstWork).filter(Objects::nonNull).min(Comparator.naturalOrder()).orElse(null);
        LocalDateTime firstCode = data.commits().stream().map(CommitEntity::getCommitDate).filter(Objects::nonNull)
                .min(Comparator.naturalOrder()).orElse(null);
        LocalDate plannedStart = epic == null ? null : epic.startDate();
        LocalDate due = epic == null ? null : epic.dueDate();

        LocalDateTime statusSince = statusChanges(epicEntity).stream().map(History::created).reduce((a, b) -> b)
                .orElse(Optional.ofNullable(epicEntity.getCreated()).orElse(epic == null ? null : epic.created()));
        Long statusDays = statusSince == null ? null : Math.max(0, ChronoUnit.DAYS.between(statusSince.toLocalDate(), now.toLocalDate()));

        // progress weighted by the phase of each work item and its story points
        Map<TaskEntity, Double> weights = weights(counted);
        double work = weights.values().stream().mapToDouble(Double::doubleValue).sum();
        Map<Stage, Double> byStage = new EnumMap<>(Stage.class);
        double credit = 0;
        for (TaskEntity item : counted) {
            Credit c = creditAt(item, null);
            byStage.merge(c.stage(), weights.get(item), Double::sum);
            credit += weights.get(item) * c.value();
        }
        boolean allLive = total > 0 && byStage.getOrDefault(Stage.LIVE, 0.0) >= work;
        boolean epicDone = done(epicEntity) || allLive;
        int progressPct = work > 0 ? (int) Math.round(credit * 100 / work) : (epicDone ? 100 : 0);
        Breakdown breakdown = new Breakdown(pct(byStage, Stage.LIVE, work), pct(byStage, Stage.DONE, work),
                pct(byStage, Stage.TEST, work), pct(byStage, Stage.DEV, work), pct(byStage, Stage.TODO, work),
                pct(byStage, Stage.BLOCKED, work));

        LocalDate today = now.toLocalDate();
        Integer expectedPct = plannedStart != null && due != null && due.isAfter(plannedStart)
                ? (int) Math.round(Math.max(0, Math.min(1, ChronoUnit.DAYS.between(plannedStart, today)
                / (double) ChronoUnit.DAYS.between(plannedStart, due))) * 100)
                : null;

        LocalDate delivered = !epicDone ? null : done(epicEntity)
                ? Optional.ofNullable(doneAt(epicEntity)).map(LocalDateTime::toLocalDate)
                .orElse(Optional.ofNullable(epicEntity.getUpdated()).map(LocalDateTime::toLocalDate).orElse(null))
                : counted.stream().map(it -> Optional.ofNullable(doneAt(it)).orElse(it.getUpdated())).filter(Objects::nonNull)
                .max(Comparator.naturalOrder()).map(LocalDateTime::toLocalDate).orElse(null);
        LocalDate forecast = !epicDone && actualStart != null && work > 0
                ? forecast(counted, weights, credit, work, actualStart, now) : null;
        List<String> signals = epicDone || actualStart == null ? List.of() : signals(counted, actualStart, now);

        Health health;
        Long delay = null;
        String reason = null;
        if (epicDone) {
            if (due != null && delivered != null && delivered.isAfter(due)) {
                health = Health.DELIVERED_LATE;
                delay = ChronoUnit.DAYS.between(due, delivered);
                reason = "DELIVERED_AFTER_DUE";
            } else {
                health = Health.DELIVERED;
            }
        } else if (actualStart == null) {
            if (due != null && today.isAfter(due)) {
                health = Health.OFF_TRACK;
                delay = ChronoUnit.DAYS.between(due, today);
                reason = "PAST_DUE";
            } else if (plannedStart != null && today.isAfter(plannedStart)) {
                health = Health.AT_RISK;
                delay = ChronoUnit.DAYS.between(plannedStart, today);
                reason = "START_DELAYED";
            } else {
                health = Health.NOT_STARTED;
            }
        } else {
            long pastDue = due != null && today.isAfter(due) ? ChronoUnit.DAYS.between(due, today) : 0;
            long forecastLate = due != null && forecast != null && forecast.isAfter(due) ? ChronoUnit.DAYS.between(due, forecast) : 0;
            int gap = expectedPct == null ? 0 : progressPct - expectedPct;
            if (pastDue > 0 || forecastLate > 0) {
                delay = Math.max(pastDue, forecastLate);
                reason = forecastLate >= pastDue ? "FORECAST_AFTER_DUE" : "PAST_DUE";
            } else if (gap < -BEHIND_PLAN_PP) {
                reason = "BEHIND_PLAN";
            } else if (!signals.isEmpty()) {
                reason = signals.getFirst();
            } else if (due == null) {
                reason = "NO_PLAN";
            }
            if (pastDue > 0 || forecastLate > OFF_TRACK_DAYS || gap < -OFF_TRACK_PP) {
                health = Health.OFF_TRACK;
            } else if (forecastLate > 0 || gap < -BEHIND_PLAN_PP || !signals.isEmpty()) {
                health = Health.AT_RISK;
            } else {
                health = Health.ON_TRACK;
            }
        }

        return new EpicSummary(
                epicEntity.getKey(),
                epic == null ? null : epic.summary(),
                Optional.ofNullable(epicEntity.getUrl()).orElse(epic == null ? null : epic.url()),
                epic == null ? null : epic.status(),
                statusSince,
                statusDays,
                epic == null || epic.assignee() == null ? null : epic.assignee().displayName(),
                plannedStart,
                actualStart,
                firstCode,
                due,
                epicDone ? delivered : forecast,
                !epicDone && forecast != null,
                health,
                delay,
                reason,
                total,
                done,
                progressPct,
                Optional.ofNullable(marks.technical().get(epicEntity.getKey())).orElse(epicEntity.getTechnical()),
                marks.technical().containsKey(epicEntity.getKey()),
                marks.quarters().get(epicEntity.getKey()),
                epicEntity.getParentKey(),
                epic == null || epic.parent() == null ? null : epic.parent().summary(),
                epic == null || epic.parent() == null ? null : epic.parent().status(),
                epic == null || epic.parent() == null ? null : epic.parent().assignee(),
                epicDone ? null : expectedPct,
                breakdown,
                signals
        );
    }

    /** Stage of a work item for the weighted progress; BLOCKED keeps the credit of the stage before the block. */
    private enum Stage {TODO, DEV, TEST, DONE, LIVE, BLOCKED}

    private record Credit(Stage stage, double value) {
    }

    /**
     * Credit of a status: backlog 0, analysis 0.1, coding 0.35 (developed 0.55), review 0.5, test 0.7 (UAT and
     * acceptance 0.85), waiting for release and done (not live yet) 0.9, live / released / closed 1.0.
     */
    private Credit stage(String status) {
        String s = Optional.ofNullable(status).orElse("").trim().toUpperCase(Locale.ROOT);
        if (s.isEmpty()) {
            return new Credit(Stage.TODO, 0);
        }
        if (s.contains("BLOCK") || s.contains("HOLD")) {
            return new Credit(Stage.BLOCKED, 0);
        }
        return switch (taskTimelineService.phaseOf(s)) {
            case BACKLOG -> new Credit(Stage.TODO, 0);
            case ANALYSIS -> new Credit(Stage.DEV, 0.1);
            case CODING -> new Credit(Stage.DEV, s.contains("DEVELOPED") ? 0.55 : 0.35);
            case REVIEW -> new Credit(Stage.DEV, 0.5);
            case TEST -> new Credit(Stage.TEST, s.contains("UAT") || s.contains("ACCEPTANCE") ? 0.85 : 0.7);
            case WAITING -> new Credit(Stage.DONE, 0.9);
            case DONE -> LIVE_STATUSES.stream().anyMatch(s::contains) ? new Credit(Stage.LIVE, 1) : new Credit(Stage.DONE, 0.9);
        };
    }

    /** Credit of a work item at a moment ({@code null} = now) from its status history. */
    private Credit creditAt(TaskEntity entity, LocalDateTime at) {
        List<History> changes = statusChanges(entity);
        String status = changes.isEmpty() ? status(entity) : changes.getFirst().from();
        Credit current = stage(status);
        Credit lastWork = current.stage() == Stage.BLOCKED ? new Credit(Stage.TODO, 0) : current;
        for (History change : changes) {
            if (at != null && change.created().isAfter(at)) {
                break;
            }
            current = stage(change.to());
            if (current.stage() != Stage.BLOCKED) {
                lastWork = current;
            }
        }
        return current.stage() == Stage.BLOCKED ? new Credit(Stage.BLOCKED, lastWork.value()) : current;
    }

    /** Work of each item: its story points, the average estimate when it has none, 1 each when nothing is estimated. */
    private static Map<TaskEntity, Double> weights(List<TaskEntity> items) {
        List<BigDecimal> estimates = items.stream().map(TaskEntity::getContent).filter(Objects::nonNull)
                .map(Task::estimate).filter(it -> it != null && it.signum() > 0).toList();
        double average = estimates.isEmpty() ? 1
                : estimates.stream().mapToDouble(BigDecimal::doubleValue).sum() / estimates.size();
        Map<TaskEntity, Double> weights = new LinkedHashMap<>();
        for (TaskEntity item : items) {
            BigDecimal estimate = estimates.isEmpty() ? null : Optional.ofNullable(item.getContent()).map(Task::estimate).orElse(null);
            weights.put(item, estimate != null && estimate.signum() > 0 ? estimate.doubleValue() : average);
        }
        return weights;
    }

    private static int pct(Map<Stage, Double> byStage, Stage stage, double work) {
        return work > 0 ? (int) Math.round(byStage.getOrDefault(stage, 0.0) * 100 / work) : 0;
    }

    /**
     * Remaining work at the recent pace of the weighted progress: credit gained in the last FORECAST_PACE_DAYS days
     * (work moved to test counts too, so it works before anything is done), or since the actual start when nothing
     * moved recently.
     */
    private LocalDate forecast(List<TaskEntity> items, Map<TaskEntity, Double> weights, double credit, double work,
                               LocalDateTime actualStart, LocalDateTime now) {
        LocalDate today = now.toLocalDate();
        double remaining = work - credit;
        if (remaining <= 0.0001) {
            return today;
        }
        LocalDateTime paceFrom = now.minusDays(FORECAST_PACE_DAYS);
        double creditThen = items.stream()
                .filter(it -> it.getCreated() == null || !it.getCreated().isAfter(paceFrom))
                .mapToDouble(it -> weights.get(it) * creditAt(it, paceFrom).value())
                .sum();
        double gained = credit - creditThen;
        double perDay = gained > MIN_GAIN && actualStart.isBefore(paceFrom)
                ? gained / FORECAST_PACE_DAYS
                : credit / Math.max(1.0, Duration.between(actualStart, now).toMinutes() / 1440.0);
        if (perDay <= 0) {
            return null;
        }
        return today.plusDays((long) Math.min(MAX_FORECAST_DAYS, Math.ceil(remaining / perDay)));
    }

    /**
     * Warning signals of an epic in progress: BLOCKED (an item on hold / blocked), STALLED (no status change of its
     * open items for STALLED_DAYS), STUCK_IN_TEST (an item in test for STUCK_IN_TEST_DAYS), SCOPE_GROWTH (items added
     * in the last SCOPE_GROWTH_DAYS are at least 20% of the ones before, 2 at least).
     */
    private List<String> signals(List<TaskEntity> items, LocalDateTime actualStart, LocalDateTime now) {
        List<String> signals = new ArrayList<>();
        List<TaskEntity> open = items.stream().filter(it -> !done(it)).toList();
        if (open.stream().anyMatch(it -> stage(status(it)).stage() == Stage.BLOCKED)) {
            signals.add("BLOCKED");
        }
        LocalDateTime lastMove = items.stream()
                .map(it -> statusChanges(it).stream().map(History::created).reduce((a, b) -> b).orElse(it.getCreated()))
                .filter(Objects::nonNull).max(Comparator.naturalOrder()).orElse(null);
        if (!open.isEmpty() && (lastMove == null || lastMove.isBefore(now.minusDays(STALLED_DAYS)))) {
            signals.add("STALLED");
        }
        LocalDateTime testSince = now.minusDays(STUCK_IN_TEST_DAYS);
        if (open.stream().anyMatch(it -> stage(status(it)).stage() == Stage.TEST
                && statusChanges(it).stream().map(History::created).reduce((a, b) -> b).map(at -> at.isBefore(testSince)).orElse(false))) {
            signals.add("STUCK_IN_TEST");
        }
        LocalDateTime growthFrom = now.minusDays(SCOPE_GROWTH_DAYS);
        if (actualStart.isBefore(growthFrom)) {
            long before = items.stream().filter(it -> it.getCreated() != null && !it.getCreated().isAfter(growthFrom)).count();
            long added = items.stream().filter(it -> it.getCreated() != null && it.getCreated().isAfter(growthFrom)).count();
            if (before > 0 && added >= Math.max(2, Math.ceil(before * 0.2))) {
                signals.add("SCOPE_GROWTH");
            }
        }
        return signals;
    }

    /** Burn-up of the unit's work items over the last {@code weeks} weeks (4-52). */
    public Mono<Burnup> burnup(String unitId, int weeks) {
        int span = Math.max(4, Math.min(52, weeks));
        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(pm -> burnup(pm.projects(), span, LocalDateTime.now()));
    }

    private Burnup burnup(Collection<String> projects, int weeks, LocalDateTime now) {
        LocalDate firstWeek = now.toLocalDate().with(DayOfWeek.MONDAY).minusWeeks(weeks - 1L);
        LocalDateTime from = firstWeek.atStartOfDay();
        // changed in the period plus still open (open since before the period and untouched in it)
        List<TaskStatus> openStatuses = Stream.of(TaskStatus.values())
                .filter(it -> taskTimelineService.phaseOf(it.getJiraName()) != Phase.DONE && !cancelled(it.getJiraName()))
                .toList();
        List<TaskEntity> items = distinctByKey(Stream.concat(
                        taskRepository.findByProjectIdInAndUpdatedAfter(projects, from).stream(),
                        taskRepository.findByProjectIdInAndStatusIn(projects, openStatuses).stream())
                .toList()).stream()
                .filter(it -> !EPIC_TYPE.equalsIgnoreCase(it.getType()) && !isSubtask(it.getType())
                        && !ReleaseTasks.isRelease(it.getType()) && !cancelled(it))
                .toList();

        record Work(LocalDateTime created, LocalDateTime doneAt, BigDecimal points) {
        }
        List<Work> work = new ArrayList<>();
        int unestimated = 0;
        for (TaskEntity item : items) {
            LocalDateTime doneAt = done(item) ? Optional.ofNullable(doneAt(item)).orElse(item.getUpdated()) : null;
            if (doneAt != null && doneAt.isBefore(from)) {
                continue;
            }
            BigDecimal points = Optional.ofNullable(item.getContent()).map(Task::estimate).filter(it -> it.signum() > 0).orElse(null);
            unestimated += points == null ? 1 : 0;
            work.add(new Work(Optional.ofNullable(item.getCreated()).orElse(from), doneAt, points == null ? BigDecimal.ZERO : points));
        }

        List<BurnupWeek> series = new ArrayList<>();
        for (int w = 0; w < weeks; w++) {
            LocalDateTime start = firstWeek.plusWeeks(w).atStartOfDay();
            LocalDateTime end = start.plusWeeks(1).isAfter(now) ? now : start.plusWeeks(1);
            List<Work> scope = work.stream().filter(it -> it.created().isBefore(end)).toList();
            List<Work> doneBy = work.stream().filter(it -> it.doneAt() != null && it.doneAt().isBefore(end)).toList();
            List<Work> closed = doneBy.stream().filter(it -> !it.doneAt().isBefore(start)).toList();
            series.add(new BurnupWeek(start.toLocalDate(), scope.size(), doneBy.size(), points(scope, Work::points),
                    points(doneBy, Work::points), closed.size(), points(closed, Work::points)));
        }
        // velocity: the last full weeks (the current one is still running)
        List<BurnupWeek> full = series.subList(Math.max(0, series.size() - 1 - VELOCITY_WEEKS), series.size() - 1);
        double velocityItems = full.isEmpty() ? 0 : full.stream().mapToInt(BurnupWeek::itemsClosed).average().orElse(0);
        BigDecimal velocityPoints = full.isEmpty() ? BigDecimal.ZERO
                : points(full, BurnupWeek::pointsClosed).divide(BigDecimal.valueOf(full.size()), 1, RoundingMode.HALF_UP);
        BurnupWeek last = series.getLast();
        return new Burnup(series, last.scopeItems(), last.doneItems(), last.scopePoints(), last.donePoints(), unestimated,
                Math.round(velocityItems * 10) / 10.0, velocityPoints);
    }

    private static <T> BigDecimal points(List<T> list, java.util.function.Function<T, BigDecimal> points) {
        return list.stream().map(points).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private String status(TaskEntity entity) {
        return Optional.ofNullable(entity.getContent()).map(Task::status)
                .orElse(entity.getStatus() == null ? null : entity.getStatus().getJiraName());
    }

    private boolean cancelled(TaskEntity entity) {
        return cancelled(status(entity));
    }

    private static boolean cancelled(String status) {
        String s = Optional.ofNullable(status).orElse("").toUpperCase(Locale.ROOT);
        return s.contains("CANCEL") || s.contains("REJECT");
    }

    private EpicDetail detail(EpicData data, LocalDateTime now, Marks marks) {
        EpicSummary summary = summary(data, now, marks);
        List<TaskEntity> children = data.children();
        List<TaskEntity> subtasks = data.subtasks();
        List<TaskEntity> defects = data.items().stream().filter(it -> isDefect(it.getType())).toList();
        List<TaskEntity> stories = children.stream().filter(it -> !isDefect(it.getType())).toList();

        LocalDate today = now.toLocalDate();
        List<Integer> perWeek = new ArrayList<>();
        for (int w = SPARKLINE_WEEKS - 1; w >= 0; w--) {
            LocalDateTime from = today.minusWeeks(w + 1L).plusDays(1).atStartOfDay();
            LocalDateTime till = today.minusWeeks(w).plusDays(1).atStartOfDay();
            perWeek.add((int) data.commits().stream()
                    .filter(c -> c.getCommitDate() != null && !c.getCommitDate().isBefore(from) && c.getCommitDate().isBefore(till))
                    .count());
        }
        int last7 = perWeek.getLast();
        BigDecimal points = sumPoints(data.items().stream().filter(it -> !isSubtask(it.getType())).toList(), false);
        BigDecimal pointsDone = sumPoints(data.items().stream().filter(it -> !isSubtask(it.getType())).toList(), true);
        int people = (int) data.items().stream().map(TaskEntity::getContent).filter(Objects::nonNull)
                .map(Task::assignee).filter(Objects::nonNull).map(Task.User::displayName).filter(Objects::nonNull)
                .distinct().count();

        Stats stats = new Stats(
                stories.size(), (int) stories.stream().filter(this::done).count(),
                subtasks.size(), (int) subtasks.stream().filter(this::done).count(),
                defects.size(), (int) defects.stream().filter(it -> !done(it)).count(),
                data.commits().size(), last7, perWeek,
                points, pointsDone, people
        );

        // children first, each followed by its sub-tasks
        Map<String, List<TaskEntity>> subsByParent = subtasks.stream().collect(Collectors.groupingBy(TaskEntity::getParentKey,
                LinkedHashMap::new, Collectors.toList()));
        List<Item> items = new ArrayList<>();
        children.stream()
                .sorted(Comparator.comparing((TaskEntity it) -> Optional.ofNullable(firstWork(it)).orElse(LocalDateTime.MAX))
                        .thenComparing(TaskEntity::getKey))
                .forEach(child -> {
                    items.add(item(child, data.commitsPerKey(), now));
                    subsByParent.getOrDefault(child.getKey(), List.of()).stream()
                            .sorted(Comparator.comparing(TaskEntity::getKey))
                            .forEach(sub -> items.add(item(sub, data.commitsPerKey(), now)));
                });

        LocalDateTime from = items.stream().flatMap(it -> it.segments().stream()).map(Segment::from).filter(Objects::nonNull)
                .min(Comparator.naturalOrder())
                .orElse(Optional.ofNullable(summary.actualStart()).orElse(now.minusDays(30)));
        LocalDateTime till = Stream.of(
                        Optional.of(now),
                        Optional.ofNullable(summary.plannedDelivery()).map(d -> d.plusDays(1).atStartOfDay()),
                        Optional.ofNullable(summary.deliveryDate()).map(d -> d.plusDays(1).atStartOfDay()))
                .flatMap(Optional::stream).max(Comparator.naturalOrder()).orElse(now);
        if (summary.plannedStart() != null && summary.plannedStart().atStartOfDay().isBefore(from)) {
            from = summary.plannedStart().atStartOfDay();
        }

        return new EpicDetail(summary, data.epic().getProjectId(), stats, from, till, items);
    }

    private Item item(TaskEntity entity, Map<String, Integer> commitsPerKey, LocalDateTime now) {
        Task task = entity.getContent();
        List<History> changes = statusChanges(entity);
        String status = changes.isEmpty() ? (task == null ? null : task.status()) : changes.getFirst().from();
        LocalDateTime cursor = Optional.ofNullable(entity.getCreated()).orElse(task == null ? null : task.created());
        List<Segment> segments = new ArrayList<>();
        Map<Phase, BigDecimal> days = new EnumMap<>(Phase.class);
        for (History change : changes) {
            addSegment(segments, days, status, cursor, change.created());
            cursor = change.created();
            status = change.to();
        }
        Phase current = taskTimelineService.phaseOf(task == null ? status : task.status());
        if (current != Phase.DONE) {
            addSegment(segments, days, status, cursor, now);
        }
        return new Item(
                entity.getKey(),
                task == null ? null : task.summary(),
                Optional.ofNullable(entity.getUrl()).orElse(task == null ? null : task.url()),
                entity.getType(),
                task == null ? null : task.status(),
                current,
                task == null || task.assignee() == null ? null : task.assignee().displayName(),
                entity.getParentKey(),
                task == null ? null : task.estimate(),
                firstWork(entity),
                current == Phase.DONE ? doneAt(entity) : null,
                days,
                segments,
                commitsPerKey.getOrDefault(entity.getKey(), 0)
        );
    }

    /** Status period as a segment; backlog and done periods are not drawn. Consecutive periods of one phase merge. */
    private void addSegment(List<Segment> segments, Map<Phase, BigDecimal> days, String status, LocalDateTime from, LocalDateTime till) {
        if (from == null || till == null || !till.isAfter(from)) {
            return;
        }
        Phase phase = taskTimelineService.phaseOf(status);
        if (phase == Phase.BACKLOG || phase == Phase.DONE) {
            return;
        }
        days.merge(phase, days(from, till), BigDecimal::add);
        if (!segments.isEmpty() && segments.getLast().phase() == phase && segments.getLast().till().equals(from)) {
            Segment last = segments.removeLast();
            segments.add(new Segment(phase, last.status(), last.from(), till));
        } else {
            segments.add(new Segment(phase, status, from, till));
        }
    }

    private List<History> statusChanges(TaskEntity entity) {
        return Optional.ofNullable(entity.getContent()).map(Task::histories).orElse(List.of()).stream()
                .filter(h -> h != null && h.created() != null && "status".equalsIgnoreCase(h.fieldType()))
                .sorted(Comparator.comparing(History::created))
                .toList();
    }

    /** First move into a working phase (coding, review, test, waiting for release). */
    private LocalDateTime firstWork(TaskEntity entity) {
        return statusChanges(entity).stream()
                .filter(h -> WORK_PHASES.contains(taskTimelineService.phaseOf(h.to())))
                .map(History::created).findFirst().orElse(null);
    }

    /** Last move into a done status. */
    private LocalDateTime doneAt(TaskEntity entity) {
        return statusChanges(entity).stream()
                .filter(h -> taskTimelineService.phaseOf(h.to()) == Phase.DONE)
                .map(History::created).reduce((a, b) -> b).orElse(null);
    }

    private boolean done(TaskEntity entity) {
        return taskTimelineService.phaseOf(status(entity)) == Phase.DONE;
    }

    private BigDecimal sumPoints(List<TaskEntity> items, boolean onlyDone) {
        return items.stream()
                .filter(it -> !onlyDone || done(it))
                .map(TaskEntity::getContent).filter(Objects::nonNull)
                .map(Task::estimate).filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private static boolean isDefect(String type) {
        String t = Optional.ofNullable(type).orElse("").toLowerCase(Locale.ROOT);
        return t.contains("bug") || t.contains("defect");
    }

    private static boolean isSubtask(String type) {
        return Optional.ofNullable(type).orElse("").toLowerCase(Locale.ROOT).replace("-", "").replace(" ", "").contains("subtask");
    }

    private static int healthOrder(Health health) {
        return switch (health) {
            case OFF_TRACK -> 0;
            case AT_RISK -> 1;
            case ON_TRACK -> 2;
            case NOT_STARTED -> 3;
            case DELIVERED_LATE -> 4;
            case DELIVERED -> 5;
        };
    }

    private static BigDecimal days(LocalDateTime from, LocalDateTime till) {
        return BigDecimal.valueOf(Math.max(0, Duration.between(from, till).toMinutes()))
                .divide(BigDecimal.valueOf(24 * 60), 1, RoundingMode.HALF_UP);
    }
}
