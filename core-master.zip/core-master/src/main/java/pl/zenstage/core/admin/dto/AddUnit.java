package pl.zenstage.core.admin.dto;

public record AddUnit(
        String name,
        String type,
        String parentUnitId
) {
}

