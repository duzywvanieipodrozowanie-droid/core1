package pl.zenstage.core.metrics.gitlab;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.mr.Approval;
import pl.zenstage.api.mr.MergeRequest;
import pl.zenstage.api.mr.MrCommit;
import pl.zenstage.core.common.MathBigDecimal;
import pl.zenstage.core.metrics.gitlab.CommitHeatmapResponse.Cell;
import pl.zenstage.core.metrics.gitlab.CommitHeatmapResponse.Committer;
import pl.zenstage.core.metrics.gitlab.CommitHeatmapResponse.GroupBy;
import pl.zenstage.core.metrics.gitlab.GitlabDetailsResponse.Attention;
import pl.zenstage.core.metrics.gitlab.GitlabDetailsResponse.AttentionKind;
import pl.zenstage.core.metrics.gitlab.GitlabDetailsResponse.Breakdown;
import pl.zenstage.core.metrics.gitlab.GitlabDetailsResponse.Developer;
import pl.zenstage.core.metrics.gitlab.GitlabDetailsResponse.MrItem;
import pl.zenstage.core.metrics.gitlab.GitlabDetailsResponse.NameCount;
import pl.zenstage.core.metrics.gitlab.GitlabDetailsResponse.ReviewEdge;
import pl.zenstage.core.metrics.gitlab.GitlabDetailsResponse.Reviewer;
import pl.zenstage.core.metrics.gitlab.GitlabDetailsResponse.SiloPair;
import pl.zenstage.core.metrics.gitlab.GitlabDetailsResponse.Summary;
import pl.zenstage.core.metrics.pr.MrFlowService;
import pl.zenstage.core.metrics.pr.MrFlowService.Flow;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationCache;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.organization.dto.Person;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.git.MergeRequestEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.MergeRequestRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Stream;

/**
 * GitLab details screen and its commit time heatmap. Read-only: everything comes from merge requests and commits
 * already imported for the projects of the unit, limited to MRs authored by the unit's members.
 */
@Service
@RequiredArgsConstructor
public class GitlabDetailsService {
    // MRs merged in the range may have been opened long before it (as in MrFlowService)
    private static final int OPENED_LOOKBACK_DAYS = 180;
    private static final Set<String> ACTIVE_STATES = Set.of("opened", "locked");
    private static final long STALE_DAYS = 3;
    private static final long WAITING_PICKUP_HOURS = 24;
    private static final int TOP_APPROVERS = 3;
    private static final int TOP_SILOS = 10;
    private static final int MAX_ATTENTION = 50;

    private final OrganizationService organizationService;
    private final OrganizationCache organizationCache;
    private final MergeRequestRepository mergeRequestRepository;
    private final CommitRepository commitRepository;
    private final MrFlowService mrFlowService;

    public Mono<GitlabDetailsResponse> details(String unitId, Interval interval) {
        Interval.Range range = interval.range(0);
        Interval.Range previous = interval.range(1);
        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(it -> {
                    Set<String> members = new HashSet<>(it.members());
                    List<MergeRequestEntity> mrs = mergeRequestRepository
                            .findByProjectIdInAndCreateDateBetween(it.projects(), previous.from().minusDays(OPENED_LOOKBACK_DAYS), range.till())
                            .stream()
                            .filter(mr -> mr.getSource() != null && mr.getSource().createdAt() != null && members.contains(mr.getAuthorId()))
                            .toList();
                    return calculate(mrs, range, previous);
                });
    }

    private GitlabDetailsResponse calculate(List<MergeRequestEntity> mrs, Interval.Range range, Interval.Range previous) {
        People people = new People(organizationCache.allPeoples());
        LocalDateTime now = LocalDateTime.now();

        List<MergeRequestEntity> merged = mergedWithin(mrs, range);
        List<MergeRequestEntity> mergedPrevious = mergedWithin(mrs, previous);
        List<Flow> mainFlows = mainFlows(merged);
        List<Flow> mainFlowsPrevious = mainFlows(mergedPrevious);

        // per MR: author, approvers (without duplicates, in approval order) and phases
        Map<MergeRequestEntity, Flow> flows = new LinkedHashMap<>();
        merged.forEach(mr -> flows.put(mr, MrFlowService.flow(mr.getSource())));

        List<Attention> attention = new ArrayList<>();
        int withoutApproval = 0;
        int selfApprovals = 0;
        Map<String, Integer> edges = new HashMap<>();
        Map<String, Map<String, Integer>> edgeModules = new HashMap<>();
        Map<String, List<BigDecimal>> reviewerHours = new HashMap<>();
        Map<String, List<MergeRequestEntity>> byAuthor = new LinkedHashMap<>();
        List<MrItem> items = new ArrayList<>();

        for (Map.Entry<MergeRequestEntity, Flow> entry : flows.entrySet()) {
            MergeRequestEntity mr = entry.getKey();
            MergeRequest src = mr.getSource();
            String author = mr.getAuthorId();
            byAuthor.computeIfAbsent(author, k -> new ArrayList<>()).add(mr);
            List<Approval> approvals = approvals(src);
            if (approvals.isEmpty()) {
                withoutApproval++;
                attention.add(attention(AttentionKind.WITHOUT_APPROVAL, mr, local(src.mergedAt()), now, people));
            }
            Set<String> seen = new HashSet<>();
            for (Approval approval : approvals) {
                String reviewer = people.key(approval.email());
                if (!seen.add(reviewer)) {
                    continue;
                }
                if (reviewer.equals(author)) {
                    selfApprovals++;
                    continue;
                }
                String edge = reviewer + "\u0000" + author;
                edges.merge(edge, 1, Integer::sum);
                edgeModules.computeIfAbsent(edge, k -> new HashMap<>()).merge(module(mr), 1, Integer::sum);
                if (approval.approvedAt() != null) {
                    reviewerHours.computeIfAbsent(reviewer, k -> new ArrayList<>())
                            .add(hours(local(src.createdAt()), local(approval.approvedAt())));
                }
            }
            Flow flow = entry.getValue();
            items.add(new MrItem(
                    mr.getMrId(), src.title(), mr.getProjectId(), mr.getModuleName(), author, people.name(author, src.authorEmail()),
                    src.state(), src.targetBranch(), local(src.createdAt()), local(src.mergedAt()),
                    flow.coding(), flow.pickup(), flow.review(), flow.merge(),
                    approvals.stream().map(Approval::email).map(people::key).distinct().map(k -> people.name(k, k)).toList(),
                    Optional.ofNullable(src.commits()).orElse(List.of()).stream().map(MrCommit::title).filter(Objects::nonNull).toList()
            ));
        }

        // open and abandoned MRs of the period
        List<MergeRequestEntity> stale = new ArrayList<>();
        for (MergeRequestEntity mr : mrs) {
            MergeRequest src = mr.getSource();
            String state = Optional.ofNullable(src.state()).orElse("").toLowerCase(Locale.ROOT);
            if (ACTIVE_STATES.contains(state) && src.mergedAt() == null) {
                LocalDateTime updated = Optional.ofNullable(local(src.updatedAt())).orElse(local(src.createdAt()));
                if (Duration.between(updated, now).toDays() >= STALE_DAYS) {
                    stale.add(mr);
                    attention.add(attention(AttentionKind.STALE, mr, updated, now, people));
                } else if (approvals(src).isEmpty() && Duration.between(local(src.createdAt()), now).toHours() >= WAITING_PICKUP_HOURS) {
                    attention.add(attention(AttentionKind.WAITING_PICKUP, mr, local(src.createdAt()), now, people));
                }
            } else if ("closed".equals(state) && src.mergedAt() == null && within(local(src.closedAt()), range)) {
                attention.add(attention(AttentionKind.ABANDONED, mr, local(src.closedAt()), now, people));
            }
        }
        attention.sort(Comparator.comparing(Attention::kind).thenComparing(Attention::days, Comparator.reverseOrder()));

        Long oldestStale = stale.stream()
                .map(mr -> Optional.ofNullable(local(mr.getSource().updatedAt())).orElse(local(mr.getSource().createdAt())))
                .map(updated -> Duration.between(updated, now).toDays())
                .max(Long::compare).orElse(null);

        Summary summary = new Summary(
                merged.size(),
                mergedPrevious.size(),
                MathBigDecimal.avg(mainFlows.stream().map(Flow::leadTime).toList(), 1),
                MathBigDecimal.avg(mainFlowsPrevious.stream().map(Flow::leadTime).toList(), 1),
                MathBigDecimal.avg(mainFlows.stream().map(Flow::pickup).toList(), 1),
                MathBigDecimal.avg(mainFlowsPrevious.stream().map(Flow::pickup).toList(), 1),
                perWeek(mainFlows.size(), range),
                perWeek(mainFlowsPrevious.size(), previous),
                withoutApproval,
                stale.size(),
                oldestStale
        );
        Breakdown breakdown = new Breakdown(
                mainFlows.size(),
                MathBigDecimal.avg(mainFlows.stream().map(Flow::coding).toList(), 1),
                MathBigDecimal.avg(mainFlows.stream().map(Flow::pickup).toList(), 1),
                MathBigDecimal.avg(mainFlows.stream().map(Flow::review).toList(), 1),
                MathBigDecimal.avg(mainFlows.stream().map(Flow::merge).toList(), 1)
        );

        List<Developer> developers = byAuthor.entrySet().stream().map(e -> {
                    String author = e.getKey();
                    List<Flow> own = e.getValue().stream().map(flows::get).toList();
                    Map<String, Integer> approvers = new HashMap<>();
                    edges.forEach((edge, count) -> {
                        String[] parts = edge.split("\u0000", 2);
                        if (parts[1].equals(author)) {
                            approvers.merge(parts[0], count, Integer::sum);
                        }
                    });
                    int ownWithoutApproval = (int) e.getValue().stream().filter(mr -> approvals(mr.getSource()).isEmpty()).count();
                    int ownSelf = (int) e.getValue().stream()
                            .filter(mr -> approvals(mr.getSource()).stream().map(Approval::email).map(people::key).anyMatch(author::equals))
                            .count();
                    return new Developer(
                            author,
                            people.name(author, e.getValue().getFirst().getSource().authorEmail()),
                            e.getValue().size(),
                            MathBigDecimal.avg(own.stream().map(Flow::coding).toList(), 1),
                            MathBigDecimal.avg(own.stream().map(Flow::pickup).toList(), 1),
                            MathBigDecimal.avg(own.stream().map(Flow::review).toList(), 1),
                            MathBigDecimal.avg(own.stream().map(Flow::merge).toList(), 1),
                            ownWithoutApproval,
                            ownSelf,
                            top(approvers, TOP_APPROVERS, people)
                    );
                })
                .sorted(Comparator.comparing(Developer::mergeRequests).reversed().thenComparing(Developer::name))
                .toList();

        int allApprovals = edges.values().stream().mapToInt(Integer::intValue).sum();
        Map<String, Integer> approvalsByReviewer = new HashMap<>();
        edges.forEach((edge, count) -> approvalsByReviewer.merge(edge.split("\u0000", 2)[0], count, Integer::sum));
        List<Reviewer> reviewers = approvalsByReviewer.entrySet().stream()
                .map(e -> new Reviewer(
                        e.getKey(),
                        people.name(e.getKey(), e.getKey()),
                        e.getValue(),
                        MathBigDecimal.avg(reviewerHours.getOrDefault(e.getKey(), List.of()), 1),
                        pct(e.getValue(), allApprovals)
                ))
                .sorted(Comparator.comparing(Reviewer::approvals).reversed().thenComparing(Reviewer::name))
                .toList();

        List<ReviewEdge> network = edges.entrySet().stream()
                .map(e -> {
                    String[] parts = e.getKey().split("\u0000", 2);
                    return new ReviewEdge(people.name(parts[0], parts[0]), people.name(parts[1], parts[1]), e.getValue());
                })
                .sorted(Comparator.comparing(ReviewEdge::count).reversed())
                .toList();

        return new GitlabDetailsResponse(
                summary, breakdown, developers, reviewers,
                attention.stream().limit(MAX_ATTENTION).toList(),
                silos(edges, edgeModules, byAuthor, people),
                network, selfApprovals, items
        );
    }

    /** Pairs approving each other's MRs, strongest first. */
    private static List<SiloPair> silos(
            Map<String, Integer> edges,
            Map<String, Map<String, Integer>> edgeModules,
            Map<String, List<MergeRequestEntity>> byAuthor,
            People people
    ) {
        List<SiloPair> pairs = new ArrayList<>();
        Set<String> done = new HashSet<>();
        edges.forEach((edge, count) -> {
            String[] parts = edge.split("\u0000", 2);
            String a = parts[0];
            String b = parts[1];
            Integer back = edges.get(b + "\u0000" + a);
            String pairKey = a.compareTo(b) < 0 ? a + "\u0000" + b : b + "\u0000" + a;
            if (back == null || !done.add(pairKey)) {
                return;
            }
            int mutual = count + back;
            int mrsOfBoth = byAuthor.getOrDefault(a, List.of()).size() + byAuthor.getOrDefault(b, List.of()).size();
            Map<String, Integer> modules = new HashMap<>(edgeModules.getOrDefault(edge, Map.of()));
            edgeModules.getOrDefault(b + "\u0000" + a, Map.of()).forEach((m, c) -> modules.merge(m, c, Integer::sum));
            pairs.add(new SiloPair(
                    people.name(a, a), people.name(b, b), mutual, pct(mutual, mrsOfBoth),
                    modules.entrySet().stream()
                            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                            .limit(3)
                            .map(m -> new NameCount(m.getKey(), m.getValue()))
                            .toList()
            ));
        });
        return pairs.stream().sorted(Comparator.comparing(SiloPair::mutual).reversed()).limit(TOP_SILOS).toList();
    }

    public Mono<CommitHeatmapResponse> commitHeatmap(String unitId, Interval interval, GroupBy groupBy, int slotHours, ZoneId zone) {
        Interval.Range range = interval.range(0);
        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(it -> {
                    Set<String> members = new HashSet<>(it.members());
                    // commit id -> (when written, author name); MR commits carry the authored date, commits of the
                    // default branch the committed date - the MR one wins for the same commit
                    Map<String, Map.Entry<Instant, String>> commits = new HashMap<>();
                    mergeRequestRepository
                            .findByProjectIdInAndCreateDateBetween(it.projects(), range.from().minusDays(OPENED_LOOKBACK_DAYS), range.till())
                            .stream()
                            .filter(mr -> mr.getSource() != null && members.contains(mr.getAuthorId()))
                            .flatMap(mr -> Optional.ofNullable(mr.getSource().commits()).orElse(List.of()).stream())
                            .filter(c -> c.id() != null && c.committedAt() != null)
                            .forEach(c -> commits.put(c.id(), Map.entry(c.committedAt(), name(c.authorName()))));
                    commitRepository
                            .findByProjectIdInAndCommitDateBetween(it.projects(), range.from().minusDays(1), range.till().plusDays(1))
                            .stream()
                            .filter(c -> c.getSource() != null && c.getSource().committedDate() != null && members.contains(c.getCommiterId()))
                            .filter(c -> c.getSource().parentIds() == null || c.getSource().parentIds().size() < 2)
                            .forEach(c -> commits.putIfAbsent(c.getCommitId(), Map.entry(
                                    c.getSource().committedDate().toInstant(), commitAuthor(c))));
                    return heatmap(commits.values(), range, groupBy, slotHours, zone);
                });
    }

    private static CommitHeatmapResponse heatmap(
            Collection<Map.Entry<Instant, String>> commits,
            Interval.Range range,
            GroupBy groupBy,
            int slotHours,
            ZoneId zone
    ) {
        ZoneId system = ZoneId.systemDefault();
        Instant from = range.from().atZone(system).toInstant();
        Instant till = range.till().atZone(system).toInstant();

        // cell key -> committer -> count
        Map<String, Map<String, Integer>> cells = new TreeMap<>();
        int total = 0;
        for (Map.Entry<Instant, String> commit : commits) {
            Instant at = commit.getKey();
            if (at.isBefore(from) || !at.isBefore(till)) {
                continue;
            }
            ZonedDateTime local = at.atZone(zone);
            String key = periodStart(local.toLocalDate(), groupBy) + "|" + local.getDayOfWeek().getValue() + "|" + local.getHour() / slotHours;
            cells.computeIfAbsent(key, k -> new HashMap<>()).merge(commit.getValue(), 1, Integer::sum);
            total++;
        }

        List<Cell> result = cells.entrySet().stream().map(e -> {
            String[] parts = e.getKey().split("\\|");
            List<Committer> committers = e.getValue().entrySet().stream()
                    .map(c -> new Committer(c.getKey(), c.getValue()))
                    .sorted(Comparator.comparing(Committer::count).reversed().thenComparing(Committer::name))
                    .toList();
            return new Cell(parts[0], Integer.parseInt(parts[1]), Integer.parseInt(parts[2]),
                    committers.stream().mapToInt(Committer::count).sum(), committers);
        }).toList();

        List<CommitHeatmapResponse.Period> periods = new ArrayList<>();
        LocalDate start = periodStart(from.atZone(zone).toLocalDate(), groupBy);
        LocalDate last = till.minusSeconds(1).atZone(zone).toLocalDate();
        while (!start.isAfter(last)) {
            LocalDate next = groupBy == GroupBy.WEEK ? start.plusWeeks(1) : start.plusMonths(1);
            periods.add(new CommitHeatmapResponse.Period(start.toString(), start, next));
            start = next;
        }

        return new CommitHeatmapResponse(
                groupBy, slotHours, zone.getId(),
                result.stream().mapToInt(Cell::count).max().orElse(0),
                total, periods, result
        );
    }

    private static LocalDate periodStart(LocalDate date, GroupBy groupBy) {
        return groupBy == GroupBy.WEEK
                ? date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                : date.withDayOfMonth(1);
    }

    private String commitAuthor(CommitEntity commit) {
        Commit src = commit.getSource();
        return name(Optional.ofNullable(src.authorName())
                .or(() -> Optional.ofNullable(commit.getCommiterId()).map(organizationCache::findPerson).map(Person::name))
                .orElse(src.authorEmail()));
    }

    private static String name(String value) {
        return value == null || value.isBlank() ? "?" : value.trim();
    }

    private List<MergeRequestEntity> mergedWithin(List<MergeRequestEntity> mrs, Interval.Range range) {
        return mrs.stream().filter(mr -> within(local(mr.getSource().mergedAt()), range)).toList();
    }

    private List<Flow> mainFlows(List<MergeRequestEntity> merged) {
        return merged.stream().filter(mrFlowService::mergedIntoMain).map(mr -> MrFlowService.flow(mr.getSource())).toList();
    }

    private static List<Approval> approvals(MergeRequest mr) {
        if (mr.approvals() != null) {
            return mr.approvals().stream().filter(a -> a.email() != null && !a.email().isBlank()).toList();
        }
        return Optional.ofNullable(mr.approverEmails()).orElse(List.of()).stream()
                .filter(e -> e != null && !e.isBlank())
                .map(e -> new Approval(e, mr.approvedAt()))
                .toList();
    }

    private static Attention attention(AttentionKind kind, MergeRequestEntity mr, LocalDateTime since, LocalDateTime now, People people) {
        MergeRequest src = mr.getSource();
        long days = since == null ? 0 : Math.max(0, ChronoUnit.DAYS.between(since, now));
        return new Attention(kind, mr.getMrId(), src.title(), mr.getProjectId(), mr.getModuleName(),
                people.name(mr.getAuthorId(), src.authorEmail()), since, days);
    }

    private static List<NameCount> top(Map<String, Integer> counts, int limit, People people) {
        return counts.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(limit)
                .map(e -> new NameCount(people.name(e.getKey(), e.getKey()), e.getValue()))
                .toList();
    }

    private static String module(MergeRequestEntity mr) {
        return Optional.ofNullable(mr.getModuleName()).filter(it -> !it.isBlank()).orElse("—");
    }

    private static boolean within(LocalDateTime value, Interval.Range range) {
        return value != null && !value.isBefore(range.from()) && value.isBefore(range.till());
    }

    private static BigDecimal perWeek(int count, Interval.Range range) {
        long days = Math.max(1, Duration.between(range.from(), range.till()).toDays());
        return BigDecimal.valueOf(count * 7L).divide(BigDecimal.valueOf(days), 1, RoundingMode.HALF_UP);
    }

    private static BigDecimal pct(int part, int total) {
        return total == 0 ? BigDecimal.ZERO
                : BigDecimal.valueOf(part * 100L).divide(BigDecimal.valueOf(total), 0, RoundingMode.HALF_UP);
    }

    private static BigDecimal hours(LocalDateTime from, LocalDateTime till) {
        if (from == null || till == null) {
            return BigDecimal.ZERO;
        }
        return BigDecimal.valueOf(Math.max(0, Duration.between(from, till).toMinutes()))
                .divide(BigDecimal.valueOf(60), 2, RoundingMode.HALF_UP);
    }

    private static LocalDateTime local(Instant instant) {
        return instant == null ? null : LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
    }

    /**
     * Approvals carry an e-mail (or a GitLab login when the e-mail is hidden): mapped to the person id when the e-mail
     * belongs to a known person, otherwise the lower-cased value itself. Authors of MRs are person ids already.
     */
    private static final class People {
        private final Map<String, Person> byId = new HashMap<>();
        private final Map<String, String> idByEmail = new HashMap<>();

        People(List<Person> people) {
            for (Person person : people) {
                byId.put(person.id(), person);
                Stream.concat(Stream.of(person.email()), Optional.ofNullable(person.commiterEmails()).orElse(List.of()).stream())
                        .filter(Objects::nonNull)
                        .map(it -> it.toLowerCase(Locale.ROOT))
                        .forEach(it -> {
                            idByEmail.putIfAbsent(it, person.id());
                            int at = it.indexOf('@');
                            if (at > 0) {
                                idByEmail.putIfAbsent(it.substring(0, at), person.id());
                            }
                        });
            }
        }

        String key(String email) {
            String value = Optional.ofNullable(email).orElse("").trim().toLowerCase(Locale.ROOT);
            return idByEmail.getOrDefault(value, value);
        }

        String name(String key, String fallback) {
            return Optional.ofNullable(key).map(byId::get).map(Person::name)
                    .orElseGet(() -> {
                        String value = Optional.ofNullable(fallback).orElse(Optional.ofNullable(key).orElse("?"));
                        int at = value.indexOf('@');
                        return at > 0 ? value.substring(0, at) : value;
                    });
        }
    }
}
