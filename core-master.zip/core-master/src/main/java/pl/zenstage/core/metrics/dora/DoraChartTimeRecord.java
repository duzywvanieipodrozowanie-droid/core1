package pl.zenstage.core.metrics.dora;

import pl.zenstage.core.common.IChartLabel;

import java.time.LocalDate;

public record DoraChartTimeRecord(
        LocalDate startDate,
        LocalDate endDate,
        int value
) implements IChartLabel {
}
