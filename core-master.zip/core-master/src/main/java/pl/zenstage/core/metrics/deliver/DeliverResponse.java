package pl.zenstage.core.metrics.deliver;

import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.Phase;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * Deliver screen: the unit's initiatives (Jira epics) with planned vs actual dates and delivery health, and the
 * details of one epic (its work items on a timeline).
 */
public final class DeliverResponse {
    private DeliverResponse() {
    }

    /**
     * ON_TRACK: no delay against the plan (or no plan) and no warning signal; AT_RISK: forecast after the due date,
     * behind the plan by more than 10 pp, the planned start passed without work or a warning signal (blocked, stalled,
     * stuck in test, scope growth); OFF_TRACK: past the due date, forecast more than 14 days after it or behind the plan
     * by more than 25 pp; DELIVERED / DELIVERED_LATE: the epic is done or all its work items are live.
     */
    public enum Health {NOT_STARTED, ON_TRACK, AT_RISK, OFF_TRACK, DELIVERED, DELIVERED_LATE}

    /** Share of an epic's work (story points, the average for items without an estimate) per stage, in percent. */
    public record Breakdown(int live, int done, int test, int dev, int todo, int blocked) {
    }

    public record EpicSummary(
            String key,
            String summary,
            String url,
            String status,
            // when the epic moved into its current status (created, if it never moved) and days since then
            LocalDateTime statusSince,
            Long statusDays,
            String assignee,
            LocalDate plannedStart,
            LocalDateTime actualStart,
            LocalDateTime firstCode,
            LocalDate plannedDelivery,
            LocalDate deliveryDate,
            boolean deliveryForecast,
            Health health,
            Long delayDays,
            String delayReason,
            int items,
            int itemsDone,
            int progressPct,
            // technical as marked on Deliver, else the Jira "technical" field (null = not set: a business epic);
            // technicalMarked = marked on Deliver; the roadmap quarter (2026-Q3, null = none)
            Boolean technical,
            boolean technicalMarked,
            String quarter,
            // the parent of the epic (an initiative in SAP): its key and, from newer imports, its name, status and assignee
            String parentKey,
            String parentSummary,
            String parentStatus,
            String parentAssignee,
            // progressPct is weighted by the phase of each work item (in test 0.7, done 0.9, live 1.0, ...);
            // expectedPct: where the plan says the epic should be today (planned start -> due, linearly; null = no plan);
            // signals: BLOCKED, STALLED, STUCK_IN_TEST, SCOPE_GROWTH
            Integer expectedPct,
            Breakdown breakdown,
            List<String> signals
    ) {
    }

    /**
     * Burn-up of the unit's work items (stories, tasks, bugs; no epics, sub-tasks, releases or cancelled ones) by week:
     * the scope (open at the start of the period plus created since) and what was done, in items and story points.
     * Velocity is the average of the last full weeks (up to 6).
     */
    public record Burnup(
            List<BurnupWeek> weeks,
            int scopeItems,
            int doneItems,
            BigDecimal scopePoints,
            BigDecimal donePoints,
            int unestimated,
            double velocityItems,
            BigDecimal velocityPoints
    ) {
    }

    /** One week of the burn-up: cumulative scope and done at its end, and what was closed during it. */
    public record BurnupWeek(
            LocalDate weekStart,
            int scopeItems,
            int doneItems,
            BigDecimal scopePoints,
            BigDecimal donePoints,
            int itemsClosed,
            BigDecimal pointsClosed
    ) {
    }

    public record EpicList(List<EpicSummary> epics) {
    }

    /** The roadmap quarter of an epic ({@code 2026-Q3}); {@code null} or blank takes it off the roadmap. */
    public record QuarterUpdate(String quarter) {
    }

    /** Technical (true) or business (false) epic; {@code null} drops the mark (the Jira field applies). */
    public record TechnicalUpdate(Boolean technical) {
    }

    public record Stats(
            int stories,
            int storiesDone,
            int subtasks,
            int subtasksDone,
            int defects,
            int defectsOpen,
            int commits,
            int commitsLast7Days,
            List<Integer> commitsPerWeek,
            BigDecimal storyPoints,
            BigDecimal storyPointsDone,
            int people
    ) {
    }

    /** One status period of a work item, mapped to a phase (same rules as Task Timeline). */
    public record Segment(Phase phase, String status, LocalDateTime from, LocalDateTime till) {
    }

    public record Item(
            String key,
            String summary,
            String url,
            String type,
            String status,
            Phase phase,
            String assignee,
            String parentKey,
            BigDecimal storyPoints,
            LocalDateTime started,
            LocalDateTime finished,
            Map<Phase, BigDecimal> phaseDays,
            List<Segment> segments,
            int commits
    ) {
    }

    public record EpicDetail(
            EpicSummary epic,
            String projectId,
            Stats stats,
            LocalDateTime timelineFrom,
            LocalDateTime timelineTill,
            List<Item> items
    ) {
    }
}
