package pl.zenstage.core.metrics.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import pl.zenstage.core.metrics.request.Interval;

public record EmployeeMetricsResponse(
        Interval interval,
        String employeeId,
        TotalMetrics total
) {
    @JsonProperty
    public AvgMetrics avg() {
        return AvgMetrics.fromTotal(interval, total());
    }
}

