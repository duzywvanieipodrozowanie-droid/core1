package pl.zenstage.core.ai;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Duration;

/**
 * Connection to an OpenAI-compatible chat completions API (OpenAI, vLLM, llama.cpp, Ollama, LM Studio...).
 * {@code base-url} is the API root including the version, e.g. {@code http://ai.local:8080/v1}.
 */
@Getter
@Component
public class AiProperties {
    private final boolean enabled;
    private final String baseUrl;
    private final String apiKey;
    private final String model;
    // false for models / servers without function calling: the unit data is then put into the prompt up front
    private final boolean toolsEnabled;
    private final int maxToolRounds;
    private final double temperature;
    private final Duration timeout;

    AiProperties(
            @Value("${zenstage.ai.enabled:false}") boolean enabled,
            @Value("${zenstage.ai.base-url:http://localhost:8080/v1}") String baseUrl,
            @Value("${zenstage.ai.api-key:}") String apiKey,
            @Value("${zenstage.ai.model:gemma-4}") String model,
            @Value("${zenstage.ai.tools-enabled:true}") boolean toolsEnabled,
            @Value("${zenstage.ai.max-tool-rounds:5}") int maxToolRounds,
            @Value("${zenstage.ai.temperature:0.2}") double temperature,
            @Value("${zenstage.ai.timeout:120s}") Duration timeout
    ) {
        this.enabled = enabled;
        this.baseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        this.apiKey = apiKey;
        this.model = model;
        this.toolsEnabled = toolsEnabled;
        this.maxToolRounds = maxToolRounds;
        this.temperature = temperature;
        this.timeout = timeout;
    }
}
