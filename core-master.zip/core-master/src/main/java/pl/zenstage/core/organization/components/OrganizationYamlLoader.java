package pl.zenstage.core.organization.components;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.core.organization.dto.Person;
import pl.zenstage.core.organization.dto.Unit;
import pl.zenstage.db.store.entity.PersonEntity;
import pl.zenstage.db.store.entity.UnitEntity;
import pl.zenstage.db.store.repository.PersonRepository;
import pl.zenstage.db.store.repository.UnitRepository;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

@Slf4j
@Service
public class OrganizationYamlLoader {
    private final UnitRepository unitRepository;
    private final PersonRepository personRepository;

    @Getter
    private Unit organization = new Unit(null, null, null, null, null, null, null);
    private List<Person> peoples = new ArrayList<>();
    @Getter
    private final Map<String, String> parentUnit = new ConcurrentHashMap<>();

    OrganizationYamlLoader(
            @Value("${zenstage.data.dir:#{null}}") String dataLocation,
            @Autowired PersonRepository personRepository,
            @Autowired UnitRepository unitRepository
    ) {
        this.personRepository = personRepository;
        this.unitRepository = unitRepository;

//        loadYaml(dataLocation);
//        syncDb();
        organizationRebuild();
    }

    public Unit organizationRebuild() {
        List<UnitEntity> all = unitRepository.findAll();
        Optional<UnitEntity> rootUnit = all.stream().filter(it -> it.getParent() == null).findAny();
        organization = rootUnit.map(it -> buildItem(all, it)).orElse(organization);
        parentUnit.clear();
        matchParentUnits(organization);
        return organization;
    }

    private Unit buildItem(List<UnitEntity> allUnits, UnitEntity unit) {
        Stream<UnitEntity> subunits = allUnits.stream().filter(it -> Objects.equals(unit.getId(),
                Optional.of(it).map(UnitEntity::getParent).map(UnitEntity::getId).orElse(null)
        ));

        return Optional.ofNullable(unit).map(it -> new Unit(
                it.getId(),
                it.getName(),
                it.getType(),
                it.getManagers(),
                it.getMembers(),
                it.getProjects(),
                subunits.map(su -> buildItem(allUnits, su)).toList()
        )).orElse(null);
    }

    public String parentUnit(String id) {
        return Optional.ofNullable(id).map(parentUnit::get).orElse(null);
    }

    private void syncDb() {
        if (organization != null) {
            List<Unit> yamlUnits = organization.unitsDeep();
            List<String> yamlIds = yamlUnits.stream().map(Unit::id).toList();
            List<UnitEntity> dbUnits = unitRepository.findAll();
//            List<String> dbIds = dbUnits.stream().map(UnitEntity::getId).toList();
            List<UnitEntity> yamlRemovedUnits = dbUnits.stream().filter(it -> !yamlIds.contains(it.getId())).toList();
//            List<Unit> yamlAddedUnits = yamlUnits.stream().filter(it -> !dbIds.contains(it.id())).toList();

            unitRepository.deleteAll(yamlRemovedUnits);
            yamlUnits.forEach(it -> {
                try {
                    unitRepository.save(new UnitEntity(
                            it.id(),
                            it.name(),
                            it.type(),
                            Optional.of(it).map(Unit::managers).orElseGet(Collections::emptySet),
                            Optional.of(it).map(Unit::members).orElseGet(Collections::emptySet),
                            Optional.of(it).map(Unit::projects).orElseGet(Collections::emptySet),
                            Optional.of(it).map(Unit::id).map(parentUnit::get).flatMap(unitRepository::findById).orElse(null)
                    ));
                } catch (Exception e) {
                    log.error("Failed to update unit: ({}) {}", it.id(), it.name(), e);
                }
            });
        }

        if (!peoples.isEmpty()) {
            List<String> yamlIds = peoples.stream().map(Person::id).toList();
            List<PersonEntity> dbUsers = personRepository.findAll();
            List<String> dbIds = dbUsers.stream().map(PersonEntity::getId).toList();
            List<PersonEntity> yamlRemovedUsers = dbUsers.stream().filter(it -> !yamlIds.contains(it.getId())).toList();
            List<Person> yamlAddedUnits = peoples.stream().filter(it -> !dbIds.contains(it.id())).toList();

            personRepository.deleteAll(yamlRemovedUsers);
            yamlAddedUnits.forEach(it -> {
                try {
                    personRepository.save(new PersonEntity(
                            it.id(),
                            it.name(),
                            it.email(),
                            it.commiterEmails(),
                            it.technical(),
                            it.admin(),
                            it.level(),
                            it.skills()
                    ));
                } catch (Exception e) {
                    log.error("Failed to update person: ({}) {}", it.id(), it.name(), e);
                }
            });
        }
    }

    private void loadYaml(String yamlLocation) {
        Path path = Optional.ofNullable(yamlLocation).map(Path::of).map(it -> it.resolve("organization"))
                .filter(it -> it.toFile().exists()).orElse(null);
        if (path == null) {
            log.warn("Organization YAML path not configured or does not exist {}", path);
            return;
        }

        ObjectMapper mapper = new YAMLMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);

        try {
            organization = mapper.readValue(
                    Files.readAllBytes(path.resolve("organization.yml")),
                    Unit.class
            );
            matchParentUnits(organization);

            Path peoplesDirPath = path.resolve("peoples");
            log.info("peoples config directory: {}", peoplesDirPath);
            peoples = Files.walk(peoplesDirPath, 10)
                    .peek(it -> log.info("Peoples config files candidate: {}", it))
                    .filter(Files::isRegularFile)
                    .filter(p -> p.toString().endsWith(".yml") || p.toString().endsWith(".yaml"))
                    .peek(it -> log.info("Found people yml file: {}", it))
                    .map(it -> ZenStageException.execQuiet(() -> Files.readAllBytes(it)))
                    .filter(Objects::nonNull)
                    .map(file -> ZenStageException.execQuiet(() -> mapper.readValue(file, new TypeReference<List<Person>>() {
                    })))
                    .filter(Objects::nonNull).flatMap(Collection::stream).toList();
        } catch (Exception e) {
            log.error("Error loading YAML files from {}", path, e);
        }
        log.info("yml loaded units: {}", organization.unitsDeep().size());
        log.info("yml loaded persons: {}", peoples.size());
    }

    private List<Unit> matchParentUnits(Unit unit) {
        if (unit == null) return Collections.emptyList();
        List<Unit> subUnits = Optional.of(unit).map(Unit::units).orElseGet(Collections::emptyList);
        subUnits.forEach(it -> parentUnit.put(it.id(), unit.id()));
        List<Unit> units = new ArrayList<>(subUnits.stream()
                .flatMap(u -> matchParentUnits(u).stream()).toList());
        units.add(unit);
        return units;
    }
}
