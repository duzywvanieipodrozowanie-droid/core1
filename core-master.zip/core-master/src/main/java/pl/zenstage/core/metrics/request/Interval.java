package pl.zenstage.core.metrics.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * The period of a metric: a preset ending today (WEEKS_1 ... MONTHS_12) or a custom one with its days,
 * {@code CUSTOM_2026-09-01_2026-09-30} (both days included). Request params and JSON take the name.
 * Formerly an enum, so it keeps {@link #values()}, {@link #name()} and {@link #valueOf(String)}.
 */
public final class Interval {
    public static final Interval WEEKS_1 = new Interval("WEEKS_1", Period.ofWeeks(1));
    public static final Interval WEEKS_2 = new Interval("WEEKS_2", Period.ofWeeks(2));
    public static final Interval WEEKS_4 = new Interval("WEEKS_4", Period.ofWeeks(4));
    public static final Interval MONTHS_1 = new Interval("MONTHS_1", Period.ofMonths(1));
    public static final Interval MONTHS_3 = new Interval("MONTHS_3", Period.ofMonths(3));
    public static final Interval MONTHS_6 = new Interval("MONTHS_6", Period.ofMonths(6));
    public static final Interval MONTHS_12 = new Interval("MONTHS_12", Period.ofYears(1));
    private static final List<Interval> PRESETS = List.of(WEEKS_1, WEEKS_2, WEEKS_4, MONTHS_1, MONTHS_3, MONTHS_6, MONTHS_12);
    private static final Pattern CUSTOM = Pattern.compile("(?i)CUSTOM_(\\d{4}-\\d{2}-\\d{2})_(\\d{4}-\\d{2}-\\d{2})");
    /** Longest custom period, the metrics read everything of the period (and of the previous one to compare). */
    static final long MAX_CUSTOM_DAYS = 3 * 366;

    private final String name;
    private final Period offset; // presets
    private final LocalDate first; // custom: first and last day
    private final LocalDate last;

    private Interval(String name, Period offset) {
        this.name = name;
        this.offset = offset;
        this.first = null;
        this.last = null;
    }

    private Interval(LocalDate first, LocalDate last) {
        this.name = "CUSTOM_" + first + "_" + last;
        this.offset = null;
        this.first = first;
        this.last = last;
    }

    public static Interval[] values() {
        return PRESETS.toArray(Interval[]::new);
    }

    /** From a preset name or {@code CUSTOM_<first day>_<last day>}; how Spring and Jackson read it. */
    @JsonCreator
    public static Interval valueOf(String value) {
        String text = Objects.toString(value, "").trim();
        for (Interval preset : PRESETS) {
            if (preset.name.equalsIgnoreCase(text)) return preset;
        }
        Matcher matcher = CUSTOM.matcher(text);
        if (matcher.matches()) {
            try {
                return custom(LocalDate.parse(matcher.group(1)), LocalDate.parse(matcher.group(2)));
            } catch (DateTimeParseException e) {
                throw new IllegalArgumentException("Invalid date in interval " + text, e);
            }
        }
        throw new IllegalArgumentException("Unknown interval " + text);
    }

    public static Interval custom(LocalDate first, LocalDate last) {
        if (first == null || last == null || last.isBefore(first)) {
            throw new IllegalArgumentException("The last day of the interval is before the first one");
        }
        if (ChronoUnit.DAYS.between(first, last) + 1 > MAX_CUSTOM_DAYS) {
            throw new IllegalArgumentException("The interval is longer than " + MAX_CUSTOM_DAYS + " days");
        }
        return new Interval(first, last);
    }

    @JsonValue
    public String name() {
        return name;
    }

    public boolean isCustom() {
        return first != null;
    }

    @Override
    public String toString() {
        return name;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof Interval other && name.equals(other.name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    private LocalDate from(LocalDate until) {
        return until.minus(offset);
    }

    /** The period ({@code offset} 0) or the one {@code offset} periods of the same length before it. */
    public Range range(int offset) {
        if (isCustom()) {
            long days = ChronoUnit.DAYS.between(first, last) + 1;
            LocalDateTime till = last.plusDays(1).atStartOfDay().minusDays(days * offset);
            return new Range(till.minusDays(days), till);
        }
        LocalDateTime till = LocalDate.now().plusDays(1).atStartOfDay();
        for (int i = 0; i < offset; i++) {
            till = this.from(till.toLocalDate()).atStartOfDay();
        }
        LocalDateTime from = this.from(till.toLocalDate()).atStartOfDay();
        return new Range(from, till);
    }

    public RangeFinder rangeFinder() {
        return new RangeFinder(this);
    }

    public static BigDecimal countWorkingDays(LocalDate startDate, LocalDate endDate) {
        if (Objects.isNull(startDate) || Objects.isNull(endDate) || startDate.isAfter(endDate)) {
            return null;
        }

        return BigDecimal.valueOf(Stream.iterate(startDate, date -> date.plusDays(1))
                .limit(ChronoUnit.DAYS.between(startDate, endDate) + 1)
                .filter(date -> date.getDayOfWeek() != DayOfWeek.SATURDAY && date.getDayOfWeek() != DayOfWeek.SUNDAY)
                .count()
        );
    }

    public record Range(LocalDateTime from, LocalDateTime till) implements Comparable<Range> {
        @Override
        public boolean equals(Object o) {
            if (o == null || getClass() != o.getClass()) return false;
            Range range = (Range) o;
            return Objects.equals(from, range.from) && Objects.equals(till, range.till);
        }

        @Override
        public int hashCode() {
            return Objects.hash(from, till);
        }

        @Override
        public int compareTo(Range o) {
            if (o == null) {
                return -1;
            }
            return Objects.compare(from, o.from, LocalDateTime::compareTo);
        }
    }

    public record RangeFinder(List<Range> ranges) {
        private RangeFinder(Interval interval) {
            this(chartRanges(interval));
        }

        public Range findRange(LocalDate commitDate) {
            return findRange(Optional.ofNullable(commitDate).map(it ->
                    it.atTime(1, 1)
            ).orElse(null));
        }

        public Range findRange(LocalDateTime commitTime) {
            Interval.Range blankInterval = new Interval.Range(LocalDateTime.now(), LocalDateTime.now());
            if (commitTime == null) {
                return blankInterval;
            }
            return ranges.stream().filter(it -> it.from().isBefore(commitTime) && it.till().isAfter(commitTime)).findFirst().orElse(blankInterval);
        }

        // AI generated ;) kiedyś to poprawię
        private static List<Range> chartRanges(Interval interval) {
            Range range = interval.range(0);
            LocalDateTime from = range.from;
            LocalDateTime till = range.till;
            Pair<Integer, Period> conf;
            if (interval == WEEKS_1) conf = new ImmutablePair<>(7, Period.ofDays(1));
            else if (interval == WEEKS_2) conf = new ImmutablePair<>(7, Period.ofDays(2));
            else if (interval == WEEKS_4) conf = new ImmutablePair<>(4, Period.ofWeeks(1));
            else if (interval == MONTHS_3) conf = new ImmutablePair<>(12, Period.ofWeeks(1));
            else if (interval == MONTHS_6) conf = new ImmutablePair<>(6, Period.ofMonths(1));
            else if (interval == MONTHS_12) conf = new ImmutablePair<>(4, Period.ofMonths(3));
            else conf = parts(from, till); // a month or a custom period

            // -------------------------------------------------
            // Budowanie listy Range
            // -------------------------------------------------
            int parts = conf.getKey();
            List<Range> result = new ArrayList<>(parts);
            LocalDateTime start = from;
            for (int i = 0; i < parts; i++) {
                // ostatni podzakres musi kończyć się dokładnie w „till”
                LocalDateTime end = (i == parts - 1) ? till : start.plus(conf.getValue());
                result.add(new Range(start, end));
                start = end;
            }
            return result;
        }

        /** Days up to 2 weeks, weeks up to ~3 months, months up to a year, quarters above; the last part ends at {@code till}. */
        private static Pair<Integer, Period> parts(LocalDateTime from, LocalDateTime till) {
            long days = Math.max(1, ChronoUnit.DAYS.between(from, till));
            if (days <= 14) return new ImmutablePair<>((int) days, Period.ofDays(1));
            if (days <= 93) return new ImmutablePair<>((int) Math.max(1, days / 7), Period.ofWeeks(1));
            if (days <= 366) return new ImmutablePair<>((int) Math.max(1, days / 30), Period.ofMonths(1));
            return new ImmutablePair<>((int) Math.max(1, days / 91), Period.ofMonths(3));
        }
    }
}
