package pl.zenstage.core.metrics;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.dora.DoraChartTimeRecord;
import pl.zenstage.core.metrics.dora.DoraService;
import pl.zenstage.core.metrics.pr.MrFlowService;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.response.ChartResponse;
import pl.zenstage.core.metrics.response.MetricValue;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequestMapping("/metrics/dora")
@RequiredArgsConstructor
public class DoraMetricsController {
    private final DoraService doraService;
    // cycle time breakdown on the DORA screen: phases of MRs merged into main/master, summing up to the lead time
    private final MrFlowService mrFlowService;

    @GetMapping("/deployment")
    public Mono<ResponseEntity<MetricValue>> deployment(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, false, doraService::development).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/ctb/coding")
    public Mono<ResponseEntity<MetricValue>> ctbCoding(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, true, mrFlowService::coding).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/ctb/pickup")
    public Mono<ResponseEntity<MetricValue>> ctbPickup(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, true, mrFlowService::pickup).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/ctb/review")
    public Mono<ResponseEntity<MetricValue>> ctbReview(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, true, mrFlowService::review).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/ctb/merge")
    public Mono<ResponseEntity<MetricValue>> ctbMerge(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, true, mrFlowService::merge).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/leadTime")
    public Mono<ResponseEntity<MetricValue>> leadTime(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, doraService::leadTime).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    /** Average hours from IN PROGRESS to LIVE of the unit's Jira tasks that went LIVE in the period. */
    @GetMapping("/inProgressToLive")
    public Mono<ResponseEntity<MetricValue>> inProgressToLive(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, true, doraService::inProgressToLive).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/failureRate")
    public Mono<ResponseEntity<MetricValue>> failureRate(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, doraService::failureRate).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/mttr")
    public Mono<ResponseEntity<MetricValue>> mttr(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return MetricValue.from(unitId, interval, doraService::mttr).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/chart/deployment")
    public Mono<ChartResponse<DoraChartTimeRecord>> chartDeployment(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return doraService.chartDeployment(unitId, interval);
    }

    @GetMapping("/chart/leadTime")
    public Mono<ChartResponse<DoraChartTimeRecord>> chartLeadTime(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval
    ) {
        return doraService.chartLeadTime(unitId, interval);
    }
}
