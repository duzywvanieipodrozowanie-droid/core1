package pl.zenstage.core.metrics.team;

import java.util.Objects;

public record ContribRecord(
        String person,
        int commits,
        int prs,
        int reviews
) implements Comparable<ContribRecord> {
    @Override
    public int compareTo(ContribRecord o) {
        if (o == null) return 0;
        return Objects.compare(person, o.person, String::compareTo);
    }
}
