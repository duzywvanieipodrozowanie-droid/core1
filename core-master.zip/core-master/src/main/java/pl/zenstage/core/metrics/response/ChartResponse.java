package pl.zenstage.core.metrics.response;

import java.util.List;

public record ChartResponse<T>(
        List<T> values,
        T sum
) {
    public ChartResponse(List<T> values) {
        this(values, null);
    }
}

