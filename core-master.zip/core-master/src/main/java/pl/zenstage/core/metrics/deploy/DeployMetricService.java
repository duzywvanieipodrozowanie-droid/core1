package pl.zenstage.core.metrics.deploy;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.release.ReleaseEntity;
import pl.zenstage.db.store.repository.ReleaseRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DeployMetricService {
    private final OrganizationService organizationService;
    private final ReleaseRepository releaseRepository;

    public Mono<BigDecimal> frequency(String unitId, Interval.Range range) {
        BigDecimal weeksInPeriod = BigDecimal.valueOf(ChronoUnit.WEEKS.between(range.from().toLocalDate(), range.till().toLocalDate()));
        if(BigDecimal.ZERO.equals(weeksInPeriod)) {
            return  Mono.just(BigDecimal.ZERO);
        }
        return organizationService.userManageAllowed(unitId).publishOn(Schedulers.boundedElastic())
                .flatMapIterable(organizationService::getUnitProjects).distinct().collectList().map(projects ->
                        releaseRepository.findAllByProjectNameInAndFinishDateBetween(projects, range.from(), range.till())
                ).map(List::size).map(it -> BigDecimal.valueOf(it).divide(weeksInPeriod, 1, RoundingMode.CEILING));
    }

    public Mono<BigDecimal> failRate(String unitId, Interval.Range range) {
        return organizationService.userManageAllowed(unitId).publishOn(Schedulers.boundedElastic())
                .flatMapIterable(organizationService::getUnitProjects).distinct().collectList().map(projects ->
                        releaseRepository.findAllByProjectNameInAndFinishDateBetween(projects, range.from(), range.till())
                ).map(releases -> {
                    Set<Long> fixed = releases.stream().map(ReleaseEntity::getParentId).collect(Collectors.toSet());
                    Set<Long> rolled = releases.stream().filter(it -> it.getRollbackDate() != null).map(ReleaseEntity::getId)
                            .filter(fixed::contains).collect(Collectors.toSet());
                    BigDecimal failedCount = BigDecimal.valueOf(fixed.size() + rolled.size());
                    if(releases.isEmpty()) {
                        return BigDecimal.ZERO;
                    }
                    return failedCount.multiply(BigDecimal.valueOf(100))
                            .divide(BigDecimal.valueOf(releases.size()), 1, RoundingMode.CEILING);
                });
    }
}
