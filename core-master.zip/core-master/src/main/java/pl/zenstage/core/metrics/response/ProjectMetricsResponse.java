package pl.zenstage.core.metrics.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import pl.zenstage.core.metrics.request.Interval;

public record ProjectMetricsResponse(
        Interval interval,
        String projectName,
        TotalMetrics total,
        TotalMetrics prevTotal
) {
    @JsonProperty
    public AvgMetrics avg() {
        return AvgMetrics.fromTotal(interval, total());
    }

    @JsonProperty
    public AvgMetrics prevAvg() {
        return AvgMetrics.fromTotal(interval, prevTotal());
    }
}
