package pl.zenstage.core.metrics.response;

public record ReleaseItem(
        String image,
        String changes
) {}
