package pl.zenstage.core.organization.components;

import lombok.RequiredArgsConstructor;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.stereotype.Service;
import pl.zenstage.core.access.AccessService;
import pl.zenstage.core.common.ZsCommons;
import pl.zenstage.core.organization.dto.ZsUserSessionDto;
import pl.zenstage.db.store.entity.PersonEntity;
import pl.zenstage.db.store.repository.PersonRepository;
import reactor.core.publisher.Mono;

import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {
    private final OrganizationService organizationService;
    private final PersonRepository personRepository;
    private final AccessService accessService;

    public Mono<ZsUserSessionDto> details() {
        return Mono.zip(
                ZsCommons.currentUser(),
                organizationService.getUserProjects()
        ).map(t -> {
            String userId = Objects.requireNonNull(t.getT1().getName());
            String userPrettyName = Optional.of(t.getT1())
                    .filter(i -> i instanceof OAuth2AuthenticationToken).map(i -> (OAuth2AuthenticationToken) i)
                    .map(OAuth2AuthenticationToken::getPrincipal).map(i -> i.getAttribute("name"))
                    .map(Object::toString).orElseGet(() -> givenName(userId));
            return new ZsUserSessionDto(
                    userPrettyName,
                    userId,
                    // live roles (Settings → Users and access), not the snapshot taken at login
                    accessService.roles(userId).stream().map(Enum::name).toList(),
                    t.getT2()
            );
        });
    }

    private String givenName(String userId) {
        return personRepository.findById(userId).map(PersonEntity::getName).orElse(userId);
    }
}

