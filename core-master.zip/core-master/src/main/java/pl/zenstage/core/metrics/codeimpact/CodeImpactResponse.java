package pl.zenstage.core.metrics.codeimpact;

import java.math.BigDecimal;
import java.util.List;

/**
 * Code ownership of the services (GitLab repositories) a unit works on: who wrote how much of each service,
 * directory and file (added lines from commit diffs), bus factor and developer knowledge criticality.
 */
public record CodeImpactResponse(
        long totalLines,
        long commitsAnalyzed,
        // commits imported before per-file data was collected; re-import with ZS_COMMITS_SINCE to include them
        long commitsWithoutFileData,
        // share of all lines written by authors who are not current members of the unit
        BigDecimal departedKnowledgePct,
        List<ServiceImpact> services,
        List<DeveloperImpact> developers
) {
    public enum Risk { HIGH, MEDIUM, LOW }

    public enum Criticality { CRITICAL, HIGH, MEDIUM, LOW, DEPARTED }

    public record AuthorShare(
            String key,
            String name,
            String personId,
            long lines,
            BigDecimal pct,
            // still a member of the unit
            boolean current,
            // matched to a person known to ZenStage (false: commit e-mail not mapped to anybody)
            boolean known
    ) {
    }

    public record AreaImpact(
            String path,
            long lines,
            int busFactor,
            int authors,
            AuthorShare topAuthor
    ) {
    }

    public record ServiceImpact(
            String project,
            String service,
            long totalLines,
            // minimal number of CURRENT members who together wrote at least half of the code; 0 = less than half is
            // known by anyone still in the unit
            int busFactor,
            Risk risk,
            BigDecimal departedPct,
            List<AuthorShare> authors,
            List<AreaImpact> directories,
            // files mostly (>= 80%) written by one person
            List<AreaImpact> knowledgeSilos
    ) {
    }

    public record DeveloperImpact(
            String key,
            String name,
            String personId,
            boolean current,
            boolean known,
            long lines,
            // share of all lines of the unit's services
            BigDecimal pct,
            // services where the person is the top author / the only current member covering half of the code
            int servicesOwned,
            int soleOwnerServices,
            int siloFiles,
            List<String> mainServices,
            Criticality criticality
    ) {
    }
}
