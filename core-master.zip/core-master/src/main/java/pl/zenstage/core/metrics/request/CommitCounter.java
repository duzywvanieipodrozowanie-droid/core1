package pl.zenstage.core.metrics.request;

import pl.zenstage.api.commit.zs.ZsSonarStats;
import pl.zenstage.api.commit.zs.ZsStats;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

public record CommitCounter(
        AtomicInteger commits,
        AtomicInteger additions,
        AtomicInteger deletions,
        AtomicInteger total,
        AtomicInteger newBugs,
        AtomicInteger newDuplicatedBlocks,
        AtomicInteger newCodeSmells,
        AtomicInteger newTechnicalDebt,
        AtomicInteger newViolations,
        AtomicInteger newReliabilityRemediationEffort,
        AtomicInteger newDevelopmentCost,
        AtomicInteger newReliabilityRating,
        AtomicInteger newSecurityRating,
        AtomicInteger newMaintainabilityRating,
        AtomicInteger newDuplicatedLinesDensity,
        AtomicInteger newSecurityReviewRating
) {
    public CommitCounter() {
        this(
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0),
                new AtomicInteger(0)
        );
    }

    public void addCommit(ZsStats stats) {
        if (stats == null) {
            return;
        }
        commits.incrementAndGet();
        additions.addAndGet(stats.additions());
        deletions.addAndGet(stats.deletions());
        total.addAndGet(stats.total());

        Optional<ZsSonarStats> extra = Optional.ofNullable(stats.sonar());
        extra.map(ZsSonarStats::newBugs).ifPresent(newBugs::addAndGet);
        extra.map(ZsSonarStats::newDuplicatedBlocks).ifPresent(newDuplicatedBlocks::addAndGet);
        extra.map(ZsSonarStats::newCodeSmells).ifPresent(newCodeSmells::addAndGet);
        extra.map(ZsSonarStats::newTechnicalDebt).ifPresent(newTechnicalDebt::addAndGet);
        extra.map(ZsSonarStats::newViolations).ifPresent(newViolations::addAndGet);
        extra.map(ZsSonarStats::newReliabilityRemediationEffort).ifPresent(newReliabilityRemediationEffort::addAndGet);
        extra.map(ZsSonarStats::newDevelopmentCost).map(it -> it.multiply(BigDecimal.TEN)).map(BigDecimal::intValue).ifPresent(newDevelopmentCost::addAndGet);
        extra.map(ZsSonarStats::newReliabilityRating).map(it -> it.multiply(BigDecimal.TEN)).map(BigDecimal::intValue).ifPresent(newReliabilityRating::addAndGet);
        extra.map(ZsSonarStats::newSecurityRating).map(it -> it.multiply(BigDecimal.TEN)).map(BigDecimal::intValue).ifPresent(newSecurityRating::addAndGet);
        extra.map(ZsSonarStats::newMaintainabilityRating).map(it -> it.multiply(BigDecimal.TEN)).map(BigDecimal::intValue).ifPresent(newMaintainabilityRating::addAndGet);
        extra.map(ZsSonarStats::newDuplicatedLinesDensity).map(it -> it.multiply(BigDecimal.TEN)).map(BigDecimal::intValue).ifPresent(newDuplicatedLinesDensity::addAndGet);
        extra.map(ZsSonarStats::newSecurityReviewRating).map(it -> it.multiply(BigDecimal.TEN)).map(BigDecimal::intValue).ifPresent(newSecurityReviewRating::addAndGet);
    }
}
