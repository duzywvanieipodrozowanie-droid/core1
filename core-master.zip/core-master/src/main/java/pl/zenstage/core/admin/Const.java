package pl.zenstage.core.admin;

public class Const {
    public static final String ADMIN = "/admin";
}
