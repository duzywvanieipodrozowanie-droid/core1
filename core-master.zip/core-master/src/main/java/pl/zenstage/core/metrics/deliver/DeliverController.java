package pl.zenstage.core.metrics.deliver;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.deliver.DeliverResponse.Burnup;
import pl.zenstage.core.metrics.deliver.DeliverResponse.EpicDetail;
import pl.zenstage.core.metrics.deliver.DeliverResponse.EpicList;
import pl.zenstage.core.metrics.deliver.DeliverResponse.QuarterUpdate;
import pl.zenstage.core.metrics.deliver.DeliverResponse.TechnicalUpdate;
import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/metrics/deliver")
@RequiredArgsConstructor
public class DeliverController {
    private final DeliverService deliverService;

    /** Open epics of the unit and the ones delivered in the period, with dates and delivery health. */
    @GetMapping("/epics")
    public Mono<ResponseEntity<EpicList>> epics(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "MONTHS_3") Interval interval
    ) {
        return deliverService.epics(unitId, interval).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    /** Burn-up of the unit's work items over the last {@code weeks} weeks (4-52): scope and done, items and story points. */
    @GetMapping("/burnup")
    public Mono<ResponseEntity<Burnup>> burnup(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "12") int weeks
    ) {
        return deliverService.burnup(unitId, weeks).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    /** One epic with its work items on a timeline; 404 when it is not an epic of the unit's projects. */
    @GetMapping("/epics/{key}")
    public Mono<ResponseEntity<EpicDetail>> epic(
            @PathVariable String key,
            @RequestParam(required = false) String unitId
    ) {
        return deliverService.epic(unitId, key).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
    }

    /** The roadmap quarter of an epic ({@code 2026-Q3}, null = off the roadmap); 404 when it is not an epic of the unit's projects. */
    @PutMapping("/epics/{key}/quarter")
    public Mono<ResponseEntity<QuarterUpdate>> quarter(
            @PathVariable String key,
            @RequestParam(required = false) String unitId,
            @RequestBody QuarterUpdate update
    ) {
        return deliverService.setQuarter(unitId, key, update == null ? null : update.quarter())
                .map(it -> ResponseEntity.ok(new QuarterUpdate(it.isEmpty() ? null : it)))
                .onErrorResume(IllegalArgumentException.class, e -> Mono.just(ResponseEntity.badRequest().build()))
                .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
    }

    /** Marks an epic technical (true) or business (false), null = the Jira field again; 404 when it is not an epic of the unit's projects. */
    @PutMapping("/epics/{key}/technical")
    public Mono<ResponseEntity<TechnicalUpdate>> technical(
            @PathVariable String key,
            @RequestParam(required = false) String unitId,
            @RequestBody TechnicalUpdate update
    ) {
        return deliverService.setTechnical(unitId, key, update == null ? null : update.technical())
                .map(it -> ResponseEntity.ok(new TechnicalUpdate(it.orElse(null))))
                .switchIfEmpty(Mono.just(ResponseEntity.notFound().build()));
    }
}
