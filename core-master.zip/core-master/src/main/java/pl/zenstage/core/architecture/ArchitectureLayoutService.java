package pl.zenstage.core.architecture;

import lombok.extern.log4j.Log4j2;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import pl.zenstage.core.common.ZenStageException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Diagrams of the Architecture (C4) screen edited by hand: positions of the boxes, colours, names, hidden elements,
 * groups and the elements and arrows added by the user, one JSON per project and diagram ({@code context},
 * {@code domains}, {@code domain:<name>}, {@code containers}, {@code components:<container>}). Shared by everyone who
 * sees the project; the scan of the importer does not touch it.
 */
@Log4j2
@Service
public class ArchitectureLayoutService {
    private static final String CREATE_TABLE = """
            CREATE TABLE IF NOT EXISTS architecture_layout (
                project_id VARCHAR(255) NOT NULL,
                diagram VARCHAR(512) NOT NULL,
                content TEXT NOT NULL,
                updated TIMESTAMP,
                updated_by VARCHAR(255),
                PRIMARY KEY (project_id, diagram)
            )""";
    private static final int MAX_DIAGRAM = 512;
    private static final int MAX_CONTENT = 1_000_000;

    private final JdbcTemplate jdbcTemplate;
    private final ObjectMapper objectMapper;

    ArchitectureLayoutService(JdbcTemplate jdbcTemplate, ObjectMapper objectMapper) {
        this.jdbcTemplate = jdbcTemplate;
        this.objectMapper = objectMapper;
    }

    @EventListener(ApplicationReadyEvent.class)
    void init() {
        jdbcTemplate.execute(CREATE_TABLE);
    }

    /** Diagram -> its saved edit (JSON object) of the project. */
    public Map<String, JsonNode> layouts(String projectId) {
        Map<String, JsonNode> result = new LinkedHashMap<>();
        jdbcTemplate.query("SELECT diagram, content FROM architecture_layout WHERE project_id = ? ORDER BY diagram",
                rs -> {
                    try {
                        result.put(rs.getString("diagram"), objectMapper.readTree(rs.getString("content")));
                    } catch (RuntimeException e) {
                        log.warn("Architecture layout {} / {} is not JSON, skipped", projectId, rs.getString("diagram"));
                    }
                }, projectId);
        return result;
    }

    /** Replaces the edit of one diagram; it has to be a JSON object. */
    public LocalDateTime save(String projectId, String diagram, String json, String user) {
        if (diagram == null || diagram.isBlank() || diagram.length() > MAX_DIAGRAM) {
            throw new ZenStageException(HttpStatus.BAD_REQUEST, "INVALID_DIAGRAM", "The diagram key is missing or too long");
        }
        if (json == null || json.length() > MAX_CONTENT) {
            throw new ZenStageException(HttpStatus.BAD_REQUEST, "INVALID_LAYOUT", "The layout is missing or bigger than 1 MB");
        }
        JsonNode layout;
        try {
            layout = objectMapper.readTree(json);
        } catch (RuntimeException e) {
            throw new ZenStageException(HttpStatus.BAD_REQUEST, "INVALID_LAYOUT", "The layout is not JSON");
        }
        if (layout == null || !layout.isObject()) {
            throw new ZenStageException(HttpStatus.BAD_REQUEST, "INVALID_LAYOUT", "The layout has to be a JSON object");
        }
        LocalDateTime now = LocalDateTime.now();
        String content = layout.toString();
        int updated = jdbcTemplate.update("UPDATE architecture_layout SET content = ?, updated = ?, updated_by = ? WHERE project_id = ? AND diagram = ?",
                content, Timestamp.valueOf(now), user, projectId, diagram);
        if (updated == 0) {
            jdbcTemplate.update("INSERT INTO architecture_layout (project_id, diagram, content, updated, updated_by) VALUES (?, ?, ?, ?, ?)",
                    projectId, diagram, content, Timestamp.valueOf(now), user);
        }
        log.info("Architecture layout of {} / {} saved by {}", projectId, diagram, user);
        return now;
    }

    /** Back to the automatic layout of the diagram. */
    public void delete(String projectId, String diagram) {
        jdbcTemplate.update("DELETE FROM architecture_layout WHERE project_id = ? AND diagram = ?", projectId, diagram);
    }
}
