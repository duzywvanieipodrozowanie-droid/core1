package pl.zenstage.core.common;

import lombok.experimental.UtilityClass;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@UtilityClass
public class ChartDateToLabelFormatter {
    private static final DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd");
    public String getLabel(LocalDate startDate, LocalDate endDate) {
        return Optional.ofNullable(startDate).map(it -> it.format(format)).orElse(null);
    }
}
