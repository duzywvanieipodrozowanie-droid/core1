package pl.zenstage.core.metrics.team;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.commit.CommitStats;
import pl.zenstage.api.commit.zs.ZsSonarStats;
import pl.zenstage.api.components.PersonService;
import pl.zenstage.api.mr.MergeRequest;
import pl.zenstage.core.common.MathBigDecimal;
import pl.zenstage.core.metrics.commits.CommitCommonsService;
import pl.zenstage.core.metrics.commits.CommitService;
import pl.zenstage.core.metrics.commits.ComplexityDelta;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.response.ChartResponse;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.organization.dto.Person;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.git.MergeRequestEntity;
import pl.zenstage.db.store.repository.SonarRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class TeamMetricsService {
    // per-person work still runs blocking queries (merge times, sonar baselines); keep it from draining the pool
    private static final int PERSON_CONCURRENCY = 4;
    private final CommitCommonsService commitCommonsService;
    private final CommitService commitService;
    private final OrganizationService organizationService;
    private final PersonService personService;
    private final SonarRepository sonarRepository;

    public Mono<BigDecimal> totalCommits(String unitId, Interval.Range range) {
        return commitService.getUnitCommitsIfAllowed(unitId, range)
                .map(commits -> BigDecimal.valueOf(commits.size()));
    }

    public Mono<ChartResponse<TotalCommitsRecord>> commitActivityChart(String unitId, Interval interval) {
        return commitService.getUnitCommitsIfAllowed(unitId, interval.rangeFinder()).map(groupedStats -> {
            List<TotalCommitsRecord> values = groupedStats.keySet().stream().map(range -> new TotalCommitsRecord(
                    range.from().toLocalDate(),
                    range.till().toLocalDate(),
                    BigDecimal.valueOf(Optional.of(range).map(groupedStats::get).orElse(Collections.emptyList()).size())
            )).toList();
            return new ChartResponse<>(values);
        });
    }

    public Mono<ChartResponse<ContribRecord>> contribChart(String unitId, Interval interval) {
        Mono<Map<String, String>> peoples = organizationService.getManagedPeoples(unitId).collectMap(Person::id, Person::name);
        return commitService.getUnitCommitsIfAllowed(unitId, interval.range(0)).zipWith(peoples).map(t -> {
            List<CommitEntity> intervalCommits = t.getT1();
            Map<String, String> commiters = t.getT2();
            Map<String, List<CommitEntity>> byCommiter = intervalCommits.stream().filter(it -> it.getCommiterId() != null)
                    .collect(Collectors.groupingBy(CommitEntity::getCommiterId));
            return new ChartResponse<>(byCommiter.entrySet().stream()
                    .map(c -> {
                        List<CommitEntity> commits = c.getValue();
                        String person = Optional.of(c.getKey()).map(commiters::get).orElse("");
                        return new ContribRecord(
                                person,
                                commits.size(),
                                Long.valueOf(CommitCommonsService.filterMergeCommits(commits).count()).intValue(),
                                0
                        );
                    })
                    .filter(it -> !it.person().isBlank())
                    .sorted().toList());
        });
    }

    public Flux<TeamPerson> getTeam(String unitId, Interval interval) {
        Flux<Person> peoples = organizationService.getManagedPeoples(unitId);
        // every member of the unit is listed, with zeros when they did nothing in the period; a manager only with activity
        Mono<Set<String>> members = organizationService.getManagedMemberIds(unitId).defaultIfEmpty(Set.of()).cache();
        // loaded once per request and shared by every person (previously re-queried per person)
        Mono<Map<String, List<ImmutablePair<CommitEntity, ZsSonarStats>>>> commitsByPerson = commitService.getCommitsByPerson(unitId, interval).cache();
        Mono<List<MergeRequestEntity>> unitMrManage = commitService.getUnitManageMrIfAllowed(unitId, interval.range(0)).cache();
        Mono<List<List<String>>> mrApprovers = unitMrManage.map(mrs -> mrs.stream().filter(Objects::nonNull)
                .map(MergeRequestEntity::getSource).filter(Objects::nonNull)
                .map(MergeRequest::approverEmails).filter(Objects::nonNull)
                .map(personService::findAllIdsByEmails).toList()
        ).cache();
        return peoples.flatMap(person -> Mono.zip(commitsByPerson, unitMrManage, mrApprovers)
                .publishOn(Schedulers.boundedElastic())
                .map(it -> {
                            List<ImmutablePair<CommitEntity, ZsSonarStats>> commits = it.getT1().getOrDefault(person.id(), List.of());
                            List<MergeRequestEntity> mrs = it.getT2();
                            List<List<String>> approvers = it.getT3();
                            Map<CommitEntity.Pk, ComplexityDelta> complexityDeltas = commitService.complexityDeltas(commits);
                            List<CommitEntity> mergeCommits = CommitCommonsService.filterMergeCommits(commits.stream().map(ImmutablePair::getKey).filter(Objects::nonNull).toList()).toList();
                            BigDecimal avgCT = MathBigDecimal.avg(mergeCommits.stream().map(commitCommonsService::mergeTime).filter(Objects::nonNull).toList(), 1);
                            Set<String> mci = mergeCommits.stream().map(CommitEntity::getCommitId).collect(Collectors.toSet());
                            long mrCreatedCount = mrs.stream().filter(Objects::nonNull)
                                    .filter(mr -> !mci.contains(mr.getCommitId()))
                                    .filter(mr -> Objects.equals(person.id(), mr.getAuthorId())).count();
                            long mrReviewedCount = approvers.stream().filter(approvals -> approvals.contains(person.id())).count();
                            return new TeamPerson(
                                    person.id(),
                                    person.name(),
                                    person.email(),
                                    new PersonMetric(
                                            BigDecimal.valueOf(commits.size()),
                                            BigDecimal.valueOf(mrCreatedCount + mergeCommits.size()), BigDecimal.valueOf(mergeCommits.size()),
                                            BigDecimal.valueOf(mrReviewedCount), avgCT,
                                            MathBigDecimal.sum(commits.stream().map(ImmutablePair::getLeft).filter(Objects::nonNull).map(CommitEntity::getSource).filter(Objects::nonNull).map(Commit::stats).filter(Objects::nonNull).map(CommitStats::additions).filter(Objects::nonNull).map(BigDecimal::new).toList()),
                                            MathBigDecimal.sum(commits.stream().map(ImmutablePair::getLeft).filter(Objects::nonNull).map(CommitEntity::getSource).filter(Objects::nonNull).map(Commit::stats).filter(Objects::nonNull).map(CommitStats::deletions).filter(Objects::nonNull).map(BigDecimal::new).toList()),
                                            BigDecimal.valueOf(commits.stream().map(ImmutablePair::getLeft).filter(Objects::nonNull).map(CommitEntity::getSource).filter(Objects::nonNull).map(Commit::project).filter(Objects::nonNull).distinct().count()),
                                            MathBigDecimal.avg(commits.stream().map(ImmutablePair::getRight).filter(Objects::nonNull).map(ZsSonarStats::newBugs).filter(Objects::nonNull).map(BigDecimal::new).toList(), 1),
                                            MathBigDecimal.avg(commits.stream().map(ImmutablePair::getRight).filter(Objects::nonNull).map(ZsSonarStats::newViolations).filter(Objects::nonNull).map(BigDecimal::new).toList(), 1),
                                            MathBigDecimal.avg(commits.stream().map(ImmutablePair::getRight).filter(Objects::nonNull).map(ZsSonarStats::newCodeSmells).filter(Objects::nonNull).map(BigDecimal::new).toList(), 1),
                                            MathBigDecimal.avg(commits.stream().map(ImmutablePair::getRight).filter(Objects::nonNull).map(ZsSonarStats::newCoverage).filter(Objects::nonNull).toList(), 1),
                                            MathBigDecimal.avg(commits.stream().map(ImmutablePair::getRight).filter(Objects::nonNull).map(ZsSonarStats::newDuplicatedBlocks).filter(Objects::nonNull).map(BigDecimal::new).toList(), 1),
                                            MathBigDecimal.avg(complexityDeltas.values().stream().map(ComplexityDelta::complexity).filter(Objects::nonNull).map(BigDecimal::new).toList(), 1),
                                            MathBigDecimal.avg(complexityDeltas.values().stream().map(ComplexityDelta::cognitiveComplexity).filter(Objects::nonNull).map(BigDecimal::new).toList(), 1)
                                    )
                            );
                        }
                ), PERSON_CONCURRENCY).filterWhen(it -> members.map(ids -> ids.contains(it.id())
                || BigDecimal.ZERO.compareTo(it.metric().commits()) != 0
                || BigDecimal.ZERO.compareTo(it.metric().prCreated()) != 0
                || BigDecimal.ZERO.compareTo(it.metric().reviews()) != 0)
        ).sort();
    }

    public Mono<TeamHealth> health(String unitId, Interval interval) {
        Random random = new Random();
        return Mono.just(new TeamHealth(
                BigDecimal.valueOf(random.nextInt(50) + 50),
                BigDecimal.valueOf(random.nextInt(50) + 50),
                BigDecimal.valueOf(random.nextInt(50) + 50),
                BigDecimal.valueOf(random.nextInt(50) + 50)
        ));
    }
}
