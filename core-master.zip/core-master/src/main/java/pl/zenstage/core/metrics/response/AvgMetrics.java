package pl.zenstage.core.metrics.response;

import pl.zenstage.core.metrics.request.Interval;

import java.math.BigDecimal;
import java.math.RoundingMode;

public record AvgMetrics(
        BigDecimal commitPerDay,
        BigDecimal additions,
        BigDecimal deletions,
        BigDecimal total,
        BigDecimal newBugs,
        BigDecimal newDuplicatedBlocks,
        BigDecimal newCodeSmells,
        BigDecimal newTechnicalDebt,
        BigDecimal newViolations,
        BigDecimal newReliabilityRemediationEffort,
        BigDecimal newDevelopmentCost,
        BigDecimal newReliabilityRating,
        BigDecimal newSecurityRating,
        BigDecimal newMaintainabilityRating,
        BigDecimal newDuplicatedLinesDensity,
        BigDecimal newSecurityReviewRating
) {
    public static AvgMetrics fromTotal(Interval interval, TotalMetrics total) {
        Interval.Range range = interval.range(0);
        BigDecimal workingDays = Interval.countWorkingDays(range.from().toLocalDate(), range.till().toLocalDate());
        if (workingDays == null || BigDecimal.ZERO.equals(workingDays)) {
            return null;
        }

        return new AvgMetrics(
                BigDecimal.valueOf(total.numberOfCommits()).divide(workingDays, 2, RoundingMode.HALF_UP),
                BigDecimal.valueOf(total.additions()).divide(workingDays, 2, RoundingMode.HALF_UP),
                BigDecimal.valueOf(total.deletions()).divide(workingDays, 2, RoundingMode.HALF_UP),
                BigDecimal.valueOf(total.total()).divide(workingDays, 2, RoundingMode.HALF_UP),
                BigDecimal.valueOf(total.newBugs()).divide(workingDays, 2, RoundingMode.HALF_UP),
                BigDecimal.valueOf(total.newDuplicatedBlocks()).divide(workingDays, 2, RoundingMode.HALF_UP),
                BigDecimal.valueOf(total.newCodeSmells()).divide(workingDays, 2, RoundingMode.HALF_UP),
                BigDecimal.valueOf(total.newTechnicalDebt()).divide(workingDays, 2, RoundingMode.HALF_UP),
                BigDecimal.valueOf(total.newViolations()).divide(workingDays, 2, RoundingMode.HALF_UP),
                BigDecimal.valueOf(total.newReliabilityRemediationEffort()).divide(workingDays, 2, RoundingMode.HALF_UP),
                total.newDevelopmentCost().divide(workingDays, 2, RoundingMode.HALF_UP),
                total.newReliabilityRating().divide(workingDays, 2, RoundingMode.HALF_UP),
                total.newSecurityRating().divide(workingDays, 2, RoundingMode.HALF_UP),
                total.newMaintainabilityRating().divide(workingDays, 2, RoundingMode.HALF_UP),
                total.newDuplicatedLinesDensity().divide(workingDays, 2, RoundingMode.HALF_UP),
                total.newSecurityReviewRating().divide(workingDays, 2, RoundingMode.HALF_UP)
        );
    }
}
