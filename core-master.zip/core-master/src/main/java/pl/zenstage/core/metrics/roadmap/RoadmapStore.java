package pl.zenstage.core.metrics.roadmap;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import pl.zenstage.db.store.entity.UserConfigEntity;
import pl.zenstage.db.store.repository.UserConfigRepository;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * The quarter of the roadmap an epic is planned for (set on the Deliver screen), e.g. {@code PROJ-12 -> 2026-Q3}, and
 * the epics marked technical or business there (over the Jira "technical" field); kept as rows of user_config, as the
 * page roles of Users and access.
 */
@Component
@RequiredArgsConstructor
public class RoadmapStore {
    static final String CONFIG_KEY = "zenstage:roadmap";
    static final String TECHNICAL_KEY = "zenstage:roadmap-technical";
    public static final Pattern QUARTER = Pattern.compile("\\d{4}-Q[1-4]");

    private final UserConfigRepository userConfigRepository;

    /** Epic key -> quarter ({@code 2026-Q3}). */
    public Map<String, String> quarters() {
        Map<String, Object> stored = userConfigRepository.findById(CONFIG_KEY).map(UserConfigEntity::getConfig).orElseGet(Collections::emptyMap);
        Map<String, String> result = new LinkedHashMap<>();
        stored.forEach((key, value) -> {
            String quarter = Objects.toString(value, null);
            if (quarter != null && QUARTER.matcher(quarter).matches()) result.put(key, quarter);
        });
        return result;
    }

    /** {@code null} or a blank quarter takes the epic off the roadmap. */
    public synchronized void set(String epicKey, String quarter) {
        Map<String, Object> stored = new LinkedHashMap<>(quarters());
        if (quarter == null || quarter.isBlank()) {
            stored.remove(epicKey);
        } else {
            stored.put(epicKey, quarter);
        }
        userConfigRepository.save(new UserConfigEntity(CONFIG_KEY, stored));
    }

    /** Epic key -> technical (true) or business (false), as marked on the Deliver screen. */
    public Map<String, Boolean> technical() {
        Map<String, Object> stored = userConfigRepository.findById(TECHNICAL_KEY).map(UserConfigEntity::getConfig).orElseGet(Collections::emptyMap);
        Map<String, Boolean> result = new LinkedHashMap<>();
        stored.forEach((key, value) -> {
            if (value instanceof Boolean flag) result.put(key, flag);
            else if (value != null) result.put(key, Boolean.parseBoolean(value.toString()));
        });
        return result;
    }

    /** {@code null} drops the mark, the Jira "technical" field applies again. */
    public synchronized void setTechnical(String epicKey, Boolean technical) {
        Map<String, Object> stored = new LinkedHashMap<>(technical());
        if (technical == null) {
            stored.remove(epicKey);
        } else {
            stored.put(epicKey, technical);
        }
        userConfigRepository.save(new UserConfigEntity(TECHNICAL_KEY, stored));
    }
}
