package pl.zenstage.core.investments;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.response.ChartResponse;
import pl.zenstage.core.metrics.response.InvestmentResponse;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequestMapping("/investment")
@RequiredArgsConstructor
public class InvestmentController {

    private final InvestmentService investmentService;

    @GetMapping("/total")
    public Mono<ResponseEntity<InvestmentResponse>> getTotal(
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval,
            @RequestParam(required = false, name = "unitId") String unitId
    ) {
        return investmentService.total(unitId, interval.range(0)).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }

    @GetMapping("/chart/total")
    public Mono<ChartResponse<List<Investment>>> getChart(
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval,
            @RequestParam(required = false, name = "unitId") String unitId
    ) {
        return investmentService.chartTotal(unitId, interval);
    }

    @GetMapping("/teams")
    public Mono<ResponseEntity<List<InvestmentTeam>>> geTeams(
            @RequestParam(required = false, defaultValue = "WEEKS_1") Interval interval,
            @RequestParam(required = false, name = "unitId") String unitId
    ) {
        return InvestmentValue.current(unitId, interval, investmentService::teams).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }
}
