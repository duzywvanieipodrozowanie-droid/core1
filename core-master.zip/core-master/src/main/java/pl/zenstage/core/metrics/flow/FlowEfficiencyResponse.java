package pl.zenstage.core.metrics.flow;

import java.math.BigDecimal;
import java.util.List;

/**
 * Flow efficiency of the unit's Jira work items finished (gone LIVE) in the period: how much of the time between the
 * first in-progress status and LIVE was spent in active statuses vs waiting ones. Durations are in days.
 * Only items with a Fix Version count; {@code itemsWithoutFixVersion} are the ones gone LIVE without it (left out).
 */
public record FlowEfficiencyResponse(
        int items,
        int itemsWithoutFixVersion,
        BigDecimal avgEfficiencyPct,
        BigDecimal activeDays,
        BigDecimal waitingDays,
        List<Bucket> histogram,
        List<StatusShare> statuses,
        String bottleneck,
        List<CurrentStatus> current,
        List<ItemEfficiency> slowest
) {
    /** Work items with flow efficiency in [from, till) percent (the last bucket includes 100). */
    public record Bucket(int from, int till, int count) {
    }

    /**
     * Time spent in one status by the finished work items: share of all their time, average per item that passed
     * through it, number of such items.
     */
    public record StatusShare(String status, boolean active, BigDecimal days, BigDecimal sharePct, BigDecimal avgDays, int items) {
    }

    /**
     * Work items sitting in a status right now (in progress, or DONE and waiting for LIVE) with their average wait there;
     * DONE is split by {@code fixVersion} (with / without a Fix Version), other statuses have it null.
     */
    public record CurrentStatus(String status, boolean active, Boolean fixVersion, int items, BigDecimal avgDaysInStatus) {
    }

    /** A finished work item with the most waiting time. */
    public record ItemEfficiency(
            String key,
            String summary,
            String url,
            String type,
            BigDecimal efficiencyPct,
            BigDecimal totalDays,
            BigDecimal waitingDays,
            String longestWaitStatus,
            BigDecimal longestWaitDays
    ) {
    }
}
