package pl.zenstage.core.metrics.gitlab;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * GitLab details screen: merge request activity of the unit's members in the selected period, all times in hours.
 */
public record GitlabDetailsResponse(
        Summary summary,
        Breakdown breakdown,
        List<Developer> developers,
        List<Reviewer> reviewers,
        List<Attention> attention,
        List<SiloPair> silos,
        List<ReviewEdge> reviewNetwork,
        int selfApprovals,
        List<MrItem> mergeRequests
) {
    /** Headline numbers of the period and of the previous period of the same length. */
    public record Summary(
            int merged,
            int mergedPrevious,
            BigDecimal leadTime,
            BigDecimal leadTimePrevious,
            BigDecimal pickup,
            BigDecimal pickupPrevious,
            BigDecimal mainMergesPerWeek,
            BigDecimal mainMergesPerWeekPrevious,
            int withoutApproval,
            int stale,
            Long oldestStaleDays
    ) {
    }

    /** Average phases of MRs merged into main/master, the same numbers as PR Cycle Time Breakdown on DORA. */
    public record Breakdown(int mergeRequests, BigDecimal coding, BigDecimal pickup, BigDecimal review, BigDecimal merge) {
    }

    public record Developer(
            String key,
            String name,
            int mergeRequests,
            BigDecimal coding,
            BigDecimal pickup,
            BigDecimal review,
            BigDecimal merge,
            int withoutApproval,
            int selfApprovals,
            List<NameCount> topApprovers
    ) {
    }

    public record Reviewer(String key, String name, int approvals, BigDecimal avgHoursToApprove, BigDecimal sharePct) {
    }

    public enum AttentionKind {WITHOUT_APPROVAL, STALE, WAITING_PICKUP, ABANDONED}

    public record Attention(
            AttentionKind kind,
            String mrId,
            String title,
            String project,
            String module,
            String authorName,
            LocalDateTime since,
            long days
    ) {
    }

    /** Two developers approving each other's MRs; sharePct = mutual approvals / all MRs of both. */
    public record SiloPair(String a, String b, int mutual, BigDecimal sharePct, List<NameCount> modules) {
    }

    public record ReviewEdge(String reviewer, String author, int count) {
    }

    public record NameCount(String name, int count) {
    }

    public record MrItem(
            String mrId,
            String title,
            String project,
            String module,
            String authorKey,
            String authorName,
            String state,
            String targetBranch,
            LocalDateTime createdAt,
            LocalDateTime mergedAt,
            BigDecimal coding,
            BigDecimal pickup,
            BigDecimal review,
            BigDecimal merge,
            List<String> approvers,
            List<String> commitTitles
    ) {
    }
}
