package pl.zenstage.core.ai;

import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.db.store.entity.UserConfigEntity;
import pl.zenstage.db.store.repository.UserConfigRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.net.URI;
import java.time.Duration;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * AI agent settings edited in the GUI. Stored as one record of the {@code user_config} table under a reserved key
 * (no user login contains a colon), so no schema change is needed; values not set there fall back to
 * {@link AiProperties}. Secrets are never returned to the GUI, only masked.
 */
@Log4j2
@Service
public class AiSettingsService {
    static final String CONFIG_KEY = "zenstage:ai-agent";
    private static final String MASK = "********";

    private final AiProperties defaults;
    private final UserConfigRepository repository;
    private volatile AiSettings current;

    /** Settings as sent by the GUI; a null secret keeps the stored one, an empty one removes it. */
    public record Form(Boolean enabled, String baseUrl, String apiKey, String model, Boolean toolsEnabled,
                       Double temperature, Integer timeoutSeconds, Integer maxToolRounds,
                       Boolean proxyEnabled, String proxyHost, Integer proxyPort, String proxyUsername,
                       String proxyPassword, String nonProxyHosts, String caCertificates, Boolean tlsSkipVerify) {
    }

    /** Settings for the GUI, with secrets masked. */
    public record View(boolean enabled, String baseUrl, boolean apiKeySet, String apiKeyMasked, String model,
                       boolean toolsEnabled, double temperature, long timeoutSeconds, int maxToolRounds,
                       boolean proxyEnabled, String proxyHost, Integer proxyPort, String proxyUsername,
                       boolean proxyPasswordSet, String nonProxyHosts, String caCertificates, List<String> caSubjects,
                       boolean tlsSkipVerify) {
    }

    AiSettingsService(AiProperties defaults, UserConfigRepository repository) {
        this.defaults = defaults;
        this.repository = repository;
        this.current = load();
    }

    public AiSettings current() {
        return current;
    }

    public View view() {
        AiSettings s = current;
        AiSettings.Proxy p = s.proxy();
        return new View(s.enabled(), s.baseUrl(), !isBlank(s.apiKey()), mask(s.apiKey()), s.model(), s.toolsEnabled(),
                s.temperature(), s.timeout().toSeconds(), s.maxToolRounds(),
                p.enabled(), p.host(), p.port(), p.username(), !isBlank(p.password()), p.nonProxyHosts(),
                s.tls().caCertificates(), subjects(s.tls().caCertificates()), s.tls().skipVerify());
    }

    /** The current settings with the form applied, without saving (e.g. to test a connection before saving). */
    public AiSettings preview(Form form) {
        return merge(current, form);
    }

    public Mono<View> save(Form form) {
        AiSettings settings = merge(current, form);
        return Mono.fromCallable(() -> {
                    repository.save(new UserConfigEntity(CONFIG_KEY, toMap(settings)));
                    current = settings;
                    log.info("AI agent settings saved: enabled={}, url={}, model={}, proxy={}, caCertificates={}, tlsSkipVerify={}",
                            settings.enabled(), settings.baseUrl(), settings.model(),
                            settings.proxy().active() ? settings.proxy().host() + ":" + settings.proxy().port() : "none",
                            subjects(settings.tls().caCertificates()).size(), settings.tls().skipVerify());
                    return view();
                })
                .subscribeOn(Schedulers.boundedElastic());
    }

    private AiSettings load() {
        AiSettings base = new AiSettings(defaults.isEnabled(), defaults.getBaseUrl(), defaults.getApiKey(), defaults.getModel(),
                defaults.isToolsEnabled(), defaults.getMaxToolRounds(), defaults.getTemperature(), defaults.getTimeout(),
                AiSettings.Proxy.NONE, AiSettings.Tls.NONE);
        try {
            Map<String, Object> stored = repository.findById(CONFIG_KEY).map(UserConfigEntity::getConfig).orElseGet(Collections::emptyMap);
            return stored.isEmpty() ? base : fromMap(base, stored);
        } catch (RuntimeException e) {
            log.warn("AI agent settings not loaded, using defaults: {}", e.getMessage());
            return base;
        }
    }

    private static AiSettings merge(AiSettings s, Form f) {
        AiSettings.Proxy p = s.proxy();
        String baseUrl = Optional.ofNullable(f.baseUrl()).map(String::trim).map(AiSettingsService::trimSlash).orElse(s.baseUrl());
        validateUrl(baseUrl);
        Integer timeout = f.timeoutSeconds();
        Integer rounds = f.maxToolRounds();
        Integer proxyPort = Optional.ofNullable(f.proxyPort()).orElse(p.port());
        if (proxyPort != null && (proxyPort < 0 || proxyPort > 65535)) {
            throw new ZenStageException(HttpStatus.BAD_REQUEST, "AI_PROXY_PORT", "Proxy port must be between 1 and 65535");
        }
        // an empty value removes the certificates
        String caCertificates = f.caCertificates() == null ? s.tls().caCertificates() : f.caCertificates().isBlank() ? null : f.caCertificates().trim();
        if (caCertificates != null) {
            try {
                OpenAiClient.certificates(caCertificates);
            } catch (IllegalArgumentException e) {
                throw new ZenStageException(HttpStatus.BAD_REQUEST, "AI_CA_CERT", "Invalid CA certificate: " + e.getMessage());
            }
        }
        return new AiSettings(
                Optional.ofNullable(f.enabled()).orElse(s.enabled()),
                baseUrl,
                secret(f.apiKey(), s.apiKey()),
                Optional.ofNullable(f.model()).map(String::trim).filter(it -> !it.isEmpty()).orElse(s.model()),
                Optional.ofNullable(f.toolsEnabled()).orElse(s.toolsEnabled()),
                rounds == null ? s.maxToolRounds() : Math.clamp(rounds, 1, 10),
                f.temperature() == null ? s.temperature() : Math.clamp(f.temperature(), 0.0, 2.0),
                timeout == null ? s.timeout() : Duration.ofSeconds(Math.clamp(timeout, 5, 600)),
                new AiSettings.Proxy(
                        Optional.ofNullable(f.proxyEnabled()).orElse(p.enabled()),
                        Optional.ofNullable(f.proxyHost()).map(String::trim).orElse(p.host()),
                        proxyPort,
                        Optional.ofNullable(f.proxyUsername()).map(String::trim).orElse(p.username()),
                        secret(f.proxyPassword(), p.password()),
                        Optional.ofNullable(f.nonProxyHosts()).map(String::trim).orElse(p.nonProxyHosts())
                ),
                new AiSettings.Tls(caCertificates, Optional.ofNullable(f.tlsSkipVerify()).orElse(s.tls().skipVerify()))
        );
    }

    private static Map<String, Object> toMap(AiSettings s) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("enabled", s.enabled());
        map.put("baseUrl", s.baseUrl());
        map.put("apiKey", s.apiKey());
        map.put("model", s.model());
        map.put("toolsEnabled", s.toolsEnabled());
        map.put("maxToolRounds", s.maxToolRounds());
        map.put("temperature", s.temperature());
        map.put("timeoutSeconds", s.timeout().toSeconds());
        map.put("proxyEnabled", s.proxy().enabled());
        map.put("proxyHost", s.proxy().host());
        map.put("proxyPort", s.proxy().port());
        map.put("proxyUsername", s.proxy().username());
        map.put("proxyPassword", s.proxy().password());
        map.put("nonProxyHosts", s.proxy().nonProxyHosts());
        map.put("caCertificates", s.tls().caCertificates());
        map.put("tlsSkipVerify", s.tls().skipVerify());
        return map;
    }

    private static AiSettings fromMap(AiSettings base, Map<String, Object> m) {
        return new AiSettings(
                bool(m, "enabled", base.enabled()),
                str(m, "baseUrl", base.baseUrl()),
                str(m, "apiKey", base.apiKey()),
                str(m, "model", base.model()),
                bool(m, "toolsEnabled", base.toolsEnabled()),
                Optional.ofNullable(num(m, "maxToolRounds")).map(Number::intValue).orElse(base.maxToolRounds()),
                Optional.ofNullable(num(m, "temperature")).map(Number::doubleValue).orElse(base.temperature()),
                Optional.ofNullable(num(m, "timeoutSeconds")).map(it -> Duration.ofSeconds(it.longValue())).orElse(base.timeout()),
                new AiSettings.Proxy(
                        bool(m, "proxyEnabled", false),
                        str(m, "proxyHost", null),
                        Optional.ofNullable(num(m, "proxyPort")).map(Number::intValue).orElse(null),
                        str(m, "proxyUsername", null),
                        str(m, "proxyPassword", null),
                        str(m, "nonProxyHosts", null)
                ),
                new AiSettings.Tls(str(m, "caCertificates", null), bool(m, "tlsSkipVerify", false))
        );
    }

    private static void validateUrl(String url) {
        try {
            URI uri = URI.create(url);
            if (!("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) || uri.getHost() == null) {
                throw new IllegalArgumentException();
            }
        } catch (IllegalArgumentException e) {
            throw new ZenStageException(HttpStatus.BAD_REQUEST, "AI_URL", "Invalid model URL: " + url);
        }
    }

    /** Subjects of the certificates, for the GUI; stored PEM was validated on save. */
    private static List<String> subjects(String pem) {
        if (isBlank(pem)) return List.of();
        try {
            return OpenAiClient.certificates(pem).stream().map(it -> it.getSubjectX500Principal().getName()).toList();
        } catch (IllegalArgumentException e) {
            return List.of();
        }
    }

    private static String secret(String value, String stored) {
        if (value == null || MASK.equals(value)) return stored;
        return value.isBlank() ? null : value.trim();
    }

    private static String mask(String secret) {
        if (isBlank(secret)) return null;
        return secret.length() <= 8 ? MASK : MASK + secret.substring(secret.length() - 4);
    }

    private static String trimSlash(String url) {
        return url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
    }

    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    private static boolean bool(Map<String, Object> m, String key, boolean fallback) {
        Object value = m.get(key);
        return value instanceof Boolean b ? b : value instanceof String s ? Boolean.parseBoolean(s) : fallback;
    }

    private static String str(Map<String, Object> m, String key, String fallback) {
        Object value = m.get(key);
        return value == null ? fallback : value.toString();
    }

    private static Number num(Map<String, Object> m, String key) {
        Object value = m.get(key);
        if (value instanceof Number n) return n;
        if (value instanceof String s && !s.isBlank()) {
            try {
                return Double.valueOf(s);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }
}
