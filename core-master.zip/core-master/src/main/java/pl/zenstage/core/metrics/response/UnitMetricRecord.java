package pl.zenstage.core.metrics.response;

import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;

public interface UnitMetricRecord {
    Mono<BigDecimal> match(String unitId, Interval.Range range);
}
