package pl.zenstage.core.metrics.team;

import java.util.Comparator;
import java.util.Objects;

public record TeamPerson(
        String id,
        String name,
        String email,
        PersonMetric metric
) implements Comparable<TeamPerson> {
    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        TeamPerson personDto = (TeamPerson) o;
        return Objects.equals(id, personDto.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public int compareTo(TeamPerson o) {
        if (this.equals(o)) return 0;
        if (o == null) return -1;
        // members without activity are listed too, a person may come without a name
        return Objects.compare(name, o.name, Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER));
    }
}
