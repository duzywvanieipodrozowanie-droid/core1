package pl.zenstage.core.ai;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.core.common.ZsCommons;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationCache;
import pl.zenstage.core.organization.dto.Person;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

/**
 * Chat with the LLM over the application data: the model answers from the results of {@link AiTools} it calls
 * (OpenAI function calling), in a loop of at most {@code zenstage.ai.max-tool-rounds} rounds.
 */
@Log4j2
@Service
@RequiredArgsConstructor
public class AiAssistantService {
    private static final int MAX_HISTORY = 12;
    private static final int MAX_MESSAGE_CHARS = 4_000;
    private static final Pattern BRIEFING_QUESTION = Pattern.compile("(?iu)pocz[aą]t(ek|ku) dnia|start of (the )?day|daily briefing|briefing");
    private static final String BRIEFING = """
            START-OF-DAY BRIEFING - answer with these sections, each short, most important first, skip a section only when its data is empty:
            1. Epics: overdue (delayDays > 0, DELIVERED_LATE) or AT_RISK - key, name, delay in days, reason, progress.
            2. Stuck work: items longest in one status (over 5 days) - key, status, assignee, days.
            3. Production defects: number open (and all defects), the oldest / highest priority ones with key, assignee, days open.
            4. Team quality and flow: PR cycle time, throughput, deployments, build failures, change failure rate vs the organization average;
               review load and Sonar quality of new code from the per-developer data.
            5. What to improve: 2-4 concrete actions for today / this week.
            6. Who to talk to 1:1 and why: people with many stale items, overload (many open items), long cycle time, no reviews or
               quality issues - with the data behind it, phrased as support, not blame. Never more than 4 people.
            """;
    private static final Pattern JIRA_QUESTION = Pattern.compile(
            "(?iu)jir|epik|epic|inicjatyw|initiative|zadani|task|story|stori|bug|błęd|ticket|status|ryzyk|risk|opóźni|delay|termin|deadline"
                    + "|blok|block|stoi|stoją|utknęł|stuck|stale|wip|w toku|in progress|backlog|sprint|dowiez|dowiezi|deliver");
    // a release compared with an environment: "czy release jest na becie", "które obrazy różnią się od taska release"
    private static final Pattern ENVIRONMENT_QUESTION = Pattern.compile("(?iu)\\bbet[aęyi]|\\bbecie|środowisk|srodowisk|environment|\\benv\\b|obraz|image|\\btag");
    private static final Pattern RELEASE_QUESTION = Pattern.compile(
            "(?iu)releas|relis|wydani|wdroż|wdroz|wdrażan|deploy|mikroserwis|microservice|fix version|wersj");

    private final AiSettingsService settingsService;
    private final OpenAiClient client;
    private final AiTools tools;
    private final ObjectMapper objectMapper;
    private final OrganizationCache organizationCache;

    public record ChatMessage(String role, String content) {
    }

    public record ChatRequest(List<ChatMessage> messages, String unitId, String interval, String lang) {
    }

    public record ChatResponse(String answer, List<String> toolsUsed) {
    }

    public record Status(boolean enabled, String model) {
    }

    public Status status() {
        AiSettings settings = settingsService.current();
        return new Status(settings.enabled(), settings.enabled() ? settings.model() : null);
    }

    public Mono<ChatResponse> chat(ChatRequest request) {
        AiSettings settings = settingsService.current();
        if (!settings.enabled()) {
            return Mono.error(new ZenStageException(HttpStatus.SERVICE_UNAVAILABLE, "AI_DISABLED", "AI assistant is not enabled"));
        }
        List<ChatMessage> history = Optional.ofNullable(request.messages()).orElse(List.of()).stream()
                .filter(it -> it != null && it.content() != null && !it.content().isBlank())
                .filter(it -> "user".equals(it.role()) || "assistant".equals(it.role()))
                .toList();
        if (history.isEmpty() || !"user".equals(history.getLast().role())) {
            return Mono.error(new ZenStageException(HttpStatus.BAD_REQUEST, "AI_NO_QUESTION", "The last message must be the user's question"));
        }
        AiTools.Context ctx = new AiTools.Context(blankToNull(request.unitId()), interval(request.interval()));
        return ZsCommons.currentUserName().flatMap(user -> {
            String base = systemPrompt(user, ctx, request.lang());
            String question = history.getLast().content();
            // the data goes up front: smaller models often answer without calling any tool
            Mono<String> promptMono;
            if (isBriefing(question)) {
                promptMono = tools.prefetch(ctx).map(data -> base + "\n\n" + BRIEFING
                        + "\n\nDATA OF THE SELECTED UNIT (JSON, already loaded - use it, call other tools only for details):\n" + data);
            } else if (isReleaseVsEnvironment(question)) {
                promptMono = tools.releaseCheck(ctx).map(data -> base + "\n\nOPEN RELEASE TASKS AGAINST BETA (JSON, already loaded - use it; "
                        + "call release_vs_environment with another environment or release key when the question names one):\n" + data);
            } else if (isAboutReleases(question)) {
                promptMono = tools.releases(ctx).map(data -> base + "\n\nRELEASES OF THE SELECTED UNIT (JSON, already loaded - use it):\n" + data);
            } else if (isAboutJira(question)) {
                promptMono = tools.jira(ctx).map(data -> base + "\n\nJIRA DATA OF THE SELECTED UNIT (JSON, already loaded - use it, call jira_epic / jira_task for details):\n" + data);
            } else {
                promptMono = Mono.just(base);
            }
            return promptMono.flatMap(prompt -> ask(settings, prompt, history, ctx));
        }).onErrorMap(e -> !(e instanceof ZenStageException), e -> {
            log.error("AI chat failed", e);
            return new ZenStageException(HttpStatus.BAD_GATEWAY, "AI_ERROR", "AI model error: " + e.getMessage(), e);
        });
    }

    private Mono<ChatResponse> ask(AiSettings settings, String prompt, List<ChatMessage> history, AiTools.Context ctx) {
        if (settings.toolsEnabled()) {
            return answer(settings, messages(prompt, history), ctx, new ArrayList<>(), 0)
                    // the server or model does not support function calling: answer from prefetched data
                    .onErrorResume(WebClientResponseException.BadRequest.class, e -> {
                        log.warn("AI chat with tools rejected ({}), retrying with prefetched data", e.getResponseBodyAsString());
                        return answerWithData(settings, prompt, history, ctx);
                    });
        }
        return answerWithData(settings, prompt, history, ctx);
    }

    static boolean isBriefing(String question) {
        return BRIEFING_QUESTION.matcher(question).find();
    }

    static boolean isAboutReleases(String question) {
        return RELEASE_QUESTION.matcher(question).find();
    }

    static boolean isReleaseVsEnvironment(String question) {
        return isAboutReleases(question) && ENVIRONMENT_QUESTION.matcher(question).find();
    }

    static boolean isAboutJira(String question) {
        return JIRA_QUESTION.matcher(question).find();
    }

    private Mono<ChatResponse> answer(AiSettings settings, ArrayNode messages, AiTools.Context ctx, List<String> toolsUsed, int round) {
        // the last round goes without tools, so that the model has to answer
        boolean withTools = round < settings.maxToolRounds();
        return client.chat(settings, messages, withTools ? tools.definitions() : null).flatMap(response -> {
            JsonNode message = response.path("choices").path(0).path("message");
            JsonNode calls = message.path("tool_calls");
            if (!withTools || !calls.isArray() || calls.isEmpty()) {
                return Mono.just(new ChatResponse(clean(message.path("content").asString("")), toolsUsed.stream().distinct().toList()));
            }
            ObjectNode assistant = messages.addObject();
            assistant.put("role", "assistant");
            assistant.put("content", message.path("content").asString(""));
            assistant.set("tool_calls", calls);
            return Flux.fromIterable(calls).concatMap(call -> {
                        String name = call.path("function").path("name").asString("");
                        JsonNode arguments = call.path("function").path("arguments");
                        toolsUsed.add(name);
                        return tools.execute(name, arguments.isString() ? arguments.asString() : arguments.toString(), ctx)
                                .map(result -> {
                                    ObjectNode tool = objectMapper.createObjectNode();
                                    tool.put("role", "tool");
                                    tool.put("tool_call_id", call.path("id").asString(name));
                                    tool.put("name", name);
                                    tool.put("content", result);
                                    return tool;
                                });
                    })
                    .doOnNext(messages::add)
                    .then(Mono.defer(() -> answer(settings, messages, ctx, toolsUsed, round + 1)));
        });
    }

    private Mono<ChatResponse> answerWithData(AiSettings settings, String prompt, List<ChatMessage> history, AiTools.Context ctx) {
        return tools.prefetch(ctx).flatMap(data -> {
            String withData = prompt + "\n\nDATA OF THE SELECTED UNIT (JSON):\n" + data;
            return client.chat(settings, messages(withData, history), null)
                    .map(response -> new ChatResponse(
                            clean(response.path("choices").path(0).path("message").path("content").asString("")),
                            List.of("prefetch")));
        });
    }

    private ArrayNode messages(String systemPrompt, List<ChatMessage> history) {
        ArrayNode messages = objectMapper.createArrayNode();
        ObjectNode system = messages.addObject();
        system.put("role", "system");
        system.put("content", systemPrompt);
        history.stream().skip(Math.max(0, history.size() - MAX_HISTORY)).forEach(it -> {
            ObjectNode message = messages.addObject();
            message.put("role", it.role());
            String content = it.content();
            message.put("content", content.length() > MAX_MESSAGE_CHARS ? content.substring(0, MAX_MESSAGE_CHARS) : content);
        });
        return messages;
    }

    private String systemPrompt(String user, AiTools.Context ctx, String lang) {
        String userName = Optional.ofNullable(organizationCache.findPerson(user)).map(Person::name).orElse(user);
        String language = "en".equalsIgnoreCase(lang) ? "English" : "Polish";
        return """
                You are an engineering analytics assistant. You help engineering managers and developers understand
                how their teams deliver software and what to improve. Today is %s. The user is %s (login %s).
                The screen they ask from: unit id %s, period %s (use these when the question does not name another unit or period).

                RULES
                - Never name the application or product you work in; say "the data", "the dashboards" or "the application".
                - Answer ONLY from data returned by the tools (or given below). Never invent numbers, people or units.
                  If data is missing or a tool returns an error, say so plainly.
                - Call tools to get data before answering any question about metrics, teams or people. If the unit id is unknown,
                  call list_units first. For a named developer call developer_metrics.
                - For questions about Jira work (tasks, stories, bugs, epics, initiatives, what is in progress, blocked or late,
                  delivery dates) call jira_work_in_progress and jira_epics; for one epic jira_epic, for one task key jira_task.
                - For releases and deployments (when was the last release, which Jira issues were deployed, which microservices
                  and versions went LIVE) call jira_releases; name the release key, the LIVE date and time, the issues and microservices.
                - To compare the open release task with an environment (is the release on beta, which image / tag of which
                  microservice differs between beta and the Fix Versions of the release) call release_vs_environment (default beta;
                  always the release tasks in status Open). List every DIFFERENT and MISSING microservice with the release key,
                  the version in the release and the tag (image) on the environment; then say how many are the same.
                - Quote the concrete numbers with units and compare them with the organization or team average.
                - Point out what looks wrong, the likely causes and 2-4 concrete, practical actions.
                - Be fair to people: never judge a developer by a single metric, mention context (role, review work, project type,
                  leave, onboarding) and phrase advice as coaching, not as a ranking.
                - Be concise: short paragraphs or bullet points, no tables wider than 4 columns. Answer in %s.

                METRICS
                - prCycle / leadTime: hours from the first commit to the merge into main/master (lower is better).
                - prThroughput: number of merged pull requests in the period (higher is better).
                - deployFreq: number of Jira release tasks moved to LIVE in the period (higher is better).
                - buildFailRate: %% of failed CI pipelines (lower is better).
                - inProgressToLive: average hours from Jira IN PROGRESS to LIVE (lower is better).
                - changeFailure: change failure rate in %% (lower is better).
                - orgAverage / diffPct / better: comparison with all units of the same type in the organization.
                - mergeRequestFlow: MRs opened / merged / in review in the period and the change vs the previous period.
                - Per developer: commits, prCreated, prMerged, reviews (MRs they approved), avgCycleTimeHours, lines added / removed,
                  repositories, avgNewBugs / avgNewCodeSmells / avgNewCoverage (Sonar, new code).
                - my_metrics: avgPickupHours (waiting for the first review), avgReviewHours, avgCycleHours.
                - Jira: daysInStatus (days since the last status change), staleItems (open items over 5 days in one status),
                  finishedInPeriod / avgLeadTimeDaysOfFinished (created -> done), epic health / delayDays / delayReason / progressPct,
                  hoursPerPhase of a task (analysis, coding, review, test, waiting).
                Typical signals: long cycle time with long pickup = reviews wait; few reviews by most people = review load on 1-2
                people; high build failure rate = flaky tests or no local checks; low deployments with high lead time = big batches.
                many open items per person or long daysInStatus = too much work in progress or blockers; epics AT_RISK with low progress
                = scope or capacity problem; long waiting / test phases = hand-offs, not coding, slow the delivery.
                """.formatted(LocalDate.now(), userName, user, Optional.ofNullable(ctx.unitId()).orElse("none"),
                ctx.interval().name(), language);
    }

    /** Drops reasoning blocks some models put into the content. */
    private static String clean(String content) {
        return content.replaceAll("(?s)<think>.*?</think>", "").trim();
    }

    private static Interval interval(String value) {
        try {
            return value == null || value.isBlank() ? Interval.WEEKS_4 : Interval.valueOf(value); // also a custom period
        } catch (IllegalArgumentException e) {
            return Interval.WEEKS_4;
        }
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }
}
