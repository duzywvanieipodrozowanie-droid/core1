package pl.zenstage.core.metrics.response;

import java.math.BigDecimal;
import java.util.Collection;

public record TotalMetrics(
        int numberOfCommits,
        long additions,
        long deletions,
        long total,
        Integer newBugs,
        Integer newDuplicatedBlocks,
        Integer newCodeSmells,
        Integer newTechnicalDebt,
        Integer newViolations,
        Integer newReliabilityRemediationEffort,
        BigDecimal newDevelopmentCost,
        BigDecimal newReliabilityRating,
        BigDecimal newSecurityRating,
        BigDecimal newMaintainabilityRating,
        BigDecimal newDuplicatedLinesDensity,
        BigDecimal newSecurityReviewRating
) {
    public static TotalMetrics sum(Collection<TotalMetrics> totalMetrics) {
        return new TotalMetrics(
                totalMetrics.stream().mapToInt(TotalMetrics::numberOfCommits).sum(),
                totalMetrics.stream().mapToLong(TotalMetrics::additions).sum(),
                totalMetrics.stream().mapToLong(TotalMetrics::deletions).sum(),
                totalMetrics.stream().mapToLong(TotalMetrics::total).sum(),
                totalMetrics.stream().mapToInt(TotalMetrics::newBugs).sum(),
                totalMetrics.stream().mapToInt(TotalMetrics::newDuplicatedBlocks).sum(),
                totalMetrics.stream().mapToInt(TotalMetrics::newCodeSmells).sum(),
                totalMetrics.stream().mapToInt(TotalMetrics::newTechnicalDebt).sum(),
                totalMetrics.stream().mapToInt(TotalMetrics::newViolations).sum(),
                totalMetrics.stream().mapToInt(TotalMetrics::newReliabilityRemediationEffort).sum(),
                totalMetrics.stream().map(TotalMetrics::newDevelopmentCost).reduce(BigDecimal.ZERO, BigDecimal::add),
                totalMetrics.stream().map(TotalMetrics::newReliabilityRating).reduce(BigDecimal.ZERO, BigDecimal::add),
                totalMetrics.stream().map(TotalMetrics::newSecurityRating).reduce(BigDecimal.ZERO, BigDecimal::add),
                totalMetrics.stream().map(TotalMetrics::newMaintainabilityRating).reduce(BigDecimal.ZERO, BigDecimal::add),
                totalMetrics.stream().map(TotalMetrics::newDuplicatedLinesDensity).reduce(BigDecimal.ZERO, BigDecimal::add),
                totalMetrics.stream().map(TotalMetrics::newSecurityReviewRating).reduce(BigDecimal.ZERO, BigDecimal::add)
        );
    }
}
