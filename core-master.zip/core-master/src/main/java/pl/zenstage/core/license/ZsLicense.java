package pl.zenstage.core.license;

import java.time.LocalDate;

public record ZsLicense(
        String name,
        ZsLicType type,
        LocalDate expireDate
) {
    public static ZsLicense community() {
        return new ZsLicense("", ZsLicType.COMMUNITY, LocalDate.now().plusDays(90));
    }

    @Override
    public String toString() {
        return "zenSTAGE License %s licensed for: %s, valid: %s".formatted(type, name, expireDate);
    }
}

