package pl.zenstage.core.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.extern.log4j.Log4j2;
import org.apache.logging.log4j.util.Strings;
import org.springframework.boot.webflux.error.ErrorWebExceptionHandler;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import pl.zenstage.core.common.RestResponse;
import pl.zenstage.core.common.ZenStageException;
import reactor.core.publisher.Mono;

import java.util.Optional;

@Component
@Order(-2)
@Log4j2
public class FluxErrorHandler implements ErrorWebExceptionHandler {
    private final ObjectMapper objectMapper;

    public FluxErrorHandler() {
        // RestResponse has a ZonedDateTime timestamp: without the module the body was not written and every error became a 500
        this.objectMapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    }

    @Override
    public Mono<Void> handle(ServerWebExchange exchange, Throwable ex) {
        if (!(ex instanceof ZenStageException e)) {
            return Mono.error(ex);
        }
        logException(exchange.getRequest().getPath().value(), e.getStatus(), e.getErrorCode(), e);
        exchange.getResponse().setStatusCode(e.getStatus());
        exchange.getResponse().getHeaders().setContentType(MediaType.APPLICATION_JSON);

        RestResponse<String> body = new RestResponse<>(e.getErrorCode(), e.getMessage());

        return writeJson(body).map(bytes ->
                        exchange.getResponse().bufferFactory().wrap(bytes)
                ).map(Mono::just).map(exchange.getResponse()::writeWith)
                .orElseGet(() -> Mono.error(ex));
    }

    private <T> Optional<byte[]> writeJson(RestResponse<T> data) {
        return Optional.ofNullable(data).map(it ->
                {
                    try {
                        return objectMapper.writeValueAsBytes(it);
                    } catch (JsonProcessingException e) {
                        return null;
                    }
                }
        );
    }

    private void logException(String resource, HttpStatus httpStatus, String errorCode, Exception e) {
        log.trace("Request: {}, StackTrace: ", resource, e);
        String format = Strings.isNotBlank(e.getMessage()) ? "{}: {} [{}] - {}" : "{}: {} [{}]";
        log.warn(format,
                resource,
                httpStatus,
                errorCode,
                e.getMessage()
        );
    }
}
