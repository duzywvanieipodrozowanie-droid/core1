package pl.zenstage.core;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportRuntimeHints;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import pl.zenstage.core.config.GraalPackagesHintsRegistrar;

@EnableAsync
@EnableScheduling
@SpringBootApplication
@ImportRuntimeHints(GraalPackagesHintsRegistrar.class)
@OpenAPIDefinition(
        info = @Info(
                title = "ZenStage Backend API",
                version = "1.0",
                description = "Dokumentacja API dla aplikacji ZenStage Backend"
        )
)
public class CoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoreApplication.class, args);
    }

}
