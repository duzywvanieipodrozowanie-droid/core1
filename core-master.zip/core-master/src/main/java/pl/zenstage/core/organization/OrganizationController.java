package pl.zenstage.core.organization;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.common.ZsCommons;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.organization.dto.UnitDto;
import reactor.core.publisher.Flux;

@RequiredArgsConstructor
@RequestMapping("/organization")
@RestController
public class OrganizationController {
    private final OrganizationService organizationService;

    @GetMapping
    public Flux<UnitDto> getManagedUnits() {
        return ZsCommons.currentUserName().flatMapMany(organizationService::userOrganization);
    }

    @GetMapping("/benchmark")
    public Flux<UnitDto> getBenchmarkUnits() {
        return ZsCommons.currentUserName().flatMapMany(organizationService::benchmarkUnits);
    }
}
