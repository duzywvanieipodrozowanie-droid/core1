package pl.zenstage.core.metrics.pr;

public enum PrState {
    open,
    // merged into a protected branch (the first protected branch on the way to production)
    merged,
    closed,
}
