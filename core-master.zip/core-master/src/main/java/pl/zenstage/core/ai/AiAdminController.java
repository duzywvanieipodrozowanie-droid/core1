package pl.zenstage.core.ai;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.admin.Const;
import reactor.core.publisher.Mono;

/** Settings → AI agent (ADMIN only, as everything under {@code /admin}). */
@RestController
@RequestMapping(Const.ADMIN + "/ai")
@RequiredArgsConstructor
public class AiAdminController {
    private final AiSettingsService settingsService;
    private final OpenAiClient client;

    @GetMapping("/settings")
    public AiSettingsService.View settings() {
        return settingsService.view();
    }

    @PutMapping("/settings")
    public Mono<AiSettingsService.View> save(@RequestBody AiSettingsService.Form form) {
        return settingsService.save(form);
    }

    /** Tests the form values (merged with the saved ones) without saving them. */
    @PostMapping("/test")
    public Mono<OpenAiClient.TestResult> test(@RequestBody AiSettingsService.Form form) {
        return Mono.fromSupplier(() -> settingsService.preview(form)).flatMap(client::test);
    }
}
