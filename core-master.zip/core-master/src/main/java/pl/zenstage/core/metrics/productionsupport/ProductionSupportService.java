package pl.zenstage.core.metrics.productionsupport;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.task.History;
import pl.zenstage.api.task.Task;
import pl.zenstage.api.task.TaskStatus;
import pl.zenstage.core.metrics.flow.FlowService;
import pl.zenstage.core.metrics.productionsupport.ProductionSupportResponse.AgeBucket;
import pl.zenstage.core.metrics.productionsupport.ProductionSupportResponse.ClosedDefect;
import pl.zenstage.core.metrics.productionsupport.ProductionSupportResponse.OpenDefect;
import pl.zenstage.core.metrics.productionsupport.ProductionSupportResponse.PriorityStats;
import pl.zenstage.core.metrics.productionsupport.ProductionSupportResponse.Summary;
import pl.zenstage.core.metrics.productionsupport.ProductionSupportResponse.Week;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.Predicate;

/**
 * Production support screen from the Jira production defects of the unit's projects. A defect is closed when its
 * status is LIVE / DONE / COMPLETED (fixed) or CANCELLED / REJECTED (rejected), or CLOSED / RESOLVED in Jira; it got
 * closed at its last move into such a status.
 */
@Service
@RequiredArgsConstructor
public class ProductionSupportService {
    private static final String STATUS_FIELD_TYPE = "status";
    /** Jira issue types counted as production defects (case-insensitive). */
    static final List<String> PRODUCTION_DEFECT_TYPES = List.of("Production defect", "Production bug", "Incident");
    private static final Set<TaskStatus> FIXED = Set.of(TaskStatus.LIVE, TaskStatus.DONE, TaskStatus.COMPLETED);
    private static final Set<TaskStatus> REJECTED = Set.of(TaskStatus.CANCELLED, TaskStatus.REJECTED);
    private static final Set<String> OTHER_CLOSED = Set.of("CLOSED", "RESOLVED", "FIXED");
    private static final int MIN_WEEKS = 8;
    private static final int[] AGE_BUCKETS = {0, 7, 30, 90};
    private static final int RECENTLY_CLOSED = 15;
    private static final String NO_PRIORITY = "—";

    private final OrganizationService organizationService;
    private final TaskRepository taskRepository;

    private record Defect(Task task, LocalDateTime reported, LocalDateTime started, LocalDateTime closed,
                          boolean rejected, LocalDateTime lastMove) {
        boolean openAt(LocalDateTime at) {
            return reported != null && !reported.isAfter(at) && (closed == null || closed.isAfter(at));
        }

        boolean fixedWithin(LocalDateTime from, LocalDateTime till) {
            return closed != null && !rejected && !closed.isBefore(from) && closed.isBefore(till);
        }

        BigDecimal daysToClose() {
            return closed == null || reported == null ? null : days(reported, closed);
        }

        String priority() {
            return task.priority() == null || task.priority().isBlank() ? NO_PRIORITY : task.priority();
        }

        String assignee() {
            return task.assignee() == null ? null : task.assignee().displayName();
        }
    }

    public Mono<ProductionSupportResponse> productionSupport(String unitId, Interval interval) {
        Interval.Range range = interval.range(0);
        Interval.Range previousRange = interval.range(1);
        LocalDateTime now = LocalDateTime.now();

        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(pm -> {
                    Map<String, Defect> byKey = new LinkedHashMap<>();
                    for (String type : PRODUCTION_DEFECT_TYPES) {
                        taskRepository.findByProjectIdInAndTypeIgnoreCase(pm.projects(), type).stream()
                                .filter(it -> it.getContent() != null)
                                .forEach(it -> byKey.putIfAbsent(it.getProjectId() + "|" + it.getKey(), defect(it)));
                    }
                    List<Defect> defects = List.copyOf(byKey.values());
                    List<Defect> open = defects.stream().filter(it -> it.closed() == null).toList();

                    return new ProductionSupportResponse(
                            summary(defects, open, range, now),
                            summary(defects, List.of(), previousRange, now),
                            weeks(defects, range),
                            aging(open, now),
                            byPriority(defects, open, range),
                            open.stream()
                                    .sorted(Comparator.comparing(Defect::reported, Comparator.nullsLast(Comparator.naturalOrder())))
                                    .map(it -> new OpenDefect(
                                            it.task().key(), it.task().summary(), it.task().url(), it.task().status(),
                                            it.priority(), it.assignee(), it.reported(),
                                            it.reported() == null ? null : days(it.reported(), now),
                                            it.lastMove() == null ? null : days(it.lastMove(), now)
                                    ))
                                    .toList(),
                            defects.stream()
                                    .filter(it -> it.closed() != null && !it.closed().isBefore(range.from()) && it.closed().isBefore(range.till()))
                                    .sorted(Comparator.comparing(Defect::closed).reversed())
                                    .limit(RECENTLY_CLOSED)
                                    .map(it -> new ClosedDefect(
                                            it.task().key(), it.task().summary(), it.task().url(), it.task().status(),
                                            it.priority(), it.assignee(), it.reported(), it.closed(), it.daysToClose()
                                    ))
                                    .toList()
                    );
                });
    }

    private static Defect defect(TaskEntity entity) {
        Task task = entity.getContent();
        List<History> changes = Optional.ofNullable(task.histories()).orElse(List.of()).stream()
                .filter(h -> h != null && h.created() != null && STATUS_FIELD_TYPE.equalsIgnoreCase(h.fieldType()))
                .sorted(Comparator.comparing(History::created))
                .toList();
        LocalDateTime reported = Optional.ofNullable(task.created()).orElse(entity.getCreated());
        LocalDateTime started = changes.stream().filter(h -> FlowService.IN_PROGRESS.contains(FlowService.status(h.to())))
                .map(History::created).findFirst().orElse(null);
        LocalDateTime lastMove = changes.isEmpty() ? reported : changes.getLast().created();

        String current = Optional.ofNullable(task.status()).map(it -> it.trim().toUpperCase(Locale.ROOT)).orElse("");
        TaskStatus status = entity.getStatus() != null && entity.getStatus() != TaskStatus.UNKNOWN
                ? entity.getStatus() : FlowService.status(current);
        boolean rejected = REJECTED.contains(status);
        if (!(rejected || FIXED.contains(status) || OTHER_CLOSED.contains(current))) {
            return new Defect(task, reported, started, null, false, lastMove);
        }
        LocalDateTime closed = changes.reversed().stream()
                .filter(h -> closing(h.to()))
                .map(History::created)
                .findFirst()
                .orElse(Optional.ofNullable(task.updated()).orElse(lastMove));
        return new Defect(task, reported, started, closed, rejected, lastMove);
    }

    private static boolean closing(String status) {
        TaskStatus s = FlowService.status(status);
        return FIXED.contains(s) || REJECTED.contains(s)
                || (status != null && OTHER_CLOSED.contains(status.trim().toUpperCase(Locale.ROOT)));
    }

    /** open: defects open now (empty for the previous period, where "now" makes no sense). */
    private static Summary summary(List<Defect> defects, List<Defect> open, Interval.Range range, LocalDateTime now) {
        Predicate<LocalDateTime> inRange = at -> at != null && !at.isBefore(range.from()) && at.isBefore(range.till());
        List<BigDecimal> toClose = defects.stream().filter(it -> it.fixedWithin(range.from(), range.till()))
                .map(Defect::daysToClose).filter(Objects::nonNull).sorted().toList();
        List<BigDecimal> toStart = defects.stream()
                .filter(it -> it.started() != null && inRange.test(it.started()) && it.reported() != null)
                .map(it -> days(it.reported(), it.started()))
                .toList();
        return new Summary(
                open.size(),
                (int) open.stream().filter(it -> it.reported() != null && it.reported().isBefore(now.minusDays(30))).count(),
                (int) defects.stream().filter(it -> inRange.test(it.reported())).count(),
                toClose.size(),
                (int) defects.stream().filter(it -> it.rejected() && inRange.test(it.closed())).count(),
                avg(toClose),
                toClose.isEmpty() ? null : FlowService.percentile(toClose, 50),
                toClose.isEmpty() ? null : FlowService.percentile(toClose, 85),
                avg(toStart)
        );
    }

    private static List<Week> weeks(List<Defect> defects, Interval.Range range) {
        LocalDateTime from = range.from().isBefore(range.till().minusWeeks(MIN_WEEKS)) ? range.from() : range.till().minusWeeks(MIN_WEEKS);
        Map<LocalDate, Week> weeks = new TreeMap<>();
        LocalDate week = from.toLocalDate().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        while (week.atStartOfDay().isBefore(range.till())) {
            LocalDateTime start = week.atStartOfDay();
            LocalDateTime end = start.plusWeeks(1);
            LocalDateTime openAt = end.isAfter(range.till()) ? range.till() : end;
            weeks.put(week, new Week(
                    week,
                    (int) defects.stream().filter(it -> it.reported() != null && !it.reported().isBefore(start) && it.reported().isBefore(end)).count(),
                    (int) defects.stream().filter(it -> it.closed() != null && !it.closed().isBefore(start) && it.closed().isBefore(end)).count(),
                    (int) defects.stream().filter(it -> it.openAt(openAt)).count()
            ));
            week = week.plusWeeks(1);
        }
        return List.copyOf(weeks.values());
    }

    private static List<AgeBucket> aging(List<Defect> open, LocalDateTime now) {
        List<AgeBucket> buckets = new ArrayList<>();
        for (int i = 0; i < AGE_BUCKETS.length; i++) {
            int from = AGE_BUCKETS[i];
            Integer till = i + 1 < AGE_BUCKETS.length ? AGE_BUCKETS[i + 1] : null;
            buckets.add(new AgeBucket(from, till, (int) open.stream().filter(it -> {
                long age = it.reported() == null ? 0 : Duration.between(it.reported(), now).toDays();
                return age >= from && (till == null || age < till);
            }).count()));
        }
        return buckets;
    }

    private static List<PriorityStats> byPriority(List<Defect> defects, List<Defect> open, Interval.Range range) {
        Map<String, List<Defect>> fixed = new TreeMap<>();
        defects.stream().filter(it -> it.fixedWithin(range.from(), range.till()))
                .forEach(it -> fixed.computeIfAbsent(it.priority(), k -> new ArrayList<>()).add(it));
        Map<String, Integer> openCounts = new TreeMap<>();
        open.forEach(it -> openCounts.merge(it.priority(), 1, Integer::sum));
        Set<String> priorities = new TreeSet<>(fixed.keySet());
        priorities.addAll(openCounts.keySet());
        return priorities.stream()
                .map(p -> new PriorityStats(
                        p,
                        openCounts.getOrDefault(p, 0),
                        fixed.getOrDefault(p, List.of()).size(),
                        avg(fixed.getOrDefault(p, List.of()).stream().map(Defect::daysToClose).filter(Objects::nonNull).toList())
                ))
                .sorted(Comparator.comparingInt((PriorityStats it) -> it.open() + it.closed()).reversed())
                .toList();
    }

    private static BigDecimal avg(List<BigDecimal> values) {
        return values.isEmpty() ? null : values.stream().reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(BigDecimal.valueOf(values.size()), 1, RoundingMode.HALF_UP);
    }

    private static BigDecimal days(LocalDateTime from, LocalDateTime till) {
        return BigDecimal.valueOf(Math.max(0, Duration.between(from, till).toMinutes()))
                .divide(BigDecimal.valueOf(24 * 60), 1, RoundingMode.HALF_UP);
    }
}
