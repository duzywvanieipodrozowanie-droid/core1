package pl.zenstage.core.metrics.team;

import java.math.BigDecimal;

/**
 * GitLab-based details of one engineer for the selected interval (Team screen, Engineers table).
 */
public record DevInsights(
        String personId,
        // pipelines run for the engineer's commits; duration = created -> last update of finished pipelines
        long pipelines,
        long failedPipelines,
        BigDecimal avgPipelineMinutes,
        // "Revert ..." commits made by the engineer / the engineer's commits reverted by anyone
        long revertsMade,
        long commitsReverted,
        // merge requests authored by the engineer; comment and size averages only over MRs imported with that data
        long mrs,
        BigDecimal avgMrComments,
        BigDecimal avgMrChangedFiles,
        long mrsWithStats
) {
}
