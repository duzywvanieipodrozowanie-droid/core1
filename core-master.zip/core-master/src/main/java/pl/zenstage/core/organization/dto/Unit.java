package pl.zenstage.core.organization.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

public record Unit(
        String id,
        String name,
        String type,
        Set<String> managers,
        Set<String> members,
        Set<String> projects,
        List<Unit> units
) {
    public List<Unit> unitsDeep() {
        ArrayList<Unit> units = new ArrayList<>();
        units.add(this);
        if (Objects.nonNull(this.units)) {
            this.units.stream().map(Unit::unitsDeep).flatMap(List::stream).forEach(units::add);
        }
        return units;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Unit unit = (Unit) o;
        return Objects.equals(id, unit.id) && Objects.equals(name, unit.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
