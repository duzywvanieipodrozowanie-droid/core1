package pl.zenstage.core.metrics.flow;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import pl.zenstage.api.task.History;
import pl.zenstage.api.task.Task;
import pl.zenstage.api.task.TaskStatus;
import pl.zenstage.core.metrics.ReleaseTasks;
import pl.zenstage.core.metrics.flow.FlowResponse.Bucket;
import pl.zenstage.core.metrics.flow.FlowResponse.CycleTime;
import pl.zenstage.core.metrics.flow.FlowResponse.Forecast;
import pl.zenstage.core.metrics.flow.FlowResponse.PaceWeek;
import pl.zenstage.core.metrics.flow.FlowResponse.Percentile;
import pl.zenstage.core.metrics.flow.FlowResponse.Wip;
import pl.zenstage.core.metrics.flow.FlowResponse.WipItem;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;

/**
 * Flow metrics ("Przepływ pracy" on Overview) from the Jira status history of the unit's projects: cycle time
 * percentiles, Monte Carlo forecast, work in progress with its age and the weekly pace of starting vs finishing.
 */
@Service
@RequiredArgsConstructor
public class FlowService {
    private static final String STATUS_FIELD_TYPE = "status";
    /** Statuses meaning the work item is being worked on (started, not LIVE yet). */
    public static final Set<TaskStatus> IN_PROGRESS = Set.of(
            TaskStatus.IN_PROGRESS, TaskStatus.IN_REVIEW, TaskStatus.DEVELOPED, TaskStatus.IN_TEST, TaskStatus.TO_TEST,
            TaskStatus.TESTED, TaskStatus.UAT, TaskStatus.IN_UAT, TaskStatus.PO_ACCEPTANCE,
            TaskStatus.ON_HOLD, TaskStatus.ON_HOLD_BLOCKED, TaskStatus.BLOCKED
    );
    private static final int[] CYCLE_PERCENTILES = {50, 70, 85, 95};
    private static final int[] FORECAST_CHANCES = {95, 85, 70, 50};
    private static final int HISTOGRAM_DAYS = 30;
    private static final int MIN_PACE_WEEKS = 8;
    private static final int FORECAST_DAYS = 30;
    private static final int FORECAST_SAMPLE_DAYS = 56;
    private static final int SIMULATIONS = 10_000;
    private static final int FORECAST_BUCKETS = 20;
    private static final long NO_MOVE_DAYS = 14;

    private final OrganizationService organizationService;
    private final TaskRepository taskRepository;

    /** One work item with the moments that matter for flow. */
    private record Item(Task task, TaskStatus status, LocalDateTime started, List<LocalDateTime> lives, LocalDateTime lastMove) {
        /** First LIVE within [from, till) after the start, if any. */
        Optional<LocalDateTime> finishedWithin(LocalDateTime from, LocalDateTime till) {
            return lives.stream().filter(it -> !it.isBefore(from) && it.isBefore(till)).findFirst();
        }
    }

    public Mono<FlowResponse> flow(String unitId, Interval interval) {
        Interval.Range range = interval.range(0);
        LocalDateTime now = LocalDateTime.now();
        // pace shows at least MIN_PACE_WEEKS, also for short periods
        LocalDateTime paceFrom = earlier(range.from(), range.till().minusWeeks(MIN_PACE_WEEKS));
        LocalDateTime sampleFrom = now.toLocalDate().minusDays(FORECAST_SAMPLE_DAYS).atStartOfDay();
        LocalDateTime loadFrom = earlier(paceFrom, sampleFrom);

        return organizationService.userManageProjectsMembers(unitId)
                .publishOn(Schedulers.boundedElastic())
                .map(pm -> {
                    Map<String, Item> items = new LinkedHashMap<>();
                    taskRepository.findByProjectIdInAndUpdatedAfter(pm.projects(), loadFrom).forEach(it -> add(items, it));
                    taskRepository.findByProjectIdInAndStatusIn(pm.projects(), IN_PROGRESS).forEach(it -> add(items, it));

                    CycleTime cycleTime = cycleTime(items.values(), range);
                    BigDecimal p85 = cycleTime.percentiles().stream().filter(it -> it.pct() == 85)
                            .map(Percentile::value).findFirst().orElse(null);
                    return new FlowResponse(
                            cycleTime,
                            forecast(items.values(), sampleFrom, now),
                            wip(items.values(), p85, pm.members().size(), now),
                            pace(items.values(), paceFrom, range.till())
                    );
                });
    }

    private static void add(Map<String, Item> items, TaskEntity entity) {
        Task task = entity.getContent();
        if (task == null || !countedType(entity.getType()) || items.containsKey(entity.getProjectId() + "|" + entity.getKey())) {
            return;
        }
        List<History> statusChanges = Optional.ofNullable(task.histories()).orElse(List.of()).stream()
                .filter(h -> h != null && h.created() != null && STATUS_FIELD_TYPE.equalsIgnoreCase(h.fieldType()))
                .sorted(Comparator.comparing(History::created))
                .toList();
        LocalDateTime started = statusChanges.stream().filter(h -> IN_PROGRESS.contains(status(h.to())))
                .map(History::created).findFirst().orElse(null);
        List<LocalDateTime> lives = statusChanges.stream().filter(h -> status(h.to()) == TaskStatus.LIVE)
                .map(History::created)
                .filter(it -> started != null && !it.isBefore(started))
                .toList();
        LocalDateTime lastMove = statusChanges.isEmpty() ? task.created() : statusChanges.getLast().created();
        items.put(entity.getProjectId() + "|" + entity.getKey(), new Item(task, entity.getStatus(), started, lives, lastMove));
    }

    /**
     * Stories, tasks, defects...: sub-tasks would double count their parent, epics/initiatives are containers,
     * release tasks only mark deployments.
     */
    static boolean countedType(String type) {
        if (type == null) {
            return true;
        }
        if (ReleaseTasks.isRelease(type)) {
            return false;
        }
        String t = type.toLowerCase(Locale.ROOT).replace("-", "").replace(" ", "");
        return !(t.contains("subtask") || t.equals("epic") || t.equals("opus") || t.equals("sap") || t.equals("initiative"));
    }

    private CycleTime cycleTime(Collection<Item> items, Interval.Range range) {
        List<BigDecimal> days = items.stream()
                .filter(it -> it.started() != null)
                .map(it -> it.finishedWithin(range.from(), range.till()).map(live -> days(it.started(), live)).orElse(null))
                .filter(Objects::nonNull)
                .sorted()
                .toList();
        List<Percentile> percentiles = new ArrayList<>();
        if (!days.isEmpty()) {
            for (int pct : CYCLE_PERCENTILES) {
                percentiles.add(new Percentile(pct, percentile(days, pct).setScale(1, RoundingMode.HALF_UP)));
            }
        }
        int[] counts = new int[HISTOGRAM_DAYS + 1];
        days.forEach(d -> counts[Math.min(HISTOGRAM_DAYS, d.intValue())]++);
        List<Bucket> histogram = new ArrayList<>();
        for (int i = 0; i <= HISTOGRAM_DAYS; i++) {
            histogram.add(new Bucket(i, i == HISTOGRAM_DAYS ? null : i + 1, counts[i]));
        }
        return new CycleTime(days.size(), percentiles, histogram);
    }

    private Forecast forecast(Collection<Item> items, LocalDateTime sampleFrom, LocalDateTime now) {
        LocalDate first = sampleFrom.toLocalDate();
        LocalDate today = now.toLocalDate();
        int sampleDays = (int) ChronoUnit.DAYS.between(first, today);
        int[] perDay = new int[Math.max(1, sampleDays)];
        items.forEach(it -> it.finishedWithin(sampleFrom, today.atStartOfDay()).ifPresent(live -> {
            int idx = (int) ChronoUnit.DAYS.between(first, live.toLocalDate());
            if (idx >= 0 && idx < perDay.length) {
                perDay[idx]++;
            }
        }));
        if (Arrays.stream(perDay).sum() == 0) {
            return new Forecast(FORECAST_DAYS, sampleDays, 0, List.of(), List.of());
        }
        // fixed seed: the same data gives the same forecast on every refresh
        Random random = new Random(42);
        int[] totals = new int[SIMULATIONS];
        for (int s = 0; s < SIMULATIONS; s++) {
            int total = 0;
            for (int d = 0; d < FORECAST_DAYS; d++) {
                total += perDay[random.nextInt(perDay.length)];
            }
            totals[s] = total;
        }
        Arrays.sort(totals);
        List<Percentile> percentiles = new ArrayList<>();
        for (int chance : FORECAST_CHANCES) {
            // "chance% of at least X" = the (100 - chance)th percentile of simulated totals
            int idx = Math.min(SIMULATIONS - 1, (int) Math.floor((100 - chance) / 100.0 * SIMULATIONS));
            percentiles.add(new Percentile(chance, BigDecimal.valueOf(totals[idx])));
        }
        int min = totals[0];
        int max = totals[SIMULATIONS - 1];
        int width = Math.max(1, (int) Math.ceil((max - min + 1) / (double) FORECAST_BUCKETS));
        Map<Integer, Integer> buckets = new TreeMap<>();
        for (int total : totals) {
            buckets.merge(min + (total - min) / width * width, 1, Integer::sum);
        }
        List<Bucket> distribution = buckets.entrySet().stream()
                .map(e -> new Bucket(e.getKey(), e.getKey() + width, e.getValue()))
                .toList();
        return new Forecast(FORECAST_DAYS, sampleDays, SIMULATIONS, percentiles, distribution);
    }

    private Wip wip(Collection<Item> items, BigDecimal p85, int people, LocalDateTime now) {
        List<WipItem> wip = items.stream()
                .filter(it -> IN_PROGRESS.contains(it.status()))
                .map(it -> {
                    Task task = it.task();
                    LocalDateTime started = Optional.ofNullable(it.started()).orElse(task.created());
                    return new WipItem(
                            task.key(),
                            task.summary(),
                            task.url(),
                            task.type(),
                            it.status().getJiraName(),
                            task.assignee() == null ? null : task.assignee().displayName(),
                            started == null ? BigDecimal.ZERO : days(started, now),
                            it.lastMove() == null ? null : days(it.lastMove(), now)
                    );
                })
                .sorted(Comparator.comparing(WipItem::ageDays).reversed())
                .toList();
        BigDecimal avgAge = wip.isEmpty() ? BigDecimal.ZERO
                : wip.stream().map(WipItem::ageDays).reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(BigDecimal.valueOf(wip.size()), 1, RoundingMode.HALF_UP);
        int olderThanP85 = p85 == null ? 0 : (int) wip.stream().filter(it -> it.ageDays().compareTo(p85) > 0).count();
        int noMove = (int) wip.stream()
                .filter(it -> it.daysSinceLastMove() != null && it.daysSinceLastMove().compareTo(BigDecimal.valueOf(NO_MOVE_DAYS)) > 0)
                .count();
        BigDecimal perPerson = people == 0 ? null
                : BigDecimal.valueOf(wip.size()).divide(BigDecimal.valueOf(people), 1, RoundingMode.HALF_UP);
        return new Wip(wip.size(), avgAge, olderThanP85, noMove, perPerson, wip);
    }

    private List<PaceWeek> pace(Collection<Item> items, LocalDateTime from, LocalDateTime till) {
        Map<LocalDate, int[]> weeks = new TreeMap<>();
        LocalDate week = monday(from.toLocalDate());
        while (week.atStartOfDay().isBefore(till)) {
            weeks.put(week, new int[2]);
            week = week.plusWeeks(1);
        }
        for (Item item : items) {
            if (item.started() != null && !item.started().isBefore(from) && item.started().isBefore(till)) {
                Optional.ofNullable(weeks.get(monday(item.started().toLocalDate()))).ifPresent(c -> c[0]++);
            }
            item.finishedWithin(from, till).ifPresent(live ->
                    Optional.ofNullable(weeks.get(monday(live.toLocalDate()))).ifPresent(c -> c[1]++));
        }
        return weeks.entrySet().stream().map(e -> new PaceWeek(e.getKey(), e.getValue()[0], e.getValue()[1])).toList();
    }

    private static LocalDate monday(LocalDate date) {
        return date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
    }

    /** Nearest-rank percentile of a sorted list. */
    public static BigDecimal percentile(List<BigDecimal> sorted, int pct) {
        int rank = (int) Math.ceil(pct / 100.0 * sorted.size());
        return sorted.get(Math.max(0, Math.min(sorted.size() - 1, rank - 1)));
    }

    private static BigDecimal days(LocalDateTime from, LocalDateTime till) {
        return BigDecimal.valueOf(Math.max(0, Duration.between(from, till).toMinutes()))
                .divide(BigDecimal.valueOf(24 * 60), 1, RoundingMode.HALF_UP);
    }

    public static TaskStatus status(String value) {
        if (value == null || value.isBlank()) {
            return TaskStatus.UNKNOWN;
        }
        String normalized = value.trim();
        for (TaskStatus status : TaskStatus.values()) {
            if (status.name().equalsIgnoreCase(normalized) || status.getJiraName().equalsIgnoreCase(normalized)) {
                return status;
            }
        }
        return TaskStatus.UNKNOWN;
    }

    private static LocalDateTime earlier(LocalDateTime a, LocalDateTime b) {
        return a.isBefore(b) ? a : b;
    }
}
