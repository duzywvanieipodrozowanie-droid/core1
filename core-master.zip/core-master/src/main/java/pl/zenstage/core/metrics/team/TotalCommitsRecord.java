package pl.zenstage.core.metrics.team;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

public record TotalCommitsRecord(
        LocalDate startDate,
        LocalDate endDate,
        BigDecimal count
) {

    private static final DateTimeFormatter format = DateTimeFormatter.ofPattern("MM-dd");

    public String getLabel() {
        return Optional.ofNullable(startDate).map(it -> it.format(format)).orElse(null);
    }
}
