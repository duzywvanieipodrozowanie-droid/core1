package pl.zenstage.core.organization.dto;

import pl.zenstage.api.admin.EmpLevel;
import pl.zenstage.api.admin.EmpSkill;

import java.util.Set;

public record Init(
        Set<EmpLevel> levels,
        Set<EmpSkill> skills
) {
}
