package pl.zenstage.core.metrics.team;

import java.math.BigDecimal;
import java.util.List;

public record SprintTeamCapacityResponse(
        List<SprintUserComprehensiveDto> users,
        int totalAnalyzedSprints
) {
    public record SprintUserComprehensiveDto(
            String assignee,

            // 1. Statystyki historyczne
            HistoricalSprintMetrics historicalMetrics,

            // 2. Statystyki obecnego/aktywnego sprintu
            CurrentSprintMetrics currentSprintMetrics
    ) {
        public record HistoricalSprintMetrics(
                double avgTotalTasksPerSprint,
                BigDecimal avgTotalEstimatePerSprint,
                double avgInitialTasksPerSprint,        // ile średnio pobiera na start
                BigDecimal avgInitialEstimatePerSprint,
                double avgAddedTasksPerSprint,          // ile średnio dobiera w trakcie
                BigDecimal avgAddedEstimatePerSprint,
                double avgCompletedTasksPerSprint,      // ile średnio zamyka/przekazuje dalej
                double avgCompletionRatePercentage     // średni % zadań zamkniętych/przekazanych dalej
        ) {
        }

        public record CurrentSprintMetrics(
                String sprintName,
                long currentTotalTasks,
                BigDecimal currentTotalEstimate,
                long initialTasks,                      // ile pobrał na start obecnego sprintu
                BigDecimal initialEstimate,
                long addedTasks,                        // ile dobrał w trakcie
                BigDecimal addedEstimate,
                long completedTasks,                    // zadania zamknięte lub przekazane dalej w obecnym sprincie
                double currentCompletionRatePercentage  // aktualny % realizacji
        ) {
        }
    }
}
