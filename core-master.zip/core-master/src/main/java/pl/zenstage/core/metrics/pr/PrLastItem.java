package pl.zenstage.core.metrics.pr;

import pl.zenstage.api.mr.MrCommit;

import java.math.BigDecimal;
import java.util.List;

/**
 * One of the latest merge requests of a unit (Overview, "Recent PRs").
 */
public record PrLastItem(
        String title,
        String author,
        // hours since the last activity of the MR (merge, close, update or creation)
        BigDecimal hoursAgo,
        // hours from creation to merge; null when not merged
        BigDecimal mergeTime,
        PrState state,
        String targetBranch,
        // commits of the MR (oldest first); for MRs imported before the commit list was stored: the merge commit only
        List<MrCommit> commits
) {
}
