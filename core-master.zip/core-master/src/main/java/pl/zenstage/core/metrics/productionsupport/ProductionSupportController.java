package pl.zenstage.core.metrics.productionsupport;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.metrics.request.Interval;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/metrics/production-support")
@RequiredArgsConstructor
public class ProductionSupportController {
    private final ProductionSupportService productionSupportService;

    /** "Production support" screen: production defects open vs closed and time to close. */
    @GetMapping
    public Mono<ResponseEntity<ProductionSupportResponse>> productionSupport(
            @RequestParam(required = false) String unitId,
            @RequestParam(required = false, defaultValue = "WEEKS_4") Interval interval
    ) {
        return productionSupportService.productionSupport(unitId, interval).map(ResponseEntity::ok)
                .switchIfEmpty(Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN).build()));
    }
}
