package pl.zenstage.core.metrics.pr;

import pl.zenstage.core.common.IChartLabel;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

public record PrThroughputRecord(
        LocalDate startDate,
        LocalDate endDate,
        int review,
        int opened,
        int merged
) implements IChartLabel {
    public BigDecimal getMergedRate() {
        if (opened + merged == 0) {
            return BigDecimal.valueOf(100);
        }
        return BigDecimal.valueOf(merged * 100L).divide(BigDecimal.valueOf(opened + merged), 0, RoundingMode.CEILING);
    }
}
