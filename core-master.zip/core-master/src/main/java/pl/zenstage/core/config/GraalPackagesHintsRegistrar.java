package pl.zenstage.core.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.aot.hint.MemberCategory;
import org.springframework.aot.hint.RuntimeHints;
import org.springframework.aot.hint.RuntimeHintsRegistrar;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AssignableTypeFilter;
import org.springframework.util.ClassUtils;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

@Slf4j
public class GraalPackagesHintsRegistrar implements RuntimeHintsRegistrar {

    @Override
    public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
        List.of(
                "logo/zeni_logo.png",
                "logo/ol_logo.jpg",
                "sig/zs.pem"
        ).forEach(hints.resources()::registerPattern);

        List<String> packagesToScan = List.of(
                "pl.zenstage.api",
                "pl.zenstage.core",
                "pl.zenstage.db.store.entity"
        );

        Consumer<String> registerClass = candidate -> {
            try {
                log.info("Register reflection for class: {}", candidate);
                Class<?> clazz = ClassUtils.forName(candidate, classLoader);
                hints.reflection().registerType(clazz, MemberCategory.values());
                Class<?> arrayClass = ClassUtils.forName("[L" + clazz.getName() + ";", classLoader);
                hints.reflection().registerType(arrayClass, MemberCategory.values());

            } catch (ClassNotFoundException | LinkageError _) {
            }
        };

        ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(false);
        scanner.addIncludeFilter(new AssignableTypeFilter(Object.class));

        for (String basePackage : packagesToScan) {
            scanner.findCandidateComponents(basePackage).stream().map(BeanDefinition::getBeanClassName)
                    .filter(Objects::nonNull).forEach(registerClass);
        }
    }
}
