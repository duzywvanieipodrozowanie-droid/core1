package pl.zenstage.core.ai;

import io.netty.channel.ChannelOption;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import io.netty.handler.ssl.util.SimpleTrustManagerFactory;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.Http11SslContextSpec;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.ProxyProvider;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

import javax.net.ssl.ManagerFactoryParameters;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Minimal non-blocking client of the OpenAI {@code /chat/completions} endpoint. The body is (de)serialized here
 * as plain JSON, so it does not depend on the WebClient codecs. The HTTP client (URL, key, proxy, TLS) is rebuilt
 * when the settings change.
 */
@Log4j2
@Component
public class OpenAiClient {
    private static final Pattern PEM_BLOCK = Pattern.compile("-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\\s]+-----END CERTIFICATE-----");
    private final ObjectMapper objectMapper;
    private volatile Connection connection;

    private record Connection(AiSettings settings, WebClient webClient) {
    }

    /**
     * @param serverCertificates when the TLS handshake failed: the chain the server presented, to show which CA to trust
     * @param tlsHints           when the TLS handshake failed: what is wrong with the chain, the CA given or the host name
     */
    public record TestResult(boolean ok, long latencyMs, String reply, List<String> models, String error,
                             List<CertificateInfo> serverCertificates, List<String> tlsHints) {
    }

    public record CertificateInfo(String subject, String issuer, String notAfter, boolean selfSigned, String pem) {
    }

    OpenAiClient(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    /**
     * @param tools function definitions, null or empty to call without tools
     * @return the whole response; the answer is in {@code choices[0].message}
     */
    public Mono<JsonNode> chat(AiSettings settings, ArrayNode messages, ArrayNode tools) {
        return chat(webClient(settings), settings, messages, tools);
    }

    private Mono<JsonNode> chat(WebClient client, AiSettings settings, ArrayNode messages, ArrayNode tools) {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("model", settings.model());
        body.put("temperature", settings.temperature());
        body.set("messages", messages);
        if (tools != null && !tools.isEmpty()) {
            body.set("tools", tools);
            body.put("tool_choice", "auto");
        }
        return client.post()
                .uri("/chat/completions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(objectMapper.writeValueAsString(body))
                .retrieve()
                .bodyToMono(String.class)
                .timeout(settings.timeout())
                .map(objectMapper::readTree);
    }

    /** Checks the settings: lists the models (when the server supports it) and asks the model for a short reply. */
    public Mono<TestResult> test(AiSettings settings) {
        // a one-off client: the settings tested may not be saved yet
        WebClient client = build(settings);
        Mono<List<String>> models = client.get().uri("/models").retrieve().bodyToMono(String.class)
                .timeout(settings.timeout())
                .map(objectMapper::readTree)
                .map(json -> {
                    List<String> ids = new ArrayList<>();
                    json.path("data").forEach(it -> ids.add(it.path("id").asString("")));
                    return ids.stream().filter(it -> !it.isBlank()).toList();
                })
                .onErrorReturn(List.of());
        ArrayNode messages = objectMapper.createArrayNode();
        ObjectNode message = messages.addObject();
        message.put("role", "user");
        message.put("content", "Reply with the single word OK.");
        long start = System.currentTimeMillis();
        Mono<String> reply = chat(client, settings, messages, null)
                .map(json -> json.path("choices").path(0).path("message").path("content").asString("").trim());
        return Mono.zip(reply, models)
                .map(t -> new TestResult(true, System.currentTimeMillis() - start, t.getT1(), t.getT2(), null, List.of(), List.of()))
                .onErrorResume(e -> {
                    long latency = System.currentTimeMillis() - start;
                    if (!isTlsError(e)) {
                        return models.map(it -> new TestResult(false, latency, null, it, describe(e), List.of(), List.of()));
                    }
                    return Mono.zip(models, serverCertificates(settings)).map(t -> {
                        List<X509Certificate> chain = t.getT2();
                        log.info("AI connection test TLS failure: {}; server chain {}", describe(e),
                                chain.stream().map(it -> it.getSubjectX500Principal().getName()).toList());
                        return new TestResult(false, latency, null, t.getT1(), describe(e),
                                chain.stream().map(OpenAiClient::info).toList(), diagnose(host(settings.baseUrl()), chain, settings.tls()));
                    });
                });
    }

    /** The certificate chain the server presents, read with a trust manager that accepts and records anything. */
    private Mono<List<X509Certificate>> serverCertificates(AiSettings settings) {
        List<X509Certificate> captured = new CopyOnWriteArrayList<>();
        X509TrustManager recorder = new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) {
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {
                if (captured.isEmpty()) captured.addAll(Arrays.asList(chain));
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }
        };
        TrustManagerFactory factory = new SimpleTrustManagerFactory() {
            @Override
            protected void engineInit(KeyStore keyStore) {
            }

            @Override
            protected void engineInit(ManagerFactoryParameters parameters) {
            }

            @Override
            protected TrustManager[] engineGetTrustManagers() {
                return new TrustManager[]{recorder};
            }
        };
        AiSettings insecure = new AiSettings(settings.enabled(), settings.baseUrl(), settings.apiKey(), settings.model(),
                settings.toolsEnabled(), settings.maxToolRounds(), settings.temperature(), settings.timeout(), settings.proxy(),
                new AiSettings.Tls(null, true));
        return build(insecure, factory).get().uri("/models").retrieve().toBodilessEntity()
                .timeout(settings.timeout())
                .onErrorResume(e -> Mono.empty())
                .then(Mono.fromSupplier(() -> List.copyOf(captured)));
    }

    /**
     * Why the chain the server presented is not trusted with the given settings, in words for the settings screen:
     * a CA that did not issue any certificate of the chain (e.g. the TLS inspection CA of a laptop, which the server
     * does not go through), an intermediate CA the server does not send, a host name the certificate is not issued for.
     */
    static List<String> diagnose(String host, List<X509Certificate> chain, AiSettings.Tls tls) {
        List<String> hints = new ArrayList<>();
        if (chain.isEmpty()) {
            hints.add("Nie udało się odczytać certyfikatów serwera – połączenie zostało zerwane przed TLS (sprawdź URL, port i proxy).");
            return hints;
        }
        X509Certificate leaf = chain.getFirst();
        List<String> names = subjectNames(leaf);
        if (host != null && !names.isEmpty() && names.stream().noneMatch(it -> hostMatches(it, host))) {
            hints.add("Certyfikat serwera jest wystawiony na " + String.join(", ", names) + ", a URL używa nazwy " + host
                    + ". Zmień w URL nazwę hosta na jedną z nich – samo zaufanie CA tego nie naprawi.");
        }
        Date now = new Date();
        for (X509Certificate certificate : chain) {
            if (now.after(certificate.getNotAfter())) {
                hints.add("Certyfikat " + commonName(certificate) + " z łańcucha serwera wygasł " + certificate.getNotAfter().toInstant() + ".");
            }
        }
        List<X509Certificate> given;
        try {
            given = tls.caCertificates() == null || tls.caCertificates().isBlank() ? List.of() : certificates(tls.caCertificates());
        } catch (IllegalArgumentException e) {
            given = List.of();
        }
        X509Certificate top = chain.getLast();
        String missingIssuer = top.getIssuerX500Principal().getName();
        if (given.isEmpty()) {
            hints.add("Nie ma zapisanego certyfikatu CA. Serwer jest podpisany przez: " + missingIssuer
                    + " – wklej certyfikat o tej nazwie albo użyj przycisku przy ostatnim certyfikacie łańcucha.");
            return hints;
        }
        for (X509Certificate ca : given) {
            if (now.after(ca.getNotAfter())) {
                hints.add("Wklejony certyfikat " + commonName(ca) + " wygasł " + ca.getNotAfter().toInstant() + ".");
            }
        }
        Optional<X509Certificate> issuer = Optional.empty();
        for (X509Certificate certificate : chain) {
            issuer = given.stream().filter(ca -> ca.equals(certificate) || issuedBy(certificate, ca)).findFirst();
            if (issuer.isPresent()) break;
        }
        if (issuer.isPresent()) {
            hints.add("Wklejony certyfikat " + commonName(issuer.get()) + " pasuje do łańcucha serwera – jeśli test nadal nie przechodzi,"
                    + " a ustawienia są zapisane, problemem jest nazwa hosta lub ważność certyfikatów (powyżej).");
            return hints;
        }
        String givenNames = given.stream().map(OpenAiClient::commonName).collect(Collectors.joining(", "));
        boolean sameNameOtherKey = given.stream().anyMatch(ca -> ca.getSubjectX500Principal().equals(top.getIssuerX500Principal()));
        if (sameNameOtherKey) {
            hints.add("Wklejony certyfikat " + givenNames + " ma tę samą nazwę co wystawca serwera, ale inny klucz – to inna (np. stara"
                    + " lub odnowiona) wersja tego CA. Pobierz aktualną albo użyj przycisku przy ostatnim certyfikacie łańcucha.");
        } else {
            hints.add("Wklejone certyfikaty (" + givenNames + ") nie wystawiły żadnego certyfikatu serwera. Serwer jest podpisany przez: "
                    + missingIssuer + (top.getSubjectX500Principal().equals(top.getIssuerX500Principal()) ? "" : " – serwer nie wysyła tego certyfikatu")
                    + ". Potrzebny jest certyfikat o tej nazwie (pośredni lub główny CA), albo użyj przycisku przy ostatnim certyfikacie łańcucha.");
        }
        if (given.stream().map(OpenAiClient::commonName).anyMatch(it -> it.matches("(?i).*(zscaler|netskope|forti|palo ?alto|blue ?coat|proxy|inspection|ssl ?decrypt).*"))) {
            hints.add("Wklejony certyfikat wygląda na CA proxy inspekcji TLS z Twojego komputera. Serwer aplikacji łączy się z modelem"
                    + " bez tego proxy i widzi inny łańcuch – zaufaj certyfikatowi z listy poniżej.");
        }
        return hints;
    }

    private static boolean issuedBy(X509Certificate certificate, X509Certificate ca) {
        if (!certificate.getIssuerX500Principal().equals(ca.getSubjectX500Principal())) return false;
        try {
            certificate.verify(ca.getPublicKey());
            return true;
        } catch (GeneralSecurityException e) {
            return false;
        }
    }

    /** DNS names and IP addresses of the certificate, or its CN when it has no subject alternative names. */
    private static List<String> subjectNames(X509Certificate certificate) {
        List<String> names = new ArrayList<>();
        try {
            Collection<List<?>> alternative = certificate.getSubjectAlternativeNames();
            if (alternative != null) {
                for (List<?> name : alternative) {
                    if (name.size() > 1 && (Integer.valueOf(2).equals(name.get(0)) || Integer.valueOf(7).equals(name.get(0)))) {
                        names.add(String.valueOf(name.get(1)));
                    }
                }
            }
        } catch (CertificateParsingException e) {
            // no names then
        }
        if (names.isEmpty()) {
            String cn = commonName(certificate);
            if (!cn.isBlank()) names.add(cn);
        }
        return names;
    }

    static boolean hostMatches(String pattern, String host) {
        String p = pattern.toLowerCase(Locale.ROOT);
        String h = host.toLowerCase(Locale.ROOT);
        if (p.startsWith("*.")) {
            int dot = h.indexOf('.');
            return dot > 0 && h.substring(dot).equals(p.substring(1));
        }
        return p.equals(h);
    }

    private static String commonName(X509Certificate certificate) {
        String dn = certificate.getSubjectX500Principal().getName();
        Matcher m = Pattern.compile("CN=((?:\\\\,|[^,])+)").matcher(dn);
        return m.find() ? m.group(1) : dn;
    }

    private static String host(String baseUrl) {
        try {
            return URI.create(baseUrl).getHost();
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static boolean isTlsError(Throwable e) {
        for (Throwable t = e; t != null; t = t.getCause()) {
            if (t instanceof SSLException || t instanceof CertificateException) return true;
        }
        return false;
    }

    private static CertificateInfo info(X509Certificate certificate) {
        String pem;
        try {
            pem = "-----BEGIN CERTIFICATE-----\n"
                    + Base64.getMimeEncoder(64, "\n".getBytes(StandardCharsets.US_ASCII)).encodeToString(certificate.getEncoded())
                    + "\n-----END CERTIFICATE-----";
        } catch (CertificateEncodingException e) {
            pem = null;
        }
        String subject = certificate.getSubjectX500Principal().getName();
        String issuer = certificate.getIssuerX500Principal().getName();
        return new CertificateInfo(subject, issuer, certificate.getNotAfter().toInstant().toString(), subject.equals(issuer), pem);
    }

    private WebClient webClient(AiSettings settings) {
        Connection current = connection;
        if (current != null && sameConnection(current.settings(), settings)) {
            return current.webClient();
        }
        WebClient client = build(settings);
        connection = new Connection(settings, client);
        return client;
    }

    private static WebClient build(AiSettings settings) {
        return build(settings, InsecureTrustManagerFactory.INSTANCE);
    }

    /** @param insecureTrust trust manager used when the settings skip TLS verification */
    private static WebClient build(AiSettings settings, TrustManagerFactory insecureTrust) {
        HttpClient http = HttpClient.create().option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 10_000);
        AiSettings.Proxy proxy = settings.proxy();
        if (settings.baseUrl().startsWith("https:")) {
            AiSettings.Tls tls = settings.tls();
            if (tls.skipVerify()) {
                http = http.secure(spec -> spec.sslContext(Http11SslContextSpec.forClient()
                                .configure(builder -> builder.trustManager(insecureTrust)))
                        .handlerConfigurator(handler -> {
                            SSLEngine engine = handler.engine();
                            SSLParameters parameters = engine.getSSLParameters();
                            parameters.setEndpointIdentificationAlgorithm(null);
                            engine.setSSLParameters(parameters);
                        }));
            } else if (tls.caCertificates() != null && !tls.caCertificates().isBlank()) {
                X509Certificate[] trusted = trustedCertificates(tls.caCertificates());
                http = http.secure(spec -> spec.sslContext(Http11SslContextSpec.forClient()
                        .configure(builder -> builder.trustManager(trusted))));
            }
        }
        if (proxy.active()) {
            http = http.proxy(spec -> {
                ProxyProvider.Builder builder = spec.type(ProxyProvider.Proxy.HTTP).host(proxy.host()).port(proxy.port());
                if (proxy.username() != null && !proxy.username().isBlank()) {
                    builder.username(proxy.username()).password(user -> Objects.toString(proxy.password(), ""));
                }
                String nonProxy = nonProxyHostsRegex(proxy.nonProxyHosts());
                if (nonProxy != null) {
                    builder.nonProxyHosts(nonProxy);
                }
            });
        }
        WebClient.Builder builder = WebClient.builder()
                .baseUrl(settings.baseUrl())
                .clientConnector(new ReactorClientHttpConnector(http));
        if (settings.apiKey() != null && !settings.apiKey().isBlank()) {
            builder.defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + settings.apiKey());
        }
        return builder.build();
    }

    private static boolean sameConnection(AiSettings a, AiSettings b) {
        return Objects.equals(a.baseUrl(), b.baseUrl()) && Objects.equals(a.apiKey(), b.apiKey())
                && Objects.equals(a.proxy(), b.proxy()) && Objects.equals(a.tls(), b.tls());
    }

    /**
     * Certificates of a PEM text (one or more {@code BEGIN CERTIFICATE} blocks).
     *
     * @throws IllegalArgumentException when there is no valid certificate
     */
    static List<X509Certificate> certificates(String pem) {
        // block by block: exports (e.g. "Bag Attributes" of a keychain or openssl) put text between the certificates,
        // and the parser of the whole text would stop at the first of them
        Matcher blocks = PEM_BLOCK.matcher(pem);
        List<X509Certificate> certificates = new ArrayList<>();
        try {
            CertificateFactory factory = CertificateFactory.getInstance("X.509");
            while (blocks.find()) {
                certificates.add((X509Certificate) factory.generateCertificate(
                        new ByteArrayInputStream(blocks.group().getBytes(StandardCharsets.US_ASCII))));
            }
        } catch (CertificateException e) {
            throw new IllegalArgumentException(e.getMessage(), e);
        }
        if (certificates.isEmpty()) {
            throw new IllegalArgumentException("no certificate found");
        }
        return certificates;
    }

    /** The JVM default trusted CAs plus the given ones, so public certificates keep working. */
    private static X509Certificate[] trustedCertificates(String pem) {
        List<X509Certificate> trusted = new ArrayList<>(certificates(pem));
        try {
            TrustManagerFactory factory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            factory.init((KeyStore) null);
            for (TrustManager manager : factory.getTrustManagers()) {
                if (manager instanceof X509TrustManager x509) {
                    trusted.addAll(Arrays.asList(x509.getAcceptedIssuers()));
                }
            }
        } catch (GeneralSecurityException e) {
            log.warn("JVM default trusted certificates not loaded: {}", e.getMessage());
        }
        return trusted.toArray(X509Certificate[]::new);
    }

    /** "localhost|*.corp.pl, 10.0.0.1" -> regex as reactor-netty expects. */
    static String nonProxyHostsRegex(String hosts) {
        if (hosts == null || hosts.isBlank()) return null;
        String regex = Arrays.stream(hosts.split("[|,;\\s]+"))
                .filter(it -> !it.isBlank())
                .map(it -> it.replace(".", "\\.").replace("*", ".*"))
                .collect(Collectors.joining("|"));
        return regex.isEmpty() ? null : regex;
    }

    private static String describe(Throwable e) {
        if (e instanceof org.springframework.web.reactive.function.client.WebClientResponseException r) {
            String body = r.getResponseBodyAsString();
            return r.getStatusCode().value() + " " + (body.length() > 300 ? body.substring(0, 300) : body);
        }
        return e.getClass().getSimpleName() + ": " + e.getMessage();
    }
}
