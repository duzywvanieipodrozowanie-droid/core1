package pl.zenstage.core.metrics.response;

import java.time.LocalDateTime;
import java.util.List;

/**
 * An author of commits not assigned to any person: e-mail (the author's, the committer's when the commit has none),
 * name, commits in the period, the last one and the repositories; mappedPersonId when a person has this e-mail / name
 * by now (the commits were imported before it was added and keep no person).
 */
public record UnknownCommitter(String email, String name, int commits, LocalDateTime lastCommit, List<String> repositories,
                               String mappedPersonId) {
}
