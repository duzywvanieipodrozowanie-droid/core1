package pl.zenstage.core.metrics.tasktimeline;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.commit.CommitStats;
import pl.zenstage.api.commit.CommitTasks;
import pl.zenstage.api.components.PersonService;
import pl.zenstage.api.mr.Approval;
import pl.zenstage.api.mr.MergeRequest;
import pl.zenstage.api.task.History;
import pl.zenstage.api.task.Sprint;
import pl.zenstage.api.task.Task;
import pl.zenstage.api.task.User;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.ApprovalInfo;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.CommitInfo;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.Event;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.MergeRequestInfo;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.Phase;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.PhaseTime;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.Pipeline;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.Source;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.StatusChange;
import pl.zenstage.core.organization.components.OrganizationCache;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.organization.dto.Person;
import pl.zenstage.db.store.entity.git.CommitEntity;
import pl.zenstage.db.store.entity.git.MergeRequestEntity;
import pl.zenstage.db.store.entity.git.PipelineEntity;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.MergeRequestRepository;
import pl.zenstage.db.store.repository.PipelineRepository;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class TaskTimelineService {
    // MRs are linked to a task by title or merge commit; only MRs created around the task's lifetime are scanned
    private static final int MR_LOOKBACK_DAYS = 30;
    private static final Set<String> FINISHED_PIPELINE = Set.of("success", "failed", "canceled");

    /**
     * Default Jira status -> phase rules (status name contains the keyword, checked in this order).
     * Exact status names can be configured with zenstage.task-timeline.phases, e.g.
     * "ANALYSIS=IN ANALYSIS,REFINEMENT;CODING=IN PROGRESS;TEST=IN TEST,QA;WAITING=READY FOR RELEASE;DONE=DONE,LIVE".
     */
    private static final List<Map.Entry<Phase, List<String>>> DEFAULT_RULES = List.of(
            Map.entry(Phase.WAITING, List.of("READY FOR RELEASE", "READY TO RELEASE", "READY FOR DEPLOY", "READY TO DEPLOY", "TO RELEASE", "AWAITING DEPLOY")),
            Map.entry(Phase.DONE, List.of("DONE", "LIVE", "CLOSED", "RESOLVED", "RELEASED", "PRODUCTION")),
            Map.entry(Phase.REVIEW, List.of("REVIEW")),
            Map.entry(Phase.TEST, List.of("TEST", "QA", "VERIF", "UAT", "ACCEPTANCE")),
            Map.entry(Phase.ANALYSIS, List.of("ANALY", "REFINE", "GROOM", "SPECIF", "DESIGN")),
            Map.entry(Phase.CODING, List.of("PROGRESS", "DEVELOP", "DOING", "IMPLEMENT", "CODING", "IN DEV"))
    );

    private final TaskRepository taskRepository;
    private final CommitRepository commitRepository;
    private final MergeRequestRepository mergeRequestRepository;
    private final PipelineRepository pipelineRepository;
    private final OrganizationService organizationService;
    private final OrganizationCache organizationCache;
    private final PersonService personService;
    private final Map<String, Phase> configuredPhases;

    TaskTimelineService(
            TaskRepository taskRepository,
            CommitRepository commitRepository,
            MergeRequestRepository mergeRequestRepository,
            PipelineRepository pipelineRepository,
            OrganizationService organizationService,
            OrganizationCache organizationCache,
            PersonService personService,
            @Value("${zenstage.task-timeline.phases:}") String phasesConfig
    ) {
        this.taskRepository = taskRepository;
        this.commitRepository = commitRepository;
        this.mergeRequestRepository = mergeRequestRepository;
        this.pipelineRepository = pipelineRepository;
        this.organizationService = organizationService;
        this.organizationCache = organizationCache;
        this.personService = personService;
        this.configuredPhases = parsePhases(phasesConfig);
    }

    /** Empty when the task does not exist or belongs to a project the user has no access to. */
    /** Timeline, or why there is none: no such task in the database, or its project is outside the user's units. */
    public record Lookup(TaskTimelineResponse timeline, String error, List<String> projectIds) {
        static final String TASK_NOT_FOUND = "TASK_NOT_FOUND";
        static final String NO_PROJECT_ACCESS = "NO_PROJECT_ACCESS";
    }

    public Mono<Lookup> timeline(String key) {
        String taskKey = key == null ? "" : key.trim().toUpperCase(Locale.ROOT);
        return organizationService.getUserProjects()
                .defaultIfEmpty(Map.of())
                .publishOn(Schedulers.boundedElastic())
                .map(projects -> {
                    List<TaskEntity> tasks = taskRepository.findByKey(taskKey);
                    if (tasks.isEmpty()) {
                        return new Lookup(null, Lookup.TASK_NOT_FOUND, List.of());
                    }
                    return tasks.stream()
                            .filter(it -> projects.containsKey(it.getProjectId()))
                            .findFirst()
                            .map(it -> new Lookup(build(it, projects.keySet()), null, List.of()))
                            .orElseGet(() -> new Lookup(null, Lookup.NO_PROJECT_ACCESS,
                                    tasks.stream().map(TaskEntity::getProjectId).distinct().toList()));
                });
    }

    /**
     * Commits and MRs are searched in all projects of the user's units, not only the task's project: the Jira project
     * and the GitLab repositories are usually mapped to different ZenStage projects.
     */
    private TaskTimelineResponse build(TaskEntity entity, Set<String> userProjects) {
        Task task = entity.getContent();
        String key = entity.getKey();
        LocalDateTime created = Optional.ofNullable(entity.getCreated()).orElse(task.created());
        LocalDateTime now = LocalDateTime.now();

        // ---- Jira: status history -> phases ----
        List<History> histories = Optional.ofNullable(task.histories()).orElse(List.of()).stream()
                .filter(it -> it.created() != null && "status".equalsIgnoreCase(it.fieldType()))
                .sorted(Comparator.comparing(History::created))
                .toList();
        String status = histories.isEmpty() ? task.status() : histories.getFirst().from();
        LocalDateTime cursor = created;
        Map<Phase, BigDecimal> phaseHours = new EnumMap<>(Phase.class);
        Map<Phase, Set<String>> phaseStatuses = new EnumMap<>(Phase.class);
        List<StatusChange> statusChanges = new ArrayList<>();
        List<Event> events = new ArrayList<>();
        events.add(new Event(created, Source.JIRA, "CREATED", "Task created", nameOf(task.creator()), phaseOf(status)));
        for (History history : histories) {
            BigDecimal hours = hours(cursor, history.created());
            addPhase(phaseHours, phaseStatuses, status, hours);
            Phase toPhase = phaseOf(history.to());
            statusChanges.add(new StatusChange(history.from(), history.to(), nameOf(history.author()), history.created(), hours, toPhase));
            events.add(new Event(history.created(), Source.JIRA, "STATUS", history.from() + " → " + history.to(), nameOf(history.author()), toPhase));
            cursor = history.created();
            status = history.to();
        }
        boolean done = phaseOf(status) == Phase.DONE;
        LocalDateTime doneAt = done ? cursor : null;
        if (!done) {
            addPhase(phaseHours, phaseStatuses, status, hours(cursor, now));
        }

        // ---- GitLab: commits with the task key ----
        Pattern keyPattern = Pattern.compile("(?<![A-Z0-9-])" + Pattern.quote(key) + "(?![0-9])", Pattern.CASE_INSENSITIVE);
        Set<String> projects = new LinkedHashSet<>(userProjects);
        projects.add(entity.getProjectId());
        List<CommitEntity> commits = commitRepository.findAllMentioningTask(projects, key, created.minusDays(MR_LOOKBACK_DAYS)).stream()
                // the query also matches longer keys (MOB-91 in MOB-910) and keys outside the message
                .filter(it -> Optional.ofNullable(it.getTaskKey()).map(CommitTasks::tasks).orElse(Set.of()).contains(key)
                        || Optional.ofNullable(it.getSource()).map(Commit::message).map(m -> keyPattern.matcher(m).find()).orElse(false))
                .toList();
        Set<String> commitShas = commits.stream().map(CommitEntity::getCommitId).collect(Collectors.toSet());
        List<CommitInfo> commitInfos = commits.stream().map(it -> {
            Optional<Commit> source = Optional.ofNullable(it.getSource());
            Optional<CommitStats> stats = source.map(Commit::stats);
            return new CommitInfo(
                    it.getCommitId(),
                    source.map(Commit::title).orElse(null),
                    personName(it.getCommiterId()).or(() -> source.map(Commit::authorName)).orElse(it.getCommiterId()),
                    it.getModuleName(),
                    it.getCommitDate(),
                    stats.map(CommitStats::additions).orElse(null),
                    stats.map(CommitStats::deletions).orElse(null),
                    source.map(Commit::mergeCommit).orElse(false)
            );
        }).toList();

        // ---- GitLab: merge requests linked by title, by their merge commit or by one of their commits ----
        List<MergeRequestEntity> mrs = mergeRequestRepository
                .findByProjectIdInAndCreateDateBetween(List.copyOf(projects), created.minusDays(MR_LOOKBACK_DAYS), now)
                .stream()
                .filter(it -> it.getSource() != null)
                .filter(it -> (it.getCommitId() != null && commitShas.contains(it.getCommitId()))
                        || (it.getSource().title() != null && keyPattern.matcher(it.getSource().title()).find())
                        // MR without the key in its title: one of its commits has it
                        || Optional.ofNullable(it.getSource().commits()).orElse(List.of()).stream()
                                .anyMatch(c -> commitShas.contains(c.id()) || (c.title() != null && keyPattern.matcher(c.title()).find())))
                .sorted(Comparator.comparing(MergeRequestEntity::getCreateDate))
                .toList();
        List<MergeRequestInfo> mrInfos = mrs.stream().map(this::mergeRequestInfo).toList();

        // Review phase comes from GitLab, not from Jira: sum of pickup + review time of the task's merge requests.
        // Time spent in Jira review statuses is therefore not counted in any phase.
        phaseHours.remove(Phase.REVIEW);
        phaseStatuses.remove(Phase.REVIEW);
        BigDecimal gitlabReviewMinutes = mrs.stream()
                .flatMap(it -> Stream.of(it.getPickupTimeMinutes(), it.getReviewTimeMinutes()))
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        if (gitlabReviewMinutes.signum() > 0) {
            phaseHours.put(Phase.REVIEW, minutesToHours(gitlabReviewMinutes));
            phaseStatuses.put(Phase.REVIEW, new LinkedHashSet<>(List.of("GitLab: pickup + review")));
        }
        List<PhaseTime> phases = phaseHours.entrySet().stream()
                .map(it -> new PhaseTime(it.getKey(), it.getValue(), List.copyOf(phaseStatuses.getOrDefault(it.getKey(), Set.of()))))
                .toList();

        Optional<MergeRequestEntity> mainMr = mrs.stream()
                .filter(it -> it.getSource().mergedAt() != null && !Boolean.FALSE.equals(it.getSource().targetBranchProtected()))
                .min(Comparator.comparing(it -> it.getSource().mergedAt()));
        LocalDateTime mergedAt = mainMr.map(it -> local(it.getSource().mergedAt())).orElse(null);
        LocalDateTime firstCommitAt = Stream.concat(
                commitInfos.stream().filter(it -> !it.mergeCommit()).map(CommitInfo::date),
                mrs.stream().map(it -> local(it.getSource().firstCommitAt()))
        ).filter(Objects::nonNull).min(LocalDateTime::compareTo).orElse(null);
        Pipeline pipeline = mainMr.map(this::pipeline).orElse(null);

        if (firstCommitAt != null) {
            String detail = commitInfos.stream().filter(it -> firstCommitAt.equals(it.date())).findFirst()
                    .map(it -> shortSha(it.id()) + " \"" + Optional.ofNullable(it.title()).orElse("") + "\" · " + it.repository() + " · " + it.author())
                    .orElse("first commit of the merge request");
            events.add(new Event(firstCommitAt, Source.GITLAB, "FIRST_COMMIT", "First commit", detail, Phase.CODING));
        }
        for (MergeRequestInfo mr : mrInfos) {
            events.add(new Event(mr.createdAt(), Source.GITLAB, "MR_OPENED", "MR " + mr.id() + " opened → " + Optional.ofNullable(mr.targetBranch()).orElse("?"),
                    Optional.ofNullable(mr.title()).orElse("") + " · " + mr.repository() + " · " + mr.author(), Phase.REVIEW));
            for (int i = 0; i < mr.approvals().size(); i++) {
                ApprovalInfo approval = mr.approvals().get(i);
                if (approval.at() != null) {
                    events.add(new Event(approval.at(), Source.GITLAB, "APPROVED", i == 0 ? "First approval" : "Approval",
                            approval.name() + " · MR " + mr.id(), Phase.REVIEW));
                }
            }
            if (mr.mergedAt() != null) {
                String target = Optional.ofNullable(mr.targetBranch()).orElse("?")
                        + (Boolean.TRUE.equals(mr.targetBranchProtected()) ? " (protected)" : Boolean.FALSE.equals(mr.targetBranchProtected()) ? " (not protected)" : "");
                String pipelineText = Optional.ofNullable(mr.pipeline())
                        .map(it -> " · pipeline " + it.status() + (it.minutes() != null ? " " + it.minutes() + " min" : "")).orElse("");
                events.add(new Event(mr.mergedAt(), Source.GITLAB, "MERGED", "MR " + mr.id() + " merged → " + target, mr.repository() + pipelineText, Phase.REVIEW));
            }
        }
        if (doneAt != null) {
            events.add(new Event(doneAt, Source.JIRA, "DONE", "Done: " + status, null, Phase.DONE));
        }
        events.sort(Comparator.comparing(Event::at, Comparator.nullsLast(Comparator.naturalOrder())));

        return new TaskTimelineResponse(
                key,
                entity.getProjectId(),
                task.summary(),
                task.type(),
                task.priority(),
                task.status(),
                task.url(),
                nameOf(task.assignee()),
                nameOf(task.creator()),
                task.parentKey(),
                Optional.ofNullable(task.sprints()).orElse(List.of()).stream().map(Sprint::name).filter(Objects::nonNull).distinct().toList(),
                created,
                doneAt,
                hours(created, done ? doneAt : now),
                phases,
                firstCommitAt,
                mergedAt,
                firstCommitAt != null && mergedAt != null ? hours(firstCommitAt, mergedAt) : null,
                mainMr.map(MergeRequestEntity::getPickupTimeMinutes).map(TaskTimelineService::minutesToHours).orElse(null),
                mainMr.map(MergeRequestEntity::getReviewTimeMinutes).map(TaskTimelineService::minutesToHours).orElse(null),
                pipeline,
                events,
                statusChanges,
                mrInfos,
                commitInfos
        );
    }

    private MergeRequestInfo mergeRequestInfo(MergeRequestEntity entity) {
        MergeRequest mr = entity.getSource();
        List<ApprovalInfo> approvals = Optional.ofNullable(mr.approvals())
                .map(list -> list.stream()
                        .sorted(Comparator.comparing(Approval::approvedAt, Comparator.nullsLast(Comparator.naturalOrder())))
                        .map(it -> new ApprovalInfo(personByEmail(it.email()), local(it.approvedAt())))
                        .toList())
                // older imports: approver e-mails without times, the earliest approval time is known
                .orElseGet(() -> {
                    List<String> emails = Optional.ofNullable(mr.approverEmails()).orElse(List.of());
                    List<ApprovalInfo> list = new ArrayList<>();
                    for (int i = 0; i < emails.size(); i++) {
                        list.add(new ApprovalInfo(personByEmail(emails.get(i)), i == 0 ? local(mr.approvedAt()) : null));
                    }
                    return list;
                });
        return new MergeRequestInfo(
                entity.getMrId(),
                mr.title(),
                entity.getModuleName(),
                mr.targetBranch(),
                mr.targetBranchProtected(),
                mr.state(),
                personName(entity.getAuthorId()).orElseGet(() -> Optional.ofNullable(mr.authorEmail()).orElse(entity.getAuthorId())),
                local(mr.createdAt()),
                local(mr.mergedAt()),
                local(mr.firstCommitAt()),
                Optional.ofNullable(entity.getPickupTimeMinutes()).map(TaskTimelineService::minutesToHours).orElse(null),
                Optional.ofNullable(entity.getReviewTimeMinutes()).map(TaskTimelineService::minutesToHours).orElse(null),
                mr.userNotesCount(),
                mr.changesCount(),
                approvals,
                mr.mergedAt() != null ? pipeline(entity) : null
        );
    }

    /** Last finished pipeline of the MR's merge commit, plus how many of its pipelines failed before. */
    private Pipeline pipeline(MergeRequestEntity mr) {
        if (mr.getCommitId() == null) {
            return null;
        }
        List<PipelineEntity> pipelines = pipelineRepository
                .findAllByProjectIdAndModuleNameAndCommitId(mr.getProjectId(), mr.getModuleName(), mr.getCommitId()).stream()
                .filter(it -> it.getCreateDate() != null)
                .sorted(Comparator.comparing(PipelineEntity::getCreateDate))
                .toList();
        if (pipelines.isEmpty()) {
            return null;
        }
        PipelineEntity last = pipelines.getLast();
        BigDecimal minutes = last.getUpdateDate() != null && FINISHED_PIPELINE.contains(lower(last.getStatus()))
                ? BigDecimal.valueOf(Duration.between(last.getCreateDate(), last.getUpdateDate()).toSeconds())
                .divide(BigDecimal.valueOf(60), 1, RoundingMode.HALF_UP)
                : null;
        long failedBefore = pipelines.subList(0, pipelines.size() - 1).stream().filter(it -> "failed".equals(lower(it.getStatus()))).count();
        return new Pipeline(last.getStatus(), minutes, failedBefore);
    }

    public Phase phaseOf(String status) {
        if (status == null || status.isBlank()) {
            return Phase.BACKLOG;
        }
        String normalized = status.trim().toUpperCase(Locale.ROOT);
        Phase configured = configuredPhases.get(normalized);
        if (configured != null) {
            return configured;
        }
        return DEFAULT_RULES.stream()
                .filter(rule -> rule.getValue().stream().anyMatch(normalized::contains))
                .map(Map.Entry::getKey)
                .findFirst().orElse(Phase.BACKLOG);
    }

    private void addPhase(Map<Phase, BigDecimal> hours, Map<Phase, Set<String>> statuses, String status, BigDecimal value) {
        Phase phase = phaseOf(status);
        if (phase == Phase.DONE) {
            return;
        }
        hours.merge(phase, value, BigDecimal::add);
        if (status != null) {
            statuses.computeIfAbsent(phase, k -> new LinkedHashSet<>()).add(status);
        }
    }

    private static Map<String, Phase> parsePhases(String config) {
        Map<String, Phase> result = new HashMap<>();
        if (config == null || config.isBlank()) {
            return result;
        }
        for (String group : config.split(";")) {
            String[] parts = group.split("=", 2);
            if (parts.length != 2) {
                continue;
            }
            Phase phase;
            try {
                phase = Phase.valueOf(parts[0].trim().toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                continue; // unknown phase name in the config - ignored instead of failing the startup
            }
            for (String status : parts[1].split(",")) {
                if (!status.isBlank()) {
                    result.put(status.trim().toUpperCase(Locale.ROOT), phase);
                }
            }
        }
        return result;
    }

    private Optional<String> personName(String personId) {
        return Optional.ofNullable(personId).map(organizationCache::findPerson).map(Person::name);
    }

    private String personByEmail(String email) {
        return Optional.ofNullable(email).map(personService::findAllIdsByEmails).flatMap(this::personName).orElse(email);
    }

    // Task.assignee()/creator() use the nested Task.User, History.author() the top-level User record
    private static String nameOf(Task.User user) {
        return Optional.ofNullable(user).map(Task.User::displayName).filter(it -> !it.isBlank()).orElse(null);
    }

    private static String nameOf(User user) {
        return Optional.ofNullable(user).map(User::displayName).filter(it -> !it.isBlank()).orElse(null);
    }

    private static LocalDateTime local(Instant instant) {
        return instant == null ? null : LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
    }

    private static BigDecimal hours(LocalDateTime from, LocalDateTime till) {
        if (from == null || till == null) {
            return BigDecimal.ZERO;
        }
        return BigDecimal.valueOf(Math.max(0, Duration.between(from, till).toMinutes()))
                .divide(BigDecimal.valueOf(60), 1, RoundingMode.HALF_UP);
    }

    private static BigDecimal minutesToHours(BigDecimal minutes) {
        return minutes.divide(BigDecimal.valueOf(60), 1, RoundingMode.HALF_UP);
    }

    private static String shortSha(String sha) {
        return sha == null ? "" : sha.substring(0, Math.min(8, sha.length()));
    }

    private static String lower(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT);
    }
}
