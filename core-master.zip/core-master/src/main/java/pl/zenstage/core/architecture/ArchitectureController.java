package pl.zenstage.core.architecture;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.zenstage.core.architecture.ArchitectureService.ProjectArchitecture;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.core.common.ZsCommons;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import tools.jackson.databind.JsonNode;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Architecture (C4) screen: the scanned projects of the user and the model of one; the importer sends the model. */
@RestController
@RequiredArgsConstructor
public class ArchitectureController {
    private final ArchitectureService architectureService;
    private final ArchitectureLayoutService layoutService;
    private final OrganizationService organizationService;

    /** From the importer (ZS-API-TOKEN, like the other /v1 endpoints). */
    @PutMapping(path = "/v1/architecture/{projectId}", consumes = MediaType.APPLICATION_JSON_VALUE)
    Mono<ProjectArchitecture> save(@PathVariable String projectId, @RequestBody String model) {
        return Mono.fromCallable(() -> architectureService.save(projectId, model)).subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * The same model gzip-compressed (Content-Type application/gzip): a proxy in front of core (e.g. nginx with its
     * default client_max_body_size 1m) rejects the plain JSON of a big project with 413, compressed it is ~10x smaller.
     */
    @PutMapping(path = "/v1/architecture/{projectId}", consumes = "application/gzip")
    Mono<ProjectArchitecture> saveGzip(@PathVariable String projectId, @RequestBody byte[] gzip) {
        return Mono.fromCallable(() -> {
            try (GZIPInputStream in = new GZIPInputStream(new ByteArrayInputStream(gzip))) {
                return architectureService.save(projectId, new String(in.readAllBytes(), StandardCharsets.UTF_8));
            } catch (IOException e) {
                throw new ZenStageException(HttpStatus.BAD_REQUEST, "INVALID_ARCHITECTURE", "The model is not gzip");
            }
        }).subscribeOn(Schedulers.boundedElastic());
    }

    /** The scanned projects the user works on (like the service map: projects of the user's units). */
    @GetMapping("/architecture")
    Mono<List<ProjectArchitecture>> projects() {
        return userProjects().flatMap(mine -> Mono.fromCallable(architectureService::projects)
                .subscribeOn(Schedulers.boundedElastic())
                .map(all -> all.stream().filter(it -> mine.contains(it.projectId().toLowerCase())).toList()));
    }

    @GetMapping(path = "/architecture/{projectId}", produces = MediaType.APPLICATION_JSON_VALUE)
    Mono<ResponseEntity<String>> model(@PathVariable String projectId) {
        return userProjects().flatMap(mine -> {
            if (!mine.contains(projectId.toLowerCase())) {
                return Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND).<String>build());
            }
            return Mono.fromCallable(() -> architectureService.model(projectId))
                    .subscribeOn(Schedulers.boundedElastic())
                    .map(it -> it.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build()));
        });
    }

    /** The diagrams of the project edited by hand: diagram key -> its edit. */
    @GetMapping("/architecture/{projectId}/layouts")
    Mono<ResponseEntity<Map<String, JsonNode>>> layouts(@PathVariable String projectId) {
        return ifMine(projectId, () -> layoutService.layouts(projectId));
    }

    /** Saves the edit of one diagram ({@code ?diagram=context}, {@code domain:payments}, {@code components:<id>}). */
    @PutMapping(path = "/architecture/{projectId}/layout", consumes = MediaType.APPLICATION_JSON_VALUE)
    Mono<ResponseEntity<LayoutSaved>> saveLayout(@PathVariable String projectId, @RequestParam String diagram, @RequestBody String layout) {
        return ZsCommons.currentUserName().defaultIfEmpty("").flatMap(user ->
                ifMine(projectId, () -> new LayoutSaved(diagram, layoutService.save(projectId, diagram, layout, user.isEmpty() ? null : user))));
    }

    /** Drops the edit of one diagram: the automatic layout again. */
    @DeleteMapping("/architecture/{projectId}/layout")
    Mono<ResponseEntity<LayoutSaved>> deleteLayout(@PathVariable String projectId, @RequestParam String diagram) {
        return ifMine(projectId, () -> {
            layoutService.delete(projectId, diagram);
            return new LayoutSaved(diagram, null);
        });
    }

    public record LayoutSaved(String diagram, LocalDateTime updated) {
    }

    /** The result of {@code call} for a project of the user, 404 for another one. */
    private <T> Mono<ResponseEntity<T>> ifMine(String projectId, java.util.concurrent.Callable<T> call) {
        return userProjects().flatMap(mine -> mine.contains(projectId.toLowerCase())
                ? Mono.fromCallable(call).subscribeOn(Schedulers.boundedElastic()).map(ResponseEntity::ok)
                : Mono.just(ResponseEntity.status(HttpStatus.NOT_FOUND).<T>build()));
    }

    /** Projects of the user's units; an admin sees every scanned project (also one no unit has yet). */
    private Mono<List<String>> userProjects() {
        Mono<Boolean> admin = ZsCommons.currentUser()
                .map(auth -> auth.getAuthorities().stream().anyMatch(it -> "ADMIN".equals(it.getAuthority())))
                .onErrorReturn(false);
        Flux<String> projects = admin.flatMapMany(isAdmin -> isAdmin
                ? Flux.concat(organizationService.getUserContributedProjects(),
                Mono.fromCallable(architectureService::projects).subscribeOn(Schedulers.boundedElastic())
                        .flatMapIterable(it -> it).map(ProjectArchitecture::projectId))
                : organizationService.getUserContributedProjects());
        return projects.map(String::toLowerCase).distinct().collectList();
    }
}
