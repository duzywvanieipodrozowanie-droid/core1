package pl.zenstage.core.metrics.gitlab;

import java.time.LocalDate;
import java.util.List;

/**
 * When commits are written: periods (weeks or months) x day of week x time slot of the day, in the given time zone.
 * Only non-empty cells are listed.
 */
public record CommitHeatmapResponse(
        GroupBy groupBy,
        int slotHours,
        String timeZone,
        int maxCount,
        int totalCommits,
        List<Period> periods,
        List<Cell> cells
) {
    public enum GroupBy {WEEK, MONTH}

    /** from inclusive, till exclusive. */
    public record Period(String key, LocalDate from, LocalDate till) {
    }

    /** day: 1 = Monday .. 7 = Sunday; slot: 0 = from midnight, each slotHours long. */
    public record Cell(String period, int day, int slot, int count, List<Committer> committers) {
    }

    public record Committer(String name, int count) {
    }
}
