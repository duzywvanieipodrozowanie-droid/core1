package pl.zenstage.core.codemap.response;

import java.util.List;

public record CodeMapModule(
        String projectId,
        String module,
        List<CodeMapEnv> envs
) {
}

