package pl.zenstage.core.organization.components;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import pl.zenstage.api.ProjectsMembers;
import pl.zenstage.core.common.ZsCommons;
import pl.zenstage.core.organization.dto.Person;
import pl.zenstage.core.organization.dto.ProjectScope;
import pl.zenstage.core.organization.dto.Unit;
import pl.zenstage.core.organization.dto.UnitDto;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrganizationService {
    private final OrganizationCache organization;

    public Mono<ProjectsMembers> userManageProjectsMembers(String unitId) {
        Mono<List<String>> projectsMono = userManageAllowed(unitId).flatMapIterable(this::getUnitProjects).distinct().collectList();
        Mono<List<String>> membersMono = this.userManageAllowed(unitId).flatMapIterable(Unit::unitsDeep).flatMapIterable(Unit::members).distinct().collectList();
        return projectsMono.zipWith(membersMono).map(it -> new ProjectsMembers(it.getT1(), it.getT2()));
    }

    /**
     * Reactor context key: with it set to true, {@link #userManageAllowed(String)} resolves any unit of the
     * organization without checking the current user's management rights. Used only by the organization benchmark,
     * which returns averages over all units, never one unit's data.
     */
    public static final String ORG_WIDE_ACCESS = "zs.orgWideAccess";

    public static Context orgWideAccess() {
        return Context.of(ORG_WIDE_ACCESS, Boolean.TRUE);
    }

    /** Units of the organization of the same type as the given one (e.g. all squads), the unit itself included. */
    public List<Unit> peerUnits(Unit unit) {
        return organization.getUnits().stream()
                .filter(it -> Objects.equals(normalizedType(it), normalizedType(unit)))
                .toList();
    }

    private static String normalizedType(Unit unit) {
        return unit.type() == null ? null : unit.type().trim().toLowerCase(Locale.ROOT);
    }

    public Flux<Unit> userManageAllowed(String unitId) {
        return Flux.deferContextual(ctx -> {
            if (unitId != null && ctx.getOrDefault(ORG_WIDE_ACCESS, Boolean.FALSE)) {
                return Flux.fromStream(organization.findUnit(unitId).stream());
            }
            return userManageAllowedChecked(unitId);
        });
    }

    private Flux<Unit> userManageAllowedChecked(String unitId) {
        return ZsCommons.currentUserName().flatMapMany(userId -> {
            if (unitId == null) {
                return Flux.fromStream(managedUnits(userId));
            }
            // A manager of a unit may also open any unit below it (e.g. squads under a managed chapter);
            // previously only units listing the user directly as manager were allowed, so their sub-units had no data.
            return Flux.fromStream(managedUnits(userId).flatMap(it -> it.unitsDeep().stream())
                    .filter(it -> Objects.equals(it.id(), unitId))
                    .limit(1));
        });
    }

    public Flux<Person> getManagedPeoples(String unitId) {
        return userManageAllowed(unitId).map(Unit::unitsDeep)
                .flatMapIterable(units -> {
                    List<String> ids = units.stream().flatMap(it ->
                            Stream.of(it.members(), it.managers()).filter(Objects::nonNull).flatMap(Collection::stream)
                    ).filter(Objects::nonNull).distinct().toList();
                    // a member id of the unit without a person (person.id) or a technical account is not shown
                    List<String> unknown = ids.stream().filter(id -> organization.findPerson(id) == null).toList();
                    if (!unknown.isEmpty()) {
                        log.warn("Unit {}: members without a person, left out of the team: {}", unitId, unknown);
                    }
                    return ids.stream().map(organization::findPerson).filter(Objects::nonNull).filter(it -> !it.technical())
                            .distinct()
                            .sorted(Comparator.comparing(Person::name, Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER))).toList();
                });
    }

    /** Ids of the members (not the managers) of the unit and its sub-units, when the user may open it. */
    public Mono<Set<String>> getManagedMemberIds(String unitId) {
        return userManageAllowed(unitId).map(Unit::unitsDeep)
                .flatMapIterable(units -> units.stream().map(Unit::members).filter(Objects::nonNull).flatMap(Collection::stream)
                        .filter(Objects::nonNull).toList())
                .collect(Collectors.toSet());
    }

    public Flux<UnitDto> userOrganization(String user) {
        return Mono.just(user).flatMapMany(userId -> {
                    List<Unit> units = managedUnits(userId).toList();
                    List<String> unitIds = units.stream().map(Unit::id).toList();
                    Map<Unit, String> unitsToParent = units.stream().collect(Collectors.toMap(
                            it -> it,
                            u -> organization.getParentUnits(u.id()).stream()
                                    .filter(pu -> unitIds.contains(pu.id())).findFirst().map(Unit::id).orElse("")
                    ));
                    Stream<UnitDto> rootUnits = unitsToParent.entrySet().stream().filter(it -> StringUtils.isAllBlank(it.getValue())).map(Map.Entry::getKey)
                            .map(u -> userTree(u, unitsToParent));
                    return Flux.fromStream(rootUnits);
                }
        );
    }

    private UnitDto userTree(Unit unit, Map<Unit, String> unitsToParent) {
        Stream<Unit> subunits = unitsToParent.entrySet().stream().filter(it -> Objects.equals(unit.id(), it.getValue())).map(Map.Entry::getKey);
        return new UnitDto(
                unit.id(),
                unit.name(),
                unit.type(),
                true,
                null,
                subunits.map(it -> userTree(it, unitsToParent)).toList()
        );
    }

    public Flux<UnitDto> benchmarkUnits(String userId) {
        return Flux.fromStream(parentUnits(userId).map(this::simpleAccess));
    }

    /**
     * @return Organization units available for current user
     */
    public Flux<UnitDto> getUserOrganization(String user) {
        return Mono.just(user).flatMapIterable(userId -> {
            List<Unit> managedUnits = managedUnits(userId).map(Unit::unitsDeep).flatMap(Collection::stream).distinct().toList();
            return new ArrayList<>(managedUnits.stream().map(this::managerAccess).flatMap(Collection::stream).toList());
        });
    }

    public Stream<Unit> managedUnits(String userId) {
        return organization.getUnits().stream().filter(u -> u.managers() != null)
                .filter(u -> u.managers().contains(userId));
    }

    public Stream<Unit> memberUnits(String userId) {
        return organization.getUnits().stream()
                .filter(u -> !(u.managers() != null && u.managers().contains(userId)))
                .filter(u -> u.members() != null).filter(u -> u.members().contains(userId));
    }

    private Stream<Unit> parentUnits(String userId) {
        Stream<Unit> parentUnits = Stream.concat(
                managedUnits(userId),
                memberUnits(userId)
        ).distinct();

        return parentUnits.map(Unit::id)
                .map(organization::getParentUnits).flatMap(Collection::stream).distinct()
                .sorted(Comparator.comparing(organization::level).thenComparing(Unit::name));
    }

    public Flux<Unit> getManagedOrganization(String username) {
        return Mono.justOrEmpty(username).flatMapMany(userId -> {
            List<Unit> managedUnits = managedUnits(userId).toList();
            ArrayList<Unit> target = new ArrayList<>(managedUnits);
            target.addAll(managedUnits.stream().map(Unit::unitsDeep).flatMap(List::stream).toList());
            return Flux.fromIterable(target);
        });
    }

    private UnitDto simpleAccess(Unit unit) {
        if (unit == null) return null;
        return new UnitDto(unit.id(), unit.name(), unit.type(), false, null, null);
    }

    private List<UnitDto> managerAccess(Unit unit) {
        if (unit == null) return null;
        ArrayList<UnitDto> units = new ArrayList<>();
        units.add(this.simpleAccess(unit));
        units.addAll(Optional.of(unit).map(Unit::units).orElseGet(ArrayList::new).stream().map(this::simpleAccess).toList());
        return units.stream().map(it -> new UnitDto(
                it.id(), it.name(),
                it.type(), true,
                it.members(), it.units()
        )).toList();
    }

    public Flux<String> getUserContributedProjects() {
        return getUserProjects().flatMapIterable(Map::keySet);
    }

    public Mono<Map<String, ProjectScope>> getUserProjects() {
        return ZsCommons.currentUserName().flatMap(this::getUserProjects);
    }

    public Mono<Map<String, ProjectScope>> getUserProjects(String username) {
        Flux<String> managedProjects = getManagedOrganization(username).map(this::getUnitProjects).flatMapIterable(it -> it);

        Flux<String> allProjects = getUserOrganization(username)
                .map(it -> organization.findUnit(it.id()))
                .filter(Optional::isPresent).map(Optional::get).flatMapIterable(this::getUnitProjects)
                .distinct();
        return allProjects.collectList()
                .zipWith(managedProjects.collectList())
                .map(t -> t.getT1().stream().collect(
                        Collectors.toMap(
                                it -> it,
                                it -> t.getT2().contains(it) ? ProjectScope.manager : ProjectScope.user
                        )
                ));
    }

    public Set<String> getUnitProjects(Unit unit) {
        List<String> projectsDownTree = unit.unitsDeep().stream()
                .map(Unit::projects).filter(Objects::nonNull).flatMap(Collection::stream).toList();

        Set<Unit> parentUnits = organization.getParentUnits(unit.id());

        List<String> parentProjects = parentUnits.stream().map(Unit::projects).filter(Objects::nonNull)
                .flatMap(Collection::stream).toList();

        HashSet<String> projects = new HashSet<>();
        projects.addAll(projectsDownTree);
        projects.addAll(parentProjects);
        return projects;
    }
}

