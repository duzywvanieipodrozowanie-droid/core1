package pl.zenstage.core.metrics.request;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Presets keep working as the enum did; a month and custom periods with the previous period of the same length. */
class IntervalTest {

    @Test
    void presetsByName() {
        assertSame(Interval.WEEKS_4, Interval.valueOf("WEEKS_4"));
        assertSame(Interval.MONTHS_1, Interval.valueOf("months_1"));
        assertEquals("MONTHS_3", Interval.MONTHS_3.name());
        assertEquals(7, Interval.values().length);
        Interval.Range month = Interval.MONTHS_1.range(0);
        assertEquals(LocalDate.now().plusDays(1).atStartOfDay(), month.till());
        assertEquals(LocalDate.now().plusDays(1).minusMonths(1).atStartOfDay(), month.from());
    }

    @Test
    void customPeriod() {
        Interval september = Interval.valueOf("CUSTOM_2026-09-01_2026-09-30");
        assertTrue(september.isCustom());
        assertEquals("CUSTOM_2026-09-01_2026-09-30", september.name());
        assertEquals(september, Interval.custom(LocalDate.of(2026, 9, 1), LocalDate.of(2026, 9, 30)));
        assertEquals(new Interval.Range(LocalDateTime.of(2026, 9, 1, 0, 0), LocalDateTime.of(2026, 10, 1, 0, 0)), september.range(0));
        // the previous period: the 30 days before
        assertEquals(new Interval.Range(LocalDateTime.of(2026, 8, 2, 0, 0), LocalDateTime.of(2026, 9, 1, 0, 0)), september.range(1));

        List<Interval.Range> weeks = september.rangeFinder().ranges();
        assertEquals(4, weeks.size());
        assertEquals(LocalDateTime.of(2026, 9, 1, 0, 0), weeks.get(0).from());
        assertEquals(LocalDateTime.of(2026, 10, 1, 0, 0), weeks.get(3).till());
        assertEquals(10, Interval.valueOf("CUSTOM_2026-09-01_2026-09-10").rangeFinder().ranges().size());
    }

    @Test
    void invalidPeriods() {
        assertThrows(IllegalArgumentException.class, () -> Interval.valueOf("CUSTOM_2026-09-30_2026-09-01"));
        assertThrows(IllegalArgumentException.class, () -> Interval.valueOf("CUSTOM_2020-01-01_2026-01-01"));
        assertThrows(IllegalArgumentException.class, () -> Interval.valueOf("DAYS_3"));
    }
}
