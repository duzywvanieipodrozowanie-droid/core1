package pl.zenstage.core.ai;

import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import pl.zenstage.core.organization.components.OrganizationCache;
import pl.zenstage.db.store.repository.UserConfigRepository;
import reactor.core.publisher.Mono;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/** The tool loop against a fake OpenAI-compatible server: a tool call round, then the final answer. */
class AiAssistantServiceTest {
    private final ObjectMapper objectMapper = new JsonMapper();
    private final List<JsonNode> requests = new CopyOnWriteArrayList<>();
    private HttpServer server;

    @BeforeEach
    void startServer() throws IOException {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/v1/chat/completions", exchange -> {
            JsonNode request = objectMapper.readTree(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            requests.add(request);
            String response = requests.size() == 1
                    ? """
                    {"choices":[{"message":{"role":"assistant","content":null,"tool_calls":[
                      {"id":"call_1","type":"function","function":{"name":"unit_overview","arguments":"{\\"period\\":\\"MONTHS_3\\"}"}}]}}]}"""
                    : """
                    {"choices":[{"message":{"role":"assistant","content":"<think>x</think>PR cycle 52h vs 30h average."}}]}""";
            byte[] body = response.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, body.length);
            exchange.getResponseBody().write(body);
            exchange.close();
        });
        server.start();
    }

    @AfterEach
    void stopServer() {
        server.stop(0);
    }

    @Test
    void callsToolsAndAnswers() {
        AiProperties properties = new AiProperties(true, "http://127.0.0.1:" + server.getAddress().getPort() + "/v1/",
                "secret", "gemma-4", true, 5, 0.2, Duration.ofSeconds(10));
        AiTools tools = mock(AiTools.class);
        when(tools.definitions()).thenReturn(objectMapper.createArrayNode());
        when(tools.execute(eq("unit_overview"), anyString(), any())).thenReturn(Mono.just("{\"prCycle\":52}"));
        UserConfigRepository repository = mock(UserConfigRepository.class);
        when(repository.findById(AiSettingsService.CONFIG_KEY)).thenReturn(Optional.empty());
        AiAssistantService service = new AiAssistantService(new AiSettingsService(properties, repository),
                new OpenAiClient(objectMapper), tools, objectMapper, mock(OrganizationCache.class));

        AiAssistantService.ChatResponse response = service.chat(new AiAssistantService.ChatRequest(
                        List.of(new AiAssistantService.ChatMessage("user", "Co jest nie tak?")), "squad-1", "WEEKS_4", "pl"))
                .contextWrite(ReactiveSecurityContextHolder.withAuthentication(new TestingAuthenticationToken("jan", null)))
                .block(Duration.ofSeconds(10));

        assertEquals("PR cycle 52h vs 30h average.", response.answer());
        assertEquals(List.of("unit_overview"), response.toolsUsed());
        assertEquals(2, requests.size());
        JsonNode second = requests.get(1).path("messages");
        assertEquals("system", second.get(0).path("role").asString());
        assertTrue(second.get(0).path("content").asString().contains("squad-1"));
        assertEquals("assistant", second.get(2).path("role").asString());
        assertFalse(second.get(2).path("tool_calls").isEmpty());
        assertEquals("tool", second.get(3).path("role").asString());
        assertEquals("call_1", second.get(3).path("tool_call_id").asString());
        assertEquals("{\"prCycle\":52}", second.get(3).path("content").asString());
        assertEquals("gemma-4", requests.get(0).path("model").asString());
    }
}
