package pl.zenstage.core.ai;

import org.junit.jupiter.api.Test;
import tools.jackson.databind.json.JsonMapper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Calls to the model open a tunnel (HTTP CONNECT) through the configured proxy, with the proxy credentials. */
class OpenAiClientProxyTest {
    @Test
    void connectsThroughProxy() throws Exception {
        List<String> headers = new CopyOnWriteArrayList<>();
        try (ServerSocket proxy = new ServerSocket(0)) {
            Thread.ofVirtual().start(() -> {
                while (!proxy.isClosed()) {
                    try (Socket socket = proxy.accept()) {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.US_ASCII));
                        for (String line = reader.readLine(); line != null && !line.isEmpty(); line = reader.readLine()) {
                            headers.add(line);
                        }
                        socket.getOutputStream().write("HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n".getBytes(StandardCharsets.US_ASCII));
                    } catch (Exception ignored) {
                        // socket closed at the end of the test
                    }
                }
            });
            AiSettings settings = new AiSettings(true, "http://llm.invalid/v1", "key-1", "gemma-4", true, 5, 0.2,
                    Duration.ofSeconds(10), new AiSettings.Proxy(true, "127.0.0.1", proxy.getLocalPort(), "proxy-user", "proxy-pass", null),
                    AiSettings.Tls.NONE);

            OpenAiClient.TestResult result = new OpenAiClient(new JsonMapper()).test(settings).block(Duration.ofSeconds(15));

            assertFalse(result.ok());
            String credentials = Base64.getEncoder().encodeToString("proxy-user:proxy-pass".getBytes(StandardCharsets.UTF_8));
            assertTrue(headers.stream().anyMatch(it -> it.startsWith("CONNECT llm.invalid:80")), headers.toString());
            assertTrue(headers.stream().anyMatch(it -> it.equalsIgnoreCase("proxy-authorization: Basic " + credentials)), headers.toString());
        }
    }
}
