package pl.zenstage.core.releasecheck;

import org.junit.jupiter.api.Test;
import pl.zenstage.api.task.Task;
import pl.zenstage.core.codemap.CodeMapService.EnvTag;
import pl.zenstage.core.releasecheck.ReleaseCheck.Comparison;
import pl.zenstage.core.releasecheck.ReleaseCheck.Result;
import pl.zenstage.core.releasecheck.ReleaseCheck.Row;
import pl.zenstage.db.store.entity.task.TaskEntity;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class ReleaseCheckServiceTest {
    private final LocalDateTime now = LocalDateTime.of(2026, 10, 28, 12, 0);

    private TaskEntity release(String key, List<String> fixVersions) {
        TaskEntity entity = new TaskEntity();
        entity.setProjectId("P");
        entity.setKey(key);
        entity.setContent(new Task("P", key, null, null, "Release", false, false, null, new Task.User("a", "Kasia"), null,
                "Open", List.of(), key + " summary", List.of(), null, now, now.minusDays(3),
                List.of(), List.of(), null, null, List.of(), fixVersions, null));
        return entity;
    }

    private static String results(Comparison c) {
        return c.rows().stream().map(r -> r.microservice() + "=" + r.result()).collect(Collectors.joining(", "));
    }

    @Test
    void betaAgainstTheFixVersionsOfTheRelease() {
        List<EnvTag> beta = List.of(
                new EnvTag("fxp", "payment-service", "beta", "registry/payment-service:2.4.0", "2.4.0"),
                new EnvTag("fxp", "fx-rates", "beta", "registry/fx-rates:v0.18.2", "v0.18.2"),
                new EnvTag("fxp", "card-service", "beta", "registry/card-service:3.3.1", "3.3.1"),
                new EnvTag("other", "unrelated", "beta", "registry/unrelated:1.0.0", "1.0.0"));
        Comparison c = ReleaseCheckService.compareRelease("beta",
                release("REL-418", List.of("payment-service 2.4.1", "fx-rates 0.18.2", "transfer-service 3.0.2")), beta, "REL-418");

        assertEquals("payment-service=DIFFERENT, transfer-service=MISSING, card-service=EXTRA, fx-rates=SAME", results(c));
        Row payment = c.rows().getFirst();
        assertEquals("2.4.0", payment.left().version());
        assertEquals("2.4.1", payment.right().version());
        assertEquals("payment-service 2.4.1", payment.right().fixVersion());
        assertNull(c.rows().get(1).left());
        assertEquals("3.0.2", c.rows().get(1).right().version());
        assertEquals("Kasia", c.releases().getFirst().assignee());
        assertNull(c.note());
    }

    @Test
    void releaseOutsideTheUnitIsNotFound() {
        Comparison c = ReleaseCheckService.compareRelease("beta", null, List.of(), "REL-1");
        assertEquals(List.of(), c.rows());
        assertNotNull(c.note());
    }

    @Test
    void alfaAgainstBeta() {
        List<EnvTag> alfa = List.of(
                new EnvTag("fxp", "payment-service", "alfa", "r/payment-service", "2.4.2"),
                new EnvTag("fxp", "web-app", "alfa", "r/web-app", "web-app-2026.44.2"),
                new EnvTag("fxp", "transfer-service", "alfa", "r/transfer-service", "3.0.2"));
        List<EnvTag> beta = List.of(
                new EnvTag("fxp", "payment-service", "beta", "r/payment-service", "2.4.0"),
                new EnvTag("fxp", "web-app", "beta", "r/web-app", "v2026.44.2"),
                new EnvTag("fxp", "card-service", "beta", "r/card-service", "3.3.1"));
        Comparison c = ReleaseCheckService.compareEnvironments("alfa", "beta", alfa, beta);
        assertEquals("payment-service=DIFFERENT, transfer-service=MISSING, card-service=EXTRA, web-app=SAME", results(c));
        assertEquals("2.4.2", c.rows().getFirst().left().version());
        assertEquals("2.4.0", c.rows().getFirst().right().version());
        assertEquals(List.of("alfa", "beta"), c.environmentsMatched());
        assertEquals(Result.MISSING, c.rows().get(1).result());
    }
}
