package pl.zenstage.core.metrics.team;

import org.junit.jupiter.api.Test;
import pl.zenstage.core.metrics.commits.CommitCommonsService;
import pl.zenstage.core.metrics.commits.CommitService;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.organization.dto.Person;
import pl.zenstage.api.components.PersonService;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/** The Engineers table lists every member of the unit, with zeros without activity; a manager only with activity. */
class TeamMetricsServiceTest {

    private static Person person(String id, String name) {
        return new Person(id, name, id + "@corp.pl", List.of(), false, false, null, Set.of());
    }

    @Test
    void everyMemberIsListedWithZerosWithoutActivity() {
        OrganizationService organization = mock(OrganizationService.class);
        CommitService commits = mock(CommitService.class);
        when(organization.getManagedPeoples("u")).thenReturn(Flux.just(person("anna", "Anna"), person("jan", null), person("boss", "Boss")));
        when(organization.getManagedMemberIds("u")).thenReturn(Mono.just(Set.of("anna", "jan")));
        when(commits.getCommitsByPerson("u", Interval.WEEKS_1)).thenReturn(Mono.just(Map.of()));
        when(commits.getUnitManageMrIfAllowed(any(), any())).thenReturn(Mono.just(List.of()));
        when(commits.complexityDeltas(anyList())).thenReturn(Map.of());
        TeamMetricsService service = new TeamMetricsService(mock(CommitCommonsService.class), commits, organization, mock(PersonService.class), null);

        List<TeamPerson> team = service.getTeam("u", Interval.WEEKS_1).collectList().block(Duration.ofSeconds(5));

        assertEquals(List.of("anna", "jan"), team.stream().map(TeamPerson::id).toList());
        assertEquals(0, BigDecimal.ZERO.compareTo(team.getFirst().metric().commits()));
        assertEquals(0, BigDecimal.ZERO.compareTo(team.getFirst().metric().reviews()));
    }
}
