package pl.zenstage.core.access;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import pl.zenstage.core.access.AccessService.Role;
import pl.zenstage.core.access.AccessService.UserUpdate;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.core.organization.dto.Unit;
import pl.zenstage.db.store.entity.AppUserEntity;
import pl.zenstage.db.store.entity.PersonEntity;
import pl.zenstage.db.store.entity.UserConfigEntity;
import pl.zenstage.db.store.repository.AppUserRepository;
import pl.zenstage.db.store.repository.PersonRepository;
import pl.zenstage.db.store.repository.UserConfigRepository;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/** Users and access: persons imported to app_user, live roles, page rules, the last admin stays. */
class AccessServiceTest {
    private final List<AppUserEntity> table = new ArrayList<>();
    private final Unit squad = new Unit("squad-1", "Squad 1", "squad", Set.of("anna"), Set.of("jan"), Set.of(), List.of());
    private AppUserRepository appUsers;
    private UserConfigRepository configs;
    private AccessService service;

    @BeforeEach
    void setUp() {
        appUsers = mock(AppUserRepository.class);
        when(appUsers.findAll()).thenAnswer(it -> List.copyOf(table));
        when(appUsers.saveAll(any())).thenAnswer(it -> {
            List<AppUserEntity> saved = new ArrayList<>();
            it.<Iterable<AppUserEntity>>getArgument(0).forEach(saved::add);
            table.addAll(saved);
            return saved;
        });
        when(appUsers.save(any())).thenAnswer(it -> it.getArgument(0));
        when(appUsers.findById(anyString())).thenReturn(Optional.empty());
        when(appUsers.countByAdminTrue()).thenAnswer(it -> table.stream().filter(AppUserEntity::isAdmin).count());
        PersonRepository persons = mock(PersonRepository.class);
        when(persons.findAll()).thenReturn(List.of(person("anna", true), person("jan", false), person("ola", false)));
        when(persons.findById(anyString())).thenReturn(Optional.empty());
        configs = mock(UserConfigRepository.class);
        when(configs.findById(AccessService.PAGES_CONFIG_KEY)).thenReturn(Optional.empty());
        OrganizationService organization = mock(OrganizationService.class);
        when(organization.managedUnits(anyString())).thenAnswer(it -> Stream.of(squad).filter(u -> u.managers().contains(it.<String>getArgument(0))));
        service = new AccessService(appUsers, persons, configs, organization, mock(JdbcTemplate.class));
        service.init();
    }

    private PersonEntity person(String id, boolean admin) {
        PersonEntity person = new PersonEntity();
        person.setId(id);
        person.setName(id.toUpperCase());
        person.setAdmin(admin);
        return person;
    }

    private static UserUpdate flags(Boolean admin, Boolean developer) {
        return new UserUpdate(admin, developer, null, null, null, null);
    }

    @Test
    void personsImportedWithLiveRoles() {
        assertEquals(3, table.size());
        assertEquals(Set.of(Role.ADMIN, Role.MANAGER, Role.DEVELOPER), service.roles("anna"));
        assertEquals(Set.of(Role.DEVELOPER), service.roles("jan"));
        assertEquals(List.of("Squad 1"), service.users().stream().filter(it -> it.id().equals("anna")).findFirst().orElseThrow().managedUnits());

        service.update("jan", flags(true, false));
        assertEquals(Set.of(Role.ADMIN), service.roles("jan"));

        // every role is its own flag; MANAGER also without managing a unit
        service.update("ola", new UserUpdate(null, null, true, true, true, true));
        assertEquals(EnumSet.of(Role.DEVELOPER, Role.TECH_LEAD, Role.MANAGER, Role.PO, Role.DOMAIN_LEADER), service.roles("ola"));

        // a new user at login: developer
        service.loggedIn("nowy", "Nowy User", "nowy@firma.pl");
        assertEquals(Set.of(Role.DEVELOPER), service.roles("nowy"));
    }

    @Test
    void pagesByRoles() {
        assertTrue(service.myAccess("jan").pages().contains("overview"));
        assertFalse(service.myAccess("jan").pages().contains("deliver"));
        assertFalse(service.myAccess("jan").pages().contains("product"));

        service.update("ola", new UserUpdate(null, false, null, null, true, null));
        assertTrue(service.myAccess("ola").pages().containsAll(List.of("product", "deliver", "team")));
        assertFalse(service.myAccess("ola").pages().contains("code-impact"));

        when(configs.findById(AccessService.PAGES_CONFIG_KEY))
                .thenReturn(Optional.of(new UserConfigEntity(AccessService.PAGES_CONFIG_KEY, Map.of("_version", 3, "deliver", List.of("PO"), "team", List.of()))));
        service.savePages(Map.of("deliver", Set.of(Role.PO), "team", Set.of()));
        assertEquals(Set.of(Role.PO), service.pageRoles("deliver"));
        assertTrue(service.myAccess("ola").pages().contains("deliver"));
        assertFalse(service.myAccess("jan").pages().contains("team"));
        // an admin sees everything
        service.update("jan", flags(true, null));
        assertTrue(service.myAccess("jan").pages().containsAll(List.of("team", "deliver", "code-impact")));
    }

    @Test
    void techLeadSeesDeliveryByDefault() {
        assertFalse(service.myAccess("ola").pages().contains("deliver"));
        service.update("ola", new UserUpdate(null, null, true, null, null, null));
        assertEquals(Set.of(Role.TECH_LEAD, Role.DEVELOPER), service.roles("ola"));
        assertTrue(service.myAccess("ola").pages().containsAll(List.of("team", "dora", "deliver", "task-timeline")));
        assertFalse(service.myAccess("ola").pages().contains("product"));
    }

    @Test
    void minimalRolesStoredBeforeAreSets() {
        // stored with every page and its minimal role: Deliver as ADMIN (the old default) is the default now
        when(configs.findById(AccessService.PAGES_CONFIG_KEY))
                .thenReturn(Optional.of(new UserConfigEntity(AccessService.PAGES_CONFIG_KEY, Map.of("deliver", "ADMIN", "team", "MANAGER", "code-impact", "ADMIN"))));
        service.init();
        assertEquals(service.pages().stream().filter(it -> it.key().equals("deliver")).findFirst().orElseThrow().defaultRoles(), service.pageRoles("deliver"));
        assertEquals(Set.of(Role.MANAGER), service.pageRoles("team"));
        assertEquals(Set.of(), service.pageRoles("code-impact"));
        // version 2: the minimal roles differing from the defaults
        when(configs.findById(AccessService.PAGES_CONFIG_KEY))
                .thenReturn(Optional.of(new UserConfigEntity(AccessService.PAGES_CONFIG_KEY, Map.of("_version", 2, "deliver", "ADMIN", "release", "TECH_LEAD"))));
        service.init();
        assertEquals(Set.of(), service.pageRoles("deliver"));
        assertEquals(Set.of(Role.MANAGER, Role.TECH_LEAD), service.pageRoles("release"));
    }

    @Test
    void lastAdminStays() {
        ZenStageException e = assertThrows(ZenStageException.class, () -> service.update("anna", flags(false, null)));
        assertEquals("LAST_ADMIN", e.getErrorCode());
    }
}
