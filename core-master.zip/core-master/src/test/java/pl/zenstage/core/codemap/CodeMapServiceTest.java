package pl.zenstage.core.codemap;

import org.junit.jupiter.api.Test;
import pl.zenstage.core.codemap.response.CodeMapEnv;
import pl.zenstage.core.codemap.response.CodeMapModule;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.release.EnvStateEntity;
import pl.zenstage.db.store.entity.release.ProjectEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.EnvStateRepository;
import pl.zenstage.db.store.repository.ProjectRepository;
import pl.zenstage.db.store.repository.TagRepository;
import pl.zenstage.db.store.repository.TaskRepository;
import pl.zenstage.api.task.Task;
import pl.zenstage.core.codemap.response.CodeMapIssues;
import pl.zenstage.db.store.entity.task.TaskEntity;
import reactor.core.publisher.Flux;

import java.time.Duration;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;

/** Environments of a module in the order of the project; an unknown tag gives no diff (not random commits). */
class CodeMapServiceTest {

    @Test
    void environmentsInProjectOrder() {
        EnvStateRepository envStates = mock(EnvStateRepository.class);
        when(envStates.findAllByProjectId("shop")).thenReturn(List.of(
                new EnvStateEntity("shop", "prod", "payment-service", "reg/payment", "1.2.0"),
                new EnvStateEntity("shop", "dev", "payment-service", "reg/payment", "1.4.0"),
                new EnvStateEntity("shop", "test", "payment-service", "reg/payment", "1.3.0"),
                new EnvStateEntity("shop", "dev", "cart-service", "reg/cart", "2.0.1")
        ));
        TagRepository tags = mock(TagRepository.class);
        when(tags.findById(any())).thenReturn(Optional.empty());
        CommitRepository commits = mock(CommitRepository.class);
        CodeMapService service = new CodeMapService(commits, envStates, mock(OrganizationService.class),
                mock(ProjectRepository.class), tags, mock(TaskRepository.class));

        List<CodeMapModule> modules = service.mapProject(new ProjectEntity("shop", "Shop", null,
                List.of("dev", "test", "prod"), List.of("payment-service"))).collectList().block(Duration.ofSeconds(5));

        assertEquals(List.of("payment-service", "cart-service"), modules.stream().map(CodeMapModule::module).toList());
        CodeMapModule payment = modules.getFirst();
        assertEquals(List.of("dev", "test", "prod"), payment.envs().stream().map(CodeMapEnv::name).toList());
        assertEquals(List.of("1.4.0", "1.3.0", "1.2.0"), payment.envs().stream().map(CodeMapEnv::tag).toList());
        assertTrue(payment.envs().stream().allMatch(it -> it.diff().commits().isEmpty()));
        verify(commits, never()).findTop50ByOrderByCommitDateDesc();
    }

    @Test
    void versionOfFixVersion() {
        assertEquals("1.4.2", CodeMapService.versionOf("payment-service 1.4.2", "payment-service"));
        assertEquals("1.4.2", CodeMapService.versionOf("Payment-Service-v1.4.2", "payment-service"));
        assertEquals("1.4.2", CodeMapService.versionOf("payment-service_1.4.2", "payment-service"));
        assertNull(CodeMapService.versionOf("payment-service-api 1.0.0", "payment-service"));
        assertNull(CodeMapService.versionOf("cart-service 1.4.2", "payment-service"));
    }

    @Test
    void issuesOfAVersionFromFixVersionAndReleaseTask() {
        TaskRepository tasks = mock(TaskRepository.class);
        TaskEntity story = task("p", "SHOP-1", "Story", List.of("payment-service 1.4.2"), List.of());
        TaskEntity older = task("p", "SHOP-2", "Story", List.of("payment-service 1.4.1"), List.of());
        TaskEntity release = task("p", "REL-9", "Release", List.of("payment-service v1.4.2"),
                List.of(new Task.Link("Contains", "contains", "SHOP-3", "Fix payment", "DONE")));
        TaskEntity foreign = task("other", "X-1", "Story", List.of("payment-service 1.4.2"), List.of());
        when(tasks.findByFixVersionLike("payment-service%")).thenReturn(List.of(story, older, release, foreign));
        when(tasks.findByKey(anyString())).thenReturn(List.of());
        OrganizationService organization = mock(OrganizationService.class);
        when(organization.getUserContributedProjects()).thenReturn(Flux.just("P"));
        CodeMapService service = new CodeMapService(mock(CommitRepository.class), mock(EnvStateRepository.class), organization,
                mock(ProjectRepository.class), mock(TagRepository.class), tasks);

        CodeMapIssues issues = service.issues("payment-service", "v1.4.2").block(Duration.ofSeconds(5));

        assertEquals(List.of("SHOP-1", "SHOP-3"), issues.issues().stream().map(CodeMapIssues.Issue::key).toList());
        assertEquals("REL-9", issues.issues().get(1).source());
        assertEquals(List.of("payment-service 1.4.2", "payment-service v1.4.2"), issues.fixVersions());
        assertEquals(List.of("payment-service 1.4.1"), issues.otherVersions());
    }

    private static TaskEntity task(String project, String key, String type, List<String> fixVersions, List<Task.Link> links) {
        TaskEntity entity = new TaskEntity();
        entity.setProjectId(project);
        entity.setKey(key);
        entity.setType(type);
        entity.setContent(new Task(project, key, null, null, type, null, null, null, null, null, "DONE", List.of(), key,
                List.of(), null, null, null, List.of(), List.of(), null, null, links, fixVersions, null));
        return entity;
    }
}
