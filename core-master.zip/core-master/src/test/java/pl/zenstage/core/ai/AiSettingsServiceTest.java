package pl.zenstage.core.ai;

import org.junit.jupiter.api.Test;
import pl.zenstage.core.common.ZenStageException;
import pl.zenstage.db.store.entity.UserConfigEntity;
import pl.zenstage.db.store.repository.UserConfigRepository;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class AiSettingsServiceTest {
    private final AiProperties defaults = new AiProperties(false, "http://localhost:8080/v1", "default-key", "gemma-4",
            true, 5, 0.2, Duration.ofSeconds(120));

    private AiSettingsService service(Map<String, Object> stored) {
        UserConfigRepository repository = mock(UserConfigRepository.class);
        when(repository.findById(AiSettingsService.CONFIG_KEY))
                .thenReturn(stored == null ? Optional.empty() : Optional.of(new UserConfigEntity(AiSettingsService.CONFIG_KEY, stored)));
        return new AiSettingsService(defaults, repository);
    }

    private static AiSettingsService.Form form(String baseUrl, String apiKey, String proxyPassword) {
        return new AiSettingsService.Form(true, baseUrl, apiKey, null, null, null, null, null,
                true, "proxy.corp", 3128, "user", proxyPassword, "localhost|*.corp.pl", null, null);
    }

    @Test
    void storedValuesOverrideDefaults() {
        AiSettings settings = service(Map.of("enabled", true, "baseUrl", "https://llm.corp/v1", "apiKey", "stored-key",
                "proxyEnabled", true, "proxyHost", "proxy", "proxyPort", 8080)).current();
        assertTrue(settings.enabled());
        assertEquals("https://llm.corp/v1", settings.baseUrl());
        assertEquals("stored-key", settings.apiKey());
        assertEquals("gemma-4", settings.model());
        assertTrue(settings.proxy().active());
    }

    @Test
    void secretsAreKeptWhenNotSentAndNeverShown() {
        AiSettingsService service = service(null);
        AiSettings kept = service.preview(form("https://llm.corp/v1/", null, "pass"));
        assertEquals("default-key", kept.apiKey());
        assertEquals("https://llm.corp/v1", kept.baseUrl());
        assertEquals("pass", kept.proxy().password());
        assertNull(service.preview(form("https://llm.corp/v1", "", null)).apiKey());
        assertEquals("new-key-123456", service.preview(form("https://llm.corp/v1", "new-key-123456", null)).apiKey());

        AiSettingsService.View view = service.view();
        assertTrue(view.apiKeySet());
        assertFalse(view.apiKeyMasked().contains("default"));
    }

    @Test
    void rejectsInvalidUrl() {
        assertThrows(ZenStageException.class, () -> service(null).preview(form("llm.corp/v1", null, null)));
    }

    @Test
    void caCertificatesAreValidatedKeptAndCleared() throws Exception {
        String pem;
        try (var in = getClass().getResourceAsStream("/ai/llm-test-ca.pem")) {
            pem = new String(in.readAllBytes(), StandardCharsets.US_ASCII);
        }
        AiSettingsService service = service(Map.of("caCertificates", pem, "tlsSkipVerify", true));
        assertEquals(pem, service.current().tls().caCertificates());
        assertTrue(service.current().tls().skipVerify());
        assertEquals(java.util.List.of("CN=localhost"), service.view().caSubjects());

        AiSettingsService.Form keep = form("https://llm.corp/v1", null, null);
        assertEquals(pem, service.preview(keep).tls().caCertificates());
        AiSettingsService.Form clear = new AiSettingsService.Form(null, null, null, null, null, null, null, null,
                null, null, null, null, null, null, "", false);
        assertNull(service.preview(clear).tls().caCertificates());
        assertFalse(service.preview(clear).tls().skipVerify());
        AiSettingsService.Form invalid = new AiSettingsService.Form(null, null, null, null, null, null, null, null,
                null, null, null, null, null, null, "-----BEGIN CERTIFICATE-----\nxyz\n-----END CERTIFICATE-----", null);
        assertThrows(ZenStageException.class, () -> service.preview(invalid));
    }

    @Test
    void nonProxyHostsToRegex() {
        assertEquals("localhost|.*\\.corp\\.pl|10\\.0\\.0\\.1", OpenAiClient.nonProxyHostsRegex("localhost | *.corp.pl, 10.0.0.1"));
        assertNull(OpenAiClient.nonProxyHostsRegex(" "));
    }
}
