package pl.zenstage.core.ai;

import org.junit.jupiter.api.Test;
import pl.zenstage.api.ProjectsMembers;
import pl.zenstage.api.task.History;
import pl.zenstage.api.task.Task;
import pl.zenstage.core.codemap.CodeMapService;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.Phase;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineService;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Mono;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/** jira_work_in_progress: open items with days in status, items finished in the period; epics are left out. */
class AiToolsJiraTest {
    private final ObjectMapper objectMapper = new JsonMapper();
    private final LocalDateTime now = LocalDateTime.now();

    private TaskEntity task(String key, String type, String status, String assignee, LocalDateTime created, History... history) {
        TaskEntity entity = new TaskEntity();
        entity.setProjectId("P");
        entity.setKey(key);
        entity.setCreated(created);
        entity.setContent(new Task("P", key, null, null, type, false, false, null,
                assignee == null ? null : new Task.User(assignee, assignee), null, status, List.of(), key + " summary",
                List.of(), null, now, created, List.of(history), List.of(), null, null, null, null, null));
        return entity;
    }

    private History status(String from, String to, LocalDateTime at) {
        return new History("status", from, to, at, null);
    }

    @Test
    void workInProgressFromJira() {
        OrganizationService organization = mock(OrganizationService.class);
        when(organization.userManageProjectsMembers("squad-1")).thenReturn(Mono.just(new ProjectsMembers(List.of("P"), List.of())));
        TaskTimelineService timeline = mock(TaskTimelineService.class);
        Map<String, Phase> phases = Map.of("In Progress", Phase.CODING, "In Review", Phase.REVIEW, "Done", Phase.DONE, "To Do", Phase.BACKLOG);
        when(timeline.phaseOf(anyString())).thenAnswer(it -> phases.getOrDefault(it.<String>getArgument(0), Phase.BACKLOG));
        TaskRepository repository = mock(TaskRepository.class);
        when(repository.findByProjectIdInAndUpdatedAfter(eq(List.of("P")), any())).thenReturn(List.of(
                task("P-1", "Story", "In Progress", "Anna", now.minusDays(20), status("To Do", "In Progress", now.minusDays(8))),
                task("P-2", "Bug", "In Review", "Jan", now.minusDays(3), status("In Progress", "In Review", now.minusDays(1))),
                task("P-3", "Story", "Done", "Jan", now.minusDays(12), status("In Review", "Done", now.minusDays(2))),
                task("P-4", "Story", "To Do", null, now.minusDays(1)),
                task("P-5", "Epic", "In Progress", "Anna", now.minusDays(60)),
                task("P-6", "Production defect", "To Do", null, now.minusDays(9)),
                task("P-7", "Bug", "Done", "Jan", now.minusDays(4))));
        AiTools tools = new AiTools(objectMapper, organization, null, null, null, null, null, timeline, repository, null);

        String json = tools.execute("jira_work_in_progress", "{}", new AiTools.Context("squad-1", Interval.WEEKS_4))
                .block(Duration.ofSeconds(5));
        JsonNode result = objectMapper.readTree(json);

        assertEquals(2, result.path("openItems").asInt(), json);
        assertEquals("P-1", result.path("openItemsLongestInStatus").path(0).path("key").asString());
        assertEquals(8, result.path("openItemsLongestInStatus").path(0).path("daysInStatus").asInt());
        assertEquals(1, result.path("staleItems (>5 days in status)").asInt());
        assertEquals(1, result.path("openByAssignee").path("Jan").asInt());
        assertEquals(1, result.path("finishedInPeriod").asInt(), json);
        assertEquals(2, result.path("openDefects").asInt(), json);
        assertEquals(1, result.path("openProductionDefects").asInt());
        assertEquals("P-6", result.path("openDefectsOldestFirst").path(0).path("key").asString());
        assertEquals(1, result.path("staleByAssignee").path("Anna").asInt());
        assertEquals(10.0, result.path("avgLeadTimeDaysOfFinished").asDouble());

        // no unit selected: all the units the user manages
        when(organization.userManageProjectsMembers(null)).thenReturn(Mono.just(new ProjectsMembers(List.of("P"), List.of())));
        JsonNode all = objectMapper.readTree(tools.execute("jira_work_in_progress", "{}", new AiTools.Context(null, Interval.WEEKS_4))
                .block(Duration.ofSeconds(5)));
        assertEquals(2, all.path("openItems").asInt(), all.toString());
    }

    @Test
    void releasesWithDeployedIssuesAndMicroservices() {
        OrganizationService organization = mock(OrganizationService.class);
        when(organization.userManageProjectsMembers("squad-1")).thenReturn(Mono.just(new ProjectsMembers(List.of("P"), List.of())));
        TaskRepository repository = mock(TaskRepository.class);
        TaskEntity older = release("R-1", now.minusDays(10), List.of(new Task.Link("Contains", "contains", "P-1", "Login", "LIVE")),
                List.of("auth-service 1.4.0"));
        TaskEntity newer = release("R-2", now.minusDays(2), List.of(
                new Task.Link("Contains", "contains", "P-2", "Payments", "LIVE"),
                new Task.Link("Contains", "is contained in", "P-9", "Parent", "Open"),
                new Task.Link("Relates", "relates to", "P-3", "Other", "Open")), List.of("payment-service 2.1.0", "gateway 3.0.1"));
        TaskEntity planned = release("R-3", null, List.of(), List.of("auth-service 1.5.0"));
        when(repository.findByProjectIdInAndUpdatedAfter(eq(List.of("P")), any())).thenReturn(List.of(older, newer, planned,
                task("P-1", "Story", "Done", "Jan", now.minusDays(20))));
        AiTools tools = new AiTools(objectMapper, organization, null, null, null, null, null, null, repository, null);

        String json = tools.execute("jira_releases", "{}", new AiTools.Context("squad-1", Interval.WEEKS_1)).block(Duration.ofSeconds(5));
        JsonNode result = objectMapper.readTree(json);

        assertEquals(2, result.path("releasesLive").asInt(), json);
        assertEquals(1, result.path("releasesLiveInPeriod").asInt(), json);
        JsonNode last = result.path("releasesNewestFirst").path(0);
        assertEquals("R-2", last.path("key").asString());
        assertEquals(3, last.path("deployedIssues").size(), json);
        assertEquals("P-2", last.path("deployedIssues").path(0).path("key").asString());
        assertEquals("payment-service", last.path("microservices").path(0).asString());
        assertEquals("gateway", last.path("microservices").path(1).asString());
        assertEquals("payment-service 2.1.0", last.path("fixVersions").path(0).asString());
        assertEquals("R-3", result.path("releasesNotLiveYet").path(0).path("key").asString());
    }

    @Test
    void microserviceNameFromFixVersion() {
        assertEquals("payment-service", AiTools.microservice("payment-service 2.1.0"));
        assertEquals("auth-service", AiTools.microservice("auth-service-1.4.0"));
        assertEquals("gateway", AiTools.microservice("gateway v3.0.1-RC1"));
        assertEquals("oauth2", AiTools.microservice("oauth2"));
        assertEquals("billing", AiTools.microservice("billing"));
    }

    private TaskEntity release(String key, LocalDateTime liveAt, List<Task.Link> links, List<String> fixVersions) {
        TaskEntity entity = new TaskEntity();
        entity.setProjectId("P");
        entity.setKey(key);
        List<History> history = liveAt == null ? List.of(status("To Do", "UAT", now.minusDays(1)))
                : List.of(status("UAT", "LIVE", liveAt));
        entity.setContent(new Task("P", key, null, null, "Release", false, false, null, null, null,
                liveAt == null ? "UAT" : "LIVE", List.of(), key + " summary", List.of(), null, now, now.minusDays(30),
                history, List.of(), null, null, links, fixVersions, null));
        return entity;
    }

    @Test
    void openReleaseComparedWithBeta() {
        TaskEntity open = release("R-5", null, List.of(), List.of("payment-service 2.1.0", "gateway v3.0.1", "auth-service 1.5.0", "orders-service-api 1.0.0"));
        List<CodeMapService.EnvTag> beta = List.of(
                new CodeMapService.EnvTag("fxp", "payment-service", "beta", "registry/payment-service", "2.0.9"),
                new CodeMapService.EnvTag("fxp", "gateway", "beta", "registry/gateway", "gateway-3.0.1"),
                new CodeMapService.EnvTag("fxp", "orders-service", "beta", "registry/orders-service", "1.0.0"));
        Map<String, Object> result = AiTools.compareReleases(List.of(open), beta, "beta");
        JsonNode json = objectMapper.valueToTree(result);
        assertEquals(1, json.path("different").asInt(), json.toString());
        assertEquals(2, json.path("missing").asInt(), json.toString());
        assertEquals(1, json.path("same").asInt(), json.toString());
        JsonNode first = json.path("comparison").path(0);
        assertEquals("payment-service", first.path("microservice").asString());
        assertEquals("2.1.0", first.path("releaseVersion").asString());
        assertEquals("2.0.9", first.path("environmentTag").asString());
        assertEquals("DIFFERENT", first.path("result").asString());
        // "orders-service-api" is another microservice than "orders-service" on beta
        assertTrue(json.path("comparison").findValuesAsString("fixVersion").contains("orders-service-api 1.0.0"));
        assertEquals("MISSING", json.path("comparison").path(2).path("result").asString(), json.toString());
    }

    @Test
    void releaseAgainstEnvironmentQuestionsAreRecognized() {
        assertTrue(AiAssistantService.isReleaseVsEnvironment("Porównaj taska release z tym co jest na becie"));
        assertTrue(AiAssistantService.isReleaseVsEnvironment("które obrazy na beta różnią się od release?"));
        assertTrue(AiAssistantService.isReleaseVsEnvironment("Compare the release fix versions with tags on beta"));
        assertFalse(AiAssistantService.isReleaseVsEnvironment("Kiedy był ostatni release?"));
    }

    @Test
    void jiraQuestionsAreRecognized() {
        assertTrue(AiAssistantService.isAboutReleases("Kiedy był ostatni release?"));
        assertTrue(AiAssistantService.isAboutReleases("które mikroserwisy weszły na produkcję"));
        assertFalse(AiAssistantService.isAboutReleases("Który epic jest na ryzyku?"));
        assertTrue(AiAssistantService.isAboutJira("Który epic jest na ryzyku?"));
        assertTrue(AiAssistantService.isAboutJira("które zadania długo stoją w jednym statusie"));
        assertFalse(AiAssistantService.isAboutJira("Jaki jest cycle time PR?"));
        assertTrue(AiAssistantService.isBriefing("Daj status na początek dnia"));
        assertFalse(AiAssistantService.isBriefing("Co jest nie tak w tym zespole?"));
    }
}
