package pl.zenstage.core.architecture;

import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import pl.zenstage.core.common.ZenStageException;
import tools.jackson.databind.json.JsonMapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** The model of the importer is stored as is (insert first, update later); anything else is refused. */
class ArchitectureServiceTest {

    @Test
    void savesValidModelOnly() {
        JdbcTemplate jdbc = mock(JdbcTemplate.class);
        when(jdbc.update(anyString(), any(), any(), any())).thenReturn(0);
        ArchitectureService service = new ArchitectureService(jdbc, JsonMapper.builder().build());

        assertEquals("fxp", service.save("fxp", "{\"containers\":[{\"id\":\"payment-service\"}],\"links\":[]}").projectId());
        verify(jdbc).update(eq("INSERT INTO architecture (project_id, content, updated) VALUES (?, ?, ?)"), eq("fxp"),
                eq("{\"containers\":[{\"id\":\"payment-service\"}],\"links\":[]}"), any());

        ZenStageException notJson = assertThrows(ZenStageException.class, () -> service.save("fxp", "not json"));
        assertEquals("INVALID_ARCHITECTURE", notJson.getErrorCode());
        assertThrows(ZenStageException.class, () -> service.save("fxp", "{\"containers\":[]}"));
    }
}
