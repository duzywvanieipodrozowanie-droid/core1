package pl.zenstage.core.metrics.flow;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Work items counted in flow metrics: release tasks only mark deployments and are left out. */
class FlowServiceCountedTypeTest {

    @Test
    void releaseTasksAreNotCounted() {
        assertFalse(FlowService.countedType("Release"));
        assertFalse(FlowService.countedType("Release Request"));
        assertFalse(FlowService.countedType("Sub-Task"));
        assertFalse(FlowService.countedType("Epic"));
        assertTrue(FlowService.countedType("Story"));
        assertTrue(FlowService.countedType("Production defect"));
    }
}
