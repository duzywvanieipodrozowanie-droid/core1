package pl.zenstage.core.metrics.dora;

import org.junit.jupiter.api.Test;
import pl.zenstage.api.task.History;
import pl.zenstage.api.task.Task;
import pl.zenstage.core.investments.TaskCommonsService;
import pl.zenstage.core.investments.TaskService;
import pl.zenstage.core.metrics.request.Interval;
import pl.zenstage.core.metrics.response.ChartResponse;
import pl.zenstage.db.store.entity.task.TaskEntity;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/** Deployment frequency: Jira release tasks moved to LIVE, each counted once, per day. */
class DoraServiceDeploymentTest {
    private final LocalDate today = LocalDate.now();

    private TaskEntity task(String key, String type, History... history) {
        TaskEntity entity = new TaskEntity();
        entity.setProjectId("P");
        entity.setKey(key);
        entity.setContent(new Task("P", key, null, null, type, false, false, null, null, null, "LIVE", List.of(),
                key, List.of(), null, null, null, List.of(history), List.of(), null, null, null, null, null));
        return entity;
    }

    private History live(LocalDateTime at) {
        return new History("status", "UAT", "LIVE", at, null);
    }

    @Test
    void countsReleaseTasksMovedToLivePerDay() {
        LocalDateTime twoDaysAgo = today.minusDays(2).atTime(10, 0);
        TaskService taskService = mock(TaskService.class);
        when(taskService.getUnitTasksUpdatedSince(eq("squad-1"), any())).thenReturn(Mono.just(List.of(
                task("R-1", "Release", live(twoDaysAgo)),
                task("R-2", "Release", live(twoDaysAgo.plusMinutes(20))),
                // back to LIVE again after a rollback: still one release
                task("R-3", "Release Request", live(today.atTime(9, 0)), live(today.atTime(11, 0))),
                // stories going LIVE are not deployments
                task("S-1", "Story", live(today.atTime(9, 0))),
                // went LIVE before the period
                task("R-4", "Release", live(today.minusDays(30).atStartOfDay())))));
        TaskCommonsService commons = mock(TaskCommonsService.class);
        when(commons.liveTransitions(any(), any())).thenCallRealMethod();
        DoraService service = new DoraService(taskService, null, commons);

        assertEquals(BigDecimal.valueOf(3), service.development("squad-1", Interval.WEEKS_1.range(0)).block(Duration.ofSeconds(5)));

        ChartResponse<DoraChartTimeRecord> chart = service.chartDeployment("squad-1", Interval.WEEKS_1).block(Duration.ofSeconds(5));
        assertEquals(7, chart.values().size());
        assertEquals(today, chart.values().getLast().startDate());
        assertEquals(1, chart.values().getLast().value());
        assertEquals(2, chart.values().get(4).value());
        assertEquals(3, chart.sum().value());
    }
}
