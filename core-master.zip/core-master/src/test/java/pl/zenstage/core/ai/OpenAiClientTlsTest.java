package pl.zenstage.core.ai;

import com.sun.net.httpserver.HttpsConfigurator;
import com.sun.net.httpserver.HttpsServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import tools.jackson.databind.json.JsonMapper;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** An https model server with a certificate the JVM does not trust (like a company CA). */
class OpenAiClientTlsTest {
    private HttpsServer server;
    private String caPem;

    @BeforeEach
    void startServer() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("PKCS12");
        try (InputStream in = getClass().getResourceAsStream("/ai/llm-test.p12")) {
            keyStore.load(in, "changeit".toCharArray());
        }
        try (InputStream in = getClass().getResourceAsStream("/ai/llm-test-ca.pem")) {
            caPem = new String(in.readAllBytes(), StandardCharsets.US_ASCII);
        }
        KeyManagerFactory keyManagers = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        keyManagers.init(keyStore, "changeit".toCharArray());
        SSLContext ssl = SSLContext.getInstance("TLS");
        ssl.init(keyManagers.getKeyManagers(), null, null);

        server = HttpsServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.setHttpsConfigurator(new HttpsConfigurator(ssl));
        server.createContext("/v1/", exchange -> {
            String response = exchange.getRequestURI().getPath().endsWith("/models")
                    ? "{\"data\":[{\"id\":\"gemma-4\"}]}"
                    : "{\"choices\":[{\"message\":{\"role\":\"assistant\",\"content\":\"OK\"}}]}";
            byte[] body = response.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, body.length);
            exchange.getResponseBody().write(body);
            exchange.close();
        });
        server.start();
    }

    @AfterEach
    void stopServer() {
        server.stop(0);
    }

    private OpenAiClient.TestResult test(String host, AiSettings.Tls tls) {
        AiSettings settings = new AiSettings(true, "https://" + host + ":" + server.getAddress().getPort() + "/v1", "key-1",
                "gemma-4", true, 5, 0.2, Duration.ofSeconds(10), AiSettings.Proxy.NONE, tls);
        return new OpenAiClient(new JsonMapper()).test(settings).block(Duration.ofSeconds(15));
    }

    @Test
    void untrustedCertificateFails() {
        OpenAiClient.TestResult result = test("localhost", AiSettings.Tls.NONE);
        assertFalse(result.ok());
        assertTrue(result.error().contains("PKIX") || result.error().contains("certificate"), result.error());
        // the presented chain is returned, ready to be trusted
        assertEquals(1, result.serverCertificates().size());
        OpenAiClient.CertificateInfo certificate = result.serverCertificates().getFirst();
        assertEquals("CN=localhost", certificate.subject());
        assertTrue(certificate.selfSigned());
        assertTrue(result.tlsHints().getFirst().contains("CN=localhost"), result.tlsHints().toString());
        assertTrue(test("localhost", new AiSettings.Tls(certificate.pem(), false)).ok());
    }

    @Test
    void trustsTheGivenCaCertificate() {
        OpenAiClient.TestResult result = test("localhost", new AiSettings.Tls(caPem, false));
        assertTrue(result.ok(), result.error());
        assertEquals("OK", result.reply());
        assertEquals(List.of("gemma-4"), result.models());
        assertTrue(result.serverCertificates().isEmpty());
    }

    @Test
    void skipVerifyAcceptsAnyCertificateAndHost() {
        // the certificate is issued for "localhost" only, so host name verification has to be off as well
        OpenAiClient.TestResult result = test("127.0.0.1", new AiSettings.Tls(null, true));
        assertTrue(result.ok(), result.error());
    }

    @Test
    void diagnosesAWrongCaAndAWrongHostName() {
        java.security.cert.X509Certificate server = OpenAiClient.certificates(caPem).getFirst();
        // the CA given is the one presented: trust is fine
        assertTrue(OpenAiClient.diagnose("localhost", List.of(server), new AiSettings.Tls(caPem, false)).getFirst().contains("pasuje"));

        List<String> hints = OpenAiClient.diagnose("127.0.0.1", List.of(server), new AiSettings.Tls(null, false));
        assertTrue(hints.getFirst().contains("localhost") && hints.getFirst().contains("127.0.0.1"), hints.toString());
        assertTrue(hints.get(1).contains("Nie ma zapisanego"), hints.toString());
        assertTrue(OpenAiClient.hostMatches("*.corp.pl", "llm.corp.pl"));
        assertFalse(OpenAiClient.hostMatches("*.corp.pl", "a.llm.corp.pl"));
    }

    @Test
    void readsEveryCertificateOfAnExportWithTextBetween() {
        String body = caPem.substring(caPem.indexOf("-----BEGIN"), caPem.indexOf("-----END CERTIFICATE-----") + 25);
        String export = "Bag Attributes\n    friendlyName: Company Root\nsubject=/CN=x\n" + body
                + "\nBag Attributes\n    friendlyName: Company Issuing\n" + body + "\n";
        assertEquals(2, OpenAiClient.certificates(export).size());
    }

    @Test
    void invalidPemIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> OpenAiClient.certificates("not a certificate"));
        assertEquals(1, OpenAiClient.certificates(caPem).size());
    }
}
