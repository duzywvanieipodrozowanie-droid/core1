package pl.zenstage.core.metrics.commits;

import org.junit.jupiter.api.Test;
import pl.zenstage.api.commit.Commit;
import pl.zenstage.core.metrics.response.UnknownCommitter;
import pl.zenstage.db.store.entity.git.CommitEntity;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/** Unknown committers are the authors of the commits without a person, grouped by the author's e-mail. */
class GitlabCommitersServiceTest {
    private final LocalDateTime now = LocalDateTime.now();

    private CommitEntity commit(String id, String module, String authorName, String authorEmail, String committerEmail, LocalDateTime at) {
        Commit source = new Commit(id, "p", module, false, "t", authorName, authorEmail, "GitLab", committerEmail,
                null, null, "m", List.of(), null, null, null);
        return new CommitEntity("p", module, id, null, at, null, source);
    }

    @Test
    void groupsByTheAuthorNotTheCommitter() {
        List<UnknownCommitter> result = GitlabCommitersService.unknown(List.of(
                commit("1", "orders", "Jan Nowak", "jan@corp.pl", "noreply@gitlab.com", now.minusDays(3)),
                commit("2", "payments", "Jan Nowak", "JAN@corp.pl", null, now.minusDays(1)),
                commit("3", "orders", "Ewa", "ewa@corp.pl", "ewa@corp.pl", now.minusDays(2)),
                commit("4", "orders", null, null, "bot@corp.pl", now.minusDays(2))),
                Map.of("ewa@corp.pl", "ewa.k"));
        assertEquals(3, result.size());
        assertEquals("jan@corp.pl", result.getFirst().email());
        assertEquals(2, result.getFirst().commits());
        assertEquals(List.of("orders", "payments"), result.getFirst().repositories());
        assertEquals(now.minusDays(1), result.getFirst().lastCommit());
        assertNull(result.getFirst().mappedPersonId());
        // a person with this e-mail was added after the import
        assertEquals("ewa.k", result.stream().filter(it -> "ewa@corp.pl".equals(it.email())).findFirst().orElseThrow().mappedPersonId());
        // no author: the committer's e-mail
        assertEquals(1, result.stream().filter(it -> "bot@corp.pl".equals(it.email())).count());
    }
}
