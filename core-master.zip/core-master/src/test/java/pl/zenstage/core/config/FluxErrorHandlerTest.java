package pl.zenstage.core.config;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import pl.zenstage.core.common.ZenStageException;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FluxErrorHandlerTest {

    @Test
    void writesTheStatusAndMessageOfZenStageException() {
        MockServerWebExchange exchange = MockServerWebExchange.from(MockServerHttpRequest.post("/ai/chat"));

        new FluxErrorHandler().handle(exchange, new ZenStageException(HttpStatus.BAD_GATEWAY, "AI_ERROR", "AI model error: 404"))
                .block(Duration.ofSeconds(5));

        assertEquals(HttpStatus.BAD_GATEWAY, exchange.getResponse().getStatusCode());
        String body = exchange.getResponse().getBodyAsString().block(Duration.ofSeconds(5));
        assertTrue(body.contains("\"error\":\"AI_ERROR\""), body);
        assertTrue(body.contains("\"content\":\"AI model error: 404\""), body);
    }
}
