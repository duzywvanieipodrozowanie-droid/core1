package pl.zenstage.core.metrics.deliver;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import pl.zenstage.api.ProjectsMembers;
import pl.zenstage.api.task.History;
import pl.zenstage.api.task.Task;
import pl.zenstage.core.metrics.deliver.DeliverResponse.Burnup;
import pl.zenstage.core.metrics.deliver.DeliverResponse.EpicSummary;
import pl.zenstage.core.metrics.deliver.DeliverResponse.Health;
import pl.zenstage.core.metrics.roadmap.RoadmapStore;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineResponse.Phase;
import pl.zenstage.core.metrics.tasktimeline.TaskTimelineService;
import pl.zenstage.core.organization.components.OrganizationService;
import pl.zenstage.db.store.entity.task.TaskEntity;
import pl.zenstage.db.store.repository.CommitRepository;
import pl.zenstage.db.store.repository.TaskRepository;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/** Deliver health: progress weighted by the phase of the work items, the plan, warning signals; the unit's burn-up. */
class DeliverServiceHealthTest {
    private static final int MAX_FORECAST_DAYS = 3650;
    private final LocalDateTime now = LocalDateTime.now();
    private final TaskRepository tasks = mock(TaskRepository.class);
    private final TaskTimelineService timeline = mock(TaskTimelineService.class);
    private final RoadmapStore roadmap = mock(RoadmapStore.class);
    private DeliverService service;

    @BeforeEach
    void setUp() {
        OrganizationService organization = mock(OrganizationService.class);
        when(organization.userManageProjectsMembers("u")).thenReturn(Mono.just(new ProjectsMembers(List.of("p"), List.of())));
        when(timeline.phaseOf(any())).thenAnswer(it -> phase(it.getArgument(0)));
        when(roadmap.quarters()).thenReturn(Map.of());
        when(roadmap.technical()).thenReturn(Map.of());
        service = new DeliverService(organization, tasks, mock(CommitRepository.class), timeline, roadmap);
    }

    @Test
    void itemsInTestCountTowardsProgress() {
        // the pace of the last 3 weeks (2 items moved from in progress) finishes in about 7 weeks, before the due date
        EpicSummary epic = epic(now.toLocalDate().minusDays(20), now.toLocalDate().plusDays(60),
                story("S-1", "LIVE"), story("S-2", "IN TEST"), story("S-3", "TO DO"), story("S-4", "TO DO"));
        assertEquals(42, epic.progressPct()); // (1 + 0.7) / 4 = 42.5
        assertEquals(25, epic.expectedPct());
        assertEquals(25, epic.breakdown().live());
        assertEquals(25, epic.breakdown().test());
        assertEquals(Health.ON_TRACK, epic.health());
    }

    @Test
    void pastDueIsOffTrack() {
        EpicSummary epic = epic(now.toLocalDate().minusDays(40), now.toLocalDate().minusDays(3),
                story("S-1", "LIVE"), story("S-2", "IN PROGRESS"));
        assertEquals(Health.OFF_TRACK, epic.health());
        assertTrue(epic.delayDays() >= 3);
    }

    @Test
    void farBehindThePlanIsOffTrack() {
        EpicSummary epic = epic(now.toLocalDate().minusDays(80), now.toLocalDate().plusDays(20),
                story("S-1", "IN PROGRESS"), story("S-2", "TO DO"), story("S-3", "TO DO"));
        assertEquals(Health.OFF_TRACK, epic.health());
    }

    @Test
    void blockedItemIsAtRisk() {
        EpicSummary epic = epic(null, null, story("S-1", "ON HOLD"), story("S-2", "IN PROGRESS"));
        assertEquals(Health.AT_RISK, epic.health());
        assertTrue(epic.signals().contains("BLOCKED"));
        assertEquals("BLOCKED", epic.delayReason());
    }

    @Test
    void allItemsLiveIsDelivered() {
        EpicSummary epic = epic(null, now.toLocalDate().plusDays(5), story("S-1", "LIVE"), story("S-2", "LIVE"));
        assertEquals(Health.DELIVERED, epic.health());
        assertEquals(100, epic.progressPct());
    }

    @Test
    void cancelledItemsAreLeftOut() {
        EpicSummary epic = epic(null, null, story("S-1", "LIVE"), story("S-2", "CANCELLED"));
        assertEquals(1, epic.items());
        assertEquals(Health.DELIVERED, epic.health());
    }

    @Test
    void noMovementInThePaceWindowDoesNotOverflowTheForecast() {
        // nothing moved in the last 3 weeks: the two sums of the progress differ only by rounding (was a 500)
        EpicSummary epic = epic(null, now.toLocalDate().plusDays(30), movedLongAgo("S-1", "LIVE"), movedLongAgo("S-2", "LIVE"),
                movedLongAgo("S-3", "UAT"), movedLongAgo("S-4", "IN PROGRESS"));
        assertTrue(epic.deliveryForecast());
        assertTrue(epic.deliveryDate().isBefore(now.toLocalDate().plusDays(MAX_FORECAST_DAYS + 1)));
    }

    @Test
    void burnupCountsScopeAndDone() {
        TaskEntity open = task("S-1", "Story", "TO DO", now.minusDays(30), List.of());
        TaskEntity done = task("S-2", "Story", "LIVE", now.minusDays(30), List.of(
                new History("status", "TO DO", "IN PROGRESS", now.minusDays(20), null),
                new History("status", "IN PROGRESS", "LIVE", now.minusDays(2), null)));
        TaskEntity cancelled = task("S-3", "Story", "CANCELLED", now.minusDays(10), List.of());
        when(tasks.findByProjectIdInAndUpdatedAfter(anyCollection(), any())).thenReturn(List.of(done, cancelled));
        when(tasks.findByProjectIdInAndStatusIn(anyCollection(), anyCollection())).thenReturn(List.of(open));
        Burnup burnup = service.burnup("u", 4).block();
        assertEquals(4, burnup.weeks().size());
        assertEquals(2, burnup.scopeItems());
        assertEquals(1, burnup.doneItems());
        assertEquals(new BigDecimal("6"), burnup.scopePoints());
        assertEquals(new BigDecimal("3"), burnup.donePoints());
    }

    private EpicSummary epic(LocalDate start, LocalDate due, TaskEntity... stories) {
        TaskEntity epic = task("E-1", "Epic", "IN PROGRESS", now.minusDays(90), List.of(
                new History("status", "TO DO", "IN PROGRESS", now.minusDays(60), null)), start, due);
        when(tasks.findByProjectIdInAndTypeIgnoreCase(anyCollection(), eq("Epic"))).thenReturn(List.of(epic));
        when(tasks.findByParentKeyIn(List.of("E-1"))).thenReturn(List.of(stories));
        return service.epics("u", null).block().epics().getFirst();
    }

    /** A story under E-1 with 3 story points, moved into its status 2 days ago (from TO DO 30 days ago). */
    private TaskEntity story(String key, String status) {
        List<History> changes = new ArrayList<>();
        if (!"TO DO".equals(status)) {
            changes.add(new History("status", "TO DO", "IN PROGRESS", now.minusDays(30), null));
            changes.add(new History("status", "IN PROGRESS", status, now.minusDays(2), null));
        }
        TaskEntity entity = task(key, "Story", status, now.minusDays(40), changes);
        entity.setParentKey("E-1");
        return entity;
    }

    /** A story under E-1 with 3 story points, moved into its status 25 days ago (before the forecast pace window). */
    private TaskEntity movedLongAgo(String key, String status) {
        TaskEntity entity = task(key, "Story", status, now.minusDays(40), List.of(
                new History("status", "TO DO", "IN PROGRESS", now.minusDays(30), null),
                new History("status", "IN PROGRESS", status, now.minusDays(25), null)));
        entity.setParentKey("E-1");
        return entity;
    }

    private TaskEntity task(String key, String type, String status, LocalDateTime created, List<History> changes) {
        return task(key, type, status, created, changes, null, null);
    }

    private TaskEntity task(String key, String type, String status, LocalDateTime created, List<History> changes,
                            LocalDate start, LocalDate due) {
        Task content = new Task("p", key, null, null, type, null, null, null, null, null, status, List.of(), key, List.of(),
                "Epic".equals(type) ? null : new BigDecimal("3"), created, created, changes, List.of(), start, due,
                List.of(), List.of(), null);
        TaskEntity entity = new TaskEntity();
        entity.setProjectId("p");
        entity.setKey(key);
        entity.setType(type);
        entity.setCreated(created);
        entity.setUpdated(changes.isEmpty() ? created : changes.getLast().created());
        entity.setContent(content);
        return entity;
    }

    /** The default phase rules of the task timeline. */
    private static Phase phase(String status) {
        String s = status == null ? "" : status.toUpperCase();
        if (s.contains("DONE") || s.contains("LIVE")) return Phase.DONE;
        if (s.contains("TEST") || s.contains("UAT")) return Phase.TEST;
        if (s.contains("PROGRESS")) return Phase.CODING;
        return Phase.BACKLOG;
    }
}
