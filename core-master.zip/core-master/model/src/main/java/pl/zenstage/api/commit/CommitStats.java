package pl.zenstage.api.commit;

public record CommitStats(
    Integer additions,
    Integer deletions,
    Integer total
) {}
