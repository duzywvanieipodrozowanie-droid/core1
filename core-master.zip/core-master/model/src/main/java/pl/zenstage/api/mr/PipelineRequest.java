package pl.zenstage.api.mr;

import java.time.Instant;

public record PipelineRequest(
        String id,
        String project,
        String module,
        String commitSha,
        String ref,
        String status,
        String source,
        Instant createdAt,
        Instant updatedAt
) {
}
