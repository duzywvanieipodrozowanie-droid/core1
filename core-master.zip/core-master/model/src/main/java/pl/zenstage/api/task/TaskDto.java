package pl.zenstage.api.task;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

public record TaskDto(
        String projectId,
        String key,
        String parentKey,
        String url,
        String type,
        String priority,
        String assignee,
        String creator,
        TaskStatus status,
        List<String> labels,
        String summary,
        List<String> text,
        BigDecimal estimate,
        LocalDateTime updated,
        LocalDateTime created,
        List<History> histories,
        List<Sprint> sprints,
        List<TaskDto> tasks
) {
    public static TaskDto map(Task task) {
        if (task == null) return null;
        return new TaskDto(
                task.projectId(),
                task.key(),
                task.parentKey(),
                task.url(),
                task.type(),
                task.priority(),
                task.assignee().displayName(),
                task.creator().displayName(),
                TaskStatus.fromJiraName(task.status().toUpperCase()),
                task.labels(),
                task.summary(),
                task.text(),
                task.estimate(),
                task.updated(),
                task.created(),
                task.histories(),
                task.sprints(),
                null
        );
    }

    public static TaskDto map(Task task, List<TaskDto> children) {
        if (task == null) return null;
        return new TaskDto(
                task.projectId(),
                task.key(),
                task.parentKey(),
                task.url(),
                task.type(),
                task.priority(),
                task.assignee().displayName(),
                task.creator().displayName(),
                TaskStatus.fromJiraName(task.status().toUpperCase()),
                task.labels(),
                task.summary(),
                task.text(),
                task.estimate(),
                task.updated(),
                task.created(),
                task.histories(),
                task.sprints(),
                children
        );
    }

    public static List<TaskDto> mapAll(Collection<Task> tasks) {
        if (tasks == null) return List.of();
        return tasks.stream().filter(Objects::nonNull).map(TaskDto::map).toList();
    }

}
