package pl.zenstage.api.mr;

import java.time.Instant;

/**
 * One approval of a merge request: approver e-mail (or GitLab login when the e-mail is not visible) and when it happened.
 */
public record Approval(
        String email,
        Instant approvedAt
) {
}
