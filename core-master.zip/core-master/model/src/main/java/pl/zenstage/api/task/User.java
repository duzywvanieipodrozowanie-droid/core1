package pl.zenstage.api.task;

public record User(
        String accountId,
        String displayName
) {
}

