package pl.zenstage.api.commit.zs;

import java.math.BigDecimal;
import java.util.Map;

public record ZsSonarStats(
        Integer newBugs,
        Integer newDuplicatedBlocks,
        Integer newCodeSmells,
        Integer newTechnicalDebt,
        Integer newViolations,
        Integer newReliabilityRemediationEffort,
        BigDecimal newDevelopmentCost,
        BigDecimal newReliabilityRating,
        BigDecimal newSecurityRating,
        BigDecimal newMaintainabilityRating,
        BigDecimal newDuplicatedLinesDensity,
        BigDecimal newSecurityReviewRating,
        BigDecimal newCoverage,
        Integer complexity,
        Integer cognitiveComplexity,
        Map<String, Object> source
) {
}
