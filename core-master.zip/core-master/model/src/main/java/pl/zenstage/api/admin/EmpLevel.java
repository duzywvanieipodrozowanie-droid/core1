package pl.zenstage.api.admin;

public enum EmpLevel {
    JUNIOR("Junior / Beginner", 1),
    REGULAR("Mid / Intermediate", 2),
    SENIOR("Senior / Advanced", 3),
    LEAD("Lead / Expert", 4);

    private final String label;
    private final int levelOrder;

    EmpLevel(String label, int levelOrder) {
        this.label = label;
        this.levelOrder = levelOrder;
    }

    public String getLabel() {
        return label;
    }

    public int getLevelOrder() {
        return levelOrder;
    }
}
