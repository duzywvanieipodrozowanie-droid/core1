package pl.zenstage.api.task;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;
import com.fasterxml.jackson.annotation.JsonValue;

public enum TaskStatus {
    READY_TO_START("READY TO START"),
    TODO("TO DO"),
    ANALYSIS("ANALYSIS"),
    IN_PROGRESS("IN PROGRESS"),
    IN_REVIEW("IN REVIEW"),
    DONE("DONE"),
    REFINEMENT("REFINEMENT"),
    READY_FOR_DEVELOPMENT("READY FOR DEVELOPMENT"),
    DEVELOPED("DEVELOPED"),
    IN_TEST("IN TEST"),
    TO_TEST("TO TEST"),
    TESTED("TESTED"),
    UAT("UAT"),
    IN_UAT("IN UAT"),
    LIVE("LIVE"),
    CANCELLED("CANCELLED"),
    ON_HOLD_BLOCKED("ON HOLD/BLOCKED"),
    ON_HOLD("ON HOLD"),
    OPEN("OPEN"),
    BLOCKED("BLOCKED"),
    COMPLETED("COMPLETED"),
    REJECTED("REJECTED"),
    DISCOVERY("DISCOVERY"),
    PO_ACCEPTANCE("PO ACCEPTANCE"),

    @JsonEnumDefaultValue
    UNKNOWN("UNKNOWN");

    private final String jiraName;

    TaskStatus(String jiraName) {
        this.jiraName = jiraName;
    }

    @JsonValue
    public String getJiraName() {
        return jiraName;
    }

    public static TaskStatus fromJiraName(String name) {
        for (TaskStatus status : values()) {
            if (status.jiraName.equalsIgnoreCase(name)) {
                return status;
            }
        }
        return UNKNOWN;
    }
}
