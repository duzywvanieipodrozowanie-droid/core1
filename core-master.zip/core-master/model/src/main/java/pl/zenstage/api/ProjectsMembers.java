package pl.zenstage.api;

import java.util.List;

public record ProjectsMembers(List<String> projects, List<String> members) {
}
