package pl.zenstage.api.project;

import java.util.List;

public record ProjectDto(
        String id,
        String label,
        String taskRegex,
        List<String> envs,
        List<String> priorityModules
) {
}
