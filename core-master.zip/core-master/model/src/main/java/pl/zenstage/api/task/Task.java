package pl.zenstage.api.task;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public record Task(
        String projectId,
        String key,
        String parentKey,
        String url,
        String type,
        Boolean bau,
        Boolean technical,
        String priority,
        User assignee,
        User creator,
        String status,
        List<String> labels,
        String summary,
        List<String> text,
        BigDecimal estimate,
        LocalDateTime updated,
        LocalDateTime created,
        List<History> histories,
        List<Sprint> sprints,
        // planned dates from Jira ("Start date" field and "Due date"); null for older imports
        LocalDate startDate,
        LocalDate dueDate,
        // Jira issue links (e.g. a release task "contains" the deployed issues) and Fix Version/s; null for older imports
        List<Link> links,
        List<String> fixVersions,
        // the parent issue as Jira gives it with the task (an epic's initiative in SAP, also without access to its project); null for older imports
        Parent parent
) {
    public record Parent(
            String key,
            String summary,
            String status,
            String type,
            // display name of the person the parent is assigned to; null for older imports
            String assignee
    ) {
    }

    /** A Jira issue link seen from this task: {@code relation} is the link's outward or inward description. */
    public record Link(
            String type,
            String relation,
            String key,
            String summary,
            String status
    ) {
    }

    public record User(
            String accountId,
            String displayName
    ) {
    }
}
