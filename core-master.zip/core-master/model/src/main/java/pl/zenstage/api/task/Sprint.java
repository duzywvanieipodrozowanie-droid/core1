package pl.zenstage.api.task;

import java.time.LocalDateTime;
import java.util.List;

public record Sprint(
        Integer originalId,
        String state,
        String name,
        String goal,
        LocalDateTime startDate,
        LocalDateTime endDate
) {
}
