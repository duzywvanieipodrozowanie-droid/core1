package pl.zenstage.api.admin;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum EmpSkill {
    // Web & Fullstack
    JAVASCRIPT("JavaScript"),
    TYPESCRIPT("TypeScript"),
    HTML_CSS("HTML/CSS"),
    PHP("PHP"),
    RUBY("Ruby"),

    // Enterprise & Backend
    JAVA("Java"),
    CSHARP("C#"),
    KOTLIN("Kotlin"),
    SCALA("Scala"),

    // Systems & Cloud
    C("C"),
    CPP("C++"),
    RUST("Rust"),
    GO("Go"),

    // Data Science, AI & Scripting
    PYTHON("Python"),
    R("R"),
    SQL("SQL"),
    BASH_SHELL("Bash/Shell"),

    // Mobile
    SWIFT("Swift"),
    DART("Dart"),

    // Frameworks
    ANGULAR("Angular"),
    REACT("React"),

    // Inne
    OTHER("Other");

    private final String displayName;

    EmpSkill(String displayName) {
        this.displayName = displayName;
    }

    @JsonValue
    public String getDisplayName() {
        return displayName;
    }

    @JsonCreator
    public static EmpSkill fromString(String value) {
        if (value == null || value.isBlank()) {
            return OTHER;
        }

        for (EmpSkill lang : values()) {
            if (lang.name().equalsIgnoreCase(value)
                    || lang.displayName.equalsIgnoreCase(value)) {
                return lang;
            }
        }

        if (value.equalsIgnoreCase("c#") || value.equalsIgnoreCase("csharp")) {
            return CSHARP;
        }
        if (value.equalsIgnoreCase("c++") || value.equalsIgnoreCase("cpp")) {
            return CPP;
        }

        return OTHER;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
