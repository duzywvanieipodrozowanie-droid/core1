package pl.zenstage.api.mr;

import java.time.Instant;
import java.util.List;

public record MergeRequest(
        String project,
        String module,
        String mergeCommitSha,
        String id,
        Instant createdAt,
        Instant updatedAt,
        Instant mergedAt,
        Instant closedAt,
        String state,
        String authorEmail,
        Instant approvedAt,
        List<String> approverEmails,
        // number of non-system comments (GitLab user_notes_count); null for older imports
        Integer userNotesCount,
        // number of changed files (GitLab changes_count); null for older imports
        Integer changesCount,
        // MR title and target branch; null for older imports
        String title,
        String targetBranch,
        // whether the target branch is protected in GitLab at import time; null for older imports
        Boolean targetBranchProtected,
        // every approval with its time (approvedAt above = the earliest one); null for older imports
        List<Approval> approvals,
        // date of the oldest commit of the MR (survives squash merges); null for older imports
        Instant firstCommitAt,
        // commits of the MR, oldest first; null for older imports
        List<MrCommit> commits
) {
}
