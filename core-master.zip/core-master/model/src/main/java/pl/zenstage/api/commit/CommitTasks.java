package pl.zenstage.api.commit;

import java.util.HashSet;
import java.util.Set;

public record CommitTasks(
        Set<String> tasks
) {
    public CommitTasks() {
        this(new HashSet<>());
    }
}
