package pl.zenstage.api.commit;

import pl.zenstage.api.commit.zs.ZsSonarStats;

@Deprecated
public record SonarScan(
        String project,
        String module,
        String commitId,
        ZsSonarStats original
) {
}
