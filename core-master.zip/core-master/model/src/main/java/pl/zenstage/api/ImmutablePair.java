package pl.zenstage.api;

import java.util.Map;

public record ImmutablePair<K, V>(
        K key,
        V value
) implements Map.Entry<K, V> {
    @Override
    public K getKey() {
        return key;
    }

    @Override
    public V getValue() {
        return value;
    }

    @Override
    public V setValue(V value) {
        throw new UnsupportedOperationException();
    }
}
