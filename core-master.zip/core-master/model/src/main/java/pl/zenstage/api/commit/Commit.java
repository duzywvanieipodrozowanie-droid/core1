package pl.zenstage.api.commit;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

public record Commit(
        String id,
        String project,
        String module,
        boolean masterBranch,
        String title,
        String authorName,
        String authorEmail,
        String committerName,
        String committerEmail,
        OffsetDateTime committedDate,
        OffsetDateTime createdAt,
        String message,
        List<String> parentIds,
        CommitStats stats,
        // changed lines (additions + deletions) per language, from the commit diff; null for older imports
        Map<String, Integer> languages,
        // added lines per code file (path -> lines), from the commit diff; null for older imports
        Map<String, Integer> files
) {
    public boolean mergeCommit() {
        boolean multiParents = parentIds != null && parentIds.size() > 1;
        return multiParents || masterBranch;
    }
}
