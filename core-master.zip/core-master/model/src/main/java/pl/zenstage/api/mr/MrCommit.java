package pl.zenstage.api.mr;

import java.time.Instant;

/**
 * One commit of a merge request (GitLab /merge_requests/:iid/commits).
 */
public record MrCommit(
        String id,
        String title,
        String authorName,
        Instant committedAt
) {
}
