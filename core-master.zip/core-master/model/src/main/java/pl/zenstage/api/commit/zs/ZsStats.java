package pl.zenstage.api.commit.zs;

import pl.zenstage.api.commit.CommitStats;
import pl.zenstage.api.commit.SonarScan;

import java.util.Optional;

public record ZsStats(
        int additions,
        int deletions,
        int total,
        ZsSonarStats sonar
) {

    public static ZsStats create(
            CommitStats stats,
            SonarScan sonar
    ) {
        if (stats == null || stats.additions() == null || stats.deletions() == null || stats.total() == null) {
            return null;
        }
        return new ZsStats(
                stats.additions(),
                stats.deletions(),
                stats.total(),
                Optional.ofNullable(sonar).map(SonarScan::original).orElse(null)
        );
    }
}

