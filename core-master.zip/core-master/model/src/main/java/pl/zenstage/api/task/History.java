package pl.zenstage.api.task;

import java.time.LocalDateTime;

public record History(
        String fieldType,
        String from,
        String to,
        LocalDateTime created,
        User author
) {
}
