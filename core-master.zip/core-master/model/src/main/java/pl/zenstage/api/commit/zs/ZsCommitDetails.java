package pl.zenstage.api.commit.zs;

import pl.zenstage.api.commit.Commit;
import pl.zenstage.api.commit.SonarScan;

import java.time.OffsetDateTime;

public record ZsCommitDetails(
        String zsProjectName,
        Commit commit,
        ZsStats stats
) {
    public ZsCommitDetails(
            String zsProjectName,
            Commit commit,
            SonarScan stats) {
        this(
                zsProjectName,
                commit,
                ZsStats.create(commit.stats(), stats)
        );
    }
}
