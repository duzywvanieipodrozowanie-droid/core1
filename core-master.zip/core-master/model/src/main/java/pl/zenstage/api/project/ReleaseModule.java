package pl.zenstage.api.project;

public record ReleaseModule(
        String module,
        String image,
        String version
) {
}
